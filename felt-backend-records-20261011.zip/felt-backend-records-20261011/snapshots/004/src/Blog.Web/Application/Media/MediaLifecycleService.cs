using System.Text.Json;
using Blog.Web.Application.Administration;
using Blog.Web.Application.Security;
using Blog.Web.Domain.Persistence;
using Microsoft.Extensions.Primitives;

namespace Blog.Web.Application.Media;

public sealed class MediaLifecycleService(IMediaLifecycleStore store, AdminMutationExecutor mutations,
    IMediaLifecycleFiles files, AdminSecurityService security, TimeProvider clock, IConfiguration config)
{
    public Task<MutationResponse> ReferencesAsync(AdminActor actor, Guid id, CancellationToken ct)
    {
        RequireId(id);
        // Hold the same row lock as reference writers across every reference projection.
        // GET takes no state-changing action and emits no audit or idempotency record.
        return mutations.ExecuteWithoutKeyAsync(actor, new(false, media: [id]), async (_, token) =>
        {
            var media = await store.ReadTrackedAsync(id, token) ?? throw new ApiFailure(ProblemCode.NOT_FOUND);
            return new(MutationResponse.Json(200, await store.ReferencesAsync(id, token), Version(media)), null);
        }, ct);
    }

    public async Task<MediaDeletionStatus> ReadDeletionAsync(Guid id, CancellationToken ct)
    {
        RequireId(id);
        var read = await store.ReadDeletionAsync(id, ct) ?? throw new ApiFailure(ProblemCode.NOT_FOUND);
        return MediaDeletionStatus.From(read.Media, read.Job);
    }

    public Task<MutationResponse> TrashAsync(AdminActor actor, Guid id, StringValues ifMatch, Guid key, MediaStateInput input, CancellationToken ct)
        => ChangeStateAsync(actor, id, ifMatch, key, input, restore: false, ct);
    public Task<MutationResponse> RestoreAsync(AdminActor actor, Guid id, StringValues ifMatch, Guid key, MediaStateInput input, CancellationToken ct)
        => ChangeStateAsync(actor, id, ifMatch, key, input, restore: true, ct);

    private Task<MutationResponse> ChangeStateAsync(AdminActor actor, Guid id, StringValues ifMatch, Guid key,
        MediaStateInput input, bool restore, CancellationToken ct)
    {
        RequireId(id);
        return mutations.ExecuteAsync(actor, restore ? "media.restore" : "media.trash", id.ToString("D"), key,
            JsonSerializer.SerializeToElement(input, ApiJson.Options), new(false, media: [id]), async (_, token) =>
        {
            RequireWritable();
            var media = await store.ReadTrackedAsync(id, token) ?? throw new ApiFailure(ProblemCode.NOT_FOUND);
            Version(media).RequireMatch(ifMatch);
            if (media.State != (restore ? MediaState.Trashed : MediaState.Ready)
                || await store.JobTrackedAsync(id, token) is not null) throw new ApiFailure(ProblemCode.STATE_CONFLICT);
            if (restore)
            {
                try
                {
                    if (!await files.VerifyAsync(Identity(media), token)) throw new ApiFailure(ProblemCode.MEDIA_FILE_INVALID);
                }
                catch (MediaLifecycleFileFailure failure)
                { throw new ApiFailure(failure.IsTransient ? ProblemCode.MEDIA_STORAGE_UNAVAILABLE : ProblemCode.MEDIA_FILE_INVALID); }
                catch (Exception error) when (error is IOException or UnauthorizedAccessException)
                { throw new ApiFailure(ProblemCode.MEDIA_STORAGE_UNAVAILABLE); }
            }
            else await RequireUnreferencedAsync(id, token);
            var prior = media.RowVersion;
            media.State = restore ? MediaState.Ready : MediaState.Trashed;
            media.TrashedAt = restore ? null : clock.GetUtcNow();
            media.ErrorCode = null; media.RowVersion = checked(prior + 1);
            return new(MutationResponse.Json(200, MediaLibraryRow.From(media).Status(), Version(media)),
                new(restore ? AuditAction.MediaRestored : AuditAction.MediaTrashed, AuditEntity.Media, id, prior, media.RowVersion,
                    new(FromState: restore ? AuditState.Trashed : AuditState.Ready, ToState: restore ? AuditState.Ready : AuditState.Trashed)));
        }, ct);
    }

    public async Task<MutationResponse> PurgeAsync(AdminActor actor, Guid sessionId, Guid id, StringValues ifMatch,
        Guid key, MediaPurgeInput input, CancellationToken ct)
    {
        RequireId(id);
        await RequireRecentAsync(actor, sessionId, ct);
        return await mutations.ExecuteAsync(actor, "media.purge", id.ToString("D"), key,
            JsonSerializer.SerializeToElement(input, ApiJson.Options), new(false, media: [id]), async (_, token) =>
        {
            RequireWritable();
            var media = await store.ReadTrackedAsync(id, token) ?? throw new ApiFailure(ProblemCode.NOT_FOUND);
            Version(media).RequireMatch(ifMatch);
            if (media.State != MediaState.Trashed) throw new ApiFailure(ProblemCode.STATE_CONFLICT);
            if (input.ConfirmMediaId != id) throw MediaLibraryValidation.Invalid("confirmMediaId");
            // Recheck after waiting for the row lock, in case the ten-minute window expired.
            // Purge replay also requires current recent reauthentication, checked above.
            await RequireRecentAsync(actor, sessionId, token);
            await RequireUnreferencedAsync(id, token);
            Identity(media);
            var job = await store.JobTrackedAsync(id, token);
            if (job is not null && job.State != JobState.Failed) throw new ApiFailure(ProblemCode.STATE_CONFLICT);
            var now = clock.GetUtcNow(); var retry = job is not null;
            if (job is null)
            {
                job = new() { Id = Guid.NewGuid(), MediaId = id, RequestedBy = actor.UserId, State = JobState.Pending, CreatedAt = now, UpdatedAt = now };
                store.Add(job);
            }
            else
            {
                job.State = JobState.Pending; job.AttemptCount = 0; job.LeaseUntil = null; job.LeaseToken = null;
                job.LastError = null; job.RequestedBy = actor.UserId; job.UpdatedAt = now;
            }
            // Keep the media nonpublic and immutable while the durable job owns it. The first
            // physical operation is performed only by a worker after this transaction commits.
            var prior = media.RowVersion; media.RowVersion = checked(prior + 1); media.ErrorCode = null;
            return new(MutationResponse.Json(202, MediaDeletionStatus.From(media, job), Version(media)),
                new(retry ? AuditAction.MediaPurgeRetried : AuditAction.MediaPurgeRequested, AuditEntity.Media, id, prior, media.RowVersion));
        }, ct);
    }

    private async Task RequireUnreferencedAsync(Guid id, CancellationToken ct)
    {
        var references = await store.ReferencesAsync(id, ct);
        if (references.Total != 0) throw new ApiFailure(ProblemCode.REFERENCED, references: references);
    }
    private async Task RequireRecentAsync(AdminActor actor, Guid sessionId, CancellationToken ct)
    {
        var session = await security.ValidateAsync(sessionId, ct);
        if (session is null || session.Identity.Id != actor.UserId) throw new ApiFailure(ProblemCode.SESSION_REQUIRED);
        if (!security.IsRecentlyReauthenticated(session)) throw new ApiFailure(ProblemCode.REAUTH_REQUIRED);
    }
    private void RequireWritable()
    { if (config.GetValue<bool>("Maintenance:ReadOnly")) throw new ApiFailure(ProblemCode.MAINTENANCE_READ_ONLY); }
    private static void RequireId(Guid id) { if (id == Guid.Empty) throw new ApiFailure(ProblemCode.NOT_FOUND); }
    internal static EntityVersion Version(MediaAsset media) => new(ResourceKind.Media, media.Id, media.RowVersion);
    internal static MediaFileIdentity Identity(MediaAsset media)
    {
        if (media.ByteSize is not > 0 || string.IsNullOrEmpty(media.StorageKey) || media.Sha256 is not { Length: 64 }
            || media.Sha256.Any(c => c is not (>= 'a' and <= 'f' or >= '0' and <= '9')))
            throw new ApiFailure(ProblemCode.MEDIA_FILE_INVALID);
        return new(media.Id, media.StorageKey, media.ByteSize.Value, media.Sha256);
    }
}
