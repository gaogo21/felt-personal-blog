using System.Text.Json;
using Blog.Web.Application.Administration;
using Blog.Web.Application.Security;
using Blog.Web.Domain.Persistence;
using Microsoft.Extensions.Primitives;

namespace Blog.Web.Application.Articles;

public sealed class ArticlePurgeService(IArticlePurgeStore store, AdminMutationExecutor mutations,
    AdminSecurityService security, TimeProvider clock, IConfiguration config)
{
    public async Task<MutationResponse> PurgeAsync(AdminActor actor, Guid sessionId, Guid id, StringValues ifMatch,
        Guid key, ArticlePurgeInput input, CancellationToken ct)
    {
        if (id == Guid.Empty) throw new ApiFailure(ProblemCode.NOT_FOUND);
        // Check before entering key lookup, including successful-result replays.
        await RequireRecentAsync(actor, sessionId, ct);
        return await mutations.ExecuteAsync(actor, "article.purge", id.ToString("D"), key,
            JsonSerializer.SerializeToElement(input, ApiJson.Options), new(true, [id]), async (tx, token) =>
        {
            if (config.GetValue<bool>("Maintenance:ReadOnly")) throw new ApiFailure(ProblemCode.MAINTENANCE_READ_ONLY);
            var read = await store.ReadAsync(id, token) ?? throw new ApiFailure(ProblemCode.NOT_FOUND);
            var article = read.Article;
            AdminArticleService.Version(article).RequireMatch(ifMatch);
            if (article.State != ArticleState.Trashed) throw new ApiFailure(ProblemCode.STATE_CONFLICT);
            if (!string.Equals(input.ConfirmSlug, article.Slug, StringComparison.Ordinal))
                throw ArticleInput.Invalid("confirmSlug");
            if (read.Draft is null || article.PublishedRevisionId is not null || read.Published is not null)
                throw new ApiFailure(ProblemCode.STATE_CONFLICT);

            var dependencies = await store.DependenciesAsync(id, token);
            if (dependencies.RevisionCount < 0 || dependencies.HasPublicMembership)
                throw new ApiFailure(ProblemCode.STATE_CONFLICT);
            await tx.LockAsync(new(false, columns: dependencies.ColumnIds, media: dependencies.MediaIds), token);
            // Recheck after every potentially blocking business lock. A request
            // that waited past the ten-minute window must not remove any content.
            await RequireRecentAsync(actor, sessionId, token);

            var previousVersion = article.RowVersion;
            article.State = ArticleState.Purged;
            article.PublishedRevisionId = null;
            article.PurgedAt = clock.GetUtcNow();
            article.RowVersion = checked(previousVersion + 1);
            read.Draft.BasePublishedRevisionId = null;
            await store.DeleteContentAsync(id, dependencies.RevisionCount, token);
            var tombstone = AdminArticleService.View(new(article, null, null));
            return new(MutationResponse.Json(200, tombstone, AdminArticleService.Version(article)),
                new(AuditAction.ArticlePurged, AuditEntity.Article, id, previousVersion, article.RowVersion,
                    new(ItemCount: dependencies.RevisionCount, FromState: AuditState.Trashed, ToState: AuditState.Purged)));
        }, ct, token => RequireRecentAsync(actor, sessionId, token));
    }

    private async Task RequireRecentAsync(AdminActor actor, Guid sessionId, CancellationToken ct)
    {
        var session = await security.ValidateAsync(sessionId, ct);
        if (session is null || session.Identity.Id != actor.UserId) throw new ApiFailure(ProblemCode.SESSION_REQUIRED);
        if (!security.IsRecentlyReauthenticated(session)) throw new ApiFailure(ProblemCode.REAUTH_REQUIRED);
    }
}
