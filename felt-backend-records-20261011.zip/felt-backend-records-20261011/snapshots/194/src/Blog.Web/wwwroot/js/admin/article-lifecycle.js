const states = { Draft: '草稿', Published: '已发布', Withdrawn: '已撤回', Trashed: '回收站', Purged: '已清空' };
const actions = { withdraw: '撤回发布', trash: '移入回收站', restore: '恢复为草稿', revision: '恢复历史到工作草稿', purge: '永久清空文章' };
const uuid = value => typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
const positive = value => Number.isSafeInteger(value) && value > 0;
const clone = value => JSON.parse(JSON.stringify(value));
const editableState = state => ['Draft', 'Published', 'Withdrawn'].includes(state);
const allowed = (state, action) => action === 'withdraw' ? state === 'Published'
  : action === 'trash' || action === 'revision' ? editableState(state) : ['restore', 'purge'].includes(action) && state === 'Trashed';

/** A separate page owns explicit lifecycle commands. It never edits or autosaves content. */
export function createArticleLifecycleAdmin(root, { fetchImpl = globalThis.fetch, reloadPage = () => location.reload(), now = () => Date.now() } = {}) {
  const abort = new AbortController(), events = { signal: abort.signal }, $ = selector => root.querySelector(selector);
  const id = root.dataset.articleId?.toLowerCase(), path = `/articles/${id}`, pageSize = 20;
  let disposed = false, epoch = 0, readSerial = 0, historySerial = 0;
  let readBusy = false, historyBusy = false, writeBusy = false, pause = null;
  let server = null, fresh = null, history = null, selected = null, intent = null, confirmation = null;
  let attempt = null, retryAllowed = false, observedArticleVersion = 0, observedDraftVersion = 0;
  let authOwner = null, writeOwner = null, purgedObserved = false;
  const request = (endpoint, options = {}) => fetchImpl(`/api/admin/v1${endpoint}`, {
    credentials: 'same-origin', cache: 'no-store', signal: abort.signal, ...options,
  });
  const pending = () => Boolean(attempt || intent || writeBusy || authOwner);
  const ready = () => !disposed && server && !purgedObserved && !pause && !readBusy && !writeBusy && !authOwner && !attempt && !intent;
  const recentlyAuthenticated = operation => operation?.reauthenticatedAt != null
    && now() >= operation.reauthenticatedAt && now() - operation.reauthenticatedAt < 10 * 60 * 1000;
  const exactSlug = operation => $('[data-confirm-slug]').value === operation?.slug;
  function clearSecret() { $('[data-password]').value = ''; }
  function clearAuthenticationOwner() {
    if (authOwner) authOwner.password = '';
    authOwner = null; clearSecret();
  }
  function invalidateAuthentication() {
    clearAuthenticationOwner();
    if (intent) intent.reauthenticatedAt = null;
    if (attempt) attempt.reauthenticatedAt = null;
  }
  const same = (left, right) => left.article.articleEtag === right.article.articleEtag
    && left.article.draftEtag === right.article.draftEtag && left.draft?.contentHash === right.draft?.contentHash;
  const title = snapshot => snapshot?.draft?.title || snapshot?.article.published?.title || snapshot?.article.slug || '未命名文章';
  function say(state, text) {
    if (disposed) return;
    root.dataset.state = state; $('[data-status]').textContent = text;
  }
  function advance() {
    epoch++; historySerial++; historyBusy = false; clearAuthenticationOwner();
  }
  function validArticle(value, response) {
    return value?.id === id && typeof value.slug === 'string' && Object.hasOwn(states, value.state)
      && positive(value.articleVersion) && value.articleEtag === `"a-${id}-${value.articleVersion}"`
      && response.headers?.get('ETag') === value.articleEtag
      && (value.state === 'Purged' ? value.draftVersion === null && value.draftEtag === null && value.published === null
        : positive(value.draftVersion) && value.draftEtag === `"d-${id}-${value.draftVersion}"`)
      && (value.state !== 'Published' || value.published && uuid(value.published.revisionId)
        && positive(value.published.revisionNo) && typeof value.published.title === 'string');
  }
  function validDraft(value, response) {
    return value?.articleId === id && positive(value.draftVersion)
      && value.draftEtag === `"d-${id}-${value.draftVersion}"` && response.headers?.get('ETag') === value.draftEtag
      && typeof value.title === 'string' && typeof value.summary === 'string'
      && typeof value.contentHash === 'string' && value.contentHash.length > 0
      && typeof value.updatedAt === 'string' && !Number.isNaN(new Date(value.updatedAt).getTime())
      && (value.basePublishedRevisionId === null || uuid(value.basePublishedRevisionId));
  }
  function observe(value) {
    if (value.article.articleVersion < observedArticleVersion || purgedObserved && value.article.state !== 'Purged' || value.article.state !== 'Purged'
      && value.draft.draftVersion < observedDraftVersion) throw new Error('A stale snapshot cannot replace a newer observation.');
    observedArticleVersion = value.article.articleVersion;
    if (value.draft) observedDraftVersion = value.draft.draftVersion;
    if (value.article.state === 'Purged') markPurged();
  }
  function markPurged() {
    purgedObserved = true; selected = null; history = null;
    $('[data-history-list]').replaceChildren(); $('[data-history-page]').textContent = '';
    $('[data-selected]').textContent = '已永久清空，没有可恢复的历史。';
    $('[data-identity]').textContent = `文章已永久清空 · ${server?.article.slug || id}`;
    $('[data-publication]').textContent = '只保留标识、地址墓碑和审计；草稿及历史已删除，无法恢复。共享媒体文件未删除。';
    $('[data-version]').textContent = `文章版本 ${observedArticleVersion} · 工作草稿版本 无`;
  }
  function describe(operation) {
    const name = operation.articleTitle ?? title(server);
    const prefix = `文章「${name}」（${operation.slug || server?.article.slug || id}）：${actions[operation.kind]}。`;
    if (operation.kind === 'withdraw') return `${prefix}确认后立即停止公开，并移除首页精选与公开专栏目录；草稿和历史保留。`;
    if (operation.kind === 'trash') return `${prefix}${operation.state === 'Published' ? '文章会在同一操作中撤回，立即停止公开并移除首页精选与公开专栏目录。' : ''}草稿和历史保留。以后恢复只回到草稿，不会自动公开。`;
    if (operation.kind === 'restore') return `${prefix}仅恢复到未发布草稿；不会重新公开，也不会恢复首页精选或公开目录。`;
    if (operation.kind === 'purge') return `${prefix}此操作无法恢复：删除工作草稿、全部发布历史和文章媒体引用，只保留标识、地址墓碑和审计。共享媒体文件不会删除；该地址仍不能重新使用。`;
    return `${prefix}选中修订 #${operation.revision.revisionNo}「${operation.revision.title}」。这会覆盖服务器上已保存的工作草稿，线上当前版本保持不变；其他编辑标签页必须重新核对，之后仍需预览并明确发布。`;
  }
  function controls() {
    if (disposed) return;
    for (const button of root.querySelectorAll('[data-action]')) {
      button.hidden = !server || purgedObserved || !allowed(server.article.state, button.dataset.action);
      button.disabled = !ready() || !allowed(server?.article.state, button.dataset.action);
    }
    $('[data-restore-revision]').disabled = !ready() || !selected || !allowed(server?.article.state, 'revision');
    $('[data-history-fields]').disabled = !ready() || historyBusy || !editableState(server?.article.state);
    $('[data-history-prev]').disabled = !ready() || historyBusy || !history || history.page <= 1;
    $('[data-history-next]').disabled = !ready() || historyBusy || !history || history.page * history.pageSize >= history.total;
    const purgeSecond = intent?.kind === 'purge' && intent.step === 2 && !attempt;
    const purgeReplay = attempt?.kind === 'purge' && retryAllowed;
    $('[data-draft-link]').hidden = !server || purgedObserved || !editableState(server.article.state);
    $('[data-history-section]').hidden = purgedObserved;
    $('[data-confirmation]').hidden = !intent && !attempt;
    $('[data-purge-fields]').hidden = !purgeSecond && !purgeReplay;
    $('[data-confirm]').disabled = !confirmation || Boolean(pause || attempt || readBusy || writeBusy || authOwner)
      || purgeSecond && (!recentlyAuthenticated(intent) || !exactSlug(intent));
    $('[data-confirm]').textContent = intent?.kind !== 'purge' ? '确认执行' : purgeSecond ? '最终确认：永久清空文章（不可恢复）' : '继续核对永久清空（第一步）';
    $('[data-reauth]').disabled = !purgeSecond && !purgeReplay || Boolean(pause && !purgeReplay || readBusy || writeBusy || authOwner)
      || !exactSlug(attempt || intent) || !window.isSecureContext && location.protocol !== 'https:';
    $('[data-password]').disabled = !purgeSecond && !purgeReplay || Boolean(readBusy || writeBusy || authOwner);
    $('[data-confirm-slug]').disabled = Boolean(attempt || readBusy || writeBusy);
    $('[data-cancel]').disabled = Boolean(attempt);
    $('[data-retry]').hidden = !attempt;
    $('[data-retry]').disabled = !attempt || !retryAllowed || readBusy || writeBusy || Boolean(authOwner)
      || attempt.kind === 'purge' && !recentlyAuthenticated(attempt);
    $('[data-review]').hidden = !fresh;
    $('[data-use-server]').disabled = !fresh || readBusy || writeBusy || Boolean(attempt && !attempt.rejected);
    $('[data-use-server]').textContent = attempt?.rejected ? '放弃已被拒绝的原请求，载入服务器状态' : '载入服务器状态，重新选择操作';
    $('[data-continue]').disabled = !fresh || readBusy || writeBusy || !attempt;
    $('[data-continue]').hidden = !attempt;
    if (attempt || intent) $('[data-confirmation-text]').textContent = describe(attempt || intent)
      + (attempt ? ` 原请求文章版本 ${attempt.articleVersion}${attempt.kind === 'revision' ? `、草稿版本 ${attempt.draftVersion}` : ''}。${writeBusy ? '正在处理，请勿离开。' : '请先读取服务器版本，再明确允许核对原请求。'}`
        : confirmation ? ` 已核对文章版本 ${confirmation.article.articleVersion}、草稿版本 ${confirmation.draft?.draftVersion ?? '无'}。` : '正在核对当前文章和工作草稿版本…');
  }
  function render() {
    if (disposed) return;
    if (server) {
      const a = server.article;
      $('[data-identity]').textContent = `已读取文章：${title(server)} · ${states[a.state]} · ${a.slug}`;
      $('[data-version]').textContent = `文章版本 ${a.articleVersion} · 工作草稿版本 ${a.draftVersion ?? '无'}`;
      $('[data-publication]').textContent = a.published
        ? `线上标题：${a.published.title} · 发布修订 #${a.published.revisionNo}。`
        : a.state === 'Purged' ? '文章已永久清空，只保留标识与地址；没有编辑或恢复操作。' : '当前没有公开版本。';
    }
    $('[data-selected]').textContent = selected ? `已选择修订 #${selected.revisionNo}：${selected.title}` : '尚未选择历史版本。';
    if (purgedObserved) markPurged();
    controls();
  }
  function freeze(reason, text) {
    if (disposed) return;
    pause = pause === 'auth' ? 'auth' : reason;
    advance(); invalidateAuthentication(); fresh = null; confirmation = null; retryAllowed = false;
    if (!attempt) intent = null;
    say(pause, text); controls();
  }
  function fail(response, writing = false) {
    const code = response.status;
    if ([401, 403].includes(code)) freeze('auth', '登录或防伪验证已失效。当前选择和原操作已保留；请在新标签页登录，再读取服务器版本并明确选择如何继续。');
    else if ([409, 412, 428].includes(code)) freeze('conflict', `文章状态或版本已变化（HTTP ${code}）。请读取服务器版本后明确选择；不会自动换用新版本提交。`);
    else if (code === 429) freeze('rate', '请求过于频繁。原操作已保留，请稍后读取服务器版本，再明确选择核对；不会自动重试。');
    else if (writing && code >= 500) freeze('unknown', '操作结果尚未确认。请读取服务器版本，再明确允许核对原操作；不会自动重试或切换目标。');
    else freeze(pause || 'review', `请求未成功（HTTP ${code}）。当前选择已保留，写入仍暂停；请重新读取服务器版本并核对。`);
  }
  async function readValue(endpoint, current, valid) {
    const response = await request(endpoint);
    if (!current()) return null;
    if (!response.ok) { fail(response); return null; }
    const value = await response.json();
    if (!current()) return null;
    if (!valid(value, response)) throw new Error('Invalid response.');
    return value;
  }
  async function snapshot(current) {
    const first = await readValue(path, current, validArticle);
    if (!first || !current()) return null;
    const draft = first.state === 'Purged' ? null : await readValue(`${path}/draft`, current, validDraft);
    if (!current() || first.state !== 'Purged' && !draft) return null;
    const last = await readValue(path, current, validArticle);
    if (!last || !current()) return null;
    if (first.articleEtag !== last.articleEtag || first.draftEtag !== last.draftEtag
      || last.state !== 'Purged' && last.draftEtag !== draft.draftEtag) throw new Error('Article and draft changed during read.');
    return { article: last, draft };
  }
  function stage(value, notice = '') {
    fresh = clone(value); pause ||= 'review'; confirmation = null;
    if (!attempt) intent = null;
    $('[data-server-details]').textContent = `服务器文章「${title(value)}」 · ${states[value.article.state]} · 文章版本 ${value.article.articleVersion} · 草稿版本 ${value.draft?.draftVersion ?? '无'}。${attempt?.rejected
      ? `原请求重放已被服务器明确拒绝（HTTP ${attempt.rejected}）。可以明确放弃继续核对并载入当前状态；不会据此执行新操作。`
      : attempt ? '这次读取不能证明原请求是否执行；需保留原请求标识核对结果。' : '载入只更新本页读取的状态，之后仍需重新选择并确认操作。'}`;
    say(pause, `${notice}${attempt ? '已读取服务器版本。请明确选择“保留原操作，允许核对结果”，然后核对同一请求。' : '已读取服务器版本。请核对后明确载入，重新选择操作。'}`);
    controls();
  }
  function adopt(value) {
    server = clone(value); fresh = null; selected = null; intent = null; confirmation = null;
    pause = null; history = null; invalidateAuthentication(); $('[data-confirm-slug]').value = ''; $('[data-reauth-status]').textContent = '';
    $('[data-history-list]').replaceChildren(); $('[data-history-page]').textContent = '';
    render();
  }
  async function readServer(initial = false, notice = '') {
    if (disposed) return;
    advance(); invalidateAuthentication(); const started = epoch, serial = ++readSerial;
    const current = () => !disposed && started === epoch && serial === readSerial;
    if (attempt?.sent && writeBusy) attempt.uncertain = true;
    fresh = null; confirmation = null; if (!attempt) intent = null;
    retryAllowed = false; readBusy = true;
    if (!initial) pause ||= 'review';
    say(pause || 'loading', `${notice}正在读取文章与工作草稿版本…`); controls();
    let loadHistoryAfter = false;
    try {
      const value = await snapshot(current);
      if (!value || !current()) return;
      observe(value);
      if (writeBusy) { freeze('review', '原操作仍在进行，请等待请求结束后重新读取；当前操作保留，不能执行其他动作。'); return; }
      if (initial && !server && !attempt && !pause) {
        adopt(value); say('ready', '已读取已保存的文章。每项操作都需要单独确认。'); loadHistoryAfter = true;
      } else stage(value, notice);
    } catch {
      if (current()) freeze(pause || 'review', '无法确认一致的文章与草稿版本。当前选择和原操作已保留；请重新读取，写入仍暂停。');
    } finally {
      if (serial === readSerial) { readBusy = false; controls(); if (loadHistoryAfter) void loadHistory(1); }
    }
  }
  function validHistory(value, response, page) {
    return value && value.articleVersion === server.article.articleVersion && value.articleEtag === server.article.articleEtag
      && response.headers?.get('ETag') === value.articleEtag && value.page === page && value.pageSize === pageSize
      && Number.isSafeInteger(value.total) && value.total >= 0 && Array.isArray(value.items)
      && value.items.length <= pageSize && value.items.length <= value.total
      && new Set(value.items.map(item => item.id)).size === value.items.length
      && value.items.every((item, index) => uuid(item.id) && item.articleId === id && positive(item.revisionNo)
        && (!index || value.items[index - 1].revisionNo > item.revisionNo)
        && typeof item.title === 'string' && typeof item.summary === 'string' && uuid(item.columnId)
        && typeof item.createdAt === 'string' && !Number.isNaN(new Date(item.createdAt).getTime())
        && typeof item.isCurrentPublished === 'boolean'
        && item.isCurrentPublished === (server.article.published?.revisionId === item.id));
  }
  async function loadHistory(page) {
    if (!ready() || !positive(page)) return;
    const started = epoch, serial = ++historySerial;
    const current = () => !disposed && started === epoch && serial === historySerial;
    historyBusy = true; selected = null; render(); $('[data-history-status]').textContent = '正在读取历史元数据…';
    try {
      const response = await request(`${path}/revisions?page=${page}&pageSize=${pageSize}`);
      if (!current()) return;
      if (!response.ok) { fail(response); return; }
      const value = await response.json();
      if (!current()) return;
      if (!validHistory(value, response, page)) { freeze('conflict', '历史或文章版本已变化，无法确认这份列表。请读取服务器版本后重新选择。'); return; }
      history = clone(value);
      $('[data-history-list]').replaceChildren(...history.items.map(item => {
        const row = document.createElement('li'), label = document.createElement('label'), input = document.createElement('input');
        input.type = 'radio'; input.name = 'revision'; input.value = item.id; input.dataset.revisionId = item.id;
        const text = document.createElement('span'), heading = document.createElement('strong'), summary = document.createElement('span'), meta = document.createElement('small');
        heading.textContent = `修订 #${item.revisionNo} · ${item.title}${item.isCurrentPublished ? '（当前线上版本）' : ''}`;
        summary.textContent = item.summary; meta.textContent = `保存时间（UTC）：${new Date(item.createdAt).toISOString()} · 专栏：${item.columnId}`;
        text.append(heading, summary, meta); label.append(input, text); row.append(label); return row;
      }));
      $('[data-history-page]').textContent = `第 ${history.page} 页 · 共 ${history.total} 个修订`;
      $('[data-history-status]').textContent = history.total === 0 ? '暂无发布历史。' : server.article.state === 'Trashed'
        ? '历史已保留。请先将回收站文章恢复为草稿，再恢复历史内容。' : server.article.state === 'Purged' ? '已清空文章没有可恢复的历史。' : '请选择修订，再单独确认恢复到工作草稿。';
    } catch {
      if (current()) freeze(pause || 'review', '无法读取完整历史元数据。请读取服务器版本后再试，当前选择不会触发恢复。');
    } finally { if (serial === historySerial) { historyBusy = false; controls(); } }
  }
  async function prepare(kind) {
    if (!ready() || !allowed(server.article.state, kind) || kind === 'revision' && !selected) return;
    const chosen = { kind, state: server.article.state, articleTitle: title(server), slug: server.article.slug,
      revision: selected && clone(selected), step: 1, reauthenticatedAt: null };
    advance(); const started = epoch, serial = ++readSerial;
    const current = () => !disposed && started === epoch && serial === readSerial;
    intent = chosen; confirmation = null; fresh = null; readBusy = true;
    $('[data-confirm-slug]').value = ''; $('[data-reauth-status]').textContent = ''; controls();
    say('checking', '正在核对文章和工作草稿的当前版本，尚未执行操作。');
    try {
      const value = await snapshot(current);
      if (!value || !current()) return;
      observe(value);
      if (!same(value, server)) { pause = 'conflict'; stage(value); return; }
      confirmation = clone(value); say('confirmation', '请核对文章、操作及影响，确认后才会执行。'); controls();
      $('#lifecycle-confirm-title').focus();
    } catch {
      if (current()) freeze(pause || 'review', '无法确认当前版本。尚未执行操作，请重新读取服务器版本。');
    } finally { if (serial === readSerial) { readBusy = false; controls(); } }
  }
  function cancel() {
    if (disposed || attempt || !intent) return;
    advance(); invalidateAuthentication(); readSerial++; readBusy = false; intent = null; confirmation = null;
    $('[data-confirm-slug]').value = ''; $('[data-reauth-status]').textContent = '';
    say('ready', '已取消，未执行文章操作。'); render();
  }
  async function sessionToken(current) {
    const response = await request('/session/bootstrap');
    if (!current()) return null;
    if (!response.ok) { fail(response); return null; }
    const session = await response.json();
    if (!current()) return null;
    if (!session?.session?.user?.id || typeof session.csrfToken !== 'string' || !session.csrfToken) {
      freeze('auth', '无法确认登录和防伪上下文。原操作已保留，请重新登录后读取服务器版本并明确选择。'); return null;
    }
    return session.csrfToken;
  }
  async function reauthenticate(event) {
    event.preventDefault();
    const replay = attempt?.kind === 'purge' && retryAllowed, chosen = replay ? attempt : intent;
    if (disposed || !replay && (intent?.kind !== 'purge' || intent.step !== 2 || attempt || pause || !confirmation)
      || readBusy || writeBusy || authOwner || !exactSlug(chosen)) { clearSecret(); return; }
    if (!window.isSecureContext && location.protocol !== 'https:') {
      clearSecret(); $('[data-reauth-status]').textContent = '密码重验必须使用本站 HTTPS 页面。'; return;
    }
    const owner = { password: $('[data-password]').value }, started = epoch; clearSecret();
    if (!owner.password || owner.password.length > 1024) { owner.password = ''; $('[data-reauth-status]').textContent = '请输入当前密码。'; return; }
    const current = () => !disposed && epoch === started && authOwner === owner
      && (replay ? attempt : intent) === chosen && exactSlug(chosen);
    authOwner = owner; chosen.reauthenticatedAt = null;
    $('[data-reauth-status]').textContent = '正在通过安全会话重验…'; controls();
    try {
      const csrf = await sessionToken(current);
      if (!csrf || !current()) return;
      const pendingResponse = request('/session/reauth', { method: 'POST', headers: {
        'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf,
      }, body: JSON.stringify({ password: owner.password }) });
      owner.password = '';
      const response = await pendingResponse;
      if (!current()) return;
      if (response.status !== 204) { fail(response); return; }
      chosen.reauthenticatedAt = now();
      $('[data-reauth-status]').textContent = replay
        ? '密码已重新验证。请明确核对同一原请求；标识、请求体和原版本保持不变。'
        : '密码已重新验证。请核对完整文章地址，再点击最终确认。';
    } catch {
      if (current()) { chosen.reauthenticatedAt = null; $('[data-reauth-status]').textContent = '未确认密码重验成功，请重新输入后再试。'; }
    } finally {
      owner.password = '';
      // An older cancelled verification must not unlock or clear a newer one.
      if (authOwner === owner) { authOwner = null; controls(); }
    }
  }
  async function execute(retry = false) {
    if (disposed || writeBusy || readBusy || authOwner) return;
    const authenticatedOperation = retry ? attempt : intent;
    if (authenticatedOperation?.kind === 'purge' && (retry || authenticatedOperation.step === 2)
      && !recentlyAuthenticated(authenticatedOperation)) {
      $('[data-reauth-status]').textContent = '请重新验证当前密码，再明确确认清空或核对原请求。'; controls(); return;
    }
    if (retry ? !attempt || !retryAllowed || attempt.kind === 'purge' && !recentlyAuthenticated(attempt)
      : attempt || !confirmation || pause || !intent) return;
    if (!retry && intent.kind === 'purge') {
      if (intent.step === 1) { intent.step = 2; controls(); $('[data-confirm-slug]').focus(); return; }
      if (!recentlyAuthenticated(intent) || !exactSlug(intent)) { controls(); return; }
    }
    if (!retry) {
      const body = intent.kind === 'revision' ? { expectedDraftVersion: confirmation.draft.draftVersion }
        : intent.kind === 'purge' ? { confirmSlug: intent.slug } : {};
      attempt = { ...clone(intent), articleVersion: confirmation.article.articleVersion,
        draftVersion: confirmation.draft?.draftVersion, articleEtag: confirmation.article.articleEtag,
        path: intent.kind === 'revision' ? `${path}/revisions/${intent.revision.id}/restore-to-draft` : `${path}/${intent.kind}`,
        body: JSON.stringify(body), key: crypto.randomUUID(), sent: false, uncertain: false };
    }
    const operation = attempt, owner = {}; operation.rejected = null; advance(); const started = epoch;
    const current = () => !disposed && epoch === started && attempt === operation && writeOwner === owner;
    writeOwner = owner; writeBusy = true; retryAllowed = false; fresh = null; confirmation = null; pause = null;
    say('working', retry ? '正在核对原请求的结果；请求标识、目标和版本保持不变。' : '正在执行已确认的文章操作…'); controls();
    try {
      const csrf = await sessionToken(current);
      if (!csrf || !current()) return;
      if (operation.kind === 'purge' && !recentlyAuthenticated(operation)) {
        freeze('auth', '密码重验已超过 10 分钟，尚未发送本次清空请求。请读取服务器版本、明确继续并重新验证密码。'); return;
      }
      operation.sent = true; operation.reauthenticatedAt = null;
      const response = await request(operation.path, { method: 'POST', headers: {
        'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf,
        'If-Match': operation.articleEtag, 'Idempotency-Key': operation.key,
      }, body: operation.body });
      if (!current()) return;
      if (!response.ok) {
        if (operation.kind === 'purge' && response.status === 403) {
          let problem; try { problem = await response.json(); } catch { problem = {}; }
          if (!current()) return;
          if (problem?.code === 'REAUTH_REQUIRED') {
            freeze('auth', '永久清空需要 10 分钟内的密码重验。原请求已保留；请读取服务器版本、明确继续并重新验证密码。'); return;
          }
        }
        if (response.status >= 500) operation.uncertain = true;
        if (operation.uncertain && [409, 412, 422, 428].includes(response.status)) operation.rejected = response.status;
        if (!operation.uncertain && ![401, 403, 429].includes(response.status) && response.status < 500) { attempt = null; intent = null; }
        fail(response, true); return;
      }
      const result = await response.json();
      if (!current()) return;
      const valid = operation.kind === 'revision'
        ? validDraft(result, response) && result.basePublishedRevisionId === operation.revision.id && result.draftVersion >= operation.draftVersion
        : response.status === 200 && validArticle(result, response)
          && result.state === { withdraw: 'Withdrawn', trash: 'Trashed', restore: 'Draft', purge: 'Purged' }[operation.kind]
          && result.articleVersion > operation.articleVersion
          && (operation.kind === 'purge' ? result.slug === operation.slug : result.draftVersion >= operation.draftVersion);
      if (!valid) throw new Error('Cannot verify mutation result.');
      if (operation.kind === 'purge') {
        observedArticleVersion = Math.max(observedArticleVersion, result.articleVersion);
        markPurged();
      }
      // A replay returns the original result, which may predate an observed server
      // snapshot. Never install mutation responses as the current page baseline.
      attempt = null; intent = null; pause = 'review';
      writeOwner = null; writeBusy = false;
      await readServer(false, `已确认“${actions[operation.kind]}”成功。`);
    } catch {
      if (current()) {
        if (operation.sent) operation.uncertain = true;
        freeze(operation.sent ? 'unknown' : 'review', operation.sent
          ? '操作结果尚未确认。原请求已保留；请读取服务器版本，再明确允许核对原操作，不会自动重试。'
          : '无法确认登录上下文，尚未发送本次请求。原操作已保留，请读取服务器版本后明确选择。');
      }
    } finally {
      if (!disposed && writeOwner === owner) {
        if (attempt === operation && operation.sent && !current()) operation.uncertain = true;
        writeOwner = null; writeBusy = false; controls();
      }
    }
  }
  function chooseServer(continueOperation) {
    if (disposed || !fresh || readBusy || writeBusy || (continueOperation ? !attempt : attempt && !attempt.rejected)) return;
    advance(); const chosen = fresh;
    if (continueOperation) {
      server = clone(chosen); fresh = null; pause = 'pending'; retryAllowed = true;
      if (attempt.kind === 'purge') {
        attempt.reauthenticatedAt = null; $('[data-confirm-slug]').value = attempt.slug;
        $('[data-reauth-status]').textContent = '请重新验证密码，再明确核对保留的同一清空请求。';
      }
      say('pending', `已保留原操作。${attempt.kind === 'purge' ? '请先重新验证密码，再' : '请'}点击“核对上次操作结果”，只会重放同一标识、请求体和原版本；不会执行新目标。`); render();
    } else {
      attempt = null; retryAllowed = false;
      adopt(chosen); say('ready', '已载入服务器状态。请重新选择并确认操作。'); void loadHistory(1);
    }
  }
  root.addEventListener('click', event => {
    const button = event.target.closest('button'); if (!button || button.disabled || !root.contains(button)) return;
    if (button.dataset.action) void prepare(button.dataset.action);
    else if (button.hasAttribute('data-restore-revision')) void prepare('revision');
    else if (button.hasAttribute('data-confirm')) void execute();
    else if (button.hasAttribute('data-cancel')) cancel();
    else if (button.hasAttribute('data-retry')) void execute(true);
    else if (button.hasAttribute('data-reload')) void readServer();
    else if (button.hasAttribute('data-use-server')) chooseServer(false);
    else if (button.hasAttribute('data-continue')) chooseServer(true);
    else if (button.hasAttribute('data-history-prev')) void loadHistory(history.page - 1);
    else if (button.hasAttribute('data-history-next')) void loadHistory(history.page + 1);
  }, events);
  $('[data-reauth-form]').addEventListener('submit', reauthenticate, events);
  $('[data-confirm-slug]').addEventListener('input', () => {
    if (attempt) { $('[data-confirm-slug]').value = attempt.slug; return; }
    invalidateAuthentication(); $('[data-reauth-status]').textContent = '';
    controls();
  }, events);
  const guardNavigation = event => {
    const link = event.target.closest('[data-draft-link],[data-article-list]');
    if (!link || !root.contains(link)) return;
    if (pending() || link.hasAttribute('data-draft-link') && (!server || purgedObserved || !editableState(server.article.state))) {
      event.preventDefault();
      if (pending()) say(pause || 'confirmation', '当前确认或原操作尚未结束。请先取消未提交的确认，或读取服务器版本并核对原请求。');
    }
  };
  root.addEventListener('click', guardNavigation, events);
  root.addEventListener('auxclick', guardNavigation, events);
  root.addEventListener('change', event => {
    const input = event.target.closest('[data-revision-id]');
    if (!input || !ready() || historyBusy || !editableState(server.article.state)
      || !input.checked || !root.contains(input) || !history || history.articleEtag !== server.article.articleEtag) return;
    const item = history.items.find(value => value.id === input.dataset.revisionId);
    if (!item) return;
    selected = clone(item); render();
  }, events);
  window.addEventListener('beforeunload', event => { if (pending()) { event.preventDefault(); event.returnValue = ''; } }, events);
  const restored = event => { if (event.persisted) { window.removeEventListener('pageshow', restored); reloadPage(); } };
  const api = { hasPending: pending, destroy({ preserveRestoreListener = false } = {}) {
    if (!preserveRestoreListener) window.removeEventListener('pageshow', restored);
    if (disposed) return;
    disposed = true; advance(); invalidateAuthentication(); readSerial++; abort.abort();
  } };
  window.addEventListener('pagehide', event => api.destroy({ preserveRestoreListener: event.persisted }), { once: true, signal: abort.signal });
  // BFCache restores a disposed document, so this listener must outlive abort.
  window.addEventListener('pageshow', restored);
  controls();
  if (!uuid(id)) freeze('error', '文章地址无效，不能读取或执行操作。'); else void readServer(true);
  return api;
}

const root = document.querySelector('[data-article-lifecycle]');
if (root) createArticleLifecycleAdmin(root);
