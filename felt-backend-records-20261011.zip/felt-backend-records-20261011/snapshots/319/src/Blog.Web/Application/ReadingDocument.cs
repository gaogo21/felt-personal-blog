using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace Blog.Web.Application;

// A server-created view model, not a JSON DTO and not an editor input schema.
// F09 owns JSON validation, publication HTML and schema-version migration.
// Reserved for F09: no implementation or service registration exists in F03.
// A future projector must validate the versioned JSON before returning these
// encoded-rendering models. Controllers must never bind this interface to input.
public interface IPublishedReadingProjector
{
    IReadOnlyList<ReadingBlock> Project(int schemaVersion, string publishedContentJson);
}

public abstract record ReadingBlock;
public sealed record ReadingParagraph(string Text) : ReadingBlock;
public sealed record ReadingHeading(Guid NodeId, int Level, string Text) : ReadingBlock;
public sealed record ReadingCode(string Text, CodeLanguage Language = CodeLanguage.Plaintext) : ReadingBlock;
public sealed record ReadingQuote(string Text) : ReadingBlock;
public sealed record ReadingList(IReadOnlyList<string> Items, bool Ordered = false) : ReadingBlock;
public sealed record ReadingTable(IReadOnlyList<IReadOnlyList<string>> Rows, bool HasHeader = true) : ReadingBlock;
public sealed record ReadingImageBlock(ReadingImage Image) : ReadingBlock;
public sealed record ReadingVideo(string Src, int Width, int Height, string Caption, string? Poster = null) : ReadingBlock;
public sealed record ReadingImage(string Src, string Alt, int Width, int Height, string Caption = "", string Credit = "", string? SourceUrl = null);
public enum CodeLanguage { Plaintext, Javascript, Typescript, Csharp, Sql, Json, Bash, Html, Css, Python }
public sealed record TocEntry(string Id, int Level, string Text);

public sealed record ReadingPresentation(IReadOnlyList<TocEntry> Toc, string PlainText, int ReadingMinutes)
{
    public static string Anchor(Guid id) => "heading-" + id.ToString("N");
    public static string UtcDate(DateTimeOffset value) => value.ToUniversalTime().ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
    public static string UtcInstant(DateTimeOffset value) => value.ToUniversalTime().ToString("O", CultureInfo.InvariantCulture);

    public static ReadingPresentation Create(ArticleContent article)
    {
        var headings = new List<TocEntry>();
        var ids = new HashSet<Guid>();
        var plain = new List<string>();
        foreach (var block in article.Blocks)
        {
            switch (block)
            {
                case ReadingParagraph p: plain.Add(p.Text); break;
                case ReadingHeading h:
                    if (h.Level is not (2 or 3) || h.NodeId == Guid.Empty || !ids.Add(h.NodeId))
                        throw new InvalidOperationException("Reading heading requires a unique nonempty UUID and H2/H3 level.");
                    headings.Add(new TocEntry(Anchor(h.NodeId), h.Level, h.Text)); plain.Add(h.Text); break;
                case ReadingCode c:
                    if (!Enum.IsDefined(c.Language)) throw new InvalidOperationException("Unknown presentation code language.");
                    plain.Add(c.Text); break;
                case ReadingQuote q: plain.Add(q.Text); break;
                case ReadingList l: plain.AddRange(l.Items); break;
                case ReadingTable t:
                    if (t.Rows.Count is < 1 or > 20 || t.Rows[0].Count is < 1 or > 6 || t.Rows.Any(row => row.Count != t.Rows[0].Count))
                        throw new InvalidOperationException("Presentation table must be rectangular, 1–20 rows and 1–6 columns.");
                    plain.AddRange(t.Rows.SelectMany(row => row)); break;
                case ReadingImageBlock image: ValidateImage(image.Image); plain.Add(image.Image.Caption); break;
                case ReadingVideo video:
                    ValidateMediaPath(video.Src); if (video.Poster is not null) ValidateMediaPath(video.Poster);
                    if (video.Width < 1 || video.Height < 1) throw new InvalidOperationException("Media dimensions are required.");
                    plain.Add(video.Caption); break;
                default: throw new InvalidOperationException("Unknown reading presentation block.");
            }
        }
        if (article.Cover is not null) ValidateImage(article.Cover);
        foreach (var sibling in new[] { article.Previous, article.Next })
            if (sibling is not null && (sibling.ColumnSlug != article.Article.ColumnSlug || sibling.Slug == article.Article.Slug))
                throw new InvalidOperationException("Reading neighbors must belong to this column and never loop to the same article.");
        if (article.RevisedAt is not null && article.RevisedAt < article.Article.FirstPublishedAt)
            throw new InvalidOperationException("Revision time cannot precede first publication.");
        var text = string.Join("\n", plain).Normalize(NormalizationForm.FormC);
        return new ReadingPresentation(headings, text, ReadingTime.FromPlainText(text));
    }

    private static void ValidateImage(ReadingImage image)
    {
        ValidateMediaPath(image.Src);
        if (string.IsNullOrWhiteSpace(image.Alt) || image.Width < 1 || image.Height < 1)
            throw new InvalidOperationException("Reading images need alt text and dimensions.");
        if (image.SourceUrl is not null && (!Uri.TryCreate(image.SourceUrl, UriKind.Absolute, out var url) || url.Scheme != "https" || url.UserInfo.Length != 0 || image.SourceUrl.Any(char.IsControl) || image.SourceUrl.Contains('\\')))
            throw new InvalidOperationException("Image source credit must be a plain HTTPS URL.");
    }
    private static void ValidateMediaPath(string path)
    {
        // Current approved design fixtures or the future controlled media endpoint.
        // Never accept a remote image, scheme-relative URL, traversal or script URL.
        if (!Regex.IsMatch(path, @"^/(assets/[a-zA-Z0-9_/-]+\.(png|webp|jpg|jpeg)|media/[a-fA-F0-9-]{36})$") || path.Contains("//", StringComparison.Ordinal))
            throw new InvalidOperationException("Presentation media requires a controlled local path.");
    }
}

public static class ReadingTime
{
    // Shared pure-text formula. F09 must reuse the same extraction contract rather
    // than calculate a separate editor/client estimate. Metadata/alt are excluded.
    public static int FromPlainText(string text)
    {
        var other = new StringBuilder(); var cjk = 0;
        foreach (var rune in text.EnumerateRunes())
        {
            var n = rune.Value;
            var isCjk = n is >= 0x3400 and <= 0x4DBF or >= 0x4E00 and <= 0x9FFF or >= 0xF900 and <= 0xFAFF
                or >= 0x20000 and <= 0x323AF or >= 0x3040 and <= 0x30FF or >= 0x31F0 and <= 0x31FF
                or >= 0xFF66 and <= 0xFF9D or >= 0xAC00 and <= 0xD7AF or >= 0x1100 and <= 0x11FF
                or >= 0x3130 and <= 0x318F or >= 0xA960 and <= 0xA97F or >= 0xD7B0 and <= 0xD7FF;
            if (isCjk) { cjk++; other.Append(' '); } else other.Append(rune.ToString());
        }
        var words = Regex.Count(other.ToString(), @"[\p{L}\p{N}]+(?:['’][\p{L}\p{N}]+)*");
        return Math.Max(1, (int)Math.Ceiling(cjk / 400d + words / 200d));
    }
}
