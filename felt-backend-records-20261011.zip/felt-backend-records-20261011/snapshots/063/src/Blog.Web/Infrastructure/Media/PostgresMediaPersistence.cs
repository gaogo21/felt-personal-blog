using System.Data;
using Blog.Web.Application.Media;
using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Blog.Web.Infrastructure.Media;

// The global admission lock coordinates quota, upload reservations and job leases across processes.
// All callers acquire it before media rows; callbacks must request media IDs in ascending order.
// No retries here: an uncertain commit is resolved by the caller's original idempotency key.
public sealed class PostgresMediaPersistence(BlogDbContext db) : IMediaPersistence
{
    public const string UploadScope = "media.upload";
    public const long AdmissionLockId = 0x426c6f674d656469; // Fixed "BlogMedi" namespace, independent of runtime hash seeds.

    public async Task<T> ExecuteAsync<T>(Func<IMediaUnitOfWork, CancellationToken, Task<T>> action, CancellationToken ct)
    {
        if (db.Database.CurrentTransaction is not null) throw new InvalidOperationException("NESTED_MEDIA_TRANSACTION");
        if (db.ChangeTracker.Entries().Any()) throw new InvalidOperationException("MEDIA_REQUIRES_FRESH_TRACKER");
        await using var transaction = await db.Database.BeginTransactionAsync(IsolationLevel.ReadCommitted, ct);
        var work = new UnitOfWork(db);
        try
        {
            await db.Database.ExecuteSqlInterpolatedAsync(AdmissionLockCommand(), ct);
            var result = await action(work, ct);
            work.Complete();
            await db.SaveChangesAsync(ct);
            await transaction.CommitAsync(ct);
            return result;
        }
        catch
        {
            await transaction.RollbackAsync(CancellationToken.None);
            throw;
        }
        finally
        {
            work.Close();
            db.ChangeTracker.Clear();
        }
    }

    public Task<MediaAsset?> ReadAsync(Guid id, CancellationToken ct)
        => db.Set<MediaAsset>().AsNoTracking().SingleOrDefaultAsync(x => x.Id == id, ct);

    public static FormattableString AdmissionLockCommand() => $"SELECT pg_advisory_xact_lock({AdmissionLockId})";
    public static FormattableString MediaLockCommand(Guid id) => $"SELECT id FROM media_assets WHERE id = {id} FOR UPDATE";
    public static IQueryable<IdempotencyRecord> KeyQuery(BlogDbContext context, Guid actor, Guid key)
        => context.Set<IdempotencyRecord>().Where(x => x.ActorUserId == actor && x.Scope == UploadScope && x.Key == key);

    // Covers body image/video/poster and cover references without filtering article or column state.
    // Every historical revision remains a reference until an explicit whole-article purge removes it.
    public static IQueryable<Guid> ReferencesQuery(BlogDbContext context, Guid id)
        => context.Set<DraftMediaReference>().Where(x => x.MediaId == id).Select(x => x.MediaId)
            .Concat(context.Set<RevisionMediaReference>().Where(x => x.MediaId == id).Select(x => x.MediaId))
            .Concat(context.Set<ArticleDraft>().Where(x => x.CoverMediaId == id).Select(x => x.CoverMediaId!.Value))
            .Concat(context.Set<ArticleRevision>().Where(x => x.CoverMediaId == id).Select(x => x.CoverMediaId!.Value))
            .Concat(context.Set<ColumnMediaSlot>().Where(x => x.MediaId == id).Select(x => x.MediaId))
            .Concat(context.Set<GallerySlot>().Where(x => x.MediaId == id).Select(x => x.MediaId))
            .Concat(context.Set<DesignAssetSlot>().Where(x => x.MediaId == id).Select(x => x.MediaId));

    private sealed class UnitOfWork(BlogDbContext db) : IMediaUnitOfWork
    {
        private readonly HashSet<Guid> lockedMedia = [];
        private readonly Dictionary<(Guid Actor, Guid Key), IdempotencyRecord> removedKeys = [];
        private readonly Dictionary<Guid, MediaUploadReservation> removedReservations = [];
        private Guid? lastLockedMedia;
        private bool closed;

        private void EnsureActive()
        {
            if (closed || db.Database.CurrentTransaction is null) throw new InvalidOperationException("MEDIA_UNIT_OF_WORK_CLOSED");
        }

        public async Task<MediaAsset?> MediaAsync(Guid id, CancellationToken ct)
        {
            EnsureActive();
            if (!lockedMedia.Contains(id))
            {
                if (lastLockedMedia is { } previous && previous.CompareTo(id) > 0)
                    throw new InvalidOperationException("MEDIA_LOCK_ORDER_INVALID");
                await db.Database.ExecuteSqlInterpolatedAsync(MediaLockCommand(id), ct);
                lockedMedia.Add(id);
                lastLockedMedia = id;
            }
            return await db.Set<MediaAsset>().SingleOrDefaultAsync(x => x.Id == id, ct);
        }

        public Task<MediaUploadReservation?> ReservationAsync(Guid mediaId, CancellationToken ct)
        {
            EnsureActive();
            return db.Set<MediaUploadReservation>().SingleOrDefaultAsync(x => x.MediaId == mediaId, ct);
        }

        public Task<IdempotencyRecord?> KeyAsync(Guid actor, Guid key, CancellationToken ct)
        {
            EnsureActive();
            return KeyQuery(db, actor, key).SingleOrDefaultAsync(ct);
        }

        public async Task<IReadOnlyList<MediaUploadReservation>> ReservationsAsync(CancellationToken ct)
        {
            EnsureActive();
            return await db.Set<MediaUploadReservation>().OrderBy(x => x.MediaId).ToListAsync(ct);
        }

        public async Task<IReadOnlyList<MediaProcessingJob>> JobsAsync(CancellationToken ct)
        {
            EnsureActive();
            return await db.Set<MediaProcessingJob>().OrderBy(x => x.MediaId).ToListAsync(ct);
        }

        public Task<MediaDeletionJob?> DeletionJobAsync(Guid mediaId, CancellationToken ct)
        {
            EnsureActive();
            if (!lockedMedia.Contains(mediaId)) throw new InvalidOperationException("MEDIA_DELETION_CHECK_REQUIRES_ROW_LOCK");
            return db.Set<MediaDeletionJob>().AsNoTracking().SingleOrDefaultAsync(x => x.MediaId == mediaId, ct);
        }

        public Task<bool> HasReferencesAsync(Guid id, CancellationToken ct)
        {
            EnsureActive();
            if (!lockedMedia.Contains(id)) throw new InvalidOperationException("MEDIA_REFERENCE_CHECK_REQUIRES_ROW_LOCK");
            return ReferencesQuery(db, id).AnyAsync(ct);
        }

        public void Add(MediaAsset value) { EnsureActive(); db.Set<MediaAsset>().Add(value); }
        public void Add(MediaProcessingJob value) { EnsureActive(); db.Set<MediaProcessingJob>().Add(value); }
        public void Add(AuditEvent value) { EnsureActive(); db.Set<AuditEvent>().Add(value); }

        public void Add(MediaUploadReservation value)
        {
            EnsureActive();
            if (removedReservations.Remove(value.MediaId, out var previous)) db.Entry(previous).CurrentValues.SetValues(value);
            else db.Set<MediaUploadReservation>().Add(value);
        }

        public void Add(IdempotencyRecord value)
        {
            EnsureActive();
            RequireUploadScope(value);
            if (removedKeys.Remove((value.ActorUserId, value.Key), out var previous)) db.Entry(previous).CurrentValues.SetValues(value);
            else db.Set<IdempotencyRecord>().Add(value);
        }

        public void Remove(MediaUploadReservation value) { EnsureActive(); removedReservations.Add(value.MediaId, value); }
        public void Remove(IdempotencyRecord value)
        {
            EnsureActive();
            RequireUploadScope(value);
            removedKeys.Add((value.ActorUserId, value.Key), value);
        }

        private static void RequireUploadScope(IdempotencyRecord value)
        {
            if (value.Scope != UploadScope) throw new InvalidOperationException("MEDIA_IDEMPOTENCY_SCOPE_INVALID");
        }

        public void Complete()
        {
            EnsureActive();
            db.Set<IdempotencyRecord>().RemoveRange(removedKeys.Values);
            db.Set<MediaUploadReservation>().RemoveRange(removedReservations.Values);
            Close();
        }

        public void Close() => closed = true;
    }
}
