using System.Data.Common;
using Blog.Web.Application.Security;
using Blog.Web.Domain;
using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Persistence;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace Blog.Web.Infrastructure.Security;

public sealed class PostgresAdminSecurityStore(BlogDbContext db, UserManager<AdminUser> users, IPasswordHasher<AdminUser> hasher) : IAdminSecurityStore
{
    private static readonly AdminUser TimingUser = new();
    private static readonly string TimingHash = new PasswordHasher<AdminUser>().HashPassword(TimingUser, Guid.NewGuid().ToString("N"));
    private IQueryable<AdminUser> EligibleUsers => db.Users.Where(u => u.IsEnabled && db.UserRoles.Any(ur => ur.UserId == u.Id && db.Roles.Any(r => r.Id == ur.RoleId && r.NormalizedName == "ADMIN")));
    private static AdminIdentity Identity(AdminUser u) => new(u.Id, u.UserName!, u.SecurityStamp!);
    private static AdminSessionView View(AdminSession s, AdminUser u) => new(s.Id, Identity(u), s.CreatedAt, s.LastSeenAt, s.AbsoluteExpiresAt, s.ReauthenticatedAt);
    private async Task<T> WithStore<T>(Func<Task<T>> action)
    { try { return await action(); } catch (DbException) { throw new SecurityStoreUnavailableException(); } catch (DbUpdateException) { throw new SecurityStoreUnavailableException(); } }

    public Task<AdminIdentity?> VerifyCredentialsAsync(string userName, string password, DateTimeOffset now, CancellationToken ct) => WithStore<AdminIdentity?>(async () =>
    {
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var normalized = users.NormalizeName(userName);
        var user = await db.Users.FromSqlInterpolated($"SELECT * FROM asp_net_users WHERE normalized_user_name = {normalized} FOR UPDATE").SingleOrDefaultAsync(ct);
        // Identity's framework password hasher is used for real and dummy verification; no custom password algorithm.
        var verification = hasher.VerifyHashedPassword(user ?? TimingUser, user?.PasswordHash ?? TimingHash, password);
        if (user is null) return null;
        if (user.PasswordHash is null || !user.IsEnabled || user.SecurityStamp is null || !await EligibleUsers.AnyAsync(x => x.Id == user.Id, ct) || user.LockoutEnd > now) return null;
        if (verification == PasswordVerificationResult.Failed)
        {
            user.AccessFailedCount++;
            if (user.AccessFailedCount >= ContentLimits.LoginFailures)
            { user.LockoutEnd = now.AddMinutes(ContentLimits.LockoutMinutes); user.AccessFailedCount = 0; }
            user.ConcurrencyStamp = Guid.NewGuid().ToString();
            await db.SaveChangesAsync(ct); await tx.CommitAsync(ct); return null;
        }
        user.AccessFailedCount = 0; user.LockoutEnd = null;
        if (verification == PasswordVerificationResult.SuccessRehashNeeded) user.PasswordHash = hasher.HashPassword(user, password);
        user.ConcurrencyStamp = Guid.NewGuid().ToString();
        await db.SaveChangesAsync(ct); await tx.CommitAsync(ct); var identity = Identity(user); db.ChangeTracker.Clear(); return identity;
    });
    public Task<AdminSessionView?> CreateSessionAsync(AdminIdentity identity, DateTimeOffset now, CancellationToken ct) => WithStore<AdminSessionView?>(async () =>
    {
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var user = await db.Users.FromSqlInterpolated($"SELECT * FROM asp_net_users WHERE id = {identity.Id} FOR UPDATE").SingleOrDefaultAsync(ct);
        if (user is null || user.SecurityStamp != identity.SecurityStamp || !await EligibleUsers.AnyAsync(x => x.Id == user.Id, ct)) return null;
        var session = new AdminSession { Id = Guid.NewGuid(), UserId = user.Id, SecurityStamp = user.SecurityStamp,
            CreatedAt = now, LastSeenAt = now, AbsoluteExpiresAt = now.AddHours(ContentLimits.AbsoluteSessionHours) };
        db.Add(session); await db.SaveChangesAsync(ct); await tx.CommitAsync(ct); return View(session, user);
    });
    public Task<AdminSessionView?> ValidateAndTouchAsync(Guid sessionId, DateTimeOffset now, CancellationToken ct) => WithStore<AdminSessionView?>(async () =>
    {
        var valid = CurrentSessions(db, sessionId, now);
        // Atomic predicate prevents a touch from clearing or reviving a concurrent revocation.
        if (await valid.ExecuteUpdateAsync(update => update.SetProperty(s => s.LastSeenAt, s => s.LastSeenAt > now ? s.LastSeenAt : now), ct) != 1)
        {
            await db.Set<AdminSession>().Where(s => s.Id == sessionId && s.RevokedAt == null).ExecuteUpdateAsync(update => update.SetProperty(s => s.RevokedAt, now), ct);
            return null;
        }
        var value = await valid.AsNoTracking().Join(EligibleUsers.AsNoTracking(), s => s.UserId, u => u.Id, (s, u) => new { Session = s, User = u }).SingleOrDefaultAsync(ct);
        return value is null ? null : View(value.Session, value.User);
    });
    internal static IQueryable<AdminSession> CurrentSessions(BlogDbContext context, Guid sessionId, DateTimeOffset now)
    {
        var cutoff = now.AddMinutes(-ContentLimits.IdleSessionMinutes);
        return context.Set<AdminSession>().Where(s => s.Id == sessionId && s.RevokedAt == null && s.LastSeenAt > cutoff && s.AbsoluteExpiresAt > now
            && context.Users.Any(u => u.Id == s.UserId && u.IsEnabled && u.SecurityStamp == s.SecurityStamp
                && context.UserRoles.Any(ur => ur.UserId == u.Id && context.Roles.Any(r => r.Id == ur.RoleId && r.NormalizedName == "ADMIN"))));
    }
    public async Task RevokeAsync(Guid sessionId, DateTimeOffset now, CancellationToken ct) => await WithStore(async () =>
    {
        await db.Set<AdminSession>().Where(x => x.Id == sessionId && x.RevokedAt == null).ExecuteUpdateAsync(s => s.SetProperty(x => x.RevokedAt, now), ct); return true;
    });
    public Task<bool> ReauthenticateAsync(Guid sessionId, string password, DateTimeOffset now, CancellationToken ct) => WithStore(async () =>
    {
        var current = await db.Set<AdminSession>().AsNoTracking().SingleOrDefaultAsync(s => s.Id == sessionId && s.RevokedAt == null, ct);
        if (current is null) return false;
        var userName = await db.Users.Where(u => u.Id == current.UserId).Select(u => u.UserName).SingleAsync(ct);
        var identity = await VerifyCredentialsAsync(userName!, password, now, ct);
        if (identity is null || identity.SecurityStamp != current.SecurityStamp) return false;
        var cutoff = now.AddMinutes(-ContentLimits.IdleSessionMinutes);
        return await db.Set<AdminSession>().Where(s => s.Id == sessionId && s.RevokedAt == null && s.SecurityStamp == identity.SecurityStamp && s.LastSeenAt > cutoff && s.AbsoluteExpiresAt > now
            && EligibleUsers.Any(u => u.Id == s.UserId && u.SecurityStamp == s.SecurityStamp))
            .ExecuteUpdateAsync(update => update.SetProperty(s => s.ReauthenticatedAt, now), ct) == 1;
    });
}

// No public endpoint invokes this recovery boundary. A later controlled operator UI must obtain user authorization.
public sealed class AdminAccountRecovery(BlogDbContext db, UserManager<AdminUser> users, TimeProvider clock)
{
    public async Task DisableAsync(Guid userId, CancellationToken ct)
    {
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var user = await db.Users.FromSqlInterpolated($"SELECT * FROM asp_net_users WHERE id = {userId} FOR UPDATE").SingleAsync(ct);
        user.IsEnabled = false;
        var result = await users.UpdateSecurityStampAsync(user); if (!result.Succeeded) throw new InvalidOperationException("ACCOUNT_UPDATE_FAILED");
        await RevokeAllAsync(userId, ct); await tx.CommitAsync(ct);
    }
    public async Task<IdentityResult> ResetPasswordAsync(Guid userId, string userEnteredResetToken, string userEnteredPassword, CancellationToken ct)
    {
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var user = await db.Users.FromSqlInterpolated($"SELECT * FROM asp_net_users WHERE id = {userId} FOR UPDATE").SingleAsync(ct);
        var result = await users.ResetPasswordAsync(user, userEnteredResetToken, userEnteredPassword);
        if (!result.Succeeded) return result;
        await RevokeAllAsync(userId, ct); await tx.CommitAsync(ct); return result;
    }
    private Task<int> RevokeAllAsync(Guid userId, CancellationToken ct) => db.Set<AdminSession>().Where(s => s.UserId == userId && s.RevokedAt == null)
        .ExecuteUpdateAsync(s => s.SetProperty(x => x.RevokedAt, clock.GetUtcNow()), ct);
}
