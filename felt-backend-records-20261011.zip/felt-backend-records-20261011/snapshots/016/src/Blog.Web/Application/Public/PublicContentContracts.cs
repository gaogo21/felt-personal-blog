using Blog.Web.Application.Columns;
using Blog.Web.Application.Home;
using Blog.Web.Application.RichText;
using Blog.Web.Domain.Persistence;

namespace Blog.Web.Application.Public;

// The callback owns one complete page read. Production runs it against one relational
// RepeatableRead snapshot; isolated tests provide an explicit immutable graph snapshot.
// No query or delayed enumeration escapes the callback's transaction lifetime.
public interface IPublicContentStore
{
    Task<T> ReadSnapshotAsync<T>(Func<IPublicContentSnapshot, CancellationToken, Task<T>> read, CancellationToken ct);
}

public interface IPublicContentSnapshot
{
    IPublicHomeQueries Home { get; }
    IPublicColumnQueries Columns { get; }
    Task<PublicListColumn?> ReadActiveColumnAsync(string slug, CancellationToken ct);
    Task<int> CountArticlesAsync(Guid? columnId, CancellationToken ct);
    Task<IReadOnlyList<PublicArticleRow>> ReadArticlesAsync(Guid? columnId, int skip, int take, CancellationToken ct);
    Task<PublicArticleDetailRow?> ReadCurrentArticleAsync(string slug, CancellationToken ct);
    Task<IReadOnlyDictionary<Guid, MediaAsset>> ReadMediaAsync(IReadOnlyList<Guid> ids, CancellationToken ct);
    Task<IReadOnlyList<BodyMediaReference>> ReadRevisionReferencesAsync(Guid revisionId, CancellationToken ct);
    Task ValidateFixedDesignAssetsAsync(CancellationToken ct);
}

public sealed record PublicListColumn(Guid Id, string Slug, string Name);
public sealed record PublicArticleRow(Guid Id, Guid RevisionId, Guid ColumnId, string Slug,
    string Title, string Summary, string ColumnSlug, string ColumnName,
    DateTimeOffset FirstPublishedAt, int ReadingMinutes);

// BodyHtml is intentionally absent. Only the schema can create trusted renderable HTML.
// The stored derived values are checked against immutable JSON, never rendered directly.
public sealed record PublicArticleDetailRow(PublicArticleRow Article, int RevisionNo,
    DateTimeOffset RevisionCreatedAt, Guid? CoverMediaId, string? CoverDisplayMeta,
    string ContentJson, int SchemaVersion, string PlainText, string TocJson);
