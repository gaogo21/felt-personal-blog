"""Explicit F22 baseline exceptions. No prefix/glob exemptions are accepted."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = Path('docs/development/f22/cleanup-manifest.json')
BASELINE_PATH = Path('docs/development/baseline/source-manifest.json')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def verify_original_baseline(root=ROOT, *, read=None, exists=None):
    read = read or (lambda relative: (root / relative).read_bytes())
    exists = exists or (lambda relative: (root / relative).exists())
    baseline = json.loads(read(BASELINE_PATH))
    manifest = json.loads(read(MANIFEST_PATH))
    original = {row['path']: row for row in baseline['files']}
    entries = manifest['entries']
    assert len(original) == 62 and len(entries) == 62, 'Original 62-file inventory must remain complete'
    assert manifest['originalBaselineCommit'] == baseline['sourceCommit'] == '78207ed7d20514901da34cb59a94ebef947f580a'
    assert len({row['path'] for row in entries}) == len(entries) and {row['path'] for row in entries} == set(original), 'Whitelist must enumerate exact baseline paths once'
    counts = {'retain': 0, 'rewrite': 0, 'remove': 0}
    for row in entries:
        name = row['path']; before = original[name]
        assert row['baselineSha256'] == before['sha256'] and row['bytes'] == before['bytes'], f'Baseline identity changed: {name}'
        action = row['action']; assert action in counts, f'Unknown action: {name}'; counts[action] += 1
        if action == 'remove':
            assert name == 'build-static.mjs' or name in {x['path'] for x in baseline['files'] if x['path'].startswith('dist/')}, 'Unapproved deletion'
            assert not exists(name), f'Retired source reappeared: {name}'
        elif action == 'rewrite':
            assert name in {'README.md', 'validate.mjs'}, f'Unapproved rewrite: {name}'
            expected = row['replacementSha256']
            if name == 'README.md':
                # F23 explicitly updates current installation/status docs. Keep
                # F22 evidence immutable and bind this one later rewrite exactly;
                # executable code, assets, other paths and mutations still fail.
                update = json.loads(read(Path('docs/development/f23/documentation-rewrites.json')))
                assert set(update) == {'path', 'priorSha256', 'replacementSha256', 'reason'}, 'Invalid documentation update contract'
                assert update['path'] == name and update['priorSha256'] == expected, 'Unexpected documentation predecessor'
                expected = update['replacementSha256']
            assert digest(read(Path(name))) == expected, f'Approved rewrite changed: {name}'
        else:
            assert name == '.openai/hosting.json', f'Unexpected retained baseline entry: {name}'
            assert digest(read(Path(name))) == before['sha256'], f'Unapproved baseline modification: {name}'
        for replacement in row['replacements']:
            assert exists(replacement), f'Missing replacement: {replacement}'
            if action == 'remove' and row.get('replacementSha256'):
                assert digest(read(Path(replacement))) == row['replacementSha256'] == before['sha256'], f'Preserved asset/license bytes changed: {replacement}'
    assert counts == {'retain': 1, 'rewrite': 2, 'remove': 59}, 'Cleanup actions exceeded the approved inventory'
    return counts

def verify_documentation_rewrite(name, old, actual, root=ROOT):
    assert name == 'src/Blog.Web/wwwroot/assets/README.md', 'No home source/CSS exemption'
    rows = json.loads((root / MANIFEST_PATH).read_text())['additionalDocumentationRewrites']
    row = next(x for x in rows if x['path'] == name)
    assert digest(old) == row['baselineSha256'] and digest(actual) == row['replacementSha256'], 'Unexpected asset documentation edit'
    return old
