using Blog.Web.Application.Articles;
using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Blog.Web.Infrastructure.Articles;

public sealed class PostgresAdminArticleStore(BlogDbContext db) : IAdminArticleStore
{
    // Single-site database: administrator access covers every article in this database, not arbitrary cross-site data.
    public static IQueryable<ArticleListItem> ListQuery(BlogDbContext context, ArticleFilter filter)
    {
        var query = from article in context.Set<Article>().AsNoTracking()
                    join work in context.Set<ArticleDraft>().AsNoTracking() on article.Id equals work.ArticleId into drafts
                    from draft in drafts.DefaultIfEmpty()
                    where filter.State == null ? article.State != ArticleState.Purged : article.State == filter.State
                    select new { article, draft };
        if (!string.IsNullOrEmpty(filter.Query)) query = query.Where(x => x.draft != null && x.draft.Title.Contains(filter.Query));
        if (filter.ColumnId is { } column) query = query.Where(x => x.draft != null && x.draft.ColumnId == column);
        return query.OrderByDescending(x => x.article.CreatedAt).ThenBy(x => x.article.Id)
            .Select(x => new ArticleListItem(x.article.Id, x.article.Slug, x.article.State.ToString(), x.draft == null ? "" : x.draft.Title,
                x.draft == null ? null : x.draft.ColumnId, x.article.RowVersion, x.draft == null ? null : (long?)x.draft.RowVersion, x.article.CreatedAt));
    }
    public async Task<AdminArticlePage> ListAsync(ArticleFilter filter, CancellationToken ct)
    {
        var query = ListQuery(db, filter);
        var total = await query.CountAsync(ct);
        var items = await query.Skip((filter.Page - 1) * filter.PageSize).Take(filter.PageSize).ToListAsync(ct);
        return new(items, total, filter.Page, filter.PageSize);
    }
    public static IQueryable<ArticleRead> ReadQuery(BlogDbContext context, Guid id)
        => from article in context.Set<Article>()
           join work in context.Set<ArticleDraft>() on article.Id equals work.ArticleId into drafts
           from draft in drafts.DefaultIfEmpty()
           join revision in context.Set<ArticleRevision>() on new { ArticleId = article.Id, RevisionId = article.PublishedRevisionId } equals new { revision.ArticleId, RevisionId = (Guid?)revision.Id } into revisions
           from published in revisions.DefaultIfEmpty()
           where article.Id == id
           select new ArticleRead(article, draft, published);
    public Task<ArticleRead?> ReadAsync(Guid id, bool tracked, CancellationToken ct)
        => (tracked ? ReadQuery(db, id) : ReadQuery(db, id).AsNoTracking()).SingleOrDefaultAsync(ct);
    public Task<bool> SlugExistsAsync(string slug, Guid? exceptId, CancellationToken ct)
        => db.Set<Article>().AnyAsync(x => x.Slug == slug && (!exceptId.HasValue || x.Id != exceptId.Value), ct);
    public Task<Column?> ColumnAsync(Guid id, CancellationToken ct) => db.Set<Column>().AsNoTracking().SingleOrDefaultAsync(x => x.Id == id, ct);
    public Task<MediaAsset?> MediaAsync(Guid id, CancellationToken ct) => db.Set<MediaAsset>().AsNoTracking().SingleOrDefaultAsync(x => x.Id == id, ct);
    public static IQueryable<Guid> DraftMediaIdsQuery(BlogDbContext context, Guid articleId)
        => context.Set<DraftMediaReference>().AsNoTracking().Where(x => x.ArticleId == articleId).Select(x => x.MediaId).Distinct();
    public async Task<IReadOnlyList<Guid>> DraftMediaIdsAsync(Guid articleId, CancellationToken ct)
    {
        if (db.Database.CurrentTransaction is null) throw new InvalidOperationException("DRAFT_REFERENCES_REQUIRE_TRANSACTION");
        return await DraftMediaIdsQuery(db, articleId).ToArrayAsync(ct);
    }
    public void Add(Article article, ArticleDraft draft) { db.Add(article); db.Add(draft); }
    public async Task ReplaceBodyReferencesAsync(Guid articleId, IReadOnlyList<Blog.Web.Application.RichText.BodyMediaReference> references, CancellationToken ct)
    {
        var old = await db.Set<DraftMediaReference>().Where(x => x.ArticleId == articleId).ToListAsync(ct);
        var expected = references.Select(x => (x.MediaId, x.Usage)).ToHashSet();
        db.RemoveRange(old.Where(x => !expected.Contains((x.MediaId, x.Usage))));
        var existing = old.Select(x => (x.MediaId, x.Usage)).ToHashSet();
        foreach (var reference in references.Where(x => !existing.Contains((x.MediaId, x.Usage))))
            db.Add(new DraftMediaReference { ArticleId = articleId, MediaId = reference.MediaId, Usage = reference.Usage });
    }
}
