#!/usr/bin/env python3
"""Safe contract preflight only: no credentials, connections, capture or restore."""
import argparse, json
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--dry-run', action='store_true', required=True)
args = parser.parse_args()
print(json.dumps({
    'mode': 'DryRunOnly', 'captureExecuted': False, 'restoreExecuted': False,
    'readyForProduction': False,
    'requiredBeforeEnabling': ['Explicit single application instance and no external writers',
        'Authorized PostgreSQL 17 source and verified pg_dump/pg_restore binaries',
        'Existing private media root and explicit MAX_MEDIA_BYTES',
        'Existing protected Data Protection keys and controlled rotation',
        'Existing separate 32-byte backup key file and private destination',
        'Configuration version and DP application name',
        'Real isolated database restore and off-host destination authorization'],
    'captureEntry': 'Authenticated, CSRF-protected, recently reauthenticated POST /api/admin/v1/maintenance/backup',
    'restoreEntry': 'Unwired operator service; explicit isolated target authorization required'
}, indent=2))
raise SystemExit(2)
