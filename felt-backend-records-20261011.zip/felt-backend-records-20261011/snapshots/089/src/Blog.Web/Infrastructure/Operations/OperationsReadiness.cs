using Blog.Web.Application;
using Blog.Web.Application.Maintenance;
using Blog.Web.Infrastructure.Backup;
using Blog.Web.Infrastructure.Media;

namespace Blog.Web.Infrastructure.Operations;

public interface IOperationsReadiness
{
    Task<bool> CheckAsync(CancellationToken cancellationToken);
}

public interface IOperationsReadinessDependencies
{
    Task<bool> CheckAsync(CancellationToken cancellationToken);
}

public sealed class OperationsReadinessDependencies(IConfiguration configuration, IWebHostEnvironment environment,
    IPublicContentQueries content, ReleaseCompatibility compatibility, IReadinessDatabase database,
    IReadinessPrivateStorage storage, TimeProvider clock) : IOperationsReadinessDependencies
{
    public async Task<bool> CheckAsync(CancellationToken cancellationToken)
    {
        // LocalMock/TestFixture can never satisfy operational readiness, and no
        // database or filesystem adapter is called in that mode.
        if (configuration["Blog:Mode"] != "PostgreSql" || content.SourceKind != ContentSourceKind.PostgreSql)
            return false;
        var connection = configuration.GetConnectionString("BlogDatabase");
        if (string.IsNullOrWhiteSpace(connection)) return false;
        var media = MediaStorageOptions.Read(configuration);
        var backup = BackupOptions.Read(configuration);
        compatibility.Validate();
        if (!backup.Enabled || backup.ConfigurationVersion != compatibility.ConfigurationVersion ||
            Environment.Version.Major != compatibility.DotnetMajor)
            return false;
        cancellationToken.ThrowIfCancellationRequested();
        storage.Validate(media, backup, environment.WebRootPath ?? Path.Combine(environment.ContentRootPath, "wwwroot"), clock.GetUtcNow());
        cancellationToken.ThrowIfCancellationRequested();
        var snapshot = await database.InspectAsync(connection, cancellationToken);
        return compatibility.CanRead(snapshot.PostgresMajor, snapshot.AppliedMigrations) &&
            compatibility.CanReadContent(snapshot.ContentSchemaVersions);
    }
}

public sealed class OperationsReadiness(IConfiguration configuration, MaintenanceCoordinator maintenance,
    IServiceScopeFactory scopes, TimeProvider clock) : IOperationsReadiness
{
    public static readonly TimeSpan ProbeTimeout = TimeSpan.FromSeconds(5);
    private readonly SemaphoreSlim probe = new(1, 1);

    public async Task<bool> CheckAsync(CancellationToken cancellationToken)
    {
        if (cancellationToken.IsCancellationRequested || !IsOpen() || !probe.Wait(0)) return false;
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        // Sync filesystem/DP reads cannot be canceled mid-read. Keep at most one
        // outstanding probe, retaining its permit and scope until it actually
        // finishes, while bounding the caller's wait and canceling database IO.
        var work = Task.Run(async () =>
        {
            try
            {
                using var scope = scopes.CreateScope();
                var result = await scope.ServiceProvider.GetRequiredService<IOperationsReadinessDependencies>().CheckAsync(timeout.Token);
                return result && IsOpen();
            }
            catch (Exception error) when (error is not OutOfMemoryException) { return false; }
            finally { probe.Release(); }
        }, CancellationToken.None);
        try { return await work.WaitAsync(ProbeTimeout, clock, cancellationToken); }
        catch (TimeoutException) { return false; }
        catch (OperationCanceledException) { return false; }
        finally { await timeout.CancelAsync(); }
    }

    private bool IsOpen()
    {
        try
        {
            return configuration["Blog:Mode"] == "PostgreSql" &&
                !configuration.GetValue<bool>("Maintenance:ReadOnly") && maintenance.Snapshot.State == MaintenanceState.Open;
        }
        catch (Exception error) when (error is not OutOfMemoryException) { return false; }
    }
}
