using System.Data;
using Blog.Web.Application.Columns;
using Blog.Web.Application.Home;
using Blog.Web.Application.Public;
using Blog.Web.Application.RichText;
using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Columns;
using Blog.Web.Infrastructure.Home;
using Blog.Web.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace Blog.Web.Infrastructure.Public;

public sealed class PostgresPublicContentStore(BlogDbContext db) : IPublicContentStore
{
    public async Task<T> ReadSnapshotAsync<T>(Func<IPublicContentSnapshot, CancellationToken, Task<T>> read, CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(read);
        ct.ThrowIfCancellationRequested();
        await using var transaction = await BeginReadSnapshotAsync(ct);
        var snapshot = new Snapshot(db);
        try
        {
            var result = await read(snapshot, ct);
            if (transaction is not null) await transaction.CommitAsync(ct);
            return result;
        }
        finally { snapshot.Close(); }
    }

    private async Task<IDbContextTransaction?> BeginReadSnapshotAsync(CancellationToken ct)
    {
        if (db.Database.CurrentTransaction is { } existing)
        {
            RequireSnapshotIsolation(existing.GetDbTransaction().IsolationLevel);
            return null;
        }
        return await db.Database.BeginTransactionAsync(IsolationLevel.RepeatableRead, ct);
    }

    public static void RequireSnapshotIsolation(IsolationLevel isolation)
    {
        if (isolation is not (IsolationLevel.RepeatableRead or IsolationLevel.Serializable))
            throw new InvalidOperationException("PUBLIC_CONTENT_SNAPSHOT_REQUIRED");
    }

    // Explicit-source overloads use exactly the production predicates and projections.
    // Controlled graph and Npgsql ToQueryString tests need no fake relational provider.
    public static IQueryable<PublicArticleRow> ArticlesQuery(BlogDbContext context, Guid? columnId = null)
        => ArticlesQuery(context.Set<Article>().AsNoTracking(), context.Set<ArticleRevision>().AsNoTracking(),
            context.Set<Column>().AsNoTracking(), columnId);

    public static IQueryable<PublicArticleRow> ArticlesQuery(IQueryable<Article> articles,
        IQueryable<ArticleRevision> revisions, IQueryable<Column> columns, Guid? columnId = null)
    {
        var current = from article in articles
                      join revision in revisions
                          on new { ArticleId = article.Id, RevisionId = article.PublishedRevisionId }
                          equals new { revision.ArticleId, RevisionId = (Guid?)revision.Id }
                      join column in columns on revision.ColumnId equals column.Id
                      where article.State == ArticleState.Published && article.PublishedRevisionId != null
                          && article.FirstPublishedAt != null && column.State == ColumnState.Active
                          && (columnId == null || column.Id == columnId)
                      orderby article.FirstPublishedAt descending, article.Id
                      select new PublicArticleRow(article.Id, revision.Id, column.Id, article.Slug,
                          revision.Title, revision.Summary, column.Slug, column.Name,
                          article.FirstPublishedAt!.Value, revision.ReadingMinutes);
        return current;
    }

    public static IQueryable<PublicArticleDetailRow> CurrentArticleQuery(BlogDbContext context, string slug)
        => CurrentArticleQuery(context.Set<Article>().AsNoTracking(), context.Set<ArticleRevision>().AsNoTracking(),
            context.Set<Column>().AsNoTracking(), slug);

    public static IQueryable<PublicArticleDetailRow> CurrentArticleQuery(IQueryable<Article> articles,
        IQueryable<ArticleRevision> revisions, IQueryable<Column> columns, string slug)
        => from article in articles
           join revision in revisions
               on new { ArticleId = article.Id, RevisionId = article.PublishedRevisionId }
               equals new { revision.ArticleId, RevisionId = (Guid?)revision.Id }
           join column in columns on revision.ColumnId equals column.Id
           where article.Slug == slug && article.State == ArticleState.Published && article.PublishedRevisionId != null
               && article.FirstPublishedAt != null && column.State == ColumnState.Active
           select new PublicArticleDetailRow(new PublicArticleRow(article.Id, revision.Id, column.Id,
                   article.Slug, revision.Title, revision.Summary, column.Slug, column.Name,
                   article.FirstPublishedAt!.Value, revision.ReadingMinutes),
               revision.RevisionNo, revision.CreatedAt, revision.CoverMediaId, revision.CoverDisplayMeta,
               revision.ContentJson, revision.SchemaVersion, revision.PlainText, revision.TocJson);

    public static IQueryable<PublicListColumn> ActiveColumnsQuery(BlogDbContext context, string slug)
        => ActiveColumnsQuery(context.Set<Column>().AsNoTracking(), slug);

    public static IQueryable<PublicListColumn> ActiveColumnsQuery(IQueryable<Column> columns, string slug)
        => columns.Where(column => column.Slug == slug && column.State == ColumnState.Active)
            .Select(column => new PublicListColumn(column.Id, column.Slug, column.Name));

    public static IQueryable<MediaAsset> ReadyMediaQuery(BlogDbContext context, IReadOnlyList<Guid> ids)
        => ReadyMediaQuery(context.Set<MediaAsset>().AsNoTracking(), ids);

    public static IQueryable<MediaAsset> ReadyMediaQuery(IQueryable<MediaAsset> media, IReadOnlyList<Guid> ids)
    {
        var selected = ids.ToArray();
        // Only authoritative render dimensions and media kind are needed here. Delivery
        // still independently checks current F12 visibility, file metadata and bytes.
        return media.Where(asset => selected.Contains(asset.Id) && asset.State == MediaState.Ready
                && asset.Width != null && asset.Width > 0 && asset.Height != null && asset.Height > 0)
            .Select(asset => new MediaAsset
            {
                Id = asset.Id, State = asset.State, Kind = asset.Kind, Width = asset.Width, Height = asset.Height
            });
    }

    public static IQueryable<BodyMediaReference> RevisionReferencesQuery(BlogDbContext context, Guid revisionId)
        => RevisionReferencesQuery(context.Set<RevisionMediaReference>().AsNoTracking(), revisionId);

    public static IQueryable<BodyMediaReference> RevisionReferencesQuery(IQueryable<RevisionMediaReference> references, Guid revisionId)
        => references.Where(reference => reference.RevisionId == revisionId)
            .OrderBy(reference => reference.MediaId).ThenBy(reference => reference.Usage)
            .Select(reference => new BodyMediaReference(reference.MediaId, reference.Usage));

    public static IQueryable<PublicFixedDesignAssetRow> FixedDesignAssetsQuery(BlogDbContext context)
        => FixedDesignAssetsQuery(context.Set<DesignAssetSlot>().AsNoTracking(), context.Set<MediaAsset>().AsNoTracking());

    public static IQueryable<PublicFixedDesignAssetRow> FixedDesignAssetsQuery(IQueryable<DesignAssetSlot> slots, IQueryable<MediaAsset> media)
        => from slot in slots
           join asset in media on slot.MediaId equals asset.Id
           orderby slot.Key
           select new PublicFixedDesignAssetRow(slot.Key, asset.Id, asset.State, asset.Kind, asset.Origin,
               asset.StorageKey, asset.MimeType, asset.ByteSize, asset.Sha256, asset.UploadSha256,
               asset.Width, asset.Height, asset.DurationMs);

    public static void ValidateFixedDesignAssets(IReadOnlyList<PublicFixedDesignAssetRow> actual)
    {
        // The nine code-level visual assets keep their approved identity and legacy
        // aliases. This catalog is validation only: it never fills missing database rows,
        // supplies homepage text, or constrains the independently replaceable gallery.
        var expected = DesignSeedCatalog.Load().Where(asset => asset.GallerySlot is null).ToDictionary(asset => asset.Key, StringComparer.Ordinal);
        if (actual.Count != expected.Count || actual.Select(asset => asset.Key).Distinct(StringComparer.Ordinal).Count() != expected.Count)
            throw new InvalidDataException("PUBLIC_FIXED_DESIGN_ASSETS_INVALID");
        foreach (var asset in actual)
            if (!expected.TryGetValue(asset.Key, out var approved) || asset.MediaId != approved.Id
                || asset.State != MediaState.Ready || asset.Kind != MediaKind.Image || asset.Origin != "system_design_seed"
                || asset.StorageKey != approved.StorageKey || asset.MimeType != approved.MimeType
                || asset.ByteSize != approved.ByteSize || asset.Sha256 != approved.Sha256 || asset.UploadSha256 != approved.Sha256
                || asset.Width != approved.Width || asset.Height != approved.Height || asset.DurationMs is not null)
                throw new InvalidDataException("PUBLIC_FIXED_DESIGN_ASSETS_INVALID");
    }

    private sealed class Snapshot(BlogDbContext context) : IPublicContentSnapshot
    {
        // Constructing both existing adapters with this exact context makes them reuse
        // the enclosing snapshot; neither adapter owns/commits a nested transaction.
        private readonly IPublicHomeQueries home = new PostgresPublicHomeQueries(context);
        private readonly IPublicColumnQueries columns = new PostgresPublicColumnQueries(context);
        private bool active = true;
        public IPublicHomeQueries Home { get { RequireActive(); return home; } }
        public IPublicColumnQueries Columns { get { RequireActive(); return columns; } }
        public void Close() => active = false;
        private void RequireActive()
        {
            if (!active) throw new InvalidOperationException("PUBLIC_CONTENT_SNAPSHOT_CLOSED");
        }
        public Task<PublicListColumn?> ReadActiveColumnAsync(string slug, CancellationToken ct)
        { RequireActive(); return ActiveColumnsQuery(context, slug).SingleOrDefaultAsync(ct); }
        public Task<int> CountArticlesAsync(Guid? columnId, CancellationToken ct)
        { RequireActive(); return ArticlesQuery(context, columnId).CountAsync(ct); }
        public async Task<IReadOnlyList<PublicArticleRow>> ReadArticlesAsync(Guid? columnId, int skip, int take, CancellationToken ct)
        {
            RequireActive();
            if (skip < 0 || take != PublicContentService.PageSize) throw new ArgumentOutOfRangeException(nameof(skip));
            return await ArticlesQuery(context, columnId).Skip(skip).Take(take).ToArrayAsync(ct);
        }
        public Task<PublicArticleDetailRow?> ReadCurrentArticleAsync(string slug, CancellationToken ct)
        { RequireActive(); return CurrentArticleQuery(context, slug).SingleOrDefaultAsync(ct); }
        public async Task<IReadOnlyDictionary<Guid, MediaAsset>> ReadMediaAsync(IReadOnlyList<Guid> ids, CancellationToken ct)
        {
            RequireActive();
            return ids.Count == 0 ? new Dictionary<Guid, MediaAsset>()
                : await ReadyMediaQuery(context, ids).ToDictionaryAsync(asset => asset.Id, ct);
        }
        public async Task<IReadOnlyList<BodyMediaReference>> ReadRevisionReferencesAsync(Guid revisionId, CancellationToken ct)
        { RequireActive(); return await RevisionReferencesQuery(context, revisionId).ToArrayAsync(ct); }
        public async Task ValidateFixedDesignAssetsAsync(CancellationToken ct)
        { RequireActive(); ValidateFixedDesignAssets(await FixedDesignAssetsQuery(context).ToArrayAsync(ct)); }
    }
}

public sealed record PublicFixedDesignAssetRow(string Key, Guid MediaId, MediaState State, MediaKind Kind, string Origin,
    string StorageKey, string MimeType, long? ByteSize, string? Sha256, string? UploadSha256,
    int? Width, int? Height, long? DurationMs);
