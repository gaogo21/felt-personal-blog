using Blog.Web.Application.Media;
using Blog.Web.Application.Security;
using Blog.Web.Infrastructure.Media;
using Blog.Web.Infrastructure.Persistence;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.Net.Http.Headers;

namespace Blog.Web.Api.Media;

public sealed class ProtectedMediaMarker;
public static class ProtectedMediaEndpoints
{
    public static IEndpointRouteBuilder MapProtectedMedia(this IEndpointRouteBuilder app)
    {
        app.MapMethods("/media/{id:guid}", ["GET", "HEAD"], Read).WithMetadata(new ProtectedMediaMarker());
        // Preserve the approved homepage URLs while removing their static-file bypass. This does
        // not grant visibility: replaced gallery seeds still require another current public reference.
        foreach (var seed in DesignSeedCatalog.Load())
        {
            var id = seed.Id;
            app.MapMethods("/" + seed.RelativePath, ["GET", "HEAD"],
                (HttpContext context, IMediaReadStore store) => Read(id, context, store))
                .WithMetadata(new ProtectedMediaMarker());
        }
        return app;
    }
    private static async Task Read(Guid id, HttpContext context, IMediaReadStore store)
    {
        // The cookie handler checks the persisted session on every request. Never trust a role or
        // a client flag alone; the validated session capability is placed here only by that handler.
        var administrator = context.User.Identity?.IsAuthenticated == true && context.User.IsInRole("Admin")
            && context.Items[typeof(AdminSessionView)] is AdminSessionView;
        var asset = id == Guid.Empty ? null : await store.FindVisibleAsync(id, administrator, context.RequestAborted);
        if (asset is null) { Empty(context, 404); return; }
        // Resolve the filesystem service only after authorization; even its initialization can fail.
        var files = context.RequestServices.GetRequiredService<IProtectedMediaFiles>();
        await using var stream = files.Open(asset);
        if (!stream.CanRead || !stream.CanSeek || stream.Length != asset.ByteSize) throw new InvalidDataException("MEDIA_STREAM_INVALID");
        var etag = new EntityTagHeaderValue('"' + asset.Sha256 + '"');
        var headers = context.Response.Headers;
        headers.ETag = etag.ToString(); headers.AcceptRanges = "bytes";
        headers.ContentDisposition = "inline"; context.Response.ContentType = asset.MimeType;
        // Preconditions follow authorization and opening, including 304/412. Missing files cannot
        // falsely produce a successful conditional response. Date validators are not advertised.
        var request = context.Request;
        if (request.Headers.ContainsKey(HeaderNames.IfMatch))
        {
            if (!EntityTagHeaderValue.TryParseStrictList([request.Headers.IfMatch.ToString()], out var tags) || tags.Count == 0 || tags.Count > 1 && tags.Any(x => x == EntityTagHeaderValue.Any)) { Empty(context, 400); return; }
            if (!tags.Any(x => x == EntityTagHeaderValue.Any || x.Compare(etag, useStrongComparison: true))) { Empty(context, 412); return; }
        }
        if (request.Headers.ContainsKey(HeaderNames.IfNoneMatch))
        {
            if (!EntityTagHeaderValue.TryParseStrictList([request.Headers.IfNoneMatch.ToString()], out var tags) || tags.Count == 0 || tags.Count > 1 && tags.Any(x => x == EntityTagHeaderValue.Any)) { Empty(context, 400); return; }
            if (tags.Any(x => x == EntityTagHeaderValue.Any || x.Compare(etag, useStrongComparison: false)))
            { context.Response.StatusCode = 304; context.Response.ContentLength = null; return; }
        }
        long start = 0, end = asset.ByteSize - 1;
        // RFC 9110 defines Range for GET only. HEAD returns the full representation headers,
        // ignores Range, and performs no byte reads, including on error/conditional paths.
        if (HttpMethods.IsGet(request.Method) && request.Headers.ContainsKey(HeaderNames.Range))
        {
            if (!RangeHeaderValue.TryParse(request.Headers.Range.ToString(), out var range)
                || !range.Unit.Equals("bytes", StringComparison.OrdinalIgnoreCase) || range.Ranges.Count != 1)
            { Unsatisfiable(context, asset.ByteSize); return; }
            var useRange = true;
            if (request.Headers.ContainsKey(HeaderNames.IfRange))
                useRange = EntityTagHeaderValue.TryParse(request.Headers.IfRange.ToString(), out var ifRange)
                    && ifRange.Compare(etag, useStrongComparison: true);
            if (useRange)
            {
                var part = range.Ranges.Single();
                if (part.From is { } first)
                {
                    if (first >= asset.ByteSize || part.To is { } last && last < first) { Unsatisfiable(context, asset.ByteSize); return; }
                    start = first; end = Math.Min(part.To ?? end, end);
                }
                else if (part.To is { } suffix && suffix > 0) start = Math.Max(0, asset.ByteSize - suffix);
                else { Unsatisfiable(context, asset.ByteSize); return; }
                context.Response.StatusCode = 206;
                headers.ContentRange = $"bytes {start}-{end}/{asset.ByteSize}";
            }
        }
        var count = end - start + 1;
        context.Response.ContentLength = count;
        if (HttpMethods.IsHead(request.Method)) return;
        stream.Seek(start, SeekOrigin.Begin);
        var buffer = new byte[65536];
        while (count > 0)
        {
            var read = await stream.ReadAsync(buffer.AsMemory(0, (int)Math.Min(count, buffer.Length)), context.RequestAborted);
            if (read == 0) throw new IOException("MEDIA_READ_INCOMPLETE");
            await context.Response.Body.WriteAsync(buffer.AsMemory(0, read), context.RequestAborted);
            count -= read;
        }
    }
    private static void Unsatisfiable(HttpContext context, long length)
    { Empty(context, 416); context.Response.Headers.ContentRange = $"bytes */{length}"; }
    internal static void Empty(HttpContext context, int status)
    { context.Response.StatusCode = status; context.Response.ContentType = null; context.Response.ContentLength = 0; }
}

public sealed class ProtectedMediaBoundary(RequestDelegate next, ILogger<ProtectedMediaBoundary> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        if (!context.Request.Path.StartsWithSegments("/media") && context.GetEndpoint()?.Metadata.GetMetadata<ProtectedMediaMarker>() is null)
        { await next(context); return; }
        void ProtectHeaders()
        {
            context.Response.Headers.CacheControl = "private, no-store";
            context.Response.Headers["X-Content-Type-Options"] = "nosniff";
            context.Response.Headers["Cross-Origin-Resource-Policy"] = "same-origin";
        }
        ProtectHeaders();
        // Rejecting an expired cookie calls SignOutAsync, which can replace Cache-Control.
        // Pin the media policy after authentication has finished altering response headers.
        context.Response.OnStarting(() => { ProtectHeaders(); return Task.CompletedTask; });
        if (context.Features.Get<IStatusCodePagesFeature>() is { } pages) pages.Enabled = false;
        try { await next(context); }
        catch (OperationCanceledException) when (context.RequestAborted.IsCancellationRequested) { context.Abort(); }
        catch (Exception error)
        {
            // No exception, key, filename, URL, query or database detail reaches either response or log.
            if (context.Response.HasStarted) { context.Abort(); return; }
            context.Response.Headers.Remove(HeaderNames.ETag);
            context.Response.Headers.Remove(HeaderNames.ContentRange);
            context.Response.Headers.Remove(HeaderNames.AcceptRanges);
            var missing = error is FileNotFoundException or DirectoryNotFoundException;
            ProtectedMediaEndpoints.Empty(context, missing ? 404 : 503);
            if (!missing) logger.LogWarning("Protected media request failed. Code: MEDIA_READ_UNAVAILABLE");
        }
    }
}
