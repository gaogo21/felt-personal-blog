diff --git a/tests/HomeMotion/admin-publication.test.mjs b/tests/HomeMotion/admin-publication.test.mjs
index 3b0c536..18f7880 100644
--- a/tests/HomeMotion/admin-publication.test.mjs
+++ b/tests/HomeMotion/admin-publication.test.mjs
@@ -231,6 +231,23 @@ await check('Unknown publication followed by auth recovery retains its pinned ke
   const e = track(environment({ override: (path, options, server) => { if (path.endsWith('/publish') && first) { first = false; result = server.commitPublication(options); return gate.promise; } } })); await flush(); await publishClick(e); e.auth(); gate.resolve(response(result)); await flush(); e.input('[name=title]', '登录恢复后输入'); e.click('#draft-reconcile'); await flush(); assert.equal(e.disabled('#draft-keep-local'), false); assert.equal(e.disabled('#draft-use-server'), true); assert.equal(e.disabled('#article-publish-retry'), true); e.click('#draft-keep-local'); await flush(); assert.equal(e.disabled('#article-publish-retry'), false); assert.equal(e.putCalls.length, 0); e.click('#article-publish-retry'); await flush();
   assert.equal(e.publishCalls[1].options.headers['Idempotency-Key'], e.publishCalls[0].options.headers['Idempotency-Key']); assert.equal(e.value('[name=title]'), '登录恢复后输入'); assert.notEqual(e.state, 'conflict'); await e.tick(1500); assert.equal(e.putCalls.length, 1);
 });
+for (const needsAuthRecovery of [false, true]) await check(`Unknown uncommitted publication with ${needsAuthRecovery ? 'auth recovery' : 'direct reconciliation'} accepts its original baseline and first replay commit resumes newer-input autosave`, async track => {
+  let first = true;
+  const e = track(environment({ override: path => {
+    if (path.endsWith('/publish') && first) { first = false; return Promise.reject(new Error('network failed before commit')); }
+  } })); await flush(); await publishClick(e); const original = e.publishCalls[0];
+  assert.equal(e.state, 'unknown'); assert.equal(e.serverArticle.articleEtag, aTag); assert.equal(e.serverDraft.draftEtag, dTag);
+  if (needsAuthRecovery) e.auth();
+  e.input('[name=title]', '未提交重试期间的新标题'); e.input('[name=summary]', '较新摘要'); e.changeBody(body('较新正文'));
+  e.click('#draft-reconcile'); await flush(); assert.equal(e.disabled('#draft-keep-local'), false); assert.equal(e.disabled('#article-publish-retry'), true);
+  e.click('#draft-keep-local'); await flush(); assert.equal(e.putCalls.length, 0); assert.equal(e.disabled('#article-publish-retry'), false);
+  e.click('#article-publish-retry'); await flush(); assert.equal(e.publishCalls.length, 2);
+  const replay = e.publishCalls[1]; assert.equal(replay.options.headers['Idempotency-Key'], original.options.headers['Idempotency-Key']); assert.equal(replay.options.headers['If-Match'], aTag); assert.equal(replay.options.body, original.options.body);
+  assert.equal(e.state, 'dirty'); assert.equal(e.serverArticle.published.title, baseDraft.title); assert.equal(e.value('[name=title]'), '未提交重试期间的新标题'); assert.deepEqual(e.content, body('较新正文'));
+  await e.tick(1500); assert.equal(e.putCalls.length, 1); assert.equal(e.putCalls[0].options.headers['If-Match'], `"d-${id}-2"`);
+  const saved = JSON.parse(e.putCalls[0].options.body); assert.equal(saved.title, '未提交重试期间的新标题'); assert.equal(saved.summary, '较新摘要'); assert.deepEqual(saved.contentJson, body('较新正文'));
+  assert.equal(e.state, 'saved'); assert.match(e.publicationText, /尚未发布的修改/); assert.equal(e.beforeUnload(), false);
+});
 await check('Known newer server versions after unknown publication are never overwritten by its older replay result', async track => {
   let first = true;
   const e = track(environment({ override: (path, options, server) => { if (path.endsWith('/publish') && first) { first = false; server.commitPublication(options); return Promise.reject(new Error('lost')); } } })); await flush(); await publishClick(e); e.auth(); e.serverDraft = { ...e.serverDraft, title: '其他地方新稿', draftVersion: 3, draftEtag: `"d-${id}-3"`, contentHash: 'external-new' }; e.click('#draft-reconcile'); await flush(); e.click('#draft-keep-local'); await flush(); e.click('#article-publish-retry'); await flush(); assert.equal(e.state, 'conflict'); assert.equal(e.putCalls.length, 0); assert.equal(e.value('[name=title]'), baseDraft.title); await e.tick(60000); assert.equal(e.putCalls.length, 0);
