using System.Xml;
using System.Xml.Linq;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.DataProtection.Repositories;

namespace Blog.Web.Infrastructure.Backup;

public interface IBackupKeyValidator
{
    void Validate(string directory, DateTimeOffset now);
}

// Each call uses a fresh manager: the application's long-lived manager caches
// descriptors by key ID and must not hide changed or corrupted on-disk material.
// The repository is an immutable read-only snapshot, with no fallback or writes.
public sealed class BackupKeyValidator : IBackupKeyValidator
{
    public void Validate(string directory, DateTimeOffset now)
    {
        try
        {
            BackupArchivePaths.CheckDirectory(directory);
            var elements = new List<XElement>();
            var expected = new HashSet<Guid>();
            foreach (var path in Directory.EnumerateFiles(directory, "*.xml"))
            {
                if (elements.Count >= 10_000) throw new InvalidOperationException();
                using var source = BackupArchivePaths.OpenRead(path);
                if (source.Length > 1024 * 1024) throw new InvalidOperationException();
                using var reader = XmlReader.Create(source, new XmlReaderSettings
                {
                    DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null,
                    MaxCharactersInDocument = 1024 * 1024
                });
                var root = XDocument.Load(reader).Root ?? throw new InvalidOperationException();
                if (root.Name == "key")
                {
                    if (!Guid.TryParse((string?)root.Attribute("id"), out var id) || id == Guid.Empty || !expected.Add(id))
                        throw new InvalidOperationException();
                }
                else if (root.Name != "revocation") throw new InvalidOperationException();
                elements.Add(root);
            }
            var services = new ServiceCollection();
            services.AddLogging(); // No providers: framework diagnostics cannot expose key XML.
            services.AddDataProtection().DisableAutomaticKeyGeneration();
            services.Configure<KeyManagementOptions>(options => options.XmlRepository = new SnapshotRepository(elements));
            using var provider = services.BuildServiceProvider();
            var keys = provider.GetRequiredService<IKeyManager>().GetAllKeys();
            if (!expected.SetEquals(keys.Select(key => key.KeyId))) throw new InvalidOperationException();
            // Old keys are needed to recover existing protected cookies. Validate
            // their descriptors too, even when a newer active key also exists.
            foreach (var key in keys)
                if (key.CreateEncryptor() is null) throw new InvalidOperationException();
            if (!keys.Any(key => !key.IsRevoked && key.ActivationDate <= now && now < key.ExpirationDate))
                throw new InvalidOperationException();
        }
        catch (Exception error) when (error is not OutOfMemoryException)
        {
            // Intentionally do not attach the framework exception: it may contain
            // a filesystem path or descriptor. Callers expose only this safe code.
            throw new InvalidOperationException("BACKUP_CURRENT_DP_KEY_INVALID");
        }
    }

    private sealed class SnapshotRepository(IReadOnlyList<XElement> elements) : IXmlRepository
    {
        public IReadOnlyCollection<XElement> GetAllElements() => elements.Select(element => new XElement(element)).ToArray();
        public void StoreElement(XElement element, string friendlyName)
            => throw new InvalidOperationException("BACKUP_DP_WRITES_FORBIDDEN");
    }
}
