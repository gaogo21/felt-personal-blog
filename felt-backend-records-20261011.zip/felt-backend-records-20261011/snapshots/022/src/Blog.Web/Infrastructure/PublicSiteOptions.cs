namespace Blog.Web.Infrastructure;

// Only an explicitly supplied deployment origin may produce absolute SEO URLs.
// Request Host/forwarded headers and fixture domains never supply this value.
public sealed record PublicSiteOptions(string? Origin)
{
    public static PublicSiteOptions Read(IConfiguration configuration)
    {
        var value = configuration["Blog:PublicOrigin"];
        if (string.IsNullOrEmpty(value)) return new((string?)null);
        if (value.Any(char.IsControl) || value.Contains('\\') || value != value.Trim()
            || !Uri.TryCreate(value, UriKind.Absolute, out var origin)
            || origin.Scheme != "https" || origin.Host.Length == 0 || origin.UserInfo.Length != 0
            || origin.AbsolutePath != "/" || origin.Query.Length != 0 || origin.Fragment.Length != 0)
            throw new InvalidOperationException("PUBLIC_ORIGIN_INVALID");
        return new(origin.GetLeftPart(UriPartial.Authority));
    }

    public string? Canonical(string path)
    {
        if (Origin is null) return null;
        if (!path.StartsWith('/') || path.StartsWith("//", StringComparison.Ordinal)
            || path.Any(char.IsControl) || path.Contains('\\') || path.Contains('#'))
            throw new InvalidOperationException("CANONICAL_PATH_INVALID");
        return Origin + path;
    }
}
