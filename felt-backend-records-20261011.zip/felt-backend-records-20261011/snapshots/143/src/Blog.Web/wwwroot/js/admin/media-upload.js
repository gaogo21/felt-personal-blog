import { MEDIA_LIMITS } from './media-limits.js';

const STORAGE_KEY = 'felt.admin.media-upload.v1';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const isId = value => typeof value === 'string' && UUID.test(value);
const SHA256 = /^[a-f0-9]{64}$/;
const TYPES = Object.freeze({ jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', mp4: 'video/mp4' });
const TERMINAL_UPLOAD_CODES = new Set(['MALFORMED_REQUEST', 'VALIDATION_FAILED', 'FILE_TOO_LARGE', 'REQUEST_TOO_LARGE', 'MEDIA_TYPE_UNSUPPORTED']);
const terminalStates = new Set(['Rejected', 'Trashed', 'Purged']);

// One transfer owns one identity until the server confirms a terminal outcome.
// The session record contains a bounded manifest, never file bytes or credentials.
export function createMediaUploadController(options = {}) {
  const {
    onChange = () => {}, onReady = () => {},
    windowRef = globalThis.window, documentRef = globalThis.document,
    navigatorRef = globalThis.navigator, cryptoImpl = globalThis.crypto,
    fetchImpl = globalThis.fetch?.bind(globalThis),
    createXhr = () => new globalThis.XMLHttpRequest(),
    FormDataImpl = globalThis.FormData, AbortControllerImpl = globalThis.AbortController,
    setTimeoutImpl = globalThis.setTimeout.bind(globalThis),
    clearTimeoutImpl = globalThis.clearTimeout.bind(globalThis),
    now = Date.now, pollIntervalMs = 2000,
  } = options;
  let storage;
  try { storage = Object.hasOwn(options, 'storage') ? options.storage : windowRef?.sessionStorage; } catch { storage = null; }
  const readFile = options.readFileImpl || (file => {
    if (typeof file.arrayBuffer === 'function') return file.arrayBuffer();
    return new Promise((resolve, reject) => {
      const reader = new windowRef.FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error || new Error('FILE_READ_FAILED'));
      reader.readAsArrayBuffer(file);
    });
  });
  let current = { phase: 'idle', message: '选择 JPEG、PNG、WebP 图片或 MP4 视频。', progress: null,
    mediaId: null, mediaState: null, fileName: '', fileSize: 0, errorCode: null,
    pauseReason: null, recoveryExpired: false, recoveryAvailable: Boolean(storage) };
  let file = null, identity = null, terminal = false, blockedRecovery = false;
  let destroyed = false, generation = 0, requestController = null, xhr = null, timer = null;
  let sent = false, polling = false, notifiedId = null;
  const online = () => navigatorRef?.onLine !== false;
  const visible = () => documentRef?.visibilityState !== 'hidden';
  const expired = () => Boolean(identity && identity.attempted && !terminal && now() - identity.createdAt >= MEDIA_LIMITS.IdempotencyHours * 3600000);
  const busy = () => ['hashing', 'authorizing', 'uploading'].includes(current.phase);
  const unresolved = () => Boolean(blockedRecovery || (identity?.attempted && !terminal) || (current.mediaId && !terminal && current.phase !== 'ready'));
  const getState = () => {
    const recoveryExpired = blockedRecovery || expired();
    const uploadRetry = !destroyed && !busy() && !polling && file && identity && !recoveryExpired && (!current.mediaId || terminal);
    return { ...current, recoveryExpired,
      message: current.message + (!current.recoveryAvailable && current.phase !== 'idle' && !terminal ? ' 此浏览器无法保存上传恢复信息；刷新后请先检查媒体库。' : ''),
      requiresFile: Boolean(identity && !file && !current.mediaId && !terminal),
      canSelectFile: !destroyed && !busy() && !polling && !blockedRecovery && !recoveryExpired && !(current.mediaId && !terminal && current.phase !== 'ready'),
      canStart: !destroyed && current.phase === 'selected' && Boolean(file) && online() && !recoveryExpired,
      canRetry: Boolean(uploadRetry && ['unknown', 'auth', 'failed', 'paused'].includes(current.phase)),
      canCancel: !destroyed && (busy() || current.phase === 'processing' || Boolean(file && identity && !identity.attempted && !terminal)),
      canResume: !destroyed && Boolean(current.mediaId) && !polling && !busy() && ['paused', 'unknown', 'auth'].includes(current.phase),
      canForgetRecovery: !destroyed && !polling && !busy() && unresolved() && ['paused', 'unknown', 'auth'].includes(current.phase) };
  };
  const emit = patch => { if (!destroyed) { current = { ...current, ...patch }; onChange(getState()); } };
  const clearTimer = () => { if (timer !== null) clearTimeoutImpl(timer); timer = null; };
  const removeRecord = () => {
    try { storage?.removeItem(STORAGE_KEY); return true; } catch { current.recoveryAvailable = false; return false; }
  };
  const persist = () => {
    if (!identity?.attempted && !current.mediaId) return;
    const record = identity ? { v: 1, key: identity.key, sha256: identity.sha256, byteSize: identity.byteSize,
      mime: identity.mime, name: identity.name, createdAt: identity.createdAt, actorId: identity.actorId, mediaId: current.mediaId }
      : { v: 1, mediaId: current.mediaId };
    try { if (storage) storage.setItem(STORAGE_KEY, JSON.stringify(record)); else current.recoveryAvailable = false; }
    catch { current.recoveryAvailable = false; }
  };
  const safeCode = body => typeof body?.code === 'string' && /^[A-Z0-9_]{1,80}$/.test(body.code) ? body.code : null;
  const statusPath = id => `/api/admin/v1/media/${id}`;
  const abortRequests = () => {
    generation++; clearTimer(); requestController?.abort(); requestController = null;
    const pendingXhr = xhr; xhr = null; polling = false;
    pendingXhr?.abort();
  };
  const failTerminal = (code, message, mediaState = current.mediaState) => {
    terminal = true; clearTimer(); removeRecord();
    emit({ phase: 'failed', errorCode: code, message, mediaState, pauseReason: null, recoveryExpired: false });
  };
  const unknown = (message, code = null) => {
    persist(); emit({ phase: 'unknown', message, errorCode: code, pauseReason: null });
  };
  const fileManifest = candidate => {
    if (!candidate || typeof candidate.name !== 'string' || !Number.isSafeInteger(candidate.size) || candidate.size <= 0) throw new Error('请选择非空文件。');
    const name = candidate.name.normalize('NFC');
    if ([...name].length > 255 || /[\u0000-\u001f\u007f-\u009f/\\\uD800-\uDFFF]/u.test(name)) throw new Error('文件名无效，请移除路径、控制字符或缩短名称。');
    const extension = name.split('.').pop().toLowerCase(), expected = TYPES[extension];
    if (!name.includes('.') || !expected || (candidate.type && candidate.type !== expected)) throw new Error('仅支持扩展名与类型一致的 JPEG、PNG、WebP 图片和 MP4 视频。');
    const limit = expected === 'video/mp4' ? MEDIA_LIMITS.VideoBytes : MEDIA_LIMITS.ImageBytes;
    if (candidate.size > limit) throw new Error(expected === 'video/mp4' ? 'MP4 视频不能超过 200 MiB。' : '图片不能超过 10 MiB。');
    return { name, mime: expected, byteSize: candidate.size };
  };

  // An expired or corrupt recovery record must not silently become a new upload.
  try {
    const raw = storage?.getItem(STORAGE_KEY);
    if (raw) {
      if (raw.length > 2048) throw new Error('INVALID_RECOVERY');
      const record = JSON.parse(raw);
      if (record.v !== 1 || (record.mediaId !== null && record.mediaId !== undefined && !isId(record.mediaId))) throw new Error('INVALID_RECOVERY');
      if (record.key !== undefined) {
        if (!isId(record.key) || !isId(record.actorId) || typeof record.sha256 !== 'string' || !SHA256.test(record.sha256) || !Object.values(TYPES).includes(record.mime) || !Number.isFinite(record.createdAt) || record.createdAt < 0 || record.createdAt > now()) throw new Error('INVALID_RECOVERY');
        const manifest = fileManifest({ name: record.name, size: record.byteSize, type: record.mime });
        identity = { ...manifest, key: record.key, sha256: record.sha256, createdAt: record.createdAt, actorId: record.actorId, attempted: true };
      } else if (!record.mediaId) throw new Error('INVALID_RECOVERY');
      current = { ...current, phase: record.mediaId ? 'paused' : 'unknown', mediaId: record.mediaId || null,
        fileName: identity?.name || '', fileSize: identity?.byteSize || 0, pauseReason: 'recovery',
        message: record.mediaId ? '发现尚未确认完成的上传，请恢复查询处理状态。' : '上次上传结果未知。请重新选择完全相同的文件，以原请求标识重试。' };
      if (expired()) current.message = '上传恢复标识已超过 24 小时，请先检查媒体库；不能安全地重新提交此未知请求。';
    }
  } catch {
    blockedRecovery = true;
    current = { ...current, phase: 'unknown', recoveryExpired: true, message: '上传恢复记录无法校验，请先检查媒体库；不能安全地创建新请求。' };
  }

  async function selectFile(candidate) {
    if (destroyed) return false;
    if (busy() || polling) { emit({ message: '当前文件正在核验、上传或查询，暂不能更换。已保留当前文件；请先取消当前操作。' }); return false; }
    if (current.mediaId && !terminal && current.phase !== 'ready') { emit({ message: '当前上传尚未确认完成，暂不能更换文件。请先恢复状态查询。' }); return false; }
    if (blockedRecovery || expired()) { emit({ message: '上传恢复标识已失效，请先检查媒体库，确认之前上传的结果。' }); return false; }
    const recovering = unresolved(), priorPhase = current.phase;
    if (!recovering) {
      file = null; identity = null; terminal = false; sent = false; notifiedId = null;
      current = { ...current, phase: 'idle', fileName: '', fileSize: 0, mediaId: null, mediaState: null, progress: null, pauseReason: null };
    }
    let manifest;
    try { manifest = fileManifest(candidate); }
    catch (error) { emit({ message: error.message + (recovering ? ' 已保留上次上传恢复记录，请选择原文件。' : ''), errorCode: 'CLIENT_FILE_INVALID' }); return false; }
    const op = ++generation;
    emit({ phase: 'hashing', progress: null, message: '正在计算文件 SHA-256…', errorCode: null });
    try {
      if (!cryptoImpl?.subtle?.digest || !cryptoImpl?.randomUUID) throw new Error('此页面无法使用安全散列，请使用 HTTPS 和支持 Web Crypto 的浏览器。');
      const bytes = await readFile(candidate);
      if (destroyed || generation !== op) return false;
      const hash = await cryptoImpl.subtle.digest('SHA-256', bytes);
      if (destroyed || generation !== op) return false;
      const sha256 = Array.from(new Uint8Array(hash), value => value.toString(16).padStart(2, '0')).join('');
      if (recovering && (!identity || identity.name !== manifest.name || identity.mime !== manifest.mime || identity.byteSize !== manifest.byteSize || identity.sha256 !== sha256)) {
        emit({ phase: priorPhase, errorCode: 'RECOVERY_FILE_MISMATCH', message: '此文件与上次请求不一致。请选择相同名称、类型、大小及内容的原文件。' }); return false;
      }
      file = candidate;
      if (!recovering) {
        identity = { ...manifest, sha256, key: cryptoImpl.randomUUID(), createdAt: now(), attempted: false };
        terminal = false; sent = false; notifiedId = null;
      }
      emit({ phase: recovering ? 'unknown' : 'selected', fileName: manifest.name, fileSize: manifest.byteSize,
        mediaId: null, mediaState: null, pauseReason: null, errorCode: null,
        message: recovering ? '原文件已核验，可使用原请求标识重试。' : '文件已核验，可以开始上传。' });
      return true;
    } catch (error) {
      if (destroyed || generation !== op) return false;
      emit({ phase: recovering ? priorPhase : 'failed', errorCode: 'CLIENT_HASH_FAILED', message: error.message || '文件散列失败，请重新选择文件。' });
      return false;
    }
  }

  async function upload(fresh = false) {
    if (destroyed || busy() || polling || !file || !identity || blockedRecovery || expired() || (current.mediaId && !terminal)) return false;
    if (!online()) { emit({ phase: 'paused', pauseReason: 'offline-upload', message: '当前离线，请联网后手动重试上传。' }); return false; }
    if (fresh) {
      identity = { ...identity, key: cryptoImpl.randomUUID(), createdAt: now(), attempted: false };
      terminal = false; sent = false; notifiedId = null;
    }
    const op = ++generation;
    requestController = new AbortControllerImpl();
    emit({ phase: 'authorizing', mediaId: null, mediaState: null, errorCode: null, pauseReason: null, progress: 0, message: '正在验证登录状态…' });
    let csrf;
    try {
      const response = await fetchImpl('/api/admin/v1/session/bootstrap', { credentials: 'same-origin', cache: 'no-store', signal: requestController.signal });
      if (destroyed || generation !== op) return false;
      if (!response.ok) {
        emit({ phase: response.status === 401 || response.status === 403 ? 'auth' : 'paused', pauseReason: 'bootstrap', errorCode: `HTTP_${response.status}`,
          message: response.status === 401 || response.status === 403 ? '请重新登录，然后手动重试；原上传标识已保留。' : '无法验证登录状态，请稍后手动重试。' });
        return false;
      }
      const bootstrap = await response.json();
      if (destroyed || generation !== op) return false;
      const actorId = bootstrap?.session?.user?.id;
      if (!isId(actorId) || typeof bootstrap.csrfToken !== 'string' || !bootstrap.csrfToken) {
        emit({ phase: 'auth', errorCode: 'SESSION_REQUIRED', message: '请重新登录，然后手动重试；原上传标识已保留。' }); return false;
      }
      // Server idempotency keys are scoped to the authenticated administrator.
      // Retrying as another actor would create a separate upload with this key.
      if (identity.attempted && identity.actorId !== actorId) {
        emit({ phase: 'auth', errorCode: 'RECOVERY_ACTOR_MISMATCH', message: '当前登录账户与原上传账户不同。请使用原账户重试；恢复记录已保留。检查媒体库后可明确丢弃本页记录，但再次上传可能重复。' });
        return false;
      }
      identity.actorId = actorId;
      csrf = bootstrap.csrfToken;
    } catch {
      if (!destroyed && generation === op) emit({ phase: identity.attempted ? 'unknown' : 'paused', pauseReason: 'bootstrap', message: '无法取得安全验证信息，请手动重试。' });
      return false;
    } finally { if (generation === op) requestController = null; }
    if (destroyed || generation !== op) return false;
    if (expired()) { unknown('上传恢复标识已超过 24 小时，请先检查媒体库。'); return false; }
    return new Promise(resolve => {
      let request, settled = false;
      const finish = action => {
        if (settled) return; settled = true;
        if (xhr === request) xhr = null;
        if (!destroyed && generation === op) action();
        resolve(true);
      };
      try {
        const form = new FormDataImpl();
        form.append('sha256', identity.sha256);
        form.append('byteSize', String(identity.byteSize));
        const bodyFile = file.type === identity.mime ? file : file.slice(0, file.size, identity.mime);
        form.append('file', bodyFile, identity.name);
        request = createXhr(); xhr = request;
        request.open('POST', '/api/admin/v1/media/uploads', true);
        request.withCredentials = true;
        request.timeout = 180000;
        request.setRequestHeader('Idempotency-Key', identity.key);
        request.setRequestHeader('X-CSRF-TOKEN', csrf);
        request.upload.onprogress = event => {
          if (destroyed || generation !== op || xhr !== request) return;
          emit({ progress: event.lengthComputable && event.total > 0 ? Math.min(100, Math.max(0, Math.round(event.loaded / event.total * 100))) : null });
        };
        request.onload = () => finish(() => {
          let body = null;
          try { body = JSON.parse(request.responseText); } catch { /* A success without a valid identity is still unknown. */ }
          if (request.status === 202 && isId(body?.mediaId) && body.state === 'Processing' && body.statusUrl === statusPath(body.mediaId)) {
            emit({ phase: 'processing', mediaId: body.mediaId, mediaState: 'Processing', progress: 100, message: '上传已接收，正在处理；尚不能插入文章。', errorCode: null });
            persist(); schedulePoll(); return;
          }
          const code = safeCode(body);
          if (request.status === 401 || request.status === 403) {
            persist(); emit({ phase: 'auth', errorCode: code || `HTTP_${request.status}`, message: '登录或安全验证失效。请重新登录后使用原请求标识重试。' }); return;
          }
          // Only an explicit server validation rejection proves this request is terminal.
          if ([400, 413, 415, 422].includes(request.status) && TERMINAL_UPLOAD_CODES.has(code)) {
            failTerminal(code, '服务器已拒绝此次上传。可更换文件，或明确重试以创建新的上传请求。'); return;
          }
          unknown(request.status === 429 ? '上传暂时限流，请稍后使用原请求标识重试。' : request.status === 409 ? '上传请求仍在处理或存在冲突。请检查媒体库，或使用原请求标识重试。' : '上传结果尚未确认，请检查媒体库，或使用原请求标识重试。', code || `HTTP_${request.status}`);
        });
        request.onerror = () => finish(() => unknown('连接中断，服务器可能已接收文件。请使用原文件和原请求标识重试。', 'NETWORK_UNKNOWN'));
        request.ontimeout = () => finish(() => unknown('上传响应超时，服务器可能已接收文件。请使用原请求标识重试。', 'UPLOAD_TIMEOUT'));
        request.onabort = () => finish(() => unknown('传输已停止，但服务器可能已接收文件。请检查媒体库或使用原请求标识重试。', 'UPLOAD_ABORTED'));
        if (!identity.attempted) identity.createdAt = now();
        identity.attempted = true; sent = true; persist();
        emit({ phase: 'uploading', message: '正在上传…', progress: 0 });
        request.send(form);
      } catch {
        finish(() => unknown('上传未能确认完成，请使用原请求标识重试。', 'UPLOAD_START_FAILED'));
      }
    });
  }

  function schedulePoll() {
    clearTimer();
    if (destroyed || !current.mediaId || terminal || current.phase === 'ready') return;
    if (!online() || !visible()) {
      emit({ phase: 'paused', pauseReason: online() ? 'hidden' : 'offline', message: online() ? '页面暂不可见，状态查询已暂停。' : '当前离线，状态查询已暂停。' }); return;
    }
    timer = setTimeoutImpl(() => { timer = null; poll(); }, Math.max(250, pollIntervalMs));
  }
  async function poll() {
    if (destroyed || polling || !current.mediaId || terminal || current.phase === 'ready') return false;
    if (!online() || !visible()) { schedulePoll(); return false; }
    clearTimer(); polling = true;
    const op = ++generation, id = current.mediaId;
    requestController = new AbortControllerImpl();
    emit({ phase: 'processing', pauseReason: null, errorCode: null, message: '正在查询媒体处理状态…' });
    try {
      const response = await fetchImpl(statusPath(id), { credentials: 'same-origin', cache: 'no-store', signal: requestController.signal });
      if (destroyed || generation !== op) return false;
      if (!response.ok) {
        emit({ phase: response.status === 401 || response.status === 403 ? 'auth' : 'unknown', errorCode: `HTTP_${response.status}`, pauseReason: 'status',
          message: response.status === 401 || response.status === 403 ? '请重新登录，再手动恢复状态查询。' : response.status === 404 ? '此媒体暂未找到。请检查媒体库后手动恢复查询，不能确认已删除。' : '无法确认处理状态，请稍后手动恢复查询。' });
        return false;
      }
      const body = await response.json();
      if (destroyed || generation !== op) return false;
      if (body?.id !== id || !['Uploading', 'Processing', 'Ready', 'Rejected', 'Trashed', 'Purged'].includes(body.state) || !Number.isSafeInteger(body.version) || body.version < 1 || !body.metadata || typeof body.metadata !== 'object' || Array.isArray(body.metadata)
        || !['Image', 'Video'].includes(body.metadata.kind) || (identity && body.metadata.kind !== (identity.mime === 'video/mp4' ? 'Video' : 'Image'))) {
        unknown('服务器状态响应无法校验，请稍后手动恢复查询。', 'STATUS_INVALID'); return false;
      }
      if (body.state === 'Ready') {
        terminal = true; removeRecord();
        emit({ phase: 'ready', mediaState: 'Ready', progress: 100, errorCode: null, message: '媒体处理完成。可在媒体库中选择并插入文章。' });
        if (notifiedId !== id) { notifiedId = id; onReady(body); }
        return true;
      }
      if (terminalStates.has(body.state)) {
        failTerminal(safeCode({ code: body.errorCode }) || body.state.toUpperCase(), body.state === 'Rejected' ? '媒体处理失败，服务器已拒绝文件。可明确重试并创建新请求。' : '此媒体已不可用，请在媒体库中查看。', body.state);
        return false;
      }
      emit({ phase: 'processing', mediaState: body.state, message: body.state === 'Uploading' ? '服务器仍在接收文件，请等待状态更新。' : '服务器正在处理文件；完成后才可插入文章。' });
      schedulePoll(); return true;
    } catch {
      if (!destroyed && generation === op) unknown('连接中断，处理结果尚未确认。请手动恢复状态查询。', 'STATUS_NETWORK_UNKNOWN');
      return false;
    } finally {
      if (generation === op) { requestController = null; polling = false; emit({}); }
    }
  }
  function resume(id = current.mediaId) {
    if (destroyed || !isId(id)) return Promise.resolve(false);
    if (busy() || polling) {
      emit({ message: '当前文件正在核验、上传或查询，请先取消当前操作，再查询其他媒体。' });
      return Promise.resolve(false);
    }
    if (file && identity && !identity.attempted && !terminal) {
      emit({ message: '已有尚未上传的文件。请先取消当前选择，再查询其他媒体；当前文件已保留。' });
      return Promise.resolve(false);
    }
    // Library status does not expose the upload hash. An arbitrary row cannot
    // prove that an unknown POST finished, even when its MIME/size look similar.
    if (blockedRecovery || (unresolved() && current.mediaId !== id)) {
      emit({ message: '请先恢复当前上传：未知请求须使用原文件重试，不能用另一条媒体记录替代。' });
      return Promise.resolve(false);
    }
    if (current.mediaId !== id) {
      identity = null; file = null; sent = false;
      current = { ...current, fileName: '', fileSize: 0, progress: null, mediaState: null };
    }
    clearTimer(); terminal = false;
    emit({ mediaId: id, phase: 'paused', pauseReason: 'manual', errorCode: null });
    persist(); return poll();
  }
  function cancel() {
    if (destroyed) return;
    const phase = current.phase, hadSent = identity?.attempted || sent;
    abortRequests();
    if (current.mediaId && !terminal) {
      persist(); emit({ phase: 'paused', pauseReason: 'cancelled', message: '状态查询已暂停。服务器可能仍在处理文件，可手动恢复查询。' });
    } else if (hadSent && !terminal) {
      unknown('传输已停止，但服务器可能已接收文件。请检查媒体库或使用原请求标识重试。', 'UPLOAD_ABORTED');
    } else if (file && identity && !identity.attempted && !terminal && !['hashing', 'authorizing', 'uploading'].includes(phase)) {
      file = null; identity = null; sent = false; notifiedId = null;
      emit({ phase: 'idle', fileName: '', fileSize: 0, mediaId: null, mediaState: null, progress: null, errorCode: null, pauseReason: null,
        message: '已取消当前文件选择，文件尚未发送。' });
    } else if (['hashing', 'authorizing', 'uploading'].includes(phase)) {
      emit({ phase: file && identity ? 'selected' : 'idle', progress: null, message: '上传已取消，尚未确认发送文件。', pauseReason: null });
    }
  }
  function forgetRecovery({ confirmed = false } = {}) {
    if (!confirmed || !getState().canForgetRecovery) return false;
    if (!removeRecord()) { emit({ message: '无法清除本页恢复记录，请检查浏览器存储设置。' }); return false; }
    abortRequests(); identity = null; file = null; terminal = false; sent = false; blockedRecovery = false; notifiedId = null;
    emit({ phase: 'idle', mediaId: null, mediaState: null, fileName: '', fileSize: 0, progress: null, errorCode: null, pauseReason: null, recoveryExpired: false,
      message: '本页恢复记录已丢弃；服务器媒体没有删除，再次上传可能产生重复。' });
    return true;
  }
  function environmentChanged() {
    if (destroyed) return;
    if (!current.mediaId || terminal || current.phase === 'ready') { emit({}); return; }
    if ((!online() || !visible()) && current.phase === 'processing') {
      abortRequests(); schedulePoll();
    } else if (online() && visible() && current.phase === 'paused' && ['hidden', 'offline'].includes(current.pauseReason)) {
      poll();
    }
  }
  function destroy() {
    if (destroyed) return;
    if (unresolved()) persist();
    destroyed = true; abortRequests(); file = null;
    documentRef?.removeEventListener('visibilitychange', environmentChanged);
    windowRef?.removeEventListener('online', environmentChanged);
    windowRef?.removeEventListener('offline', environmentChanged);
    windowRef?.removeEventListener('pagehide', destroy);
  }
  documentRef?.addEventListener('visibilitychange', environmentChanged);
  windowRef?.addEventListener('online', environmentChanged);
  windowRef?.addEventListener('offline', environmentChanged);
  windowRef?.addEventListener('pagehide', destroy);
  emit({});
  return { getState, get state() { return getState(); }, selectFile,
    start: () => current.phase === 'selected' ? upload() : Promise.resolve(false),
    retry: () => getState().canRetry ? upload(terminal) : Promise.resolve(false),
    cancel, resume, destroy, forgetRecovery,
    hasPending: () => !destroyed && (unresolved() || busy() || Boolean(file && identity && !terminal) || current.phase === 'selected') };
}
