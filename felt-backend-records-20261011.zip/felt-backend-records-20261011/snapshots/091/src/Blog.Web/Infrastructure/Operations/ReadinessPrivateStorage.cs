using Blog.Web.Infrastructure.Backup;
using Blog.Web.Infrastructure.Media;

namespace Blog.Web.Infrastructure.Operations;

public interface IReadinessPrivateStorage
{
    void Validate(MediaStorageOptions media, BackupOptions backup, string webRoot, DateTimeOffset now);
}

public sealed class ReadinessPrivateStorage(IBackupKeyValidator keys) : IReadinessPrivateStorage
{
    public void Validate(MediaStorageOptions media, BackupOptions backup, string webRoot, DateTimeOffset now)
    {
        try
        {
            if (!backup.Enabled || media.MaxMediaBytes <= 0) throw new InvalidOperationException();
            backup.ValidateExistingFiles(webRoot);
            var root = BackupArchivePaths.Full(media.PrivateRoot);
            BackupArchivePaths.RequireSeparate(root, BackupArchivePaths.Full(webRoot));
            BackupArchivePaths.RequireSeparate(root, backup.DataProtectionRoot);
            BackupArchivePaths.RequireSeparate(root, backup.DestinationRoot);
            BackupArchivePaths.RequireSeparate(root, backup.EncryptionKeyFile);
            var mediaStamp = BackupArchivePaths.ReadStamp(root, directory: true);
            RequirePrivateDirectory(mediaStamp);
            foreach (var area in new[] { "quarantine", "work", "objects" })
            {
                var stamp = BackupArchivePaths.ReadStamp(Path.Combine(root, area), directory: true);
                RequirePrivateDirectory(stamp);
                if (stamp.DeviceMajor != mediaStamp.DeviceMajor || stamp.DeviceMinor != mediaStamp.DeviceMinor)
                    throw new InvalidOperationException();
            }
            RequirePrivateDirectory(BackupArchivePaths.ReadStamp(backup.DataProtectionRoot, directory: true));
            keys.Validate(backup.DataProtectionRoot, now);
        }
        catch (Exception error) when (error is not OutOfMemoryException)
        {
            throw new InvalidOperationException("READINESS_PRIVATE_STORAGE_UNAVAILABLE");
        }
    }

    // Read-only no-follow handles inspect the fixed existing directories. This
    // checks private owner permissions and same-device media areas, not capacity,
    // mount health, fsync behavior, actual writability, or every stored object.
    // Those need separate operational evidence; the probe creates nothing.
    private static void RequirePrivateDirectory(BackupArchiveFileStamp stamp)
    {
        if ((stamp.Mode & 0x1ff) != 0x1c0) throw new InvalidOperationException();
    }
}
