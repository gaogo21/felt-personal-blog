using Blog.Web.Api.Admin.V1;
using Blog.Web.Application.Media;
namespace Blog.Web.Infrastructure.Media;
public static class MediaHosting
{
    public static IServiceCollection AddMediaPipeline(this IServiceCollection services)
    {
        services.AddSingleton(sp => MediaStorageOptions.Read(sp.GetRequiredService<IConfiguration>()));
        services.AddSingleton<PrivateMediaStorage>();
        services.AddSingleton<UploadSlots>();
        services.AddSingleton(sp => sp.GetRequiredService<IConfiguration>().GetSection("Media:Tools").Get<MediaToolOptions>() ?? new MediaToolOptions());
        services.AddSingleton<IMediaFileProcessor, ToolMediaFileProcessor>();
        services.AddScoped<IMediaPersistence, PostgresMediaPersistence>();
        services.AddScoped<MediaUploadService>(); services.AddScoped<MediaProcessingService>();
        services.AddHostedService<MediaProcessingWorker>();
        return services;
    }
}
public sealed class MediaProcessingWorker(IServiceScopeFactory scopes, IHostEnvironment environment, IConfiguration config, TimeProvider clock, ILogger<MediaProcessingWorker> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Component tests drive leases explicitly through isolated stores; never contact PostgreSQL in a test host.
        if (environment.EnvironmentName == "ComponentTests") return;
        var sweepAt = clock.GetUtcNow();
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await using var scope = scopes.CreateAsyncScope(); var service = scope.ServiceProvider.GetRequiredService<MediaProcessingService>();
                var processed = await service.RunOneAsync(stoppingToken);
                if (clock.GetUtcNow() >= sweepAt && !config.GetValue<bool>("Maintenance:ReadOnly"))
                { await service.SweepOrphansAsync(stoppingToken); sweepAt = clock.GetUtcNow().AddHours(1); }
                if (!processed) await Task.Delay(TimeSpan.FromSeconds(1), stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { break; }
            catch (Exception)
            {
                logger.LogWarning("Media worker is unavailable; private tasks remain pending. Code: MEDIA_WORKER_UNAVAILABLE");
                await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
            }
        }
    }
}
