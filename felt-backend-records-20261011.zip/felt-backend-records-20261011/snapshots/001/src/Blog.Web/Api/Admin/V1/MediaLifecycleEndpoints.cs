using Blog.Web.Application.Administration;
using Blog.Web.Application.Media;
using Blog.Web.Application.Security;
using Blog.Web.Infrastructure.Administration;

namespace Blog.Web.Api.Admin.V1;

public static class MediaLifecycleEndpoints
{
    public static void MapAdminMediaLifecycleEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/admin/v1/media/{id:guid}").RequireAuthorization(AdminSecurityService.Policy);
        group.MapGet("/references", async (Guid id, HttpContext context, MediaLifecycleService service) =>
        {
            NoQuery(context);
            await AdminApiHosting.WriteMutation(context, await service.ReferencesAsync(
                AdminActor.From(context.User, context.TraceIdentifier), id, context.RequestAborted));
        });
        group.MapGet("/deletion", async (Guid id, HttpContext context, MediaLifecycleService service) =>
        {
            NoQuery(context);
            var result = await service.ReadDeletionAsync(id, context.RequestAborted);
            context.Response.Headers.ETag = new EntityVersion(ResourceKind.Media, id, result.Version).ETag;
            return Results.Json(result);
        });
        group.MapPost("/trash", async (Guid id, HttpContext context, MediaLifecycleService service) =>
        {
            NoQuery(context);
            var input = await AdminJsonBody.Read<MediaStateInput>(context, 1024);
            await AdminApiHosting.WriteMutation(context, await service.TrashAsync(AdminActor.From(context.User, context.TraceIdentifier), id,
                context.Request.Headers.IfMatch, IdempotencyKey.Require(context.Request.Headers["Idempotency-Key"]), input, context.RequestAborted));
        });
        group.MapPost("/restore", async (Guid id, HttpContext context, MediaLifecycleService service) =>
        {
            NoQuery(context);
            var input = await AdminJsonBody.Read<MediaStateInput>(context, 1024);
            await AdminApiHosting.WriteMutation(context, await service.RestoreAsync(AdminActor.From(context.User, context.TraceIdentifier), id,
                context.Request.Headers.IfMatch, IdempotencyKey.Require(context.Request.Headers["Idempotency-Key"]), input, context.RequestAborted));
        });
        group.MapPost("/purge", async (Guid id, HttpContext context, MediaLifecycleService service) =>
        {
            NoQuery(context);
            var input = await AdminJsonBody.Read<MediaPurgeInput>(context, 1024);
            await AdminApiHosting.WriteMutation(context, await service.PurgeAsync(AdminActor.From(context.User, context.TraceIdentifier),
                AdminSecurityService.SessionId(context.User) ?? throw new ApiFailure(ProblemCode.SESSION_REQUIRED), id,
                context.Request.Headers.IfMatch, IdempotencyKey.Require(context.Request.Headers["Idempotency-Key"]), input, context.RequestAborted));
        });
    }
    private static void NoQuery(HttpContext context)
    { if (context.Request.Query.Count != 0) throw new ApiFailure(ProblemCode.MALFORMED_REQUEST); }
}
