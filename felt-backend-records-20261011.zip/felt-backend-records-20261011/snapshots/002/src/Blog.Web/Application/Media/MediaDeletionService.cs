using System.Text.Json;
using Blog.Web.Application.Administration;
using Blog.Web.Domain;
using Blog.Web.Domain.Persistence;

namespace Blog.Web.Application.Media;

public sealed class MediaDeletionService(IMediaLifecycleStore store, IAdminMutationStore transactions,
    IMediaLifecycleFiles files, TimeProvider clock)
{
    // Reuse the approved processing time budget and recovery grace. This is an internal
    // lease, not a retention policy: no job is created without the explicit purge command.
    public const int LeaseSeconds = ContentLimits.ProcessingTimeoutSeconds + 30;

    public Task<MediaDeletionLease?> ClaimAsync(CancellationToken ct)
        => transactions.InTransactionAsync<MediaDeletionLease?>(async (tx, token) =>
        {
            var candidate = await store.CandidateAsync(clock.GetUtcNow(), token);
            if (candidate is null) return null;
            await tx.LockAsync(new(false, media: [candidate.MediaId]), token);
            var media = await store.ReadTrackedAsync(candidate.MediaId, token);
            var job = await store.JobTrackedAsync(candidate.MediaId, token);
            var now = clock.GetUtcNow();
            // The candidate is only a hint. A competing process may have claimed or completed
            // it while this transaction waited for the shared media row lock.
            if (job?.Id != candidate.JobId || job.State != JobState.Pending
                && !(job.State == JobState.Leased && job.LeaseUntil <= now)) return null;
            if (media?.State != MediaState.Trashed)
            {
                Fail(tx, media, job, "MEDIA_DELETION_STATE_INVALID", false, now);
                return null;
            }
            if (job.AttemptCount >= ContentLimits.AutomaticRetries + 1)
            {
                Fail(tx, media, job, "MEDIA_RETRY_EXHAUSTED", false, now);
                return null;
            }
            MediaFileIdentity identity;
            try { identity = MediaLifecycleService.Identity(media); }
            catch (ApiFailure)
            {
                Fail(tx, media, job, "MEDIA_FILE_INVALID", false, now);
                return null;
            }
            var lease = Guid.NewGuid();
            job.State = JobState.Leased; job.AttemptCount++; job.LeaseToken = lease;
            job.LeaseUntil = now.AddSeconds(LeaseSeconds); job.UpdatedAt = now;
            media.RowVersion = checked(media.RowVersion + 1);
            return new(job.Id, media.Id, lease, job.LeaseUntil.Value, media.RowVersion, identity);
        }, ct);

    public Task<bool> CompleteAsync(MediaDeletionLease lease, CancellationToken ct)
        => transactions.InTransactionAsync(async (tx, token) =>
        {
            await tx.LockAsync(new(false, media: [lease.MediaId]), token);
            var media = await store.ReadTrackedAsync(lease.MediaId, token);
            var job = await store.JobTrackedAsync(lease.MediaId, token);
            // Rechecking after the row lock fences both late processes and changed objects.
            // The lock is retained through file IO, fsync, audit and transaction commit.
            if (media?.State != MediaState.Trashed || media.RowVersion != lease.MediaVersion
                || job?.Id != lease.JobId || job.State != JobState.Leased || job.LeaseToken != lease.Token
                || job.LeaseUntil != lease.LeaseUntil || job.LeaseUntil <= clock.GetUtcNow()
                || media.Id != lease.Identity.MediaId || media.StorageKey != lease.Identity.StorageKey
                || media.ByteSize != lease.Identity.ByteSize || media.Sha256 != lease.Identity.Sha256) return false;

            // Even a corrupt or unexpected reference must fail closed before touching disk.
            if ((await store.ReferencesAsync(media.Id, token)).Total != 0)
            {
                Fail(tx, media, job, "MEDIA_REFERENCED", false, clock.GetUtcNow());
                return false;
            }
            if (job.LeaseUntil <= clock.GetUtcNow()) return false;
            try { await files.DeleteExactAsync(lease.Identity, token); }
            catch (MediaLifecycleFileFailure failure)
            {
                Fail(tx, media, job, failure.Code, failure.IsTransient, clock.GetUtcNow());
                return false;
            }
            catch (Exception error) when (error is IOException or UnauthorizedAccessException)
            {
                Fail(tx, media, job, "MEDIA_STORAGE_UNAVAILABLE", true, clock.GetUtcNow());
                return false;
            }
            // A lease that expires during IO still owns the row lock. A replacement worker
            // cannot obtain the lock or a new token until this completion commits/rolls back.
            // DB failures and cancellation bubble: the old durable lease is reclaimed, and
            // an already absent exact file is an idempotent success on that later attempt.
            var prior = media.RowVersion;
            media.State = MediaState.Purged; media.ErrorCode = null; media.RowVersion = checked(prior + 1);
            job.State = JobState.Succeeded; job.LeaseUntil = null; job.LeaseToken = null; job.LastError = null; job.UpdatedAt = clock.GetUtcNow();
            tx.Add(Audit(job, AuditAction.MediaPurged, prior, media.RowVersion, job.UpdatedAt));
            return true;
        }, ct);

    public async Task<bool> RunOneAsync(CancellationToken ct)
    {
        var lease = await ClaimAsync(ct);
        if (lease is null) return false;
        using var budget = CancellationTokenSource.CreateLinkedTokenSource(ct);
        budget.CancelAfter(TimeSpan.FromSeconds(ContentLimits.ProcessingTimeoutSeconds));
        await CompleteAsync(lease, budget.Token);
        return true;
    }

    private static void Fail(IAdminMutationTransaction tx, MediaAsset? media, MediaDeletionJob job,
        string code, bool transient, DateTimeOffset now)
    {
        job.State = transient && job.AttemptCount <= ContentLimits.AutomaticRetries ? JobState.Pending : JobState.Failed;
        job.LastError = code; job.LeaseUntil = null; job.LeaseToken = null; job.UpdatedAt = now;
        long? prior = null;
        // Preserve unexpected terminal/public states while failing the inconsistent job.
        if (media?.State == MediaState.Trashed)
        {
            prior = media.RowVersion; media.RowVersion = checked(media.RowVersion + 1); media.ErrorCode = code;
        }
        tx.Add(Audit(job, AuditAction.MediaPurgeFailed, prior, prior is null ? null : media!.RowVersion, now));
    }
    private static AuditEvent Audit(MediaDeletionJob job, AuditAction action, long? before, long? after, DateTimeOffset now)
        => new()
        {
            Id = Guid.NewGuid(), ActorUserId = job.RequestedBy, Action = action.ToString(), EntityType = AuditEntity.Media.ToString(),
            EntityId = job.MediaId, OldVersion = before, NewVersion = after, OccurredAt = now, RequestId = Guid.NewGuid().ToString("N"),
            Summary = JsonSerializer.Serialize(new AuditFacts(FromState: AuditState.Trashed,
                ToState: action == AuditAction.MediaPurged ? AuditState.Purged : AuditState.Trashed), ApiJson.Options)
        };
}
