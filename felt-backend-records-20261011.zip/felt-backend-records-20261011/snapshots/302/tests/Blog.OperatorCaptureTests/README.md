# Stopped-service backup command fixtures

This executable checks the explicit `capture-stopped` command using fake terminal input, clock, capture and ledger boundaries. Generated temporary directories test the existing file receipt implementation and the cooperating Linux instance lock. A child copy of this test executable probes only a generated lock directory; it never dispatches the application command.

The checks cover default disablement, exact argument/TTY/UUID/attestation rules, lock and fresh-key preflight failures, shared F25 capture/receipt semantics, separate operator and HTTP actor ownership, stable success replay, refusal of pending/unknown/failed receipts, cancellation settling, safe output, existing lock validation, cross-process exclusion, and web-worker/capture settling before release.

No PostgreSQL connection or service, real key material, user media, backup dump, listener, or hosted worker is used. The generated 32-byte preflight fixture is not an application key. The suite does not prove production filesystem durability, remote writer exclusion, successful database restore, or recovery timing.

The command requires `Operator:Capture:Enabled=true`, the existing explicit `Backup` configuration and prerequisites, an interactive terminal, a nonempty canonical UUID operation key, and exactly:

`CREATE ENCRYPTED BACKUP; SERVICE STOPPED; NO EXTERNAL WRITERS`

The reserved operator receipt owner is the empty UUID, which the HTTP `AdminActor` boundary rejects. Command and HTTP operations therefore share the same F25 engine and request hash while retaining separate actor/key receipt namespaces. An interrupted pending receipt requires deliberate operator reconciliation, never automatic retry with that key.

The permanent empty `.blog-instance.lock` in the configured backup destination is created as 0600 or an existing private regular single-link file is required. It is never removed or replaced on release. Every cooperating web and command process must use the same destination on the same host. This advisory lock cannot exclude external tools, a different destination, or remote writers; the terminal attestation remains mandatory. The web host must retain the lease until its actual worker tasks, admitted child work, and active maintenance operation have settled, even when normal host shutdown stops waiting sooner.

After the owner-controlled build lane has built current sources:

```sh
dotnet run --project tests/Blog.OperatorCaptureTests --no-build --no-restore
```

Structured output is written to `artifacts/f26/operator-capture-results.json`.
