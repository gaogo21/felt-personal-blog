using Blog.Web.Infrastructure.Backup;

namespace Blog.Web.Infrastructure.Operations;

public sealed record OperatorCaptureOptions(bool Enabled)
{
    public static OperatorCaptureOptions Read(IConfiguration configuration)
        => new(configuration.GetValue<bool>("Operator:Capture:Enabled"));
}

public interface IOperatorCapturePreflight
{
    void Validate();
}

public sealed class OperatorCapturePreflight(BackupOptions options, IConfiguration configuration,
    IWebHostEnvironment environment, IBackupKeyValidator keys, TimeProvider clock) : IOperatorCapturePreflight
{
    public void Validate()
    {
        if (!options.Enabled || configuration["Blog:Mode"] != "PostgreSql")
            throw new InvalidOperationException("OPERATOR_CAPTURE_CONFIGURATION_REQUIRED");
        options.ValidateExistingFiles(environment.WebRootPath);
        // Use the same fresh, read-only existing-key validation as web startup
        // and capture. This never generates or repairs Data Protection keys.
        keys.Validate(options.DataProtectionRoot, clock.GetUtcNow());
    }
}
