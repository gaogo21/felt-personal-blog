using System.Security.Cryptography;
using Blog.ApiFoundationTests;
using Blog.SecurityTests;
using Blog.Web.Application.Media;
using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Media;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;

namespace Blog.MediaReadTests;

// Explicit non-database graph fixture. EnumerableQuery runs the production visibility expression,
// but cannot establish PostgreSQL translation, transactions, isolation or cross-process guarantees.
internal sealed class GraphReadStore : IMediaReadStore
{
    public List<MediaAsset> Media { get; } = [];
    public List<Article> Articles { get; } = [];
    public List<ArticleRevision> Revisions { get; } = [];
    public List<RevisionMediaReference> References { get; } = [];
    public List<GallerySlot> Gallery { get; } = [];
    public List<ColumnMediaSlot> ColumnSlots { get; } = [];
    public List<Column> Columns { get; } = [];
    public List<DesignAssetSlot> Design { get; } = [];
    // These are deliberately excluded from the public visibility query.
    public List<ArticleDraft> Drafts { get; } = [];
    public List<DraftMediaReference> DraftReferences { get; } = [];
    public List<(Guid Id, bool Administrator)> Reads { get; } = [];
    public bool FailRead { get; set; }
    public Task<MediaReadAsset?> FindVisibleAsync(Guid id, bool administrator, CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested(); Reads.Add((id, administrator));
        if (FailRead) throw new IOException("F12_PRIVATE_STORE_SENTINEL_AND_DATABASE_PASSWORD");
        return Task.FromResult(PostgresMediaReadStore.VisibleQuery(Media.AsQueryable(), Articles.AsQueryable(),
            Revisions.AsQueryable(), References.AsQueryable(), Gallery.AsQueryable(), ColumnSlots.AsQueryable(),
            Columns.AsQueryable(), Design.AsQueryable(), id, administrator).SingleOrDefault());
    }
    public Article Publish(MediaAsset asset, MediaUsage? usage = null)
    {
        var article = new Article { Id = Guid.NewGuid(), State = ArticleState.Published, PublishedRevisionId = Guid.NewGuid() };
        Articles.Add(article);
        Revisions.Add(new ArticleRevision { Id = article.PublishedRevisionId.Value, ArticleId = article.Id, CoverMediaId = usage is null ? asset.Id : null });
        if (usage is { } kind) References.Add(new RevisionMediaReference { RevisionId = article.PublishedRevisionId.Value, MediaId = asset.Id, Usage = kind });
        return article;
    }
}
internal sealed class MediaReadEnvironment(string root) : IWebHostEnvironment
{
    public string ApplicationName { get; set; } = "Blog.Web";
    public string EnvironmentName { get; set; } = "ComponentTests";
    public string ContentRootPath { get; set; } = root;
    public string WebRootPath { get; set; } = Path.Combine(root, "wwwroot");
    public IFileProvider ContentRootFileProvider { get; set; } = new NullFileProvider();
    public IFileProvider WebRootFileProvider { get; set; } = new NullFileProvider();
}
internal sealed class ReadProbe(IProtectedMediaFiles inner) : IProtectedMediaFiles
{
    private int readCalls, opens, disposals;
    public int ReadCalls => Volatile.Read(ref readCalls);
    public int Opens => Volatile.Read(ref opens);
    public int Disposals => Volatile.Read(ref disposals);
    public bool FailOpen { get; set; }
    public Func<int, CancellationToken, ValueTask>? BeforeReadAsync { get; set; }
    public Stream Open(MediaReadAsset asset)
    {
        Interlocked.Increment(ref opens);
        if (FailOpen) throw new IOException("F12_PRIVATE_FILE_SENTINEL_AND_ABSOLUTE_PATH");
        return new ObservedStream(inner.Open(asset), async ct =>
        {
            var call = Interlocked.Increment(ref readCalls);
            if (BeforeReadAsync is { } before) await before(call, ct);
        }, () => Interlocked.Increment(ref disposals));
    }
    private sealed class ObservedStream(Stream inner, Func<CancellationToken, ValueTask> read, Action disposed) : Stream
    {
        private bool closed;
        public override bool CanRead => inner.CanRead;
        public override bool CanSeek => inner.CanSeek;
        public override bool CanWrite => false;
        public override long Length => inner.Length;
        public override long Position { get => inner.Position; set => inner.Position = value; }
        public override int Read(byte[] buffer, int offset, int count) { read(default).AsTask().GetAwaiter().GetResult(); return inner.Read(buffer, offset, count); }
        public override int Read(Span<byte> buffer) { read(default).AsTask().GetAwaiter().GetResult(); return inner.Read(buffer); }
        public override async Task<int> ReadAsync(byte[] buffer, int offset, int count, CancellationToken ct) { await read(ct); return await inner.ReadAsync(buffer, offset, count, ct); }
        public override async ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken ct = default) { await read(ct); return await inner.ReadAsync(buffer, ct); }
        public override long Seek(long offset, SeekOrigin origin) => inner.Seek(offset, origin);
        public override void Flush() => inner.Flush();
        public override void SetLength(long value) => throw new NotSupportedException();
        public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
        protected override void Dispose(bool disposing)
        {
            if (disposing && !closed) { closed = true; inner.Dispose(); disposed(); }
            base.Dispose(disposing);
        }
        public override async ValueTask DisposeAsync()
        {
            if (!closed) { closed = true; await inner.DisposeAsync(); disposed(); }
            GC.SuppressFinalize(this);
        }
    }
}
internal sealed class MediaReadScenario : IAsyncDisposable
{
    // Generated delivery bytes are intentionally not a media-decoder fixture; F11 owns decoding.
    public static readonly byte[] Bytes = Enumerable.Range(0, 257).Select(x => (byte)(x % 251)).ToArray();
    public string Root { get; }
    public GraphReadStore Store { get; } = new();
    public PrivateMediaStorage Storage { get; }
    public SecurityFactory Factory { get; }
    public ReadProbe Probe { get; private set; } = null!;
    public int FileServiceResolutions { get; private set; }
    public HttpClient Http { get; }
    public ApiClient Api { get; }
    public MediaReadScenario(string runRoot, bool failReaderFactory = false)
    {
        Root = Path.Combine(runRoot, Guid.NewGuid().ToString("N"));
        var options = new MediaStorageOptions(Root, 1024 * 1024);
        Storage = new(options, new MediaReadEnvironment(Path.Combine(runRoot, "host")));
        Factory = new(services =>
        {
            services.RemoveAll<IMediaReadStore>(); services.AddSingleton<IMediaReadStore>(Store);
            services.RemoveAll<MediaStorageOptions>(); services.AddSingleton(options);
            services.RemoveAll<PrivateMediaStorage>(); services.AddSingleton(Storage);
            // Preserve the production reader implementation and wrap only its return stream.
            var original = services.Last(x => x.ServiceType == typeof(IProtectedMediaFiles));
            services.RemoveAll<IProtectedMediaFiles>();
            services.AddSingleton<IProtectedMediaFiles>(provider =>
            {
                FileServiceResolutions++;
                if (failReaderFactory) throw new IOException("F12_PRIVATE_READER_CONSTRUCTION_SENTINEL");
                var implementation = original.ImplementationInstance
                    ?? original.ImplementationFactory?.Invoke(provider)
                    ?? ActivatorUtilities.CreateInstance(provider, original.ImplementationType!);
                Probe = new((IProtectedMediaFiles)implementation); return Probe;
            });
            foreach (var descriptor in services.Where(x => x.ServiceType == typeof(IHostedService) && x.ImplementationType?.Namespace?.Contains("Media", StringComparison.Ordinal) == true).ToArray()) services.Remove(descriptor);
        });
        Http = Factory.CreateClient(new WebApplicationFactoryClientOptions { BaseAddress = new("https://localmock.invalid"), AllowAutoRedirect = false, HandleCookies = false });
        if (Factory.Server is not TestServer) throw new InvalidOperationException("F12 permits only in-process TestServer");
        Api = new(Http);
        if (!failReaderFactory) _ = Factory.Services.GetRequiredService<IProtectedMediaFiles>();
    }
    public MediaAsset Asset(bool gallery = false, string mime = "image/png", MediaState state = MediaState.Ready, byte[]? payload = null)
    {
        payload ??= Bytes;
        var id = Guid.NewGuid(); var key = Storage.FinalKey(id, Guid.NewGuid(), mime);
        File.WriteAllBytes(Storage.Resolve(key), payload);
        var asset = new MediaAsset
        {
            Id = id, StorageKey = key, OriginalFileName = "F12_PRIVATE_ORIGINAL_FILENAME.png", State = state,
            Kind = mime == "video/mp4" ? MediaKind.Video : MediaKind.Image,
            MimeType = mime, ByteSize = payload.Length, Sha256 = Convert.ToHexStringLower(SHA256.HashData(payload)),
            UploadSha256 = Convert.ToHexStringLower(SHA256.HashData(payload)), Width = 2, Height = 2,
            DurationMs = mime == "video/mp4" ? 1000 : null
        };
        Store.Media.Add(asset);
        if (gallery) Store.Gallery.Add(new GallerySlot { Slot = (short)(Store.Gallery.Count + 1), MediaId = id });
        return asset;
    }
    public async Task<HttpResponseMessage> Send(Guid id, HttpMethod? method = null, bool authenticated = false, params (string Name, string Value)[] headers)
        => await SendPath("/media/" + id.ToString("D"), method, authenticated, headers);
    public async Task<HttpResponseMessage> SendPath(string path, HttpMethod? method = null, bool authenticated = false, params (string Name, string Value)[] headers)
    {
        using var request = new HttpRequestMessage(method ?? HttpMethod.Get, path);
        if (authenticated && Api.Cookies.Count > 0) request.Headers.Add("Cookie", string.Join("; ", Api.Cookies.Select(x => x.Key + "=" + x.Value)));
        foreach (var (name, value) in headers) request.Headers.TryAddWithoutValidation(name, value);
        return await Http.SendAsync(request);
    }
    public async ValueTask DisposeAsync() { Api.Dispose(); await Factory.DisposeAsync(); }
}
