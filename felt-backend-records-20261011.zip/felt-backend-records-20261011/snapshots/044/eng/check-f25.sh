#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p artifacts/f25
bash eng/check-f22.sh
for item in MaintenanceGate BackupArchive BackupDatabase BackupControl; do
  "${BLOG_DOTNET_BIN:-dotnet}" run --project "tests/Blog.${item}Tests" --no-build --no-restore | tee "artifacts/f25/${item}-output.txt"
done
set +e
python3 eng/backup-dry-run.py --dry-run > artifacts/f25/dry-run.json
result=$?
set -e
test "$result" -eq 2
python3 - <<'PY'
from pathlib import Path
import json, shutil
out=Path('artifacts/f25')
for source in Path('artifacts/f22').glob('*'):
    if source.is_file() and (source.suffix == '.json' or source.name in ('editor-test-output.txt','media-upload-output.txt')):
        shutil.copy2(source,out/source.name)
checks={}
for name in ('MaintenanceGate','BackupArchive','BackupDatabase','BackupControl'):
    lines=(out/f'{name}-output.txt').read_text().splitlines()
    checks[name]={'passed':sum(x.startswith('PASS ') for x in lines),'failed':sum(x.startswith('FAIL ') for x in lines)}
    assert checks[name]['passed']>0 and checks[name]['failed']==0
(out/'backup-aggregate-results.json').write_text(json.dumps({'scope':'Isolated fixtures and in-process HTTP only; no real PostgreSQL dump/restore, production keys, off-host upload or browser', 'checks':checks,'dryRunExit':2,'postgresqlIntegration':'blocked','physicalCrash':'pending','productionRestore':'pending'},indent=2)+'\n')
PY
