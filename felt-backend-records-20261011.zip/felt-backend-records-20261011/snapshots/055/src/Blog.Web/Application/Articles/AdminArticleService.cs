using System.Text.Json;
using Blog.Web.Application.Administration;
using Blog.Web.Domain.Persistence;
using Blog.Web.Application.RichText;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Primitives;
using Npgsql;

namespace Blog.Web.Application.Articles;

public sealed class AdminArticleService(IAdminArticleStore store, AdminMutationExecutor mutations, IDraftBodyBoundary bodyBoundary, TimeProvider clock)
{
    public Task<AdminArticlePage> ListAsync(ArticleFilter filter, CancellationToken ct) => store.ListAsync(filter, ct);
    public async Task<ArticleView> ReadAsync(Guid id, CancellationToken ct) => View(await RequireAsync(id, false, ct));
    public async Task<DraftView> ReadDraftAsync(Guid id, CancellationToken ct)
    {
        var read = await RequireAsync(id, false, ct);
        if (read.Article.State == ArticleState.Purged) throw new ApiFailure(ProblemCode.STATE_CONFLICT);
        return Draft(RequireDraft(read));
    }
    public async Task<(ArticleView Article, DraftView Draft)> ReadWorkingSnapshotAsync(Guid id, CancellationToken ct)
    {
        var read = await RequireAsync(id, false, ct);
        return (View(read), Draft(RequireDraft(read)));
    }
    public Task<MutationResponse> CreateAsync(AdminActor actor, Guid key, CreateArticleInput input, CancellationToken ct)
    {
        var title = ArticleInput.Text(input.Title ?? "", Domain.ContentLimits.TitleScalars, "title");
        var slug = input.Slug is null ? null : ArticleInput.Slug(input.Slug);
        return WithSlugConflict(() => mutations.ExecuteAsync(actor, "article.create", "", key, JsonSerializer.SerializeToElement(new { title, slug }, ApiJson.Options), new(false), async (_, token) =>
        {
            var id = Guid.NewGuid(); var value = slug ?? "article-" + id.ToString("D");
            if (await store.SlugExistsAsync(value, null, token)) throw new ApiFailure(ProblemCode.DUPLICATE_SLUG);
            var now = clock.GetUtcNow();
            var article = new Article { Id = id, Slug = value, State = ArticleState.Draft, CreatedAt = now, CreatedBy = actor.UserId };
            var draft = new ArticleDraft { ArticleId = id, Title = title, ContentJson = RichTextSchema.EmptyJson, UpdatedAt = now, UpdatedBy = actor.UserId };
            draft.ContentHash = ArticleInput.ContentHash(Input(draft)); store.Add(article, draft);
            return new(MutationResponse.Json(201, new { article = View(new(article, draft, null)), draft = Draft(draft) }, Version(article), "/api/admin/v1/articles/" + id.ToString("D")), new(AuditAction.ArticleCreated, AuditEntity.Article, id, null, 1));
        }, ct));
    }
    public Task<MutationResponse> ChangeIdentityAsync(AdminActor actor, Guid id, StringValues ifMatch, IdentityInput input, CancellationToken ct)
    {
        if (id == Guid.Empty) throw new ApiFailure(ProblemCode.NOT_FOUND);
        var slug = ArticleInput.Slug(input.Slug);
        return WithSlugConflict(() => mutations.ExecuteWithoutKeyAsync(actor, new(false, [id]), async (_, token) =>
        {
            var read = await RequireAsync(id, true, token); var article = read.Article;
            Version(article).RequireMatch(ifMatch); RequireEditable(article);
            if (article.FirstPublishedAt is not null) throw new ApiFailure(ProblemCode.STATE_CONFLICT);
            if (article.Slug == slug) return new(MutationResponse.Json(200, View(read), Version(article)), null);
            if (await store.SlugExistsAsync(slug, id, token)) throw new ApiFailure(ProblemCode.DUPLICATE_SLUG);
            var prior = article.RowVersion; article.Slug = slug; article.RowVersion = checked(prior + 1);
            return new(MutationResponse.Json(200, View(read), Version(article)), new(AuditAction.ArticleIdentityChanged, AuditEntity.Article, id, prior, article.RowVersion));
        }, ct));
    }
    public Task<MutationResponse> SaveDraftAsync(AdminActor actor, Guid id, StringValues ifMatch, DraftInput input, CancellationToken ct)
    {
        if (id == Guid.Empty) throw new ApiFailure(ProblemCode.NOT_FOUND);
        var normalized = ArticleInput.Normalize(input);
        var body = bodyBoundary.Validate(normalized.ContentJson, normalized.SchemaVersion);
        return mutations.ExecuteWithoutKeyAsync(actor, new(false, [id]), async (tx, token) =>
        {
            var read = await RequireAsync(id, true, token); var draft = RequireDraft(read);
            Version(draft).RequireMatch(ifMatch); RequireEditable(read.Article);
            // F19: reference removal uses the same media row locks as insertion and deletion.
            // Discover actual retained rows only after locking the article/draft, then take
            // the old/new union once in global order; never lock new IDs before older IDs.
            var mediaIds = (await store.DraftMediaIdsAsync(id, token)).Concat(body.References.Select(x => x.MediaId))
                .Concat(draft.CoverMediaId is { } oldCover ? [oldCover] : [])
                .Concat(normalized.CoverMediaId is { } cover ? [cover] : []);
            await tx.LockAsync(new(false, columns: normalized.ColumnId is { } column ? [column] : [], media: mediaIds), token);
            await body.CheckMediaAsync(store.MediaAsync, token);
            if (normalized.ColumnId is { } columnId && await store.ColumnAsync(columnId, token) is null) throw ArticleInput.Invalid("columnId", FieldIssue.Unavailable);
            if (normalized.CoverMediaId is { } mediaId)
            {
                var media = await store.MediaAsync(mediaId, token);
                if (media is null || media.State != MediaState.Ready || media.Kind != MediaKind.Image) throw ArticleInput.Invalid("coverMediaId", FieldIssue.Unavailable);
            }
            var canonical = normalized with { ContentJson = ParseElement(body.Json) };
            var hash = ArticleInput.ContentHash(canonical);
            // The ETag check has already run. Same-content stale writes are still rejected.
            if (draft.ContentHash == hash) return new(MutationResponse.Json(200, Draft(draft), Version(draft)), null);
            var prior = draft.RowVersion;
            draft.Title = canonical.Title; draft.Summary = canonical.Summary; draft.ColumnId = canonical.ColumnId; draft.CoverMediaId = canonical.CoverMediaId;
            draft.CoverDisplayMeta = canonical.CoverDisplayMeta is null ? null : JsonSerializer.Serialize(canonical.CoverDisplayMeta, ApiJson.Options);
            draft.ContentJson = body.Json; draft.SchemaVersion = canonical.SchemaVersion; draft.ContentHash = hash;
            draft.RowVersion = checked(prior + 1); draft.UpdatedAt = clock.GetUtcNow(); draft.UpdatedBy = actor.UserId;
            await store.ReplaceBodyReferencesAsync(id, body.References, token);
            return new(MutationResponse.Json(200, Draft(draft), Version(draft)), new(AuditAction.DraftSaved, AuditEntity.Draft, id, prior, draft.RowVersion));
        }, ct);
    }
    private async Task<ArticleRead> RequireAsync(Guid id, bool tracked, CancellationToken ct)
    {
        if (id == Guid.Empty) throw new ApiFailure(ProblemCode.NOT_FOUND);
        return await store.ReadAsync(id, tracked, ct) ?? throw new ApiFailure(ProblemCode.NOT_FOUND);
    }
    private static ArticleDraft RequireDraft(ArticleRead read)
    {
        if (read.Article.State == ArticleState.Purged) throw new ApiFailure(ProblemCode.STATE_CONFLICT);
        return read.Draft ?? throw new InvalidOperationException("ARTICLE_DRAFT_INTEGRITY_FAILURE");
    }
    private static void RequireEditable(Article article)
    { if (article.State is ArticleState.Trashed or ArticleState.Purged) throw new ApiFailure(ProblemCode.STATE_CONFLICT); }
    private static async Task<MutationResponse> WithSlugConflict(Func<Task<MutationResponse>> action)
    {
        try { return await action(); }
        catch (DbUpdateException error) when (error.InnerException is PostgresException { SqlState: "23505", ConstraintName: "IX_articles_slug" }) { throw new ApiFailure(ProblemCode.DUPLICATE_SLUG); }
    }
    public static EntityVersion Version(Article article) => new(ResourceKind.Article, article.Id, article.RowVersion);
    public static EntityVersion Version(ArticleDraft draft) => new(ResourceKind.Draft, draft.ArticleId, draft.RowVersion);
    public static ArticleView View(ArticleRead value) => new(value.Article.Id, value.Article.Slug, value.Article.State.ToString(), value.Article.RowVersion, Version(value.Article).ETag,
        value.Draft?.RowVersion, value.Draft is null ? null : Version(value.Draft).ETag, value.Article.CreatedAt, value.Article.FirstPublishedAt, value.Article.LastPublishedAt,
        value.Published is null ? null : new(value.Published.Id, value.Published.Title, value.Published.Summary, value.Published.ColumnId, value.Published.RevisionNo, RevisionContentHash(value.Published)),
        value.Article.PurgedAt);
    private static string RevisionContentHash(ArticleRevision value) => ArticleInput.ContentHash(new(value.Title, value.Summary, value.ColumnId, value.CoverMediaId,
        value.CoverDisplayMeta is null ? null : JsonSerializer.Deserialize<DisplayMeta>(value.CoverDisplayMeta, ApiJson.Options), ParseElement(value.ContentJson), value.SchemaVersion));
    public static DraftView Draft(ArticleDraft value) => new(value.ArticleId, value.Title, value.Summary, value.ColumnId, value.CoverMediaId,
        value.CoverDisplayMeta is null ? null : JsonSerializer.Deserialize<DisplayMeta>(value.CoverDisplayMeta, ApiJson.Options), ParseElement(value.ContentJson),
        value.SchemaVersion, value.ContentHash, value.BasePublishedRevisionId, value.RowVersion, Version(value).ETag, value.UpdatedAt);
    private static JsonElement ParseElement(string json) { using var document = JsonDocument.Parse(json); return document.RootElement.Clone(); }
    private static DraftInput Input(ArticleDraft value) => new(value.Title, value.Summary, value.ColumnId, value.CoverMediaId,
        value.CoverDisplayMeta is null ? null : JsonSerializer.Deserialize<DisplayMeta>(value.CoverDisplayMeta, ApiJson.Options), ParseElement(value.ContentJson), value.SchemaVersion);
}
