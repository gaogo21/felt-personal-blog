using System.Data;
using System.Text.Json;
using System.Text.RegularExpressions;
using Blog.Web.Application.Administration;
using Blog.Web.Application.Articles;
using Blog.Web.Application.Home;
using Blog.Web.Domain;
using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace Blog.Web.Infrastructure.Home;

public sealed class PostgresPublicHomeQueries(BlogDbContext db) : IPublicHomeQueries
{
    public async Task<PublicHomeConfiguration> ReadAsync(CancellationToken ct)
    {
        await using var transaction = await BeginReadSnapshotAsync(ct);
        var settings = await db.Set<SiteSettings>().AsNoTracking().SingleAsync(x => x.Id == 1, ct);
        var site = await db.Set<SiteState>().AsNoTracking().SingleAsync(x => x.Id == 1, ct);
        var gallery = MapGallery(await GalleryQuery(db).ToArrayAsync(ct));
        var featured = await FeaturedQuery(db).ToArrayAsync(ct);
        if (featured.Length > ContentLimits.FeaturedMaximum || featured.Select(x => x.ArticleId).Distinct().Count() != featured.Length)
            throw new InvalidDataException("PUBLIC_HOME_FEATURED_INVALID");
        var result = new PublicHomeConfiguration(settings.AboutText, gallery, featured, site.RowVersion, site.UpdatedAt);
        if (transaction is not null) await transaction.CommitAsync(ct);
        return result;
    }
    private async Task<IDbContextTransaction?> BeginReadSnapshotAsync(CancellationToken ct)
    {
        if (db.Database.CurrentTransaction is { } existing)
        {
            RequireSnapshotIsolation(existing.GetDbTransaction().IsolationLevel);
            return null;
        }
        return await db.Database.BeginTransactionAsync(IsolationLevel.RepeatableRead, ct);
    }
    public static void RequireSnapshotIsolation(IsolationLevel isolation)
    {
        if (isolation is not (IsolationLevel.RepeatableRead or IsolationLevel.Serializable))
            throw new InvalidOperationException("PUBLIC_HOME_SNAPSHOT_REQUIRED");
    }
    public static IQueryable<PublicHomeImageRow> GalleryQuery(BlogDbContext context)
        => GalleryQuery(context.Set<GallerySlot>().AsNoTracking(), context.Set<MediaAsset>().AsNoTracking());
    public static IQueryable<PublicHomeImageRow> GalleryQuery(IQueryable<GallerySlot> slots, IQueryable<MediaAsset> mediaAssets)
        => from slot in slots
           join media in mediaAssets on slot.MediaId equals media.Id
           where slot.Slot >= 1 && slot.Slot <= ContentLimits.GalleryCount && media.State == MediaState.Ready
               && media.Kind == MediaKind.Image && media.Width != null && media.Width > 0 && media.Height != null && media.Height > 0
           orderby slot.Slot
           select new PublicHomeImageRow(slot.Slot, media.Id, media.Width!.Value, media.Height!.Value, media.Sha256, slot.DisplayMeta);

    public static IQueryable<PublicHomeArticle> FeaturedQuery(BlogDbContext context)
        => FeaturedQuery(context.Set<HomeFeaturedArticle>().AsNoTracking(), context.Set<Article>().AsNoTracking(),
            context.Set<ArticleRevision>().AsNoTracking(), context.Set<Column>().AsNoTracking());
    public static IQueryable<PublicHomeArticle> FeaturedQuery(IQueryable<HomeFeaturedArticle> slots, IQueryable<Article> articles,
        IQueryable<ArticleRevision> revisions, IQueryable<Column> columns)
        => from slot in slots
           join article in articles on slot.ArticleId equals article.Id
           join revision in revisions
               on new { ArticleId = article.Id, RevisionId = article.PublishedRevisionId }
               equals new { revision.ArticleId, RevisionId = (Guid?)revision.Id }
           join column in columns on revision.ColumnId equals column.Id
           where slot.Slot >= 1 && slot.Slot <= ContentLimits.FeaturedMaximum && article.State == ArticleState.Published
               && article.PublishedRevisionId != null && article.FirstPublishedAt != null && column.State == ColumnState.Active
           orderby slot.Slot
           select new PublicHomeArticle(slot.Slot, article.Id, revision.Id, article.Slug, revision.Title, revision.Summary,
               column.Slug, column.Name, article.FirstPublishedAt!.Value, revision.ReadingMinutes);

    public static IReadOnlyList<PublicHomeImage> MapGallery(IEnumerable<PublicHomeImageRow> images)
    {
        var slots = images.OrderBy(x => x.Slot).ToArray();
        if (!slots.Select(x => (int)x.Slot).SequenceEqual(Enumerable.Range(1, ContentLimits.GalleryCount))
            || slots.Select(x => x.MediaId).Distinct().Count() != ContentLimits.GalleryCount
            || slots.Any(x => x.Sha256 is not { Length: 64 } || !Regex.IsMatch(x.Sha256, "^[0-9a-f]{64}$"))
            || slots.Select(x => x.Sha256).Distinct(StringComparer.Ordinal).Count() != ContentLimits.GalleryCount)
            throw new InvalidDataException("PUBLIC_HOME_GALLERY_INVALID");
        return slots.Select(image =>
        {
            try
            {
                var snapshot = JsonSerializer.Deserialize<DisplayMeta>(image.DisplayMeta, ApiJson.Options) ?? throw new JsonException();
                _ = HomeConfigurationInput.NormalizeGallery(HomeConfigurationInput.FromSnapshot(image.MediaId, snapshot), "gallery");
                return new PublicHomeImage(image.Slot, image.MediaId, $"/media/{image.MediaId:D}", image.Width, image.Height, snapshot);
            }
            catch (Exception error) when (error is JsonException or ApiFailure)
            { throw new InvalidDataException("PUBLIC_HOME_GALLERY_INVALID"); }
        }).ToArray();
    }
}

public sealed record PublicHomeImageRow(short Slot, Guid MediaId, int Width, int Height, string? Sha256, string DisplayMeta);
