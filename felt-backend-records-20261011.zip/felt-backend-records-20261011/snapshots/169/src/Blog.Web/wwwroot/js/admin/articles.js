const root = document.querySelector('.admin-articles');
const status = document.querySelector('#article-status');
const create = document.querySelector('#article-create');
const identity = document.querySelector('#article-identity');
const draftForm = document.querySelector('#article-draft');
const editorElement = document.querySelector('#body-editor');
const details = document.querySelector('#draft-save-details');
const preview = document.querySelector('#article-preview');
const publish = document.querySelector('#article-publish');
const retryPublish = document.querySelector('#article-publish-retry');
const publicationDetails = document.querySelector('#article-publication-details');
const columnSelect = document.querySelector('#article-column');
const columnStatus = document.querySelector('#article-column-status');
const refreshColumns = document.querySelector('#article-columns-refresh');
const reconcile = document.querySelector('#draft-reconcile');
const choice = document.querySelector('#draft-recovery-choice');
const serverDetails = document.querySelector('#draft-server-details');
const useServer = document.querySelector('#draft-use-server');
const keepLocal = document.querySelector('#draft-keep-local');
const copyRecovery = document.querySelector('#draft-recovery-copy');
const downloadRecovery = document.querySelector('#draft-recovery-download');
const controller = new AbortController();
const listener = { signal: controller.signal };
const initiallyDisabled = new Map([...root.querySelectorAll('button')].map(button => [button, button.disabled]));
const recoveryButtons = new Set([reconcile, useServer, keepLocal, copyRecovery, downloadRecovery, retryPublish, refreshColumns]);
const downloadUrls = new Set();
const mediaElement = document.querySelector('#article-media-library');
let mediaLibrary = null;
function coverStatus() {
  const label = document.querySelector('#article-cover-status');
  if (label) label.textContent = workingDraft?.coverMediaId ? `当前封面：${workingDraft.coverDisplayMeta?.alt || workingDraft.coverMediaId}` : '当前未选择封面（可选）。';
}
let bodyEditor = null, editorFactory = null;
let busy = false, disposed = false, ready = false, composing = false;
let pause = null, draft = null, article = null, workingDraft = null, pendingCreate = null;
let createDirty = false, draftTouched = false, revision = 0, dirtySince = null, timer = null;
let saveDue = false, flushRequested = false, previewRequested = false;
let unknownAttempt = null, freshServer = null, recoveryCanContinue = false;
let publishRequested = false, publicationAttempt = null, publicationRetryAllowed = false;
let writeEpoch = 0, columnRead = 0, columnsLoaded = false, columnsLoading = false;
let activeColumns = new Map();
const editable = root.dataset.editable !== 'false';
const renderedFields = draftForm ? { title: draftForm.elements.title.value, summary: draftForm.elements.summary.value, slug: identity.elements.slug.value } : null;
const clone = value => JSON.parse(JSON.stringify(value));
// Object key order is not part of the draft's content contract.
const stable = value => JSON.stringify(value, (_, item) => item && typeof item === 'object' && !Array.isArray(item)
  ? Object.fromEntries(Object.keys(item).sort().map(key => [key, item[key]])) : item);
const equal = (left, right) => stable(left) === stable(right);
const payload = value => Object.fromEntries(['title', 'summary', 'columnId', 'coverMediaId', 'coverDisplayMeta', 'contentJson', 'schemaVersion'].map(key => [key, value[key]]));
const hardPaused = () => pause !== null && pause !== 'validation' && pause !== 'error';
const request = (path, options = {}) => fetch(`/api/admin/v1${path}`, { credentials: 'same-origin', cache: 'no-store', signal: controller.signal, ...options });
const current = epoch => !disposed && epoch === writeEpoch;
const uuid = value => typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
function message(state, text) {
  if (disposed) return;
  root.dataset.saveState = state;
  if (status) { status.dataset.state = state; status.textContent = text; }
}
function savedDetails(value) {
  if (!value) return '尚未读取已保存的版本。';
  const date = new Date(value.updatedAt);
  const utc = Number.isNaN(date.getTime()) ? '未提供' : date.toISOString();
  return `草稿版本：${value.draftVersion ?? '未提供'} · 内容校验值：${value.contentHash ?? '未提供'} · 保存时间（UTC）：${utc}`;
}
function renderControls() {
  if (disposed) return;
  if (create) create.elements.title.readOnly = busy;
  for (const [button, disabled] of initiallyDisabled) {
    if (recoveryButtons.has(button)) continue;
    // A manual save or preview click during a draft save flushes its newest queue.
    const canQueue = ready && (button === preview || button === publish || button.closest('#article-draft'));
    button.disabled = disabled || hardPaused() || (busy && !canQueue);
  }
  if (reconcile) reconcile.disabled = busy || !root.dataset.articleId;
  if (copyRecovery) copyRecovery.disabled = !workingDraft;
  if (downloadRecovery) downloadRecovery.disabled = !workingDraft;
  if (choice) choice.hidden = !freshServer;
  if (useServer) useServer.disabled = busy || !freshServer || Boolean(publicationAttempt);
  if (keepLocal) keepLocal.disabled = busy || !freshServer || !recoveryCanContinue;
  if (keepLocal) keepLocal.textContent = publicationAttempt ? '保留本页输入，允许核对上次发布' : '服务器版本未变，继续本页编辑';
  if (publish) { publish.textContent = article?.state === 'Published' ? '发布更新' : '发布'; publish.disabled ||= !ready || !editable || Boolean(publicationAttempt) || publishRequested; }
  if (retryPublish) { retryPublish.hidden = !publicationAttempt; retryPublish.disabled = busy || !publicationRetryAllowed; }
  if (columnSelect) columnSelect.disabled = !ready || !editable || hardPaused();
  if (refreshColumns) refreshColumns.disabled = columnsLoading || !ready || hardPaused();
  if (identity) identity.elements.slug.readOnly = Boolean(publicationAttempt);
  if (identity && article?.firstPublishedAt) for (const field of identity.elements) field.disabled = true;
  bodyEditor?.setEditable(editable && ready && !hardPaused());
  mediaLibrary?.setEnabled(editable && ready && !hardPaused()); coverStatus();
  if (details) details.textContent = savedDetails(draft);
  renderPublication();
}
function renderPublication() {
  if (!publicationDetails) return;
  const published = article?.published;
  if (!published) { publicationDetails.textContent = '尚未发布。保存工作草稿后仍需明确点击发布。'; return; }
  const changed = hasUnsavedDraft() || !published.contentHash || published.contentHash !== draft?.contentHash;
  publicationDetails.textContent = `${changed ? '有尚未发布的修改。' : '当前工作草稿内容与线上版本一致。'}线上标题：${published.title} · 发布修订：${published.revisionNo ?? published.revisionId} · 已发布内容校验值：${published.contentHash ?? '未提供'}${published.sourceDraftVersion ? ` · 发布来源草稿版本：${published.sourceDraftVersion}` : ''} · 当前草稿版本：${draft?.draftVersion ?? '未提供'}。`;
}
function clearTimer() { if (timer !== null) window.clearTimeout(timer); timer = null; }
function localPayload() {
  if (!draftForm || !workingDraft) return null;
  return { ...payload(workingDraft), title: draftForm.elements.title.value, summary: draftForm.elements.summary.value,
    contentJson: bodyEditor ? bodyEditor.getJSON() : workingDraft.contentJson };
}
function hasUnsavedDraft() {
  if (!draftForm) return false;
  if (!workingDraft || !draft) return draftTouched;
  try { return !equal(localPayload(), payload(draft)); } catch { return true; }
}
const hasUnsavedIdentity = () => Boolean(identity && article && identity.elements.slug.value !== article.slug);
const hasUnsaved = () => createDirty || hasUnsavedDraft() || hasUnsavedIdentity();
function markSavedOrDirty() {
  if (hasUnsaved()) message('dirty', '当前仍有未保存内容。已确认的工作草稿不会改变线上版本。');
  else message('saved', '工作草稿已保存，线上版本未改变。');
}
function stopWrites(reason, text) {
  if (publicationAttempt?.sent && (reason === 'unknown' || reason === 'auth')) publicationAttempt.uncertain = true;
  writeEpoch++; pause = reason; clearTimer(); saveDue = false; flushRequested = false; previewRequested = false; publishRequested = false;
  publicationRetryAllowed = reason === 'unknown' && Boolean(publicationAttempt);
  freshServer = null; recoveryCanContinue = false;
  message(reason, text); renderControls();
}
function fail(response) {
  if (response.status === 401 || response.status === 403) stopWrites('auth', `${response.status === 401 ? '登录已过期' : '防伪验证已失效'}。当前输入已保留。请在新标签页重新登录，再读取服务器版本并明确选择如何继续。`);
  else if (response.status === 412 || response.status === 428) stopWrites('conflict', '此内容已在其他地方修改。当前输入已保留；请读取服务器版本，核对并选择，不会自动覆盖。');
  else if (response.status === 422 || response.status === 400 || response.status === 413 || response.status === 415) stopWrites('validation', '输入不符合要求，请检查长度、地址格式或正文结构；修改后或手动保存时再试。');
  else if (response.status >= 500) stopWrites('unknown', '服务器结果未确认。当前输入已保留；请先读取服务器版本核对，不会自动重试。');
  else stopWrites('error', response.status === 409 ? '当前状态或地址存在冲突。输入已保留，请核对后手动重试。' : '保存失败，当前输入已保留。请核对后手动重试。');
}
function failRecovery(response, priorPause) {
  if (response.status === 401) { fail(response); return; }
  // A failed recovery read cannot authorize writes. Preserve the freeze even
  // when this status would be a retryable validation/write error elsewhere.
  const retained = priorPause && priorPause !== 'validation' && priorPause !== 'error' ? priorPause : 'review';
  stopWrites(retained, `无法读取服务器版本（HTTP ${response.status}）。当前输入已保留，写入仍暂停；请重新读取成功后明确选择如何继续。`);
}
async function mutate(path, method, body, headers = {}, context = { epoch: writeEpoch }) {
  const bootstrap = await request('/session/bootstrap');
  if (!current(context.epoch)) return null;
  if (!bootstrap.ok) { if (context.bootstrapFailure) await context.bootstrapFailure(bootstrap); else fail(bootstrap); return null; }
  const session = await bootstrap.json();
  if (!current(context.epoch)) return null;
  if (!session.csrfToken) { stopWrites('auth', '无法确认防伪上下文。当前输入已保留，请重新登录后读取服务器版本并明确选择。'); return null; }
  if (context.beforeSend && !context.beforeSend()) return null;
  const response = await request(path, { method, headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': session.csrfToken, ...headers }, body: JSON.stringify(body) });
  if (!current(context.epoch)) return null;
  if (!response.ok) { if (context.failure) await context.failure(response); else fail(response); }
  return response;
}
function fieldsValid(title, summary = '') {
  if (Array.from(title.normalize('NFC')).length > 120 || Array.from(summary.normalize('NFC')).length > 240) {
    stopWrites('validation', '标题最多 120 个字符，摘要最多 240 个字符。'); return false;
  }
  return true;
}
function validDraft(value) {
  return value && value.articleId === root.dataset.articleId && Number.isSafeInteger(value.draftVersion) && value.draftVersion > 0
    && value.draftEtag === `"d-${root.dataset.articleId}-${value.draftVersion}"`
    && typeof value.contentHash === 'string' && value.contentHash.length > 0 && !Number.isNaN(new Date(value.updatedAt).getTime())
    && typeof value.title === 'string' && typeof value.summary === 'string' && value.contentJson && Number.isInteger(value.schemaVersion)
    && ['columnId', 'coverMediaId', 'coverDisplayMeta'].every(key => Object.hasOwn(value, key));
}
function sameDraft(left, right) {
  return Boolean(left && right && left.draftEtag === right.draftEtag && left.draftVersion === right.draftVersion
    && left.contentHash === right.contentHash && equal(payload(left), payload(right)));
}
function sameArticle(left, right) { return Boolean(left && right && left.articleEtag === right.articleEtag && left.slug === right.slug); }
function renderColumns() {
  if (!columnSelect) return;
  const selected = workingDraft ? workingDraft.columnId : columnSelect.value;
  const empty = new Option('暂不选择（仅可保存草稿）', '');
  const options = [empty, ...[...activeColumns].map(([id, name]) => new Option(name, id))];
  if (selected && !activeColumns.has(selected)) options.push(new Option(`当前专栏 ${selected}（未确认公开，不能发布）`, selected));
  columnSelect.replaceChildren(...options); columnSelect.value = selected || '';
  if (columnStatus && columnsLoaded) columnStatus.textContent = !activeColumns.size ? '暂无 Active 专栏。请先前往专栏管理创建并激活；未选专栏仍可保存草稿。'
    : selected && !activeColumns.has(selected) ? '当前已选专栏不在 Active 列表中，不能发布。请选择公开专栏后保存。' : `可选公开专栏：${activeColumns.size} 个。发布时会再次验证专栏状态。`;
}
async function loadColumns() {
  if (!columnSelect || disposed || columnsLoading) return;
  const serial = ++columnRead, epoch = writeEpoch;
  columnsLoading = true; columnsLoaded = false;
  if (columnStatus) columnStatus.textContent = '正在读取全部 Active 专栏…';
  renderControls();
  try {
    const found = new Map(); let page = 1, total = null;
    do {
      const response = await request(`/columns?state=Active&page=${page}&pageSize=100`);
      if (!current(epoch) || serial !== columnRead) return;
      if (!response.ok) { if (response.status === 401 || response.status === 403) fail(response); throw new Error(`HTTP ${response.status}`); }
      const value = await response.json();
      if (!current(epoch) || serial !== columnRead) return;
      if (!Array.isArray(value.items) || !Number.isSafeInteger(value.total) || value.total < 0 || value.page !== page
        || !Number.isSafeInteger(value.pageSize) || value.pageSize < 1 || (total !== null && total !== value.total)
        || value.items.some(item => !uuid(item.id) || item.state !== 'Active' || typeof item.name !== 'string' || found.has(item.id))) throw new Error('专栏分页结果无法确认');
      total = value.total;
      for (const item of value.items) found.set(item.id, item.name);
      if (found.size < total && value.items.length === 0) throw new Error('专栏列表不完整');
      page++;
    } while (found.size < total);
    if (found.size !== total) throw new Error('专栏列表已变化，请刷新');
    activeColumns = found; columnsLoaded = true; renderColumns();
  } catch (error) {
    if (current(epoch) && serial === columnRead && error.name !== 'AbortError' && columnStatus) columnStatus.textContent = `无法确认可发布专栏（${error.message}）。可继续保存草稿，请刷新专栏列表后再发布。`;
  } finally { if (serial === columnRead) { columnsLoading = false; renderControls(); } }
}
function publishBlocked() {
  if (mediaLibrary?.hasPending()) return '媒体上传或说明尚未完成，请先处理媒体库当前操作，再发布。';
  if (hasUnsavedIdentity()) return '地址尚未保存，请先保存地址再发布。';
  if (!columnsLoaded || columnsLoading) return '尚未确认全部可发布专栏，请刷新专栏列表后再发布。';
  if (!draft?.columnId || !activeColumns.has(draft.columnId)) return '发布必须选择一个 Active 专栏。未选择或已归档的专栏仅可保存草稿。';
  return null;
}
async function publicationFailure(response, prerequisite = false) {
  // HTTP 5xx may have lost the commit result. Retain the exact request for replay.
  // A failed retry's auth/rate-limit prerequisite says nothing about whether
  // the earlier request committed. Keep its original identity across recovery.
  const unsettled = publicationAttempt?.uncertain && (prerequisite || [401, 403, 429].includes(response.status));
  if (response.status < 500 && !unsettled) publicationAttempt = null;
  if (unsettled && ![401, 403].includes(response.status)) stopWrites('unknown', '核对上次发布结果暂时失败。原请求标识与当前输入已保留，请按错误提示等待后再次核对。');
  else fail(response);
  const epoch = writeEpoch;
  let problem = null;
  try { problem = await response.json(); } catch { /* The status is authoritative. */ }
  if (!current(epoch)) return;
  const parts = [];
  if (typeof problem?.code === 'string') parts.push(problem.code);
  if (problem?.fieldErrors && typeof problem.fieldErrors === 'object') for (const [field, errors] of Object.entries(problem.fieldErrors)) {
    if (Array.isArray(errors)) parts.push(`${field}：${errors.filter(value => typeof value === 'string').join('；')}`);
  }
  if (typeof problem?.requestId === 'string') parts.push(`请求编号：${problem.requestId}`);
  const after = response.headers?.get('Retry-After'); if (after) parts.push(`请按 Retry-After 等待：${after}`);
  if (parts.length && status) status.textContent += ` ${parts.join(' · ')}`;
  renderControls();
}
function validPublication(value, attempt, response) {
  return value?.state === 'Published' && uuid(value.publishedRevisionId)
    && value.articleVersion === attempt.baseArticle.articleVersion + 1 && value.articleEtag === `"a-${root.dataset.articleId}-${value.articleVersion}"`
    && value.draftVersion === attempt.body.expectedDraftVersion + 1 && value.draftEtag === `"d-${root.dataset.articleId}-${value.draftVersion}"`
    && value.contentHash === attempt.baseDraft.contentHash && typeof value.url === 'string' && value.url === `/articles/${attempt.baseArticle.slug}`
    && [value.firstPublishedAt, value.lastPublishedAt].every(date => typeof date === 'string' && !Number.isNaN(new Date(date).getTime()))
    && (!response.headers?.get('ETag') || response.headers.get('ETag') === value.articleEtag);
}
async function publishDraft(retry = false) {
  if (disposed || busy || !ready || !editable || (!retry && (pause || composing)) || (retry && !publicationRetryAllowed)) return;
  if (!retry) {
    const blocked = publishBlocked();
    if (blocked) { publishRequested = false; message('dirty', blocked); renderControls(); return; }
    if (hasUnsavedDraft() || !validDraft(draft)) return;
    publicationAttempt = { key: crypto.randomUUID(), body: { expectedDraftVersion: draft.draftVersion }, baseDraft: clone(draft), baseArticle: clone(article), revision, sent: false };
  }
  const attempt = publicationAttempt, epoch = writeEpoch;
  busy = true; publicationRetryAllowed = false; clearTimer(); message('publishing', retry ? '正在使用同一请求标识核对上次发布结果…' : '正在准备发布已确认保存的工作草稿…'); renderControls();
  try {
    const response = await mutate(`/articles/${root.dataset.articleId}/publish`, 'POST', attempt.body,
      { 'If-Match': attempt.baseArticle.articleEtag, 'Idempotency-Key': attempt.key }, { epoch, failure: publicationFailure,
        bootstrapFailure: response => publicationFailure(response, true), beforeSend() {
        if (!retry) {
          const blocked = publishBlocked();
          if (blocked) { publicationAttempt = null; publishRequested = false; message('dirty', blocked); return false; }
          if (composing || revision !== attempt.revision || hasUnsavedDraft() || !sameDraft(draft, attempt.baseDraft)) { publicationAttempt = null; return false; }
        }
        attempt.sent = true; publishRequested = false; return true;
      } });
    if (!current(epoch)) return;
    if (response?.ok) {
      const result = await response.json();
      if (!current(epoch)) return;
      if (!validPublication(result, attempt, response)) throw new Error('Unconfirmed publication response');
      // Publishing only advances metadata. Never replace content or selection,
      // including when an idempotent replay arrives after newer local edits.
      article = { ...attempt.baseArticle, state: result.state, articleVersion: result.articleVersion, articleEtag: result.articleEtag,
        draftVersion: result.draftVersion, draftEtag: result.draftEtag, firstPublishedAt: result.firstPublishedAt, lastPublishedAt: result.lastPublishedAt,
        published: { revisionId: result.publishedRevisionId, title: attempt.baseDraft.title, summary: attempt.baseDraft.summary, columnId: attempt.baseDraft.columnId,
          contentHash: result.contentHash, sourceDraftVersion: attempt.body.expectedDraftVersion } };
      draft = { ...attempt.baseDraft, draftVersion: result.draftVersion, draftEtag: result.draftEtag, basePublishedRevisionId: result.publishedRevisionId };
      publicationAttempt = null; unknownAttempt = null; pause = null;
      if (attempt.observedServer && (!sameDraft(attempt.observedServer.draft, draft) || !sameArticle(attempt.observedServer.article, article))) {
        stopWrites('conflict', '已确认上次发布成功，但服务器随后已有更新。当前输入保留；请重新读取服务器版本并明确核对。'); return;
      }
      message(hasUnsaved() ? 'dirty' : 'published', hasUnsaved() ? '已发布提交的版本；当前较新输入尚未发布，将继续保存到工作草稿。' : '发布成功，当前工作草稿内容已上线。');
    } else if (!attempt.sent && publicationAttempt === attempt) publicationAttempt = null;
  } catch (error) {
    if (current(epoch)) stopWrites('unknown', '发布结果未确认，当前输入已保留。请点击“核对上次发布结果”，使用同一请求标识安全重试。');
  } finally {
    busy = false;
    if (publicationAttempt && !attempt.sent) publicationAttempt = null;
    renderControls();
    if (!disposed && !pause) { if (publishRequested || saveDue || flushRequested || previewRequested) void pump(); else schedule(); }
  }
}
function schedule() {
  clearTimer();
  if (disposed || !ready || !editable || pause || composing || !hasUnsavedDraft()) return;
  dirtySince ??= Date.now();
  timer = window.setTimeout(() => { timer = null; saveDue = true; void pump(); }, Math.min(1500, Math.max(0, dirtySince + 10000 - Date.now())));
}
function edited() {
  draftTouched = true; revision++;
  if (pause === 'validation' || pause === 'error') { pause = null; unknownAttempt = null; }
  if (!hardPaused()) {
    message(busy ? 'saving' : 'dirty', busy ? '正在保存提交的版本；较新输入已排队，尚未保存。' : '内容已修改，尚未保存。');
    dirtySince ??= Date.now(); schedule();
  }
  renderControls();
}
async function loadEditor(content) {
  if (!editorElement || bodyEditor || disposed) return;
  editorFactory ??= (await import('./editor.bundle.js')).createBodyEditor;
  if (disposed) return;
  bodyEditor = editorFactory(editorElement, {
    content, editable: editable && ready && !hardPaused(), onUpdate: edited,
    onError: text => message('validation', text),
    onOpenMedia: mediaElement ? (mode = 'body', node = null) => mediaLibrary?.open(mode, node) : undefined,
    onMediaFiles: mediaElement ? files => mediaLibrary?.files(files) : undefined
  });
  if (mediaElement && !mediaLibrary) {
    const { createMediaLibrary } = await import('./media-library.js');
    if (disposed) return;
    mediaLibrary = createMediaLibrary(mediaElement, {
      onAuthRequired: () => stopWrites('auth', '登录已过期。正文和媒体选择已保留，请重新登录后核对服务器版本。'),
      onPendingChange: () => renderControls(),
      onInsert: ({ mode, media, meta, node }) => {
        if (!editable || !ready || hardPaused() || disposed) return false;
        if (mode === 'cover') { workingDraft.coverMediaId = media.id; workingDraft.coverDisplayMeta = clone(meta); edited(); return true; }
        return mode === 'edit' ? bodyEditor.updateSelectedMedia(node) : bodyEditor.insertMedia(node);
      }
    });
    renderControls();
  }
}
async function pump() {
  if (disposed || busy || !ready || !editable || pause || composing || !draftForm) return;
  if (!hasUnsavedDraft()) {
    clearTimer(); dirtySince = null; saveDue = false; flushRequested = false;
    if (publishRequested) { previewRequested = false; await publishDraft(); }
    else if (previewRequested) {
      previewRequested = false;
      if (mediaLibrary?.hasPending()) { message('dirty', '媒体上传或说明尚未完成，请先处理媒体库当前操作，再预览。'); return; }
      if (hasUnsavedIdentity()) { message('dirty', '地址尚未保存，请先保存地址再预览。'); return; }
      if (!Number.isSafeInteger(draft.draftVersion) || draft.draftVersion < 1) { message('error', '无法确认已保存的草稿版本，请重新读取后再预览。'); return; }
      location.assign(`/admin/articles/${root.dataset.articleId}/preview?draftVersion=${draft.draftVersion}`);
    } else markSavedOrDirty();
    return;
  }
  if (!saveDue && !flushRequested && !previewRequested && !publishRequested) return;
  const body = clone(localPayload());
  if (!fieldsValid(body.title, body.summary)) return;
  const epoch = writeEpoch;
  const attempt = { kind: 'draft', body, revision, baseDraft: clone(draft), baseArticle: clone(article) };
  clearTimer(); dirtySince = null; saveDue = false; flushRequested = false;
  busy = true; unknownAttempt = attempt; message('saving', '正在保存工作草稿…'); renderControls();
  try {
    const response = await mutate(`/articles/${root.dataset.articleId}/draft`, 'PUT', body, { 'If-Match': attempt.baseDraft.draftEtag }, { epoch });
    if (!current(epoch)) return;
    if (response?.ok) {
      // JSON decoding is part of the in-flight operation. It may yield for more input.
      const saved = await response.json();
      if (!current(epoch)) return;
      if (!validDraft(saved)) throw new Error('Unconfirmed draft response');
      if (revision === attempt.revision && equal(localPayload(), body)) {
        draftForm.elements.title.value = saved.title;
        draftForm.elements.summary.value = saved.summary;
        // An identical ProseMirror replacement resets the user's current caret or
        // selection, even when they only moved it while the response was pending.
        if (bodyEditor && !equal(bodyEditor.getJSON(), saved.contentJson) && bodyEditor.setContent(saved.contentJson) === false) throw new Error('Editor normalization rejected');
        workingDraft = clone(saved);
      }
      draft = saved; unknownAttempt = null; renderColumns(); markSavedOrDirty();
    } else if (pause !== 'unknown') unknownAttempt = null;
  } catch (error) {
    if (current(epoch) && error.name !== 'AbortError') stopWrites('unknown', '网络结果未确认，当前输入已保留。请先读取服务器版本核对，不会自动重试。');
  } finally {
    busy = false; renderControls();
    if (!disposed && !pause) {
      if (saveDue || flushRequested || previewRequested || publishRequested) void pump();
      else if (hasUnsavedDraft() && timer === null) schedule();
    }
  }
}
create?.addEventListener('submit', async event => {
  event.preventDefault();
  if (disposed || busy || hardPaused()) return;
  const title = create.elements.title.value;
  if (!fieldsValid(title)) return;
  const body = { title };
  if (pendingCreate && pendingCreate.json !== JSON.stringify(body)) { message('unknown', '上次创建结果尚未确认。请恢复上次标题并重试，避免重复创建。'); return; }
  pendingCreate ??= { key: crypto.randomUUID(), json: JSON.stringify(body) };
  const epoch = writeEpoch;
  pause = null; busy = true; message('saving', '正在创建工作草稿…'); renderControls();
  try {
    const response = await mutate('/articles', 'POST', body, { 'Idempotency-Key': pendingCreate.key }, { epoch, failure(response) {
      if (response.status < 500 && response.status !== 429) pendingCreate = null;
      fail(response);
    } });
    if (!current(epoch)) return;
    if (response?.ok) {
      const result = await response.json();
      if (!current(epoch)) return;
      pendingCreate = null; createDirty = false; busy = false; renderControls();
      location.assign(`/admin/articles/${result.article.id}`);
    } else if (response && response.status < 500 && response.status !== 429) pendingCreate = null;
  } catch (error) {
    if (current(epoch) && error.name !== 'AbortError') message('unknown', '网络结果未确认，输入已保留。创建重试会使用同一个请求标识。');
  } finally {
    // Creation alone can safely retry its bounded idempotency key after an unknown response.
    if (pause === 'unknown') pause = null;
    busy = false; renderControls();
  }
}, listener);
identity?.addEventListener('submit', async event => {
  event.preventDefault(); if (disposed || busy || !ready || !editable || hardPaused() || !article || identity.elements.slug.disabled) return;
  const body = { slug: identity.elements.slug.value };
  const epoch = writeEpoch;
  pause = null; busy = true; unknownAttempt = { kind: 'identity', body, baseDraft: draft && clone(draft), baseArticle: clone(article) };
  message('saving', '正在保存地址…'); renderControls();
  try {
    const response = await mutate(`/articles/${root.dataset.articleId}/identity`, 'PATCH', body, { 'If-Match': article.articleEtag }, { epoch });
    if (!current(epoch)) return;
    if (response?.ok) {
      const saved = await response.json();
      if (!current(epoch)) return;
      article = saved; unknownAttempt = null; markSavedOrDirty();
    } else if (pause !== 'unknown') unknownAttempt = null;
  } catch (error) {
    if (current(epoch) && error.name !== 'AbortError') stopWrites('unknown', '地址保存结果未确认，输入已保留。请先读取服务器版本核对。');
  } finally { busy = false; renderControls(); if (!pause) { if (saveDue || flushRequested || previewRequested || publishRequested) void pump(); else schedule(); } }
}, listener);
function flushDraft(wantsPreview) {
  if (disposed || hardPaused() || !ready || !editable) return;
  pause = null; flushRequested = true; previewRequested ||= wantsPreview; clearTimer(); void pump();
}
draftForm?.addEventListener('submit', event => { event.preventDefault(); flushDraft(false); }, listener);
preview?.addEventListener('click', event => { event.preventDefault(); flushDraft(true); }, listener);
publish?.addEventListener('click', event => {
  event.preventDefault();
  if (disposed || hardPaused() || !ready || !editable || publicationAttempt || publishRequested) return;
  if (hasUnsavedIdentity() || mediaLibrary?.hasPending()) { message('dirty', hasUnsavedIdentity() ? '地址尚未保存，请先保存地址再发布。' : '媒体上传或说明尚未完成，请先处理媒体库当前操作，再发布。'); return; }
  pause = null; publishRequested = true; flushRequested = true; previewRequested = false; clearTimer(); renderControls(); void pump();
}, listener);
retryPublish?.addEventListener('click', () => { if (publicationAttempt && publicationRetryAllowed) void publishDraft(true); }, listener);
refreshColumns?.addEventListener('click', () => { if (ready && !hardPaused()) void loadColumns(); }, listener);
columnSelect?.addEventListener('change', () => {
  if (!workingDraft || !ready || !editable || hardPaused()) return;
  workingDraft.columnId = columnSelect.value || null; edited(); renderColumns();
}, listener);
root.addEventListener('input', event => {
  if (event.target.closest('.body-editor-toolbar')) return;
  if (event.target.closest('#article-create')) { createDirty = true; if (pause === 'validation' || pause === 'error') pause = null; renderControls(); }
  else if (event.target.closest('#article-identity')) { if (!hardPaused()) message('dirty', '地址已修改，尚未保存。'); }
  else if (event.target !== columnSelect && event.target.closest('#article-draft') && !event.target.closest('#body-editor')) edited();
}, listener);
root.addEventListener('compositionstart', event => { if (event.target.closest('#article-draft')) { composing = true; clearTimer(); } }, listener);
root.addEventListener('compositionend', event => { if (event.target.closest('#article-draft')) { composing = false; edited(); if (flushRequested || previewRequested || publishRequested || saveDue) void pump(); } }, listener);
reconcile?.addEventListener('click', async () => {
  if (disposed || busy) return;
  const priorPause = pause;
  const epoch = ++writeEpoch;
  clearTimer(); saveDue = false; flushRequested = false; previewRequested = false; publishRequested = false; publicationRetryAllowed = false;
  freshServer = null; recoveryCanContinue = false; pause = 'reconciling'; busy = true;
  message('loading', '正在读取服务器版本；当前输入保留在本页。'); renderControls();
  try {
    const articleResponse = await request(`/articles/${root.dataset.articleId}`);
    if (!current(epoch)) return;
    if (!articleResponse.ok) { failRecovery(articleResponse, priorPause); return; }
    const currentArticle = await articleResponse.json();
    if (!current(epoch)) return;
    const draftResponse = await request(`/articles/${root.dataset.articleId}/draft`);
    if (!current(epoch)) return;
    if (!draftResponse.ok) { failRecovery(draftResponse, priorPause); return; }
    const currentDraft = await draftResponse.json();
    if (!current(epoch)) return;
    if (!validDraft(currentDraft)) throw new Error('Invalid current draft');
    const wasUnknown = priorPause === 'unknown' && unknownAttempt;
    const confirmedAttempt = !publicationAttempt && wasUnknown && (unknownAttempt.kind === 'draft'
      ? equal(payload(currentDraft), unknownAttempt.body) && sameArticle(currentArticle, unknownAttempt.baseArticle)
      : currentArticle.slug === unknownAttempt.body.slug && sameDraft(currentDraft, unknownAttempt.baseDraft));
    if (confirmedAttempt) {
      // The lost response committed. Advance only the baseline, never the newer local input.
      draft = currentDraft; article = currentArticle; unknownAttempt = null; pause = null;
      message(hasUnsaved() ? 'dirty' : 'saved', hasUnsaved() ? '已核对上次保存成功；当前较新输入仍未保存，将继续自动保存。' : '已核对上次保存成功，当前内容已保存。');
      dirtySince = null; schedule();
    } else {
      freshServer = { article: currentArticle, draft: currentDraft };
      recoveryCanContinue = Boolean(publicationAttempt) || sameDraft(currentDraft, draft) && sameArticle(currentArticle, article);
      pause = recoveryCanContinue ? (priorPause || 'review') : 'conflict';
      if (serverDetails) serverDetails.textContent = `${savedDetails(currentDraft)} · 服务器标题：${currentDraft.title} · 服务器地址：${currentArticle.slug}`;
      message(recoveryCanContinue ? (priorPause || 'review') : 'conflict', publicationAttempt
        ? '上次发布结果仍需通过同一请求标识确认。当前输入保留；请选择继续本页编辑，再点击“核对上次发布结果”。'
        : recoveryCanContinue
        ? '服务器版本与上次读取一致。请选择保留本页输入并继续，或载入服务器版本替换本页输入。'
        : '服务器版本已经变化，已停止写入。请先复制或下载本页恢复文件，再明确选择载入服务器版本。');
    }
  } catch (error) {
    if (current(epoch) && error.name !== 'AbortError') stopWrites(priorPause === 'auth' ? 'auth' : 'unknown', '无法核对服务器版本。当前输入已保留，写入仍暂停；请稍后重新读取。');
  } finally { busy = false; renderControls(); }
}, listener);
keepLocal?.addEventListener('click', async () => {
  if (disposed || busy || !freshServer || !recoveryCanContinue) return;
  const epoch = writeEpoch;
  busy = true; renderControls();
  try {
    await loadEditor(workingDraft.contentJson);
    if (!current(epoch)) return;
    if (publicationAttempt) {
      publicationAttempt.observedServer = freshServer; freshServer = null; pause = 'unknown'; publicationRetryAllowed = true;
      message('unknown', '当前输入已保留。请点击“核对上次发布结果”；确认之前不会保存或发布其他版本。'); return;
    }
    article = freshServer.article; draft = freshServer.draft;
    freshServer = null; unknownAttempt = null; pause = null; dirtySince = null; ready = true;
    markSavedOrDirty(); flushRequested = true; if (!columnsLoaded) void loadColumns();
  } catch (error) {
    if (current(epoch) && error.name !== 'AbortError') stopWrites('load', '无法加载编辑器。当前输入已保留，请复制或下载恢复文件后再试。');
  } finally { busy = false; renderControls(); if (!pause) void pump(); }
}, listener);
useServer?.addEventListener('click', async () => {
  if (disposed || busy || !freshServer || publicationAttempt) return;
  const selected = freshServer, selectedRevision = revision, selectedSlug = identity.elements.slug.value;
  const epoch = writeEpoch;
  busy = true; pause = 'loading'; renderControls();
  try {
    await loadEditor(workingDraft?.contentJson ?? selected.draft.contentJson);
    if (!current(epoch)) return;
    if (revision !== selectedRevision || identity.elements.slug.value !== selectedSlug) {
      stopWrites('conflict', '载入期间出现了新输入，已保留。请重新读取服务器版本，再明确选择是否替换。'); return;
    }
    if (bodyEditor && bodyEditor.setContent(selected.draft.contentJson) === false) throw new Error('Editor rejected server content');
    draftForm.elements.title.value = selected.draft.title;
    draftForm.elements.summary.value = selected.draft.summary;
    identity.elements.slug.value = selected.article.slug;
    article = selected.article; draft = selected.draft; workingDraft = clone(draft);
    revision++; ready = true; pause = null; freshServer = null; unknownAttempt = null;
    dirtySince = null; clearTimer(); renderColumns(); markSavedOrDirty(); if (!columnsLoaded) void loadColumns();
  } catch (error) {
    if (current(epoch) && error.name !== 'AbortError') stopWrites('load', '无法加载服务器正文。当前输入保留，请复制或下载恢复文件后再试。');
  } finally { busy = false; renderControls(); }
}, listener);
function recoveryJson() {
  if (!workingDraft) throw new Error('No complete local draft');
  return JSON.stringify({ format: 'felt-draft-recovery', formatVersion: 1, articleId: root.dataset.articleId,
    exportedAtUtc: new Date().toISOString(), slug: identity?.elements.slug.value ?? article?.slug ?? '',
    ...localPayload(), base: draft ? { draftVersion: draft.draftVersion, contentHash: draft.contentHash, updatedAt: draft.updatedAt } : null }, null, 2);
}
copyRecovery?.addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(recoveryJson()); if (!disposed && status) status.textContent = '恢复 JSON 已复制；其中包含当前标题、摘要、正文、地址和媒体引用。'; }
  catch { if (!disposed && status) status.textContent = '无法复制。请使用“下载恢复文件”保留当前输入。'; }
}, listener);
downloadRecovery?.addEventListener('click', () => {
  try {
    const url = URL.createObjectURL(new Blob([recoveryJson()], { type: 'application/json;charset=utf-8' }));
    downloadUrls.add(url);
    const link = document.createElement('a'); link.href = url; link.download = `draft-recovery-${root.dataset.articleId}.json`;
    document.body.append(link); link.click(); link.remove();
    window.setTimeout(() => { URL.revokeObjectURL(url); downloadUrls.delete(url); }, 0);
    if (status) status.textContent = '已请求下载恢复 JSON；请确认文件已保存在本机。';
  } catch { if (status) status.textContent = '无法生成下载文件。请尝试复制恢复 JSON。'; }
}, listener);
window.addEventListener('beforeunload', event => {
  if (hasUnsaved() || busy || pendingCreate || publicationAttempt || publishRequested || pause === 'unknown' || mediaLibrary?.hasPending()) { event.preventDefault(); event.returnValue = ''; }
}, listener);
window.addEventListener('pagehide', () => {
  disposed = true; clearTimer(); controller.abort(); mediaLibrary?.destroy(); bodyEditor?.destroy();
  for (const url of downloadUrls) URL.revokeObjectURL(url);
  downloadUrls.clear();
}, { once: true });
window.addEventListener('pageshow', event => { if (event.persisted) location.reload(); });
if (root.dataset.articleId) {
  busy = true; message('loading', '正在核对工作草稿版本…');
  let seeded = false;
  const initial = document.querySelector('#draft-initial-state');
  if (initial) {
    try {
      const state = JSON.parse(initial.value);
      if (state.article && validDraft(state.draft)) { article = state.article; draft = state.draft; workingDraft = clone(draft); seeded = true; }
    } catch { /* An invalid seed cannot authorize a write or an incomplete recovery export. */ }
  }
  renderControls();
  (async () => {
    const epoch = writeEpoch;
    try {
      if (seeded) await loadEditor(workingDraft.contentJson);
      if (!current(epoch)) return;
      const response = await request(`/articles/${root.dataset.articleId}`);
      if (!current(epoch)) return;
      if (!response.ok) { fail(response); return; }
      const currentArticle = await response.json();
      if (!current(epoch)) return;
      if (draftForm) {
        const draftResponse = await request(`/articles/${root.dataset.articleId}/draft`);
        if (!current(epoch)) return;
        if (!draftResponse.ok) { fail(draftResponse); return; }
        const currentDraft = await draftResponse.json();
        if (!current(epoch)) return;
        if (!validDraft(currentDraft)) throw new Error('Invalid initial draft');
        const matches = root.dataset.articleEtag === currentArticle.articleEtag && root.dataset.draftEtag === currentDraft.draftEtag
          && renderedFields.title === currentDraft.title && renderedFields.summary === currentDraft.summary && renderedFields.slug === currentArticle.slug
          && (!seeded || sameArticle(currentArticle, article) && sameDraft(currentDraft, draft));
        if (!matches) { stopWrites('conflict', '内容版本已经变化。当前输入已保留，请读取服务器版本并核对后明确选择。'); return; }
        article = currentArticle; draft = currentDraft; workingDraft ??= clone(draft);
        await loadEditor(workingDraft.contentJson);
        if (!current(epoch)) return;
        ready = true; renderColumns(); void loadColumns(); markSavedOrDirty(); if (hasUnsavedDraft()) schedule();
      } else { article = currentArticle; ready = true; }
    } catch (error) {
      if (current(epoch) && error.name !== 'AbortError') stopWrites('load', '无法读取当前版本或加载编辑器。当前输入保留，请复制或下载恢复文件后再试。');
    } finally { busy = false; renderControls(); }
  })();
} else renderControls();

for (const [id, mode] of [['article-media', 'body'], ['article-cover', 'cover']]) {
  document.getElementById(id)?.addEventListener('click', () => { if (ready && editable && !hardPaused()) mediaLibrary?.open(mode); }, listener);
}
document.querySelector('#article-cover-clear')?.addEventListener('click', () => {
  if (!workingDraft || !ready || !editable || hardPaused()) return;
  workingDraft.coverMediaId = null; workingDraft.coverDisplayMeta = null; edited();
}, listener);
