#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p artifacts/f24
export BLOG_F24_CHECKS=1
bash eng/check-f26.sh
"${BLOG_DOTNET_BIN:-dotnet}" run --project tests/Blog.StaticCompressionTests --no-build --no-restore | tee artifacts/f24/static-compression-output.txt
node --test --test-reporter=tap tests/HomeMotion/compressed-artifacts.test.mjs tests/HomeMotion/accessibility.test.mjs tests/HomeMotion/admin-accessibility.test.mjs | tee artifacts/f24/static-accessibility-output.txt
node eng/check-f24-assets.mjs artifacts/f22/publish/wwwroot
python3 eng/verify-runtime-notices.py artifacts/f22/publish --json-output artifacts/f24/runtime-notice-verification.json
python3 eng/check-home-preservation.py
python3 eng/summarize-f24.py
