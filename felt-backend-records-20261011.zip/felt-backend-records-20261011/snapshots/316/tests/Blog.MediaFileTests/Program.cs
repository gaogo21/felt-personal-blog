using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Blog.MediaFileTests;
using Blog.Web.Application.Media;
using Blog.Web.Domain;
using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Media;

var root = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../../../"));
var run = Path.Combine(root, "artifacts/f11/media-file-tests", Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(run);
var toolchain = Path.GetFullPath(Path.Combine(root, "../blog-toolchain"));
var options = new MediaToolOptions
{
    ScannerPath = Path.Combine(toolchain, "debian-root/usr/bin/clamscan"),
    ScannerDatabasePath = Path.Combine(toolchain, "clamav-db"),
    ScannerLibraryPath = Path.Combine(toolchain, "debian-root/usr/lib/x86_64-linux-gnu")
};
var processor = new ToolMediaFileProcessor(options);
var results = new List<object>();
var failures = 0;
void Assert(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
async Task Check(string name, Func<Task> test)
{
    if (args.Length > 1 && args[0] == "--filter" && !args.Skip(1).Any(filter => name.Contains(filter, StringComparison.OrdinalIgnoreCase))) return;
    try { await test(); results.Add(new { name, status = "passed" }); Console.WriteLine("PASS " + name); }
    catch (Exception error) { failures++; results.Add(new { name, status = "failed", error = error.Message }); Console.WriteLine("FAIL " + name + ": " + error.Message); }
}
MediaInspectionInput Input(string source, string mime, MediaKind kind = MediaKind.Image) => new(Path.Combine(run, source), Path.Combine(run, Guid.NewGuid().ToString("N") + ".result"), kind, mime);
async Task Reject(MediaInspectionInput input, string[] codes, ToolMediaFileProcessor? usingProcessor = null, bool transient = false)
{
    try { await (usingProcessor ?? processor).ProcessAsync(input); throw new InvalidOperationException("Rejected fixture accepted"); }
    catch (MediaProcessingFailure error)
    {
        Assert(codes.Contains(error.Code), "Unexpected safe code " + error.Code);
        Assert(error.IsTransient == transient, "Incorrect retry classification");
        Assert(error.Message == error.Code && error.InnerException is null, "Diagnostic disclosure");
    }
    Assert(!File.Exists(input.OutputPath), "Rejected file reached trusted output");
    Assert(!File.Exists(input.OutputPath + ".stage"), "Processing temporary file leaked");
}
async Task Write(string name, byte[] bytes) => await File.WriteAllBytesAsync(Path.Combine(run, name), bytes);
string Sha(byte[] bytes) => Convert.ToHexStringLower(SHA256.HashData(bytes));

await MediaFixtures.MakeAsync(run);
await Check("Failure codes cannot expose arbitrary diagnostics or exceed the schema limit", () =>
{
    foreach (var unsafeCode in new string?[] { null, "", "private/input.jpg", "MEDIA_FAILED\nsecret", new('A', 65), "éERROR", "9ERROR", "_ERROR" })
    {
        var error = new MediaProcessingFailure(unsafeCode, true);
        Assert(error.Code == "MEDIA_PROCESSING_FAILED" && error.Message == error.Code && error.IsTransient, "Unsafe failure code escaped");
    }
    foreach (var code in new[] { "A", "MEDIA_TOOL_FAILED", "MEDIA_123", new string('A', 64) })
        Assert(new MediaProcessingFailure(code).Code == code, "Valid safe code changed");
    return Task.CompletedTask;
});
foreach (var (name, mime) in new[] { ("still.jpg", "image/jpeg"), ("still.png", "image/png"), ("still.webp", "image/webp") })
    await Check("Real scan, decode and safe re-encoding: " + mime, async () =>
    {
        var input = Input(name, mime);
        var result = await processor.ProcessAsync(input);
        var bytes = await File.ReadAllBytesAsync(input.OutputPath);
        Assert(result.MimeType == mime && result.Width == 32 && result.Height == 24 && result.DurationMs is null, "Derived image metadata");
        Assert(result.ByteSize == bytes.Length && result.Sha256 == Sha(bytes), "Final-byte digest/size");
    });
foreach (var source in new[] { "silent.mp4", "audio.mp4" })
    await Check("Real H264 MP4 verification preserves all bytes: " + source, async () =>
    {
        var input = Input(source, "video/mp4", MediaKind.Video);
        var result = await processor.ProcessAsync(input);
        var original = await File.ReadAllBytesAsync(input.InputPath);
        var saved = await File.ReadAllBytesAsync(input.OutputPath);
        Assert(saved.SequenceEqual(original), "Video was changed or transcoded");
        Assert(result.DurationMs is > 0 and <= 1100 && result.Width == 32 && result.Height == 24 && result.Sha256 == Sha(original), "Video metadata");
    });
await Check("JPEG EXIF/GPS, XMP and comments never survive re-encoding", async () =>
{
    var jpg = await File.ReadAllBytesAsync(Path.Combine(run, "still.jpg"));
    // Valid little-endian TIFF with one ASCII ImageDescription. Marker text acts as a privacy sentinel.
    var description = Encoding.ASCII.GetBytes("private GPS latitude=1 longitude=2\0");
    var exif = new byte[6 + 26 + description.Length];
    "Exif\0\0"u8.CopyTo(exif); "II"u8.CopyTo(exif.AsSpan(6));
    BinaryPrimitives.WriteUInt16LittleEndian(exif.AsSpan(8), 42);
    BinaryPrimitives.WriteUInt32LittleEndian(exif.AsSpan(10), 8);
    BinaryPrimitives.WriteUInt16LittleEndian(exif.AsSpan(14), 1);
    BinaryPrimitives.WriteUInt16LittleEndian(exif.AsSpan(16), 0x010e);
    BinaryPrimitives.WriteUInt16LittleEndian(exif.AsSpan(18), 2);
    BinaryPrimitives.WriteInt32LittleEndian(exif.AsSpan(20), description.Length);
    BinaryPrimitives.WriteUInt32LittleEndian(exif.AsSpan(24), 26);
    description.CopyTo(exif, 32);
    jpg = MediaFixtures.JpegSegment(jpg, 0xe1, exif);
    jpg = MediaFixtures.JpegSegment(jpg, 0xe1, Encoding.ASCII.GetBytes("http://ns.adobe.com/xap/1.0/\0private XMP owner=fixture"));
    jpg = MediaFixtures.JpegSegment(jpg, 0xfe, "private comment"u8.ToArray());
    await Write("metadata.jpg", jpg);
    var input = Input("metadata.jpg", "image/jpeg");
    await processor.ProcessAsync(input);
    var output = Encoding.Latin1.GetString(await File.ReadAllBytesAsync(input.OutputPath));
    Assert(!output.Contains("Exif") && !output.Contains("private") && !output.Contains("adobe.com"), "Private JPEG metadata remains");
    Assert(Sha(jpg) != Sha(await File.ReadAllBytesAsync(input.OutputPath)), "Original bytes were copied");
});
await Check("PNG text and EXIF chunks are stripped", async () =>
{
    var png = await File.ReadAllBytesAsync(Path.Combine(run, "still.png"));
    var tagged = png[..33].Concat(MediaFixtures.Chunk("tEXt", "Comment\0private owner fixture"u8.ToArray()))
        .Concat(MediaFixtures.Chunk("eXIf", MediaFixtures.ExifWithOrientationAndGps()[6..])).Concat(png[33..]).ToArray();
    await Write("metadata.png", tagged);
    var input = Input("metadata.png", "image/png"); await processor.ProcessAsync(input);
    var output = Encoding.Latin1.GetString(await File.ReadAllBytesAsync(input.OutputPath));
    Assert(!output.Contains("private") && !output.Contains("eXIf"), "PNG non-display metadata remains");
});
await Check("JPEG GPS IFD is stripped while display orientation is applied to pixels", async () =>
{
    var jpg = MediaFixtures.JpegSegment(await File.ReadAllBytesAsync(Path.Combine(run, "still.jpg")), 0xe1, MediaFixtures.ExifWithOrientationAndGps());
    await Write("gps-oriented.jpg", jpg);
    var input = Input("gps-oriented.jpg", "image/jpeg"); var metadata = await processor.ProcessAsync(input);
    Assert(metadata.Width == 24 && metadata.Height == 32, "Display rotation lost");
    Assert(!Encoding.Latin1.GetString(await File.ReadAllBytesAsync(input.OutputPath)).Contains("Exif"), "GPS IFD remains");
});
await Check("MIME declarations must match byte signatures", async () => await Reject(Input("still.png", "image/jpeg"), ["MEDIA_TYPE_MISMATCH"]));
await Check("SVG and unsupported kind/MIME combinations are rejected", async () =>
{
    await Reject(Input("still.png", "image/svg+xml"), ["MEDIA_TYPE_UNSUPPORTED"]);
    await Reject(Input("silent.mp4", "video/mp4"), ["MEDIA_TYPE_UNSUPPORTED"]);
});
await Check("Truncated JPEG and PNG never yield output", async () =>
{
    await Write("truncated.jpg", (await File.ReadAllBytesAsync(Path.Combine(run, "still.jpg")))[..^2]);
    await Write("truncated.png", (await File.ReadAllBytesAsync(Path.Combine(run, "still.png")))[..^3]);
    await Reject(Input("truncated.jpg", "image/jpeg"), ["MEDIA_CORRUPT"]);
    await Reject(Input("truncated.png", "image/png"), ["MEDIA_CORRUPT"]);
});
await Check("PNG with valid signature and CRC but corrupt compressed pixels fails real decoding", async () =>
{
    var png = await File.ReadAllBytesAsync(Path.Combine(run, "still.png"));
    await Write("broken-pixels.png", png[..33].Concat(MediaFixtures.Chunk("IDAT", [1, 2, 3, 4, 5])).Concat(MediaFixtures.Chunk("IEND", [])).ToArray());
    await Reject(Input("broken-pixels.png", "image/png"), ["MEDIA_CORRUPT", "MEDIA_SCAN_REJECTED"]);
});
await Check("APNG and animated WebP are rejected before flattening", async () =>
{
    await Reject(Input("animated.png", "image/png"), ["MEDIA_ANIMATION_UNSUPPORTED"]);
    await Reject(Input("animated.webp", "image/webp"), ["MEDIA_ANIMATION_UNSUPPORTED"]);
});
await Check("Concatenated JPEG and mismatched RIFF lengths are rejected", async () =>
{
    var jpg = await File.ReadAllBytesAsync(Path.Combine(run, "still.jpg")); await Write("two.jpg", jpg.Concat(jpg).ToArray());
    await Reject(Input("two.jpg", "image/jpeg"), ["MEDIA_CORRUPT"]);
    var webp = await File.ReadAllBytesAsync(Path.Combine(run, "still.webp")); webp[4] ^= 2; await Write("broken.webp", webp);
    await Reject(Input("broken.webp", "image/webp"), ["MEDIA_CORRUPT"]);
});
await Check("Image pixel and edge limits are checked before decoding allocation", async () =>
{
    var png = await File.ReadAllBytesAsync(Path.Combine(run, "still.png"));
    foreach (var (width, height) in new[] { (8000, 5001), (16385, 1) })
    {
        var header = png[16..29]; BinaryPrimitives.WriteInt32BigEndian(header, width); BinaryPrimitives.WriteInt32BigEndian(header.AsSpan(4), height);
        await Write("large-header.png", png[..8].Concat(MediaFixtures.Chunk("IHDR", header)).Concat(png[33..]).ToArray());
        await Reject(Input("large-header.png", "image/png"), ["MEDIA_DIMENSIONS_EXCEEDED"]);
    }
});
await Check("Image 10 MiB and video 200 MiB source size limits fail before native tools", async () =>
{
    foreach (var (name, size, kind, mime) in new[] { ("oversize.png", ContentLimits.ImageBytes, MediaKind.Image, "image/png"), ("oversize.mp4", ContentLimits.VideoBytes, MediaKind.Video, "video/mp4") })
    {
        await using (var file = File.Create(Path.Combine(run, name))) file.SetLength(size + 1);
        await Reject(Input(name, mime, kind), ["MEDIA_SIZE_EXCEEDED"]);
    }
});
await Check("MP4 unsupported video codec and QuickTime container are rejected", async () =>
{
    await Reject(Input("wrong-codec.mp4", "video/mp4", MediaKind.Video), ["MEDIA_CODEC_UNSUPPORTED", "MEDIA_CORRUPT"]);
    var bytes = await File.ReadAllBytesAsync(Path.Combine(run, "silent.mp4")); "qt  "u8.CopyTo(bytes.AsSpan(8)); await Write("quicktime.mp4", bytes);
    await Reject(Input("quicktime.mp4", "video/mp4", MediaKind.Video), ["MEDIA_CONTAINER_UNSUPPORTED"]);
});
await Check("MP4 601-second duration is rejected", async () =>
{
    await MediaFixtures.RunAsync("-f", "lavfi", "-i", "color=c=black:s=16x16:r=1", "-t", "601", "-c:v", "libx264", "-threads", "1", Path.Combine(run, "long.mp4"));
    await Reject(Input("long.mp4", "video/mp4", MediaKind.Video), ["MEDIA_DURATION_EXCEEDED"]);
});
await Check("MP4 exact 600-second boundary passes full decoding", async () =>
{
    await MediaFixtures.RunAsync("-f", "lavfi", "-i", "color=c=black:s=16x16:r=1", "-t", "600", "-c:v", "libx264", "-threads", "1", Path.Combine(run, "boundary.mp4"));
    var input = Input("boundary.mp4", "video/mp4", MediaKind.Video); var result = await processor.ProcessAsync(input);
    Assert(result.DurationMs == 600000, "Inclusive duration boundary changed");
});
await Check("MP4 frames above 8294400 pixels fail the decoder pixel cap", async () =>
{
    await MediaFixtures.RunAsync("-f", "lavfi", "-i", "color=c=black:s=3840x2162:r=1", "-frames:v", "1", "-c:v", "libx264", "-preset", "ultrafast", "-threads", "1", Path.Combine(run, "oversize-frame.mp4"));
    await Reject(Input("oversize-frame.mp4", "video/mp4", MediaKind.Video), ["MEDIA_DIMENSIONS_EXCEEDED", "MEDIA_CORRUPT"]);
});
await Check("MP4 non-AAC audio is rejected", async () =>
{
    await MediaFixtures.RunAsync("-i", Path.Combine(run, "audio.mp4"), "-c:v", "copy", "-c:a", "libmp3lame", "-threads", "1", Path.Combine(run, "mp3-audio.mp4"));
    await Reject(Input("mp3-audio.mp4", "video/mp4", MediaKind.Video), ["MEDIA_CODEC_UNSUPPORTED", "MEDIA_CORRUPT"]);
});
await Check("MP4 corrupt actual coded packets cannot be approved by headers alone", async () =>
{
    var mp4 = await File.ReadAllBytesAsync(Path.Combine(run, "silent.mp4"));
    var marker = mp4.AsSpan().IndexOf("mdat"u8); Assert(marker > 3, "No mdat fixture");
    var size = BinaryPrimitives.ReadInt32BigEndian(mp4.AsSpan(marker - 4));
    mp4.AsSpan(marker + 4, size - 8).Fill(0); await Write("broken-packets.mp4", mp4);
    await Reject(Input("broken-packets.mp4", "video/mp4", MediaKind.Video), ["MEDIA_CORRUPT"]);
});
await Check("Additional subtitle streams are unsupported", async () =>
{
    await File.WriteAllTextAsync(Path.Combine(run, "subtitle.srt"), "1\n00:00:00,000 --> 00:00:00,500\nfixture\n");
    await MediaFixtures.RunAsync("-i", Path.Combine(run, "silent.mp4"), "-i", Path.Combine(run, "subtitle.srt"), "-map", "0", "-map", "1", "-c:v", "copy", "-c:s", "mov_text", Path.Combine(run, "subtitle.mp4"));
    await Reject(Input("subtitle.mp4", "video/mp4", MediaKind.Video), ["MEDIA_STREAM_UNSUPPORTED", "MEDIA_CORRUPT"]);
});
await Check("Missing scanner and missing database fail closed, eligible for bounded queue retries", async () =>
{
    var absent = new ToolMediaFileProcessor(new MediaToolOptions { ScannerPath = Path.Combine(run, "no-scanner"), ScannerDatabasePath = options.ScannerDatabasePath });
    await Reject(Input("still.png", "image/png"), ["MEDIA_SCANNER_UNAVAILABLE"], absent, true);
    var noDatabase = new ToolMediaFileProcessor(new MediaToolOptions { ScannerPath = options.ScannerPath, ScannerDatabasePath = Path.Combine(run, "no-db") });
    await Reject(Input("still.png", "image/png"), ["MEDIA_SCANNER_UNAVAILABLE"], noDatabase, true);
});
await Check("Unmodified official benign EICAR file is rejected by the real scanner", async () =>
{
    var eicar = Encoding.ASCII.GetBytes(@"X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*");
    await Write("standard-scanner-test.txt", eicar);
    using var stop = new CancellationTokenSource(TimeSpan.FromSeconds(ContentLimits.ProcessingTimeoutSeconds));
    try { await processor.ScanAsync(Path.Combine(run, "standard-scanner-test.txt"), stop.Token); throw new InvalidOperationException("Scanner missed standard EICAR fixture"); }
    catch (MediaProcessingFailure error) { Assert(error.Code == "MEDIA_SCAN_REJECTED" && !error.IsTransient, "Incorrect scan rejection"); }
    await Reject(Input("standard-scanner-test.txt", "image/jpeg"), ["MEDIA_TYPE_MISMATCH"]);
});
await Check("Native stdout flood is bounded and the process is terminated", async () =>
{
    using var stop = new CancellationTokenSource(TimeSpan.FromSeconds(10));
    try { await BoundedMediaProcess.RunAsync("/usr/bin/ffmpeg", ["-hide_banner", "-h", "full"], stop.Token); throw new InvalidOperationException("Unbounded output accepted"); }
    catch (MediaProcessingFailure error) { Assert(error.Code == "MEDIA_TOOL_OUTPUT_LIMIT", "Wrong diagnostic cap failure"); }
});
await Check("Encoded binary pipe enforces the exact disk byte cap", async () =>
{
    using var stop = new CancellationTokenSource(TimeSpan.FromSeconds(10));
    var target = Path.Combine(run, "binary-cap.result");
    try
    {
        await BoundedMediaProcess.RunAsync("/usr/bin/ffmpeg", ["-hide_banner", "-v", "error", "-threads", "1", "-i", Path.Combine(run, "still.png"), "-frames:v", "1", "-threads", "1", "-f", "rawvideo", "pipe:1"], stop.Token, outputFile: target, outputByteLimit: 100);
        throw new InvalidOperationException("Binary disk budget ignored");
    }
    catch (MediaProcessingFailure error) { Assert(error.Code == "MEDIA_SIZE_EXCEEDED", "Wrong disk cap failure"); }
    Assert(new FileInfo(target).Length <= 100, "Oversized stage was written");
});
await Check("Shared processing deadline kills native work and returns a transient sanitized code", async () =>
{
    var fast = new ToolMediaFileProcessor(new MediaToolOptions
    {
        ScannerPath = options.ScannerPath, ScannerDatabasePath = options.ScannerDatabasePath,
        ScannerLibraryPath = options.ScannerLibraryPath, ProcessingTimeout = TimeSpan.FromMilliseconds(100)
    });
    var watch = System.Diagnostics.Stopwatch.StartNew();
    await Reject(Input("still.png", "image/png"), ["MEDIA_PROCESSING_TIMEOUT"], fast, true);
    Assert(watch.Elapsed < TimeSpan.FromSeconds(5), "Native process was not stopped promptly");
});
await Check("Caller cancellation propagates and never creates an output", async () =>
{
    var input = Input("still.jpg", "image/jpeg");
    using var stop = new CancellationTokenSource(TimeSpan.FromMilliseconds(100));
    try { await processor.ProcessAsync(input, stop.Token); throw new InvalidOperationException("Cancellation ignored"); }
    catch (OperationCanceledException) { }
    Assert(!File.Exists(input.OutputPath), "Canceled output exists");
    Assert(!File.Exists(input.OutputPath + ".stage"), "Canceled stage file remains");
});
await Check("Output is exclusive and existing files are never overwritten", async () =>
{
    var input = Input("still.png", "image/png"); await File.WriteAllTextAsync(input.OutputPath, "existing fixture");
    try { await processor.ProcessAsync(input); throw new InvalidOperationException("Existing output accepted"); }
    catch (MediaProcessingFailure error) { Assert(error.Code == "MEDIA_STORAGE_PATH_INVALID", "Wrong path code"); }
    Assert(await File.ReadAllTextAsync(input.OutputPath) == "existing fixture", "Existing file overwritten");
});
await Check("A symlink input cannot evade scanner path checks", async () =>
{
    File.CreateSymbolicLink(Path.Combine(run, "linked.png"), Path.Combine(run, "still.png"));
    await Reject(Input("linked.png", "image/png"), ["MEDIA_STORAGE_PATH_INVALID"]);
});
var resultName = args.Length > 1 && args[0] == "--filter" ? "results-filtered.json" : "results.json";
await File.WriteAllTextAsync(Path.Combine(root, "artifacts/f11/media-file-tests", resultName), JsonSerializer.Serialize(new { passed = results.Count - failures, failed = failures, fixtures = run, results }, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"Media file checks: {results.Count - failures} passed, {failures} failed.");
return failures == 0 && results.Count > 0 ? 0 : 1;
