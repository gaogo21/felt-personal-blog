using Blog.Web.Infrastructure.Persistence;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Primitives;

namespace Blog.Web.Infrastructure.Media;

// The original seed files remain in the source for reproducible initialization and visual hashes.
// Their HTTP aliases are served only by ProtectedMediaEndpoints, never by StaticFileMiddleware.
public sealed class ProtectedStaticFiles(IFileProvider inner) : IFileProvider
{
    private static readonly HashSet<string> ControlledPaths = DesignSeedCatalog.Load()
        .Select(x => "/" + x.RelativePath).ToHashSet(StringComparer.OrdinalIgnoreCase);
    public IFileInfo GetFileInfo(string subpath)
    {
        try
        {
            var normalized = Path.GetFullPath("/" + subpath.TrimStart('/')).Replace('\\', '/');
            if (ControlledPaths.Contains(normalized)) return new NotFoundFileInfo(subpath);
        }
        catch (Exception e) when (e is ArgumentException or NotSupportedException or PathTooLongException)
        { return new NotFoundFileInfo(subpath); }
        return inner.GetFileInfo(subpath);
    }
    public IDirectoryContents GetDirectoryContents(string subpath) => NotFoundDirectoryContents.Singleton;
    public IChangeToken Watch(string filter) => inner.Watch(filter);
}
