namespace Blog.Web.Infrastructure.Operations;

// All operator input passes through this boundary. Production never substitutes
// redirected streams, environment variables, files, or command-line values.
public interface IOperatorConsole
{
    bool IsInteractive { get; }
    void Write(string text);
    ConsoleKeyInfo? ReadKey(CancellationToken cancellationToken);
}

public sealed class SystemOperatorConsole : IOperatorConsole
{
    public bool IsInteractive => !Console.IsInputRedirected && !Console.IsOutputRedirected && !Console.IsErrorRedirected;
    public void Write(string text) => Console.Write(text);

    public ConsoleKeyInfo? ReadKey(CancellationToken cancellationToken)
    {
        if (!IsInteractive) throw new OperatorInputException(OperatorInputFailure.InteractiveRequired);
        var previousControlC = Console.TreatControlCAsInput;
        try
        {
            Console.TreatControlCAsInput = true;
            while (!Console.KeyAvailable)
            {
                cancellationToken.ThrowIfCancellationRequested();
                cancellationToken.WaitHandle.WaitOne(50);
            }
            cancellationToken.ThrowIfCancellationRequested();
            return Console.ReadKey(intercept: true);
        }
        finally { Console.TreatControlCAsInput = previousControlC; }
    }
}

public enum OperatorInputFailure { Cancelled, TooLong, InvalidInput, InteractiveRequired }

public sealed class OperatorInputException(OperatorInputFailure failure) : Exception("OPERATOR_INPUT_REJECTED")
{
    public OperatorInputFailure Failure { get; } = failure;
}

public static class OperatorInput
{
    public const int MaximumLength = 256;

    public static string ReadLine(IOperatorConsole console, string prompt, bool secret, CancellationToken cancellationToken)
    {
        if (!console.IsInteractive) throw new OperatorInputException(OperatorInputFailure.InteractiveRequired);
        cancellationToken.ThrowIfCancellationRequested();
        console.Write(prompt);
        var buffer = new char[MaximumLength];
        var length = 0;
        try
        {
            while (true)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var input = console.ReadKey(cancellationToken);
                if (input is null) throw new OperatorInputException(OperatorInputFailure.Cancelled);
                var key = input.Value;
                if (key.Key == ConsoleKey.Escape || key.KeyChar is '\u0003' or '\u0004' or '\u001a' ||
                    (key.Modifiers.HasFlag(ConsoleModifiers.Control) && key.Key is ConsoleKey.C or ConsoleKey.D or ConsoleKey.Z))
                    throw new OperatorInputException(OperatorInputFailure.Cancelled);
                if (key.Key == ConsoleKey.Enter)
                {
                    console.Write(Environment.NewLine);
                    return new string(buffer, 0, length);
                }
                if (key.Key == ConsoleKey.Backspace)
                {
                    if (length > 0)
                    {
                        buffer[--length] = '\0';
                        if (!secret) console.Write("\b \b");
                    }
                    continue;
                }
                // Navigation/function keys have no text. Never render arbitrary
                // control sequences supplied by a terminal or a fake boundary.
                if (key.KeyChar == '\0') continue;
                if (char.IsControl(key.KeyChar)) throw new OperatorInputException(OperatorInputFailure.InvalidInput);
                if (length == MaximumLength) throw new OperatorInputException(OperatorInputFailure.TooLong);
                buffer[length++] = key.KeyChar;
                if (!secret) console.Write(key.KeyChar.ToString());
            }
        }
        finally { Array.Clear(buffer); }
    }
}
