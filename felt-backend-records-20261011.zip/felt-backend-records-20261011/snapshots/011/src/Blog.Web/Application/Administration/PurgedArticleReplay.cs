using System.Text.Json;
using Blog.Web.Domain.Persistence;

namespace Blog.Web.Application.Administration;

// A content-free invalidation receipt keeps a used key/hash reserved after the
// article is purged. It can never be mistaken for a successful mutation response.
public static class PurgedArticleReplay
{
    public static string Create(Guid articleId)
    {
        if (articleId == Guid.Empty) throw new ArgumentException("Empty article ID.");
        return JsonSerializer.Serialize(new { articlePurged = articleId }, ApiJson.Options);
    }

    public static bool TryRead(IdempotencyRecord record, out Guid articleId)
    {
        articleId = Guid.Empty;
        if (record.Status != IdempotencyState.Completed || record.ResponseCode != 409 || record.ResponseJson is null
            || record.Scope is not ("article.create" or "article.publish" or "article.withdraw" or "article.trash"
                or "article.restore" or "article.revision.restore")) return false;
        try
        {
            using var document = JsonDocument.Parse(record.ResponseJson);
            var root = document.RootElement;
            return root.ValueKind == JsonValueKind.Object && root.EnumerateObject().Count() == 1
                && root.TryGetProperty("articlePurged", out var owner) && owner.ValueKind == JsonValueKind.String
                && Guid.TryParseExact(owner.GetString(), "D", out articleId) && articleId != Guid.Empty;
        }
        catch (JsonException) { return false; }
    }
}
