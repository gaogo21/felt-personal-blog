namespace Blog.Web.Infrastructure.Operations;

// Operator verbs are a separate entry mode, never host configuration or an HTTP
// bootstrap. Unknown bare verbs fail closed instead of starting the web server.
public static class OperatorInvocation
{
    private static readonly HashSet<string> Commands = new(StringComparer.Ordinal)
    {
        "initialize-admin", "reset-admin-password", "seed-design", "restore-isolated", "capture-stopped"
    };

    public static bool IsOperatorMode(IReadOnlyList<string> arguments)
        => arguments.Count > 0 && !arguments[0].StartsWith('-');

    public static bool IsValid(IReadOnlyList<string> arguments)
        => arguments.Count == 1 && Commands.Contains(arguments[0]);

    // Input validation and the terminal boundary precede even constructing a
    // host/service provider. This seam is exercised with isolated fake runners.
    public static async Task<int> RunAsync(IReadOnlyList<string> arguments, IOperatorConsole console,
        Func<string, CancellationToken, Task<int>> run, CancellationToken cancellationToken)
    {
        try
        {
            if (!IsValid(arguments)) return Finish(OperatorExitCode.InvalidCommand, "OPERATOR_COMMAND_INVALID");
            if (!console.IsInteractive) return Finish(OperatorExitCode.InteractiveRequired, "OPERATOR_INTERACTIVE_TERMINAL_REQUIRED");
            cancellationToken.ThrowIfCancellationRequested();
            return await run(arguments[0], cancellationToken);
        }
        catch (OperationCanceledException) { return Finish(OperatorExitCode.Cancelled, "OPERATOR_CANCELLED"); }
        catch (Exception error) when (error is not OutOfMemoryException)
        {
            return Finish(OperatorExitCode.OperationFailed, "OPERATOR_OPERATION_FAILED");
        }

        int Finish(int code, string message)
        {
            try { console.Write(message + Environment.NewLine); }
            catch (Exception error) when (error is not OutOfMemoryException) { }
            return code;
        }
    }
}
