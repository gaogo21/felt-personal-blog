using System.Text.Json;
using System.Text.RegularExpressions;
using Blog.Web.Application.Administration;
using Blog.Web.Application.Articles;
using Blog.Web.Application.Columns;
using Blog.Web.Application.Home;
using Blog.Web.Application.RichText;
using Blog.Web.Domain;
using Blog.Web.Domain.Persistence;

namespace Blog.Web.Application.Public;

public sealed class PublicContentService(IPublicContentStore store, RichTextSchema schema) : IPublicContentQueries
{
    public const int PageSize = 12;
    public ContentSourceKind SourceKind => ContentSourceKind.PostgreSql;

    public Task<HomeContent> GetHomeAsync(CancellationToken cancellationToken)
        => store.ReadSnapshotAsync(async (snapshot, ct) =>
        {
            await snapshot.ValidateFixedDesignAssetsAsync(ct);
            var home = await snapshot.Home.ReadAsync(ct);
            var columns = await snapshot.Columns.GetHomeColumnsAsync(ct);
            try
            {
                // Revalidate the captured configuration without replacing its text with
                // seed defaults or replacing a deliberate empty featured selection.
                _ = HomeConfigurationInput.Normalize(new(home.AboutText,
                    home.Gallery.Select(image => HomeConfigurationInput.FromSnapshot(image.MediaId, image.DisplayMeta)).ToArray(),
                    home.Featured.Select(article => article.ArticleId).ToArray()));
                if (!home.Gallery.Select(image => (int)image.Slot).SequenceEqual(Enumerable.Range(1, ContentLimits.GalleryCount))
                    || !home.Featured.Select(article => (int)article.Slot).SequenceEqual(Enumerable.Range(1, home.Featured.Count)))
                    throw Invalid("HOME_CONFIGURATION");
            }
            catch (ApiFailure) { throw Invalid("HOME_CONFIGURATION"); }
            return new HomeContent(home.AboutText, home.Featured.Select(article => new ArticleSummary(
                    article.Slug, article.Title, article.Summary, article.ColumnSlug, article.ColumnName,
                    article.FirstPublishedAt, article.ReadingMinutes)).ToArray(),
                columns.Select(MapColumn).ToArray(), home.Gallery.Select(image =>
                    MapImage(image.MediaId, image.Src, image.Width, image.Height, image.DisplayMeta)).ToArray());
        }, cancellationToken);

    public Task<ArticlePage?> GetArticlesAsync(string? columnSlug, int page, int pageSize, CancellationToken cancellationToken)
    {
        if (page < 1) throw new ArgumentOutOfRangeException(nameof(page));
        if (pageSize != PageSize) throw new ArgumentOutOfRangeException(nameof(pageSize));
        if (columnSlug is not null && !ValidSlug(columnSlug)) return Task.FromResult<ArticlePage?>(null);
        return store.ReadSnapshotAsync<ArticlePage?>(async (snapshot, ct) =>
        {
            PublicListColumn? column = null;
            if (columnSlug is not null)
            {
                column = await snapshot.ReadActiveColumnAsync(columnSlug, ct);
                if (column is null) return null;
            }
            var total = await snapshot.CountArticlesAsync(column?.Id, ct);
            if (total < 0) throw Invalid("ARTICLE_COUNT");
            // All positive int page values are valid. A far beyond-last-page request
            // remains empty without overflowing or passing an unsafe OFFSET to SQL.
            var offset = ((long)page - 1) * PageSize;
            var items = offset >= total ? Array.Empty<PublicArticleRow>()
                : await snapshot.ReadArticlesAsync(column?.Id, (int)offset, PageSize, ct);
            return new ArticlePage(items.Select(MapArticle).ToArray(), total, column?.Name);
        }, cancellationToken);
    }

    public Task<ColumnContent?> GetColumnAsync(string slug, CancellationToken cancellationToken)
    {
        if (!ValidSlug(slug)) return Task.FromResult<ColumnContent?>(null);
        return store.ReadSnapshotAsync<ColumnContent?>(async (snapshot, ct) =>
        {
            var directory = await snapshot.Columns.GetDirectoryAsync(slug, ct);
            if (directory is null) return null;
            if (directory.Column.PublishedArticleCount != directory.Articles.Count
                || directory.Articles.Select(article => article.Id).Distinct().Count() != directory.Articles.Count
                || directory.Articles.Where((article, index) => article.Position != index + 1).Any())
                throw Invalid("COLUMN_ORDER");
            return new ColumnContent(MapColumn(directory.Column), directory.Articles.Select(article =>
                new ArticleSummary(article.Slug, article.Title, article.Summary, directory.Column.Slug,
                    directory.Column.Name, article.FirstPublishedAt, article.ReadingMinutes)).ToArray());
        }, cancellationToken);
    }

    public Task<ArticleContent?> GetArticleAsync(string slug, CancellationToken cancellationToken)
    {
        if (!ValidSlug(slug)) return Task.FromResult<ArticleContent?>(null);
        return store.ReadSnapshotAsync<ArticleContent?>(async (snapshot, ct) =>
        {
            var current = await snapshot.ReadCurrentArticleAsync(slug, ct);
            if (current is null) return null;
            var navigation = await snapshot.Columns.GetArticleNavigationAsync(current.Article.Id, ct);
            if (navigation is null || navigation.ArticleId != current.Article.Id
                || navigation.RevisionId != current.Article.RevisionId || navigation.ColumnId != current.Article.ColumnId
                || navigation.ColumnSlug != current.Article.ColumnSlug || navigation.ColumnName != current.Article.ColumnName)
                throw Invalid("ARTICLE_NAVIGATION");

            RichTextDocument document;
            ReadingImage? cover;
            try
            {
                using var json = JsonDocument.Parse(current.ContentJson);
                document = schema.Validate(json.RootElement, current.SchemaVersion);
                var references = await snapshot.ReadRevisionReferencesAsync(current.Article.RevisionId, ct);
                if (references.Count != references.Distinct().Count()
                    || !document.References.ToHashSet().SetEquals(references)) throw Invalid("ARTICLE_CONTENT");
                var ids = document.References.Select(reference => reference.MediaId)
                    .Concat(current.CoverMediaId is { } coverId ? [coverId] : []).Distinct().Order().ToArray();
                var media = await snapshot.ReadMediaAsync(ids, ct);
                document = document.WithTrustedMedia(media);
                if (!document.HasSubstantiveText && !document.References.Any(reference => reference.Usage is MediaUsage.BodyImage or MediaUsage.Video))
                    throw Invalid("ARTICLE_CONTENT");
                var toc = JsonSerializer.Deserialize<TocEntry[]>(current.TocJson, ApiJson.Options);
                if (current.PlainText != document.PlainText || current.Article.ReadingMinutes != document.ReadingMinutes
                    || toc is null || !toc.SequenceEqual(document.Toc)
                    || current.RevisionNo < 1 || current.RevisionCreatedAt < current.Article.FirstPublishedAt)
                    throw Invalid("ARTICLE_CONTENT");
                cover = MapCover(current, media);
            }
            catch (Exception error) when (error is JsonException or ApiFailure or InvalidOperationException or ArgumentException)
            { throw Invalid("ARTICLE_CONTENT"); }
            return new ArticleContent(MapArticle(current.Article), Array.Empty<ReadingBlock>(), cover,
                current.RevisionNo > 1 ? current.RevisionCreatedAt : null,
                navigation.Previous, navigation.Next, document);
        }, cancellationToken);
    }

    private static ReadingImage? MapCover(PublicArticleDetailRow current, IReadOnlyDictionary<Guid, MediaAsset> media)
    {
        if (current.CoverMediaId is null)
        {
            if (current.CoverDisplayMeta is not null) throw Invalid("ARTICLE_CONTENT");
            return null;
        }
        if (current.CoverMediaId == Guid.Empty || current.CoverDisplayMeta is null
            || !media.TryGetValue(current.CoverMediaId.Value, out var cover)
            || cover.Id != current.CoverMediaId || cover.Kind != MediaKind.Image || cover.State != MediaState.Ready
            || cover.Width is not > 0 || cover.Height is not > 0) throw Invalid("ARTICLE_CONTENT");
        var meta = JsonSerializer.Deserialize<DisplayMeta>(current.CoverDisplayMeta, ApiJson.Options)
            ?? throw Invalid("ARTICLE_CONTENT");
        _ = ArticleInput.Meta(meta);
        return new ReadingImage($"/media/{cover.Id:D}", meta.Alt, cover.Width.Value, cover.Height.Value,
            meta.Caption, meta.Credit, Optional(meta.SourceUrl), meta.LicenseName, Optional(meta.LicenseUrl));
    }

    private static ArticleSummary MapArticle(PublicArticleRow article)
        => new(article.Slug, article.Title, article.Summary, article.ColumnSlug, article.ColumnName,
            article.FirstPublishedAt, article.ReadingMinutes);

    private static ColumnSummary MapColumn(PublicColumnSummary column)
    {
        if (column.PublishedArticleCount < 0 || !column.Images.Select(image => image.Slot).SequenceEqual(new short[] { 1, 2, 3 })
            || column.Images.Select(image => image.MediaId).Distinct().Count() != 3) throw Invalid("COLUMN_MEDIA");
        return new(column.Slug, column.Name, column.Introduction, column.PublishedArticleCount,
            column.Images.Select(image => MapImage(image.MediaId, image.Src, image.Width, image.Height, image.Snapshot)).ToArray());
    }

    private static DesignImage MapImage(Guid id, string src, int width, int height, DisplayMeta meta)
    {
        if (id == Guid.Empty || src != $"/media/{id:D}" || width < 1 || height < 1) throw Invalid("DISPLAY_MEDIA");
        try { _ = ArticleInput.Meta(meta); }
        catch (ApiFailure) { throw Invalid("DISPLAY_MEDIA"); }
        // DisplayMeta has one captured credit, no separate creator/provider fields.
        // Preserve it whole and never guess a provider from a mutable URL or filename.
        return new(src, meta.Alt, string.IsNullOrWhiteSpace(meta.Caption) ? meta.Alt : meta.Caption,
            meta.Credit, "", meta.SourceUrl, meta.LicenseName, meta.LicenseUrl, width, height);
    }

    private static bool ValidSlug(string? slug) => slug is { Length: > 0 and <= ContentLimits.SlugScalars }
        && Regex.IsMatch(slug, "\\A[a-z0-9]+(?:-[a-z0-9]+)*\\z");
    private static string? Optional(string value) => value.Length == 0 ? null : value;
    private static InvalidDataException Invalid(string field) => new($"PUBLIC_{field}_INVALID");
}
