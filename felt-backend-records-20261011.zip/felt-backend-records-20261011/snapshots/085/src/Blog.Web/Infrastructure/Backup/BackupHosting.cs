using Blog.Web.Application.Maintenance;
using Blog.Web.Infrastructure.Media;
using Microsoft.AspNetCore.DataProtection;

namespace Blog.Web.Infrastructure.Backup;
public static class BackupHosting
{
    public static IServiceCollection AddBackupMaintenance(this IServiceCollection services, IConfiguration configuration)
    {
        var options = BackupOptions.Read(configuration);
        services.AddSingleton(options);
        services.AddSingleton<IBackupKeyValidator, BackupKeyValidator>();
        services.AddSingleton<MaintenanceCoordinator>();
        services.AddSingleton<BackupArchiveStore>();
        services.AddSingleton<IBackupOperationLedger, FileBackupOperationLedger>();
        services.AddScoped<BackupControlService>();
        services.AddScoped<IBackupCapture>(provider => options.Enabled
            ? ActivatorUtilities.CreateInstance<BackupCaptureService>(provider) : new DisabledCapture());
        services.AddScoped<IPostgresBackupDatabase>(provider => new PostgresBackupDatabase(
            configuration.GetConnectionString("BlogDatabase") ?? throw new InvalidOperationException("PRODUCTION_DATABASE_CONFIGURATION_REQUIRED"),
            new PostgresBackupOptions(configuration["Backup:PgDumpPath"] ?? "", configuration["Backup:PgRestorePath"] ?? "",
                TimeSpan.FromMinutes(15), 8L * 1024 * 1024 * 1024),
            new PostgresBackupProcessRunner(new SystemPostgresBackupProcessFactory()), new NpgsqlPostgresBackupMetadata()));
        if (options.Enabled)
        {
            // Explicit operational mode: keys already exist and controlled rotation
            // is required. No request/background refresh may generate a key while frozen.
            services.AddDataProtection().SetApplicationName(options.ApplicationName)
                .PersistKeysToFileSystem(new DirectoryInfo(options.DataProtectionRoot)).DisableAutomaticKeyGeneration();
        }
        return services;
    }
    public static void ValidateBackupConfiguration(IServiceProvider services)
    {
        var options = services.GetRequiredService<BackupOptions>();
        if (!options.Enabled) return;
        if (services.GetRequiredService<IConfiguration>()["Blog:Mode"] != "PostgreSql")
            throw new InvalidOperationException("BACKUP_POSTGRESQL_MODE_REQUIRED");
        var now = services.GetRequiredService<TimeProvider>().GetUtcNow();
        options.ValidateExistingFiles(services.GetRequiredService<IWebHostEnvironment>().WebRootPath);
        services.GetRequiredService<IBackupKeyValidator>().Validate(options.DataProtectionRoot, now);
    }
    private sealed class DisabledCapture : IBackupCapture
    {
        public Task CaptureAsync(Guid operationId, DateTimeOffset createdAt, CancellationToken ct)
            => throw new InvalidOperationException("BACKUP_DISABLED");
    }
}
