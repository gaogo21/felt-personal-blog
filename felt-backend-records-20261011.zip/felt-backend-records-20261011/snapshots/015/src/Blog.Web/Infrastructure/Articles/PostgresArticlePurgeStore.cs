using Blog.Web.Application.Administration;
using Blog.Web.Application.Articles;
using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Blog.Web.Infrastructure.Articles;

public sealed class PostgresArticlePurgeStore(BlogDbContext db) : IArticlePurgeStore
{
    public Task<ArticleRead?> ReadAsync(Guid id, CancellationToken ct)
    { RequireTransaction(); return PostgresAdminArticleStore.ReadQuery(db, id).SingleOrDefaultAsync(ct); }

    public static IQueryable<Guid> RetainedColumnIdsQuery(BlogDbContext context, Guid articleId)
        => context.Set<ArticleDraft>().Where(x => x.ArticleId == articleId && x.ColumnId != null).Select(x => x.ColumnId!.Value)
            .Union(context.Set<ArticleRevision>().Where(x => x.ArticleId == articleId).Select(x => x.ColumnId));

    public static IQueryable<Guid> RetainedMediaIdsQuery(BlogDbContext context, Guid articleId)
        => context.Set<ArticleDraft>().Where(x => x.ArticleId == articleId && x.CoverMediaId != null).Select(x => x.CoverMediaId!.Value)
            .Union(context.Set<ArticleRevision>().Where(x => x.ArticleId == articleId && x.CoverMediaId != null).Select(x => x.CoverMediaId!.Value))
            .Union(context.Set<DraftMediaReference>().Where(x => x.ArticleId == articleId).Select(x => x.MediaId))
            .Union(from reference in context.Set<RevisionMediaReference>()
                   join revision in context.Set<ArticleRevision>() on reference.RevisionId equals revision.Id
                   where revision.ArticleId == articleId
                   select reference.MediaId);

    public async Task<ArticlePurgeDependencies> DependenciesAsync(Guid articleId, CancellationToken ct)
    {
        RequireTransaction();
        return new(await RetainedColumnIdsQuery(db, articleId).ToArrayAsync(ct),
            await RetainedMediaIdsQuery(db, articleId).ToArrayAsync(ct),
            await db.Set<ArticleRevision>().CountAsync(x => x.ArticleId == articleId, ct),
            await HasPublicMembershipAsync(articleId, ct));
    }

    public async Task DeleteContentAsync(Guid articleId, int expectedRevisionCount, CancellationToken ct)
    {
        RequireTransaction();
        var articleEntry = db.ChangeTracker.Entries<Article>().SingleOrDefault(x => x.Entity.Id == articleId);
        var draftEntry = db.ChangeTracker.Entries<ArticleDraft>().SingleOrDefault(x => x.Entity.ArticleId == articleId);
        if (articleEntry is null || draftEntry is null || expectedRevisionCount < 0
            || articleEntry.OriginalValues.GetValue<ArticleState>(nameof(Article.State)) != ArticleState.Trashed
            || articleEntry.Entity.State != ArticleState.Purged || articleEntry.Entity.PublishedRevisionId is not null
            || articleEntry.Entity.PurgedAt is null || draftEntry.Entity.BasePublishedRevisionId is not null
            || await HasPublicMembershipAsync(articleId, ct))
            throw new InvalidOperationException("ARTICLE_PURGE_REQUIRES_STAGED_TOMBSTONE");

        // SchemaGuardsV1 permits revision/reference DELETE only after their own
        // article is Purged with no public pointer. Flush that state and clear the
        // draft's composite base FK first, while retaining the outer transaction.
        // Deferred integrity checks run after every child has been removed.
        await db.SaveChangesAsync(ct);
        await InvalidateReceiptsAsync(articleId, ct);
        await db.Set<DraftMediaReference>().Where(x => x.ArticleId == articleId).ExecuteDeleteAsync(ct);
        var revisions = db.Set<ArticleRevision>().Where(x => x.ArticleId == articleId);
        await db.Set<RevisionMediaReference>().Where(x => revisions.Any(r => r.Id == x.RevisionId)).ExecuteDeleteAsync(ct);
        if (await db.Set<ArticleDraft>().Where(x => x.ArticleId == articleId).ExecuteDeleteAsync(ct) != 1)
            throw new InvalidOperationException("ARTICLE_PURGE_DRAFT_COUNT_MISMATCH");
        // ExecuteDelete intentionally bypasses tracking; prevent this removed draft
        // from being flushed again by the mutation executor's final SaveChanges.
        draftEntry.State = EntityState.Detached;
        if (await revisions.ExecuteDeleteAsync(ct) != expectedRevisionCount)
            throw new InvalidOperationException("ARTICLE_PURGE_REVISION_COUNT_MISMATCH");
    }

    private Task<bool> HasPublicMembershipAsync(Guid articleId, CancellationToken ct)
        => db.Set<Article>().Where(x => x.Id == articleId).Select(x =>
            db.Set<ColumnArticleOrder>().Any(o => o.ArticleId == articleId)
            || db.Set<HomeFeaturedArticle>().Any(f => f.ArticleId == articleId)).SingleAsync(ct);

    // All paths and scopes are server-owned. Compare exact serialized UUIDs; never
    // search free text, slug, title, ETag fragments or request bodies for an owner.
    // Publication receipts identify a retained revision, so invalidate before its
    // deletion. Never acquire another key's advisory lock while holding an article.
    public static FormattableString InvalidateReceiptsCommand(Guid articleId)
    {
        var owner = articleId.ToString("D");
        var marker = PurgedArticleReplay.Create(articleId);
        return $$"""
            UPDATE idempotency_records AS receipt
            SET response_code = 409, response_json = CAST({{marker}} AS jsonb)
            WHERE receipt.status = 1 AND (
                (receipt.scope = 'article.create' AND receipt.response_json #>> '{body,article,id}' = {{owner}})
                OR (receipt.scope IN ('article.withdraw', 'article.trash', 'article.restore')
                    AND receipt.response_json #>> '{body,id}' = {{owner}})
                OR (receipt.scope = 'article.revision.restore' AND receipt.response_json #>> '{body,articleId}' = {{owner}})
                OR (receipt.scope = 'article.publish' AND EXISTS (
                    SELECT 1 FROM article_revisions AS revision
                    WHERE revision.article_id = {{articleId}}
                      AND revision.id::text = receipt.response_json #>> '{body,publishedRevisionId}')))
            """;
    }
    private Task<int> InvalidateReceiptsAsync(Guid articleId, CancellationToken ct)
        => db.Database.ExecuteSqlInterpolatedAsync(InvalidateReceiptsCommand(articleId), ct);
    private void RequireTransaction()
    { if (db.Database.CurrentTransaction is null) throw new InvalidOperationException("ARTICLE_PURGE_REQUIRES_TRANSACTION"); }
}
