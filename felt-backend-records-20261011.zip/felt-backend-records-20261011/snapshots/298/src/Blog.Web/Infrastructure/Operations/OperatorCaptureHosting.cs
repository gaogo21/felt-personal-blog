using Blog.Web.Infrastructure.Backup;
using Blog.Web.Application.Maintenance;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Blog.Web.Infrastructure.Operations;

public static class OperatorCaptureHosting
{
    // BackupMaintenance supplies the existing ledger, capture and coordinator.
    // Registration alone opens no files, starts no process and creates no keys.
    public static IServiceCollection AddOperatorCaptureCommand(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddSingleton(OperatorCaptureOptions.Read(configuration));
        services.TryAddSingleton<IOperatorConsole, SystemOperatorConsole>();
        services.TryAddSingleton<IBackupLocalInstanceLock, BackupLocalInstanceLock>();
        services.TryAddScoped<IOperatorCapturePreflight, OperatorCapturePreflight>();
        services.TryAddScoped<OperatorCaptureStoppedCommand>();
        return services;
    }

    // Web startup must first validate backup configuration, then retain this
    // lease through complete host disposal. Disabled backup mode performs no I/O.
    public static IDisposable? AcquireWebInstanceLock(IServiceProvider services)
    {
        var options = services.GetRequiredService<BackupOptions>();
        return options.Enabled ? new BackupLocalInstanceLock(options).Acquire() : null;
    }

    // Host StopAsync/DisposeAsync may stop waiting before a BackgroundService or
    // admitted detached child actually finishes. A cooperating CLI must remain
    // excluded until those real tasks and the capture/receipt lifetime settle.
    // No timeout or cancellation here transfers a live process's lock ownership.
    public static async Task WaitForWebWritersAsync(IEnumerable<Task> actualWorkerTasks, MaintenanceCoordinator maintenance)
    {
        try { await Task.WhenAll(actualWorkerTasks); }
        catch (Exception error) when (error is not OutOfMemoryException)
        {
            // WhenAll has observed every task and does not complete early on a
            // first fault. Faulted work is settled; host logging owns its error.
        }
        while (maintenance.Snapshot is not { State: MaintenanceState.Open, InFlight: 0 })
            await Task.Delay(25);
    }
}
