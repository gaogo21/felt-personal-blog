using System.Diagnostics;
using System.Runtime.Versioning;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using Blog.Web.Application.Administration;
using Blog.Web.Application.Maintenance;
using Blog.Web.Infrastructure.Backup;
using Blog.Web.Infrastructure.Media;
using Blog.Web.Infrastructure.Operations;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;

[assembly: SupportedOSPlatform("linux")]

// This mode is only a generated-directory lock probe for the owning test.
// It cannot call a database, capture service, console command, or web host.
if (args.Length == 2 && args[0] == "--probe-generated-lock")
{
    try
    {
        using var lease = new BackupLocalInstanceLock(new(true, args[1], "", "", "fixture", 1)).Acquire();
        return 0;
    }
    catch (BackupLocalInstanceLockFailure) { return 23; }
}

var checks = new List<object>();
var failures = 0;
async Task Check(string name, Func<Task> body)
{
    try { await body(); checks.Add(new { name, passed = true }); Console.WriteLine("PASS " + name); }
    catch (Exception error)
    {
        failures++;
        checks.Add(new { name, passed = false, error = error.Message });
        Console.WriteLine("FAIL " + name + ": " + error.Message);
    }
}

static void Assert(bool value, string reason) { if (!value) throw new Exception(reason); }
static Task Sync(Action action) { action(); return Task.CompletedTask; }
static void RefusesLock(IBackupLocalInstanceLock instanceLock)
{
    try { using var unexpected = instanceLock.Acquire(); }
    catch (BackupLocalInstanceLockFailure) { return; }
    throw new Exception("Invalid or held lock was accepted");
}

await Check("Stopped capture is default disabled and registration performs no file or capture work", () => Sync(() =>
{
    var configuration = new ConfigurationBuilder().Build();
    Assert(!OperatorCaptureOptions.Read(configuration).Enabled, "Command enabled by default");
    var services = new ServiceCollection();
    services.AddOperatorCaptureCommand(configuration);
    using var provider = services.BuildServiceProvider();
    Assert(!provider.GetRequiredService<OperatorCaptureOptions>().Enabled, "Registration enabled command");
    var explicitConfiguration = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>
    { ["Operator:Capture:Enabled"] = "true" }).Build();
    Assert(OperatorCaptureOptions.Read(explicitConfiguration).Enabled, "Explicit flag ignored");
}));

foreach (var arguments in new[] { Array.Empty<string>(), new[] { "wrong" }, new[] { "capture-stopped", "secret-must-not-print" } })
    await Check("Only the exact command with no extra arguments is accepted: " + arguments.Length, async () =>
    {
        var fixture = new CaptureFixture();
        var console = new FakeConsole();
        var code = await fixture.Command(console).RunAsync(arguments, default);
        Assert(code == OperatorExitCode.InvalidCommand && fixture.Lock.Acquisitions == 0 && fixture.Ledger.Reservations == 0, "Invalid command ran work");
        Assert(!console.Output.Contains("secret-must-not-print", StringComparison.Ordinal), "Rejected argument echoed");
    });

await Check("Redirected terminal is refused before prompts, locks, receipts or capture", async () =>
{
    var fixture = new CaptureFixture();
    var console = new FakeConsole { IsInteractive = false };
    var result = await fixture.Command(console).RunAsync(["capture-stopped"], default);
    Assert(result == OperatorExitCode.InteractiveRequired && console.Reads == 0 && fixture.Lock.Acquisitions == 0 && fixture.Ledger.Reservations == 0, "Noninteractive operation executed");
});

foreach (var disabled in new[] { "operator", "backup" })
    await Check("Both independent enablement flags are required: " + disabled, async () =>
    {
        var fixture = new CaptureFixture { OperatorEnabled = disabled != "operator", BackupEnabled = disabled != "backup" };
        var console = new FakeConsole();
        var result = await fixture.Command(console).RunAsync(["capture-stopped"], default);
        Assert(result == OperatorExitCode.PreflightFailed && console.Reads == 0 && fixture.Lock.Acquisitions == 0, "Disabled mode touched input or storage");
    });

foreach (var key in new[] { "", "not-a-uuid", Guid.Empty.ToString("D"), Guid.NewGuid().ToString("N") })
    await Check("A nonempty canonical UUID is required before capture: " + key.Length, async () =>
    {
        var fixture = new CaptureFixture();
        var result = await fixture.Command(new FakeConsole(key)).RunAsync(["capture-stopped"], default);
        Assert(result == OperatorExitCode.InputRejected && fixture.Lock.Acquisitions == 0 && fixture.Capture.Calls == 0, "Bad key reached capture");
    });

foreach (var confirmation in new[] { "", "CREATE ENCRYPTED BACKUP", OperatorCaptureStoppedCommand.Confirmation.ToLowerInvariant(), OperatorCaptureStoppedCommand.Confirmation + " " })
    await Check("Exact stopped-service and no-external-writer attestation is mandatory: " + confirmation.Length, async () =>
    {
        var fixture = new CaptureFixture();
        var result = await fixture.Command(new FakeConsole(Guid.NewGuid().ToString("D"), confirmation)).RunAsync(["capture-stopped"], default);
        Assert(result == OperatorExitCode.Cancelled && fixture.Lock.Acquisitions == 0 && fixture.Capture.Calls == 0, "Inexact attestation reached capture");
    });

await Check("Escape or end-of-input cancels without acquiring the lock", async () =>
{
    var fixture = new CaptureFixture();
    var result = await fixture.Command(new FakeConsole()).RunAsync(["capture-stopped"], default);
    Assert(result == OperatorExitCode.Cancelled && fixture.Lock.Acquisitions == 0, "Missing input reached lock");
    var cancelled = new FakeConsole();
    cancelled.Keys.Enqueue(new('\u001b', ConsoleKey.Escape, false, false, false));
    result = await fixture.Command(cancelled).RunAsync(["capture-stopped"], default);
    Assert(result == OperatorExitCode.Cancelled && fixture.Lock.Acquisitions == 0, "Escape reached lock");
});

await Check("A held local instance lock refuses capture without cancelling or changing its owner", async () =>
{
    var fixture = new CaptureFixture();
    fixture.Lock.Fail = true;
    var console = CaptureFixture.Input();
    var result = await fixture.Command(console).RunAsync(["capture-stopped"], default);
    Assert(result == OperatorExitCode.PreflightFailed && fixture.Preflight.Calls == 0 && fixture.Ledger.Reservations == 0, "Lock refusal reached protected operation");
    Assert(console.Output.Contains("OPERATOR_CAPTURE_EXCLUSIVE_ACCESS_REQUIRED", StringComparison.Ordinal), "Lock refusal lost safe status");
    Assert(fixture.Lock.Disposals == 0, "Failed acquirer released another lease");
});

await Check("Existing-key preflight runs under the lease and failure leaves no receipt", async () =>
{
    var fixture = new CaptureFixture();
    fixture.Preflight.OnValidate = () =>
    {
        Assert(fixture.Lock.Held, "Preflight escaped lock");
        throw new InvalidOperationException("sensitive-provider-details");
    };
    var console = CaptureFixture.Input();
    var result = await fixture.Command(console).RunAsync(["capture-stopped"], default);
    Assert(result == OperatorExitCode.PreflightFailed && fixture.Lock.Disposals == 1 && fixture.Ledger.Reservations == 0, "Failed preflight created work or retained lock");
    Assert(!console.Output.Contains("sensitive-provider-details", StringComparison.Ordinal), "Provider failure leaked");
});

await Check("Stopped capture uses the existing controller, reserved receipt owner, fake clock and integrity-only result", async () =>
{
    var fixture = new CaptureFixture();
    var key = Guid.NewGuid();
    fixture.Capture.OnCapture = (_, _) =>
    {
        Assert(fixture.Lock.Held && fixture.Maintenance.Snapshot.State == MaintenanceState.Frozen, "Capture ran outside exclusion");
        return Task.CompletedTask;
    };
    fixture.Ledger.OnComplete = () => Assert(fixture.Lock.Held, "Receipt completed after release");
    var console = CaptureFixture.Input(key);
    var result = await fixture.Command(console).RunAsync(["capture-stopped"], default);
    var receipt = fixture.Ledger.Receipts[(Guid.Empty, key)];
    Assert(result == OperatorExitCode.Success && fixture.Capture.Calls == 1 && receipt.Status == "Succeeded", "Successful capture contract failed");
    Assert(receipt.CreatedAtUtc == fixture.Clock.GetUtcNow() && fixture.Capture.CreatedAt == receipt.CreatedAtUtc, "Clock or receipt creation time changed");
    Assert(fixture.Capture.OperationId == receipt.OperationId && fixture.Lock.Disposals == 1 && !fixture.Lock.Held, "Operation or lock lifetime changed");
    Assert(fixture.Maintenance.Snapshot == new MaintenanceSnapshot(MaintenanceState.Open, 0), "Maintenance admission retained");
    Assert(console.Output.Contains("ARTIFACT_INTEGRITY_ONLY", StringComparison.Ordinal) && console.Output.Contains(receipt.OperationId.ToString("D"), StringComparison.Ordinal), "Result overclaimed or omitted operation");
});

await Check("Successful operator replay has identical receipt and never recaptures", async () =>
{
    var fixture = new CaptureFixture();
    var key = Guid.NewGuid();
    Assert(await fixture.Command(CaptureFixture.Input(key)).RunAsync(["capture-stopped"], default) == 0, "Initial operation failed");
    var first = fixture.Ledger.Receipts[(Guid.Empty, key)];
    var replayConsole = CaptureFixture.Input(key);
    Assert(await fixture.Command(replayConsole).RunAsync(["capture-stopped"], default) == 0, "Replay failed");
    Assert(fixture.Capture.Calls == 1 && fixture.Ledger.Receipts[(Guid.Empty, key)] == first, "Replay changed artifact or receipt");
    Assert(fixture.Lock.Acquisitions == 2 && fixture.Preflight.Calls == 2, "Replay bypassed terminal exclusion or fresh validation");
});

foreach (var status in new[] { "Pending", "Unknown", "Failed" })
    await Check("Existing " + status + " receipt is conservatively retained without capture", async () =>
    {
        var fixture = new CaptureFixture();
        var key = Guid.NewGuid();
        fixture.Ledger.ExistingStatus = status;
        var console = CaptureFixture.Input(key);
        var result = await fixture.Command(console).RunAsync(["capture-stopped"], default);
        Assert(result == OperatorExitCode.OperationFailed && fixture.Capture.Calls == 0 && fixture.Ledger.Completions == 0, "Existing receipt was executed or changed");
        if (status != "Failed") Assert(console.Output.Contains("PENDING_RECONCILIATION_REQUIRED", StringComparison.Ordinal), "Unknown or pending lost reconciliation instruction");
    });

await Check("HTTP actors cannot collide with the reserved operator owner and same keys stay actor scoped", async () =>
{
    var fixture = new CaptureFixture();
    var key = Guid.NewGuid();
    var user = Guid.NewGuid();
    static ClaimsPrincipal Principal(Guid id) => new(new ClaimsIdentity([
        new Claim(ClaimTypes.NameIdentifier, id.ToString("D")), new Claim(ClaimTypes.Role, "Admin")], "fixture"));
    try { AdminActor.From(Principal(Guid.Empty), Guid.NewGuid().ToString("N")); throw new Exception("Empty HTTP actor accepted"); }
    catch (ApiFailure error) { Assert(error.Code == ProblemCode.SESSION_REQUIRED, "Wrong empty actor rejection"); }
    using (var admission = fixture.Maintenance.TryEnter()!)
        await fixture.Control.RunAsync(AdminActor.From(Principal(user), Guid.NewGuid().ToString("N")), key,
            new("CREATE ENCRYPTED BACKUP"), admission, default);
    Assert(await fixture.Command(CaptureFixture.Input(key)).RunAsync(["capture-stopped"], default) == 0, "Operator operation collided with HTTP key");
    Assert(fixture.Capture.Calls == 2 && fixture.Ledger.Receipts.Count == 2, "Distinct owners shared receipt");
    Assert(fixture.Ledger.Receipts[(user, key)].RequestHash == fixture.Ledger.Receipts[(Guid.Empty, key)].RequestHash, "Operator changed the canonical F25 request");
});

await Check("Failed capture retains failed receipt and never leaks provider details or retries on replay", async () =>
{
    var fixture = new CaptureFixture();
    var key = Guid.NewGuid();
    fixture.Capture.OnCapture = (_, _) => throw new IOException("sensitive-provider-details");
    var console = CaptureFixture.Input(key);
    Assert(await fixture.Command(console).RunAsync(["capture-stopped"], default) == OperatorExitCode.OperationFailed, "Capture failure succeeded");
    Assert(fixture.Ledger.Receipts[(Guid.Empty, key)].Status == "Failed" && fixture.Lock.Disposals == 1, "Failure receipt or lease missing");
    Assert(!console.Output.Contains("sensitive-provider-details", StringComparison.Ordinal), "Provider details escaped");
    Assert(await fixture.Command(CaptureFixture.Input(key)).RunAsync(["capture-stopped"], default) == OperatorExitCode.OperationFailed && fixture.Capture.Calls == 1, "Failed attempt blindly retried");
});

await Check("Cancellation retains exclusion until the actual capture and failure receipt settle", async () =>
{
    var fixture = new CaptureFixture();
    var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var finish = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    fixture.Capture.OnCapture = async (_, ct) => { entered.SetResult(); await finish.Task; ct.ThrowIfCancellationRequested(); };
    fixture.Ledger.OnComplete = () => Assert(fixture.Lock.Held, "Cancelled completion escaped lock");
    using var cancelled = new CancellationTokenSource();
    var key = Guid.NewGuid();
    var pending = fixture.Command(CaptureFixture.Input(key)).RunAsync(["capture-stopped"], cancelled.Token);
    await entered.Task;
    cancelled.Cancel();
    Assert(!pending.IsCompleted && fixture.Lock.Held && fixture.Maintenance.Snapshot.State == MaintenanceState.Frozen, "Observer cancelled underlying lifetime");
    finish.SetResult();
    Assert(await pending == OperatorExitCode.Cancelled && fixture.Lock.Disposals == 1, "Settled cancellation did not release lease");
    Assert(fixture.Ledger.Receipts[(Guid.Empty, key)].FailureCode == "BACKUP_CANCELLED", "Cancelled receipt missing");
});

await Check("The local lock is exclusive, permanent, private and reusable only after release", () => Sync(() =>
{
    using var directory = new GeneratedDirectory();
    var instanceLock = new BackupLocalInstanceLock(directory.Options);
    using (var owner = instanceLock.Acquire())
    {
        RefusesLock(instanceLock);
        Assert(File.GetUnixFileMode(directory.LockPath) == (UnixFileMode.UserRead | UnixFileMode.UserWrite), "Lock was not created 0600");
        Assert(new FileInfo(directory.LockPath).Length == 0, "Lock holds data");
    }
    Assert(File.Exists(directory.LockPath), "Release deleted the lock identity");
    using var next = instanceLock.Acquire();
}));

await Check("A second cooperating process cannot acquire the same lock until its owner releases", async () =>
{
    using var directory = new GeneratedDirectory();
    var instanceLock = new BackupLocalInstanceLock(directory.Options);
    async Task<int> Probe()
    {
        var start = new ProcessStartInfo(Environment.ProcessPath!)
        { UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true };
        if (Path.GetFileNameWithoutExtension(Environment.ProcessPath) == "dotnet")
            start.ArgumentList.Add(typeof(GeneratedDirectory).Assembly.Location);
        start.ArgumentList.Add("--probe-generated-lock");
        start.ArgumentList.Add(directory.Root);
        using var process = Process.Start(start) ?? throw new Exception("Could not start generated lock probe");
        await process.WaitForExitAsync();
        return process.ExitCode;
    }
    using (var owner = instanceLock.Acquire()) Assert(await Probe() == 23, "Another process bypassed held lock");
    Assert(await Probe() == 0, "Released lock could not be acquired by next process");
});

foreach (var invalid in new[] { "nonempty", "permissive", "executable", "directory", "symlink", "root-symlink" })
    await Check("Existing unsafe lock or root is refused without mutation: " + invalid, () => Sync(() =>
    {
        using var directory = new GeneratedDirectory();
        var options = directory.Options;
        if (invalid == "directory") Directory.CreateDirectory(directory.LockPath);
        else if (invalid == "symlink") File.CreateSymbolicLink(directory.LockPath, Path.Combine(directory.Root, "absent"));
        else if (invalid == "root-symlink")
        {
            var real = Path.Combine(directory.Root, "real");
            Directory.CreateDirectory(real, UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute);
            var alias = Path.Combine(directory.Root, "alias");
            Directory.CreateSymbolicLink(alias, real);
            options = options with { DestinationRoot = alias };
        }
        else
        {
            using (var file = new FileStream(directory.LockPath, new FileStreamOptions
            { Mode = FileMode.CreateNew, Access = FileAccess.Write, UnixCreateMode = UnixFileMode.UserRead | UnixFileMode.UserWrite }))
                if (invalid == "nonempty") file.WriteByte(1);
            if (invalid == "permissive") File.SetUnixFileMode(directory.LockPath, UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.GroupRead);
            if (invalid == "executable") File.SetUnixFileMode(directory.LockPath, UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute);
        }
        RefusesLock(new BackupLocalInstanceLock(options));
        if (invalid == "nonempty") Assert(File.ReadAllBytes(directory.LockPath).SequenceEqual(new byte[] { 1 }), "Refusal changed existing data");
        if (invalid == "permissive") Assert(File.GetUnixFileMode(directory.LockPath).HasFlag(UnixFileMode.GroupRead), "Refusal repaired existing permissions");
        if (invalid == "symlink") Assert(new FileInfo(directory.LockPath).LinkTarget is not null, "Refusal replaced symlink");
    }));

await Check("Web helper performs no lock I/O when disabled and holds the shared lock when enabled", () => Sync(() =>
{
    using var directory = new GeneratedDirectory();
    var disabled = new ServiceCollection().AddSingleton(directory.Options with { Enabled = false }).BuildServiceProvider();
    using (disabled)
        Assert(OperatorCaptureHosting.AcquireWebInstanceLock(disabled) is null && !File.Exists(directory.LockPath), "Disabled web mode created lock");
    using var enabled = new ServiceCollection().AddSingleton(directory.Options).BuildServiceProvider();
    using (var hostLease = OperatorCaptureHosting.AcquireWebInstanceLock(enabled))
    {
        Assert(hostLease is not null, "Enabled web mode lacks lock");
        RefusesLock(new BackupLocalInstanceLock(directory.Options));
    }
    using var next = new BackupLocalInstanceLock(directory.Options).Acquire();
}));

await Check("Host stop returning cannot release lock before workers, detached admissions and capture settle", async () =>
{
    using var directory = new GeneratedDirectory();
    var coordinator = new MaintenanceCoordinator(TimeProvider.System);
    var worker = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var detached = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    using var request = coordinator.TryEnter()!;
    _ = request.Track(detached.Task);
    request.Dispose();
    var maintenance = coordinator.BeginAsync();
    var instanceLock = new BackupLocalInstanceLock(directory.Options);
    var lease = instanceLock.Acquire();
    async Task SimulatedHostFinally()
    {
        await OperatorCaptureHosting.WaitForWebWritersAsync([worker.Task], coordinator);
        lease.Dispose();
    }
    var shutdown = SimulatedHostFinally();
    Assert(!shutdown.IsCompleted, "Host-stop return abandoned real worker");
    RefusesLock(instanceLock);
    worker.SetResult();
    Assert(!shutdown.IsCompleted, "Worker completion abandoned detached request");
    RefusesLock(instanceLock);
    detached.SetResult();
    using (var capture = await maintenance)
    {
        Assert(!shutdown.IsCompleted && coordinator.Snapshot.State == MaintenanceState.Frozen, "Capture lifetime abandoned");
        RefusesLock(instanceLock);
    }
    await shutdown;
    using var next = instanceLock.Acquire();
});

await Check("Faulted worker observation still waits for every other actual task", async () =>
{
    var worker = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var coordinator = new MaintenanceCoordinator(TimeProvider.System);
    var waiting = OperatorCaptureHosting.WaitForWebWritersAsync([Task.FromException(new IOException("generated worker failure")), worker.Task], coordinator);
    Assert(!waiting.IsCompleted, "First worker failure abandoned another worker");
    worker.SetResult();
    await waiting;
});

await Check("Concrete preflight validates existing paths and keys with a fresh time and never provisions missing material", () => Sync(() =>
{
    using var directory = new GeneratedDirectory();
    var dp = Path.Combine(directory.Root, "dp");
    var web = Path.Combine(directory.Root, "web");
    var destination = Path.Combine(directory.Root, "destination");
    foreach (var path in new[] { dp, web, destination })
        Directory.CreateDirectory(path, UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute);
    var fixtureKey = Path.Combine(directory.Root, "fixture-bytes");
    using (var file = new FileStream(fixtureKey, new FileStreamOptions
    { Mode = FileMode.CreateNew, Access = FileAccess.Write, UnixCreateMode = UnixFileMode.UserRead | UnixFileMode.UserWrite }))
        file.Write(new byte[32]);
    var options = new BackupOptions(true, destination, dp, fixtureKey, "fixture", 1);
    var configuration = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?> { ["Blog:Mode"] = "PostgreSql" }).Build();
    var clock = new FixedClock();
    var keys = new RecordingKeys();
    var preflight = new OperatorCapturePreflight(options, configuration, new FixtureEnvironment { WebRootPath = web }, keys, clock);
    preflight.Validate();
    Assert(keys.Calls == 1 && keys.Directory == dp && keys.Now == clock.GetUtcNow(), "Existing-key validation skipped");
    try
    {
        new OperatorCapturePreflight(options, configuration, new FixtureEnvironment { WebRootPath = web }, new BackupKeyValidator(), clock).Validate();
        throw new Exception("Empty DP directory passed real validator");
    }
    catch (InvalidOperationException error) { Assert(error.Message == "BACKUP_CURRENT_DP_KEY_INVALID", "Wrong missing-key refusal"); }
    Assert(!Directory.EnumerateFileSystemEntries(dp).Any(), "Preflight created a key");
}));

await Check("File ledger preserves reserved operator receipt across fresh command and ledger instances", async () =>
{
    using var directory = new GeneratedDirectory();
    var fixture = new CaptureFixture();
    var key = Guid.NewGuid();
    var capture = fixture.Capture;
    async Task<int> Run()
    {
        var coordinator = new MaintenanceCoordinator(fixture.Clock);
        var ledger = new FileBackupOperationLedger(directory.Options, new LinuxPrivateFileDurability());
        var control = new BackupControlService(directory.Options, coordinator, ledger, capture, fixture.Clock, NullLogger<BackupControlService>.Instance);
        var command = new OperatorCaptureStoppedCommand(CaptureFixture.Input(key), new(true), directory.Options,
            new BackupLocalInstanceLock(directory.Options), new FakePreflight(), coordinator, control);
        return await command.RunAsync(["capture-stopped"], default);
    }
    Assert(await Run() == 0 && await Run() == 0 && capture.Calls == 1, "Persistent replay recaptured or failed");
    var files = Directory.GetFiles(directory.Root, "operation-*.json");
    Assert(files.Length == 1, "Operator receipt namespace unstable");
    using var source = File.OpenRead(files[0]);
    var receipt = await JsonSerializer.DeserializeAsync<BackupOperationReceipt>(source, ApiJson.Options);
    Assert(receipt is { UserId: var owner, Status: "Succeeded" } && owner == Guid.Empty, "Reserved receipt owner not persisted");
});

var output = Path.GetFullPath("artifacts/f26");
Directory.CreateDirectory(output);
await File.WriteAllTextAsync(Path.Combine(output, "operator-capture-results.json"), JsonSerializer.Serialize(new
{
    scope = "Isolated command, fake clock/capture/ledger, generated lock/receipt paths and process probes only; no PostgreSQL, real keys, production data, listener or hosted workers",
    checks,
    failures
}, new JsonSerializerOptions { WriteIndented = true }));
return failures == 0 ? 0 : 1;

sealed class CaptureFixture
{
    public bool OperatorEnabled = true, BackupEnabled = true;
    public FixedClock Clock { get; } = new();
    public FakeCapture Capture { get; } = new();
    public FakeLedger Ledger { get; } = new();
    public FakePreflight Preflight { get; } = new();
    public FakeLock Lock { get; } = new();
    public MaintenanceCoordinator Maintenance { get; }
    public BackupControlService Control { get; }
    public CaptureFixture()
    {
        Maintenance = new(Clock);
        Control = new(new(true, "", "", "", "fixture", 1), Maintenance, Ledger, Capture, Clock, NullLogger<BackupControlService>.Instance);
    }
    public OperatorCaptureStoppedCommand Command(FakeConsole console) => new(console, new(OperatorEnabled),
        new(BackupEnabled, "", "", "", "fixture", 1), Lock, Preflight, Maintenance, Control);
    public static FakeConsole Input(Guid? key = null) => new((key ?? Guid.NewGuid()).ToString("D"), OperatorCaptureStoppedCommand.Confirmation);
}

sealed class FakeConsole(params string[] lines) : IOperatorConsole
{
    public bool IsInteractive { get; set; } = true;
    public Queue<ConsoleKeyInfo> Keys { get; } = new(lines.SelectMany(line => line.Select(c =>
        new ConsoleKeyInfo(c, ConsoleKey.A, false, false, false)).Append(new('\r', ConsoleKey.Enter, false, false, false))));
    private readonly StringBuilder output = new();
    public string Output => output.ToString();
    public int Reads;
    public void Write(string text) => output.Append(text);
    public ConsoleKeyInfo? ReadKey(CancellationToken ct) { ct.ThrowIfCancellationRequested(); Reads++; return Keys.Count == 0 ? null : Keys.Dequeue(); }
}

sealed class FixedClock : TimeProvider
{
    public override DateTimeOffset GetUtcNow() => new(2026, 10, 10, 12, 0, 0, TimeSpan.Zero);
}

sealed class FakePreflight : IOperatorCapturePreflight
{
    public int Calls;
    public Action? OnValidate;
    public void Validate() { Calls++; OnValidate?.Invoke(); }
}

sealed class FakeLock : IBackupLocalInstanceLock
{
    public int Acquisitions, Disposals;
    public bool Fail, Held;
    public IDisposable Acquire()
    {
        Acquisitions++;
        if (Fail || Held) throw new BackupLocalInstanceLockFailure();
        Held = true;
        return new Lease(this);
    }
    private sealed class Lease(FakeLock owner) : IDisposable
    {
        private bool disposed;
        public void Dispose() { if (disposed) return; disposed = true; owner.Held = false; owner.Disposals++; }
    }
}

sealed class FakeCapture : IBackupCapture
{
    public int Calls;
    public Guid OperationId;
    public DateTimeOffset CreatedAt;
    public Func<Guid, CancellationToken, Task>? OnCapture;
    public async Task CaptureAsync(Guid operationId, DateTimeOffset createdAt, CancellationToken ct)
    { Calls++; OperationId = operationId; CreatedAt = createdAt; if (OnCapture is not null) await OnCapture(operationId, ct); }
}

sealed class FakeLedger : IBackupOperationLedger
{
    public int Reservations, Completions;
    public string? ExistingStatus;
    public Action? OnComplete;
    public Dictionary<(Guid User, Guid Key), BackupOperationReceipt> Receipts { get; } = [];
    public Task<BackupReservation> ReserveAsync(Guid user, Guid key, string hash, DateTimeOffset now, CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        Reservations++;
        if (Receipts.TryGetValue((user, key), out var existing))
        {
            if (existing.RequestHash != hash) throw new ApiFailure(ProblemCode.IDEMPOTENCY_CONFLICT);
            return Task.FromResult(new BackupReservation(existing, false));
        }
        var receipt = new BackupOperationReceipt(Guid.NewGuid(), user, key, hash, now, ExistingStatus ?? "Pending", null);
        Receipts[(user, key)] = receipt;
        return Task.FromResult(new BackupReservation(receipt, ExistingStatus is null));
    }
    public Task CompleteAsync(BackupOperationReceipt receipt, string status, string? failureCode, CancellationToken ct)
    {
        Completions++;
        OnComplete?.Invoke();
        Receipts[(receipt.UserId, receipt.Key)] = receipt with { Status = status, FailureCode = failureCode };
        return Task.CompletedTask;
    }
}

sealed class GeneratedDirectory : IDisposable
{
    public string Root { get; } = Path.Combine(Path.GetTempPath(), "blog-operator-capture-fixture-" + Guid.NewGuid().ToString("N"));
    public string LockPath => Path.Combine(Root, BackupLocalInstanceLock.FileName);
    public BackupOptions Options => new(true, Root, "", "", "fixture", 1);
    public GeneratedDirectory() => Directory.CreateDirectory(Root, UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute);
    public void Dispose() => Directory.Delete(Root, recursive: true);
}

sealed class RecordingKeys : IBackupKeyValidator
{
    public int Calls;
    public string? Directory;
    public DateTimeOffset Now;
    public void Validate(string directory, DateTimeOffset now) { Calls++; Directory = directory; Now = now; }
}

sealed class FixtureEnvironment : Microsoft.AspNetCore.Hosting.IWebHostEnvironment
{
    public string WebRootPath { get; set; } = "";
    public string ContentRootPath { get; set; } = "";
    public string ApplicationName { get; set; } = "fixture";
    public string EnvironmentName { get; set; } = "ComponentTests";
    public Microsoft.Extensions.FileProviders.IFileProvider WebRootFileProvider { get; set; } = new Microsoft.Extensions.FileProviders.NullFileProvider();
    public Microsoft.Extensions.FileProviders.IFileProvider ContentRootFileProvider { get; set; } = new Microsoft.Extensions.FileProviders.NullFileProvider();
}
