using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using Blog.Web.Application.Administration;
using Blog.Web.Domain;
using Blog.Web.Domain.Persistence;

namespace Blog.Web.Application.Articles;

public sealed record CreateArticleInput(string? Title = null, string? Slug = null);
public sealed record IdentityInput([property: JsonRequired] string Slug);
public sealed record DisplayMeta(
    [property: JsonRequired] string Alt, [property: JsonRequired] string Caption,
    [property: JsonRequired] string Credit, [property: JsonRequired] string SourceUrl,
    [property: JsonRequired] string LicenseName, [property: JsonRequired] string LicenseUrl);
public sealed record DraftInput(
    [property: JsonRequired] string Title, [property: JsonRequired] string Summary,
    [property: JsonRequired] Guid? ColumnId, [property: JsonRequired] Guid? CoverMediaId,
    [property: JsonRequired] DisplayMeta? CoverDisplayMeta, [property: JsonRequired] JsonElement ContentJson,
    [property: JsonRequired] int SchemaVersion);
public sealed record PublishedArticleSummary(Guid RevisionId, string Title, string Summary, Guid ColumnId, int RevisionNo, string ContentHash);
public sealed record ArticleView(Guid Id, string Slug, string State, long ArticleVersion, string ArticleEtag, long? DraftVersion, string? DraftEtag,
    DateTimeOffset CreatedAt, DateTimeOffset? FirstPublishedAt, DateTimeOffset? LastPublishedAt, PublishedArticleSummary? Published);
public sealed record DraftView(Guid ArticleId, string Title, string Summary, Guid? ColumnId, Guid? CoverMediaId, DisplayMeta? CoverDisplayMeta,
    JsonElement ContentJson, int SchemaVersion, string ContentHash, Guid? BasePublishedRevisionId, long DraftVersion, string DraftEtag, DateTimeOffset UpdatedAt);
public sealed record ArticleListItem(Guid Id, string Slug, string State, string Title, Guid? ColumnId, long ArticleVersion, long? DraftVersion, DateTimeOffset CreatedAt);
public sealed record AdminArticlePage(IReadOnlyList<ArticleListItem> Items, int Total, int Page, int PageSize);
public sealed record ArticleRead(Article Article, ArticleDraft? Draft, ArticleRevision? Published);
public sealed record ArticleFilter(ArticleState? State, string? Query, Guid? ColumnId, int Page, int PageSize);
public interface IAdminArticleStore
{
    Task<AdminArticlePage> ListAsync(ArticleFilter filter, CancellationToken ct);
    Task<ArticleRead?> ReadAsync(Guid id, bool tracked, CancellationToken ct);
    Task<bool> SlugExistsAsync(string slug, Guid? exceptId, CancellationToken ct);
    Task<Column?> ColumnAsync(Guid id, CancellationToken ct);
    Task<MediaAsset?> MediaAsync(Guid id, CancellationToken ct);
    void Add(Article article, ArticleDraft draft);
    Task ReplaceBodyReferencesAsync(Guid articleId, IReadOnlyList<RichText.BodyMediaReference> references, CancellationToken ct);
}
public interface IDraftBodyBoundary
{
    RichText.RichTextDocument Validate(JsonElement body, int schemaVersion);
}
public static class ArticleInput
{
    public static ApiFailure Invalid(string field, FieldIssue issue = FieldIssue.Invalid) => new(ProblemCode.VALIDATION_FAILED, new Dictionary<string, FieldIssue[]> { [field] = [issue] });
    public static string Text(string? input, int limit, string field)
    {
        if (input is null) throw Invalid(field, FieldIssue.Required);
        string value; try { value = input.Normalize(NormalizationForm.FormC); } catch (ArgumentException) { throw Invalid(field); }
        if (value.EnumerateRunes().Count() > limit) throw Invalid(field, FieldIssue.TooLong);
        return value;
    }
    public static string Slug(string? input)
    {
        var value = Text(input, ContentLimits.SlugScalars, "slug");
        if (!Regex.IsMatch(value, "^[a-z0-9]+(?:-[a-z0-9]+)*$")) throw Invalid("slug");
        return value;
    }
    public static DisplayMeta Meta(DisplayMeta input)
    {
        var value = new DisplayMeta(Text(input.Alt, ContentLimits.AltScalars, "coverDisplayMeta.alt"), Text(input.Caption, ContentLimits.CaptionScalars, "coverDisplayMeta.caption"),
            Text(input.Credit, ContentLimits.CreditScalars, "coverDisplayMeta.credit"), Text(input.SourceUrl, ContentLimits.LinkScalars, "coverDisplayMeta.sourceUrl"),
            Text(input.LicenseName, ContentLimits.LicenseScalars, "coverDisplayMeta.licenseName"), Text(input.LicenseUrl, ContentLimits.LinkScalars, "coverDisplayMeta.licenseUrl"));
        if (string.IsNullOrWhiteSpace(value.Alt)) throw Invalid("coverDisplayMeta.alt", FieldIssue.Required);
        CheckUrl(value.SourceUrl, "coverDisplayMeta.sourceUrl"); CheckUrl(value.LicenseUrl, "coverDisplayMeta.licenseUrl"); return value;
    }
    private static void CheckUrl(string value, string field)
    {
        if (value.Length > 0 && (value.Any(char.IsControl) || !Uri.TryCreate(value, UriKind.Absolute, out var uri) || uri.Scheme != "https" || !string.IsNullOrEmpty(uri.UserInfo))) throw Invalid(field);
    }
    public static DraftInput Normalize(DraftInput input)
    {
        if (input.ColumnId == Guid.Empty) throw Invalid("columnId");
        if (input.CoverMediaId == Guid.Empty || (input.CoverMediaId is null) != (input.CoverDisplayMeta is null)) throw Invalid("coverMediaId");
        return input with { Title = Text(input.Title, ContentLimits.TitleScalars, "title"), Summary = Text(input.Summary, ContentLimits.SummaryScalars, "summary"), CoverDisplayMeta = input.CoverDisplayMeta is null ? null : Meta(input.CoverDisplayMeta) };
    }
    public static string ContentHash(DraftInput input) => CanonicalRequest.Hash("draft.content", "", JsonSerializer.SerializeToElement(input, ApiJson.Options));
    public static ArticleFilter Filter(string? state, string? query, Guid? columnId, int page, int pageSize)
    {
        ArticleState? parsed = null;
        if (state is not null && (!Enum.TryParse<ArticleState>(state, false, out var value) || !Enum.IsDefined(value) || state != value.ToString())) throw Invalid("state");
        else if (state is not null) parsed = Enum.Parse<ArticleState>(state);
        if (page < 1 || pageSize < 1 || pageSize > ContentLimits.AdminMaxPageSize || (long)(page - 1) * pageSize > int.MaxValue) throw Invalid("page");
        if (columnId == Guid.Empty) throw Invalid("columnId");
        return new(parsed, query is null ? null : Text(query, 100, "q"), columnId, page, pageSize);
    }
}
