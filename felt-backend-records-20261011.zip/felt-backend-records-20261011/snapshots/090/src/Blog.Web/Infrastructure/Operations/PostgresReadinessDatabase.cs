using Npgsql;

namespace Blog.Web.Infrastructure.Operations;

public sealed record ReadinessDatabaseSnapshot(int PostgresMajor, IReadOnlyList<string> AppliedMigrations,
    IReadOnlyList<int> ContentSchemaVersions);

public interface IReadinessDatabase
{
    Task<ReadinessDatabaseSnapshot> InspectAsync(string connectionString, CancellationToken cancellationToken);
}

// A single bounded SELECT, no EF migration, seed, repair, write, or subprocess.
// This adapter is exercised only through fake boundaries in offline F26 tests.
public sealed class PostgresReadinessDatabase : IReadinessDatabase
{
    public async Task<ReadinessDatabaseSnapshot> InspectAsync(string connectionString, CancellationToken cancellationToken)
    {
        try
        {
            var options = new NpgsqlConnectionStringBuilder(connectionString)
            {
                Timeout = 2, CommandTimeout = 2, Pooling = false, Enlist = false,
                IncludeErrorDetail = false, LogParameters = false
            };
            await using var connection = new NpgsqlConnection(options.ConnectionString);
            await connection.OpenAsync(cancellationToken);
            await using var command = new NpgsqlCommand("""
                SELECT current_setting('server_version_num')::integer / 10000,
                       ARRAY(SELECT "MigrationId" FROM public."__EFMigrationsHistory"
                             ORDER BY "MigrationId" COLLATE "C" LIMIT 257),
                       ARRAY(SELECT schema_version FROM public.article_drafts
                             UNION SELECT schema_version FROM public.article_revisions
                             ORDER BY schema_version LIMIT 17)
                """, connection) { CommandTimeout = 2 };
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken)) throw new InvalidOperationException();
            return new(reader.GetInt32(0), reader.GetFieldValue<string[]>(1), reader.GetFieldValue<int[]>(2));
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw new OperationCanceledException(cancellationToken);
        }
        catch (Exception error) when (error is not OutOfMemoryException)
        {
            // No inner exception, connection details, host names, SQL, or paths.
            throw new InvalidOperationException("READINESS_DATABASE_UNAVAILABLE");
        }
    }
}
