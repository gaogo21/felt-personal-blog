using System.Security.Claims;
using Blog.Web.Domain;

namespace Blog.Web.Application.Security;

public sealed record AdminIdentity(Guid Id, string UserName, string SecurityStamp);
public sealed record AdminSessionView(Guid Id, AdminIdentity Identity, DateTimeOffset CreatedAt,
    DateTimeOffset LastSeenAt, DateTimeOffset AbsoluteExpiresAt, DateTimeOffset? ReauthenticatedAt);

// Production uses Identity and PostgreSQL; explicit test doubles live only in the test assembly.
public interface IAdminSecurityStore
{
    Task<AdminIdentity?> VerifyCredentialsAsync(string userName, string password, DateTimeOffset now, CancellationToken ct);
    Task<AdminSessionView?> CreateSessionAsync(AdminIdentity identity, DateTimeOffset now, CancellationToken ct);
    Task<AdminSessionView?> ValidateAndTouchAsync(Guid sessionId, DateTimeOffset now, CancellationToken ct);
    Task RevokeAsync(Guid sessionId, DateTimeOffset now, CancellationToken ct);
    Task<bool> ReauthenticateAsync(Guid sessionId, string password, DateTimeOffset now, CancellationToken ct);
}
public sealed class SecurityStoreUnavailableException : Exception
{
    public SecurityStoreUnavailableException() : base("SECURITY_STORE_UNAVAILABLE") { }
}
public sealed class AdminSecurityService(IAdminSecurityStore store, TimeProvider clock)
{
    public const string Scheme = "AdminSession";
    public const string Policy = "Admin";
    public const string SessionClaim = "blog:session";
    public async Task<AdminSessionView?> LoginAsync(string userName, string password, CancellationToken ct)
    {
        var now = clock.GetUtcNow();
        var identity = await store.VerifyCredentialsAsync(userName, password, now, ct);
        return identity is null ? null : await store.CreateSessionAsync(identity, now, ct);
    }
    public Task<AdminSessionView?> ValidateAsync(Guid sessionId, CancellationToken ct) => store.ValidateAndTouchAsync(sessionId, clock.GetUtcNow(), ct);
    public Task LogoutAsync(Guid sessionId, CancellationToken ct) => store.RevokeAsync(sessionId, clock.GetUtcNow(), ct);
    public Task<bool> ReauthenticateAsync(Guid sessionId, string password, CancellationToken ct) => store.ReauthenticateAsync(sessionId, password, clock.GetUtcNow(), ct);
    public async Task<bool> HasRecentAuthenticationAsync(Guid sessionId, CancellationToken ct)
    {
        var current = await ValidateAsync(sessionId, ct);
        return current is not null && IsRecentlyReauthenticated(current);
    }
    internal bool IsRecentlyReauthenticated(AdminSessionView session) => session.ReauthenticatedAt is { } at && at <= clock.GetUtcNow() && clock.GetUtcNow() - at < TimeSpan.FromMinutes(ContentLimits.ReauthenticationMinutes);
    public static ClaimsPrincipal Principal(AdminSessionView session) => new(new ClaimsIdentity(new[]
    {
        new Claim(SessionClaim, session.Id.ToString()), new Claim(ClaimTypes.NameIdentifier, session.Identity.Id.ToString()),
        new Claim(ClaimTypes.Name, session.Identity.UserName), new Claim(ClaimTypes.Role, Policy)
    }, Scheme));
    public static Guid? SessionId(ClaimsPrincipal principal) => Guid.TryParse(principal.FindFirstValue(SessionClaim), out var id) ? id : null;
}

// Single application instance: per-connection-IP fixed windows; never trusts a client-supplied X-Forwarded-For.
public sealed class LoginAttemptLimiter(TimeProvider clock)
{
    private sealed record Window(DateTimeOffset Start, int Count);
    private readonly Dictionary<string, Window> windows = new(StringComparer.Ordinal);
    private readonly object gate = new();
    public bool TryAcquire(string key, out int retryAfter)
    {
        lock (gate)
        {
            var now = clock.GetUtcNow();
            foreach (var expired in windows.Where(x => now - x.Value.Start >= TimeSpan.FromMinutes(1)).Select(x => x.Key).ToArray()) windows.Remove(expired);
            if (!windows.TryGetValue(key, out var window))
            {
                // Bound memory and fail closed rather than evicting an attacker's active counter.
                if (windows.Count >= 10000) { retryAfter = 60; return false; }
                window = new Window(now, 0);
            }
            retryAfter = Math.Max(1, (int)Math.Ceiling((window.Start.AddMinutes(1) - now).TotalSeconds));
            if (window.Count >= ContentLimits.IpLoginAttemptsPerMinute) return false;
            windows[key] = window with { Count = window.Count + 1 }; return true;
        }
    }
}
