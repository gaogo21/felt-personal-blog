namespace Blog.Web.Application.Maintenance;

public enum MaintenanceState { Open, Draining, Frozen }

public sealed record MaintenanceSnapshot(MaintenanceState State, int InFlight);

/// <summary>
/// Admission and drain for one application process. Deployment must exclude all other
/// writers; this coordinator is deliberately not a distributed database or file lock.
/// </summary>
public sealed class MaintenanceCoordinator(TimeProvider clock)
{
    public static readonly TimeSpan DrainTimeout = TimeSpan.FromMinutes(5);
    private readonly object sync = new();
    private MaintenanceState state;
    private int inFlight;
    private MaintenanceLease? maintenance;
    private TaskCompletionSource? drained;

    public MaintenanceSnapshot Snapshot
    {
        get { lock (sync) return new(state, inFlight); }
    }

    public MaintenanceOperationLease? TryEnter()
    {
        lock (sync)
        {
            if (state != MaintenanceState.Open) return null;
            inFlight++;
            return new(this);
        }
    }

    /// <summary>
    /// Closes admission and atomically consumes the initiating request's root lease.
    /// Previously accepted operations and their detached children retain their leases.
    /// The caller must retain the returned lease for the complete frozen operation.
    /// </summary>
    public async Task<MaintenanceLease> BeginAsync(MaintenanceOperationLease? initiatingLease = null,
        CancellationToken ct = default)
    {
        ct.ThrowIfCancellationRequested();
        MaintenanceLease acquired;
        Task drain;
        lock (sync)
        {
            if (state != MaintenanceState.Open) throw new InvalidOperationException("MAINTENANCE_ALREADY_ACTIVE");
            if (initiatingLease is not null && (initiatingLease.Owner != this || initiatingLease.RootReleased))
                throw new InvalidOperationException("MAINTENANCE_REQUEST_LEASE_INVALID");
            state = MaintenanceState.Draining;
            maintenance = acquired = new(this);
            drained = new(TaskCreationOptions.RunContinuationsAsynchronously);
            if (initiatingLease is not null) ReleaseRootLocked(initiatingLease);
            if (inFlight == 0) drained.TrySetResult();
            drain = drained.Task;
        }
        try
        {
            await drain.WaitAsync(DrainTimeout, clock, ct);
            ct.ThrowIfCancellationRequested();
            lock (sync)
            {
                if (maintenance != acquired || inFlight != 0)
                    throw new InvalidOperationException("MAINTENANCE_DRAIN_INVALID");
                state = MaintenanceState.Frozen;
            }
            return acquired;
        }
        catch
        {
            acquired.Dispose();
            throw;
        }
    }

    internal void Track(MaintenanceOperationLease operation, Task task)
    {
        ArgumentNullException.ThrowIfNull(task);
        lock (sync)
        {
            // A child can only be attached while its admitted root still owns the work.
            // Draining does not revoke an old root's right to finish its operation.
            if (operation.Owner != this || operation.RootReleased)
                throw new InvalidOperationException("MAINTENANCE_OPERATION_LEASE_INVALID");
            operation.Children++;
        }
        _ = task.ContinueWith(completed =>
        {
            // WaitAsync may already have abandoned a faulted child. Observe its exception
            // without changing the task or the original caller's error contract.
            if (completed.IsFaulted) _ = completed.Exception;
            lock (sync)
            {
                operation.Children--;
                if (operation.RootReleased && operation.Children == 0) CompleteOperationLocked();
            }
        }, CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
    }

    internal void ReleaseRoot(MaintenanceOperationLease operation)
    {
        lock (sync) ReleaseRootLocked(operation);
    }

    private void ReleaseRootLocked(MaintenanceOperationLease operation)
    {
        if (operation.RootReleased) return;
        operation.RootReleased = true;
        if (operation.Children == 0) CompleteOperationLocked();
    }

    private void CompleteOperationLocked()
    {
        inFlight--;
        if (inFlight == 0 && state == MaintenanceState.Draining) drained?.TrySetResult();
    }

    internal void End(MaintenanceLease lease)
    {
        lock (sync)
        {
            if (maintenance != lease) return;
            maintenance = null;
            drained = null;
            state = MaintenanceState.Open;
        }
    }
}

public sealed class MaintenanceOperationLease : IDisposable
{
    internal MaintenanceOperationLease(MaintenanceCoordinator owner) => Owner = owner;
    internal MaintenanceCoordinator Owner { get; }
    internal bool RootReleased { get; set; }
    internal int Children { get; set; }

    public Task Track(Task task) { Owner.Track(this, task); return task; }
    public Task<T> Track<T>(Task<T> task) { Owner.Track(this, task); return task; }
    public void Dispose() => Owner.ReleaseRoot(this);
}

public sealed class MaintenanceLease : IDisposable
{
    internal MaintenanceLease(MaintenanceCoordinator owner) => Owner = owner;
    private MaintenanceCoordinator Owner { get; }
    public void Dispose() => Owner.End(this);
}
