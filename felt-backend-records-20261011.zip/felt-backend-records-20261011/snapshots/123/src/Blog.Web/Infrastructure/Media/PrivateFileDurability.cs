using System.Runtime.InteropServices;
namespace Blog.Web.Infrastructure.Media;

// Linux deployment contract: do not let a cross-filesystem File.Move silently copy.
// All inputs are validated private server-generated paths, never request filenames.
internal static class PrivateFileDurability
{
    public static void Commit(string source, string target)
    {
        if (!OperatingSystem.IsLinux()) throw new IOException("MEDIA_ATOMIC_RENAME_REQUIRES_LINUX");
        using (var stream = new FileStream(source, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) stream.Flush(flushToDisk: true);
        if (RenameAt2(-100, source, -100, target, 1) != 0) throw new IOException("MEDIA_ATOMIC_RENAME_FAILED");
        SyncDirectory(Path.GetDirectoryName(target)!);
        SyncDirectory(Path.GetDirectoryName(source)!);
    }
    private static void SyncDirectory(string path)
    {
        var fd = Open(path, 0);
        if (fd < 0) throw new IOException("MEDIA_DIRECTORY_SYNC_FAILED");
        try { if (Fsync(fd) != 0) throw new IOException("MEDIA_DIRECTORY_SYNC_FAILED"); }
        finally { Close(fd); }
    }
    [DllImport("libc", EntryPoint = "renameat2", SetLastError = true)]
    private static extern int RenameAt2(int oldDirectory, [MarshalAs(UnmanagedType.LPUTF8Str)] string oldPath, int newDirectory, [MarshalAs(UnmanagedType.LPUTF8Str)] string newPath, uint flags);
    [DllImport("libc", EntryPoint = "open", SetLastError = true)]
    private static extern int Open([MarshalAs(UnmanagedType.LPUTF8Str)] string path, int flags);
    [DllImport("libc", EntryPoint = "fsync", SetLastError = true)]
    private static extern int Fsync(int file);
    [DllImport("libc", EntryPoint = "close", SetLastError = true)]
    private static extern int Close(int file);
}
