using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Blog.Web.Application.Administration;
using Blog.Web.Infrastructure.Media;

namespace Blog.Web.Infrastructure.Backup;

public sealed record BackupOperationReceipt(Guid OperationId, Guid UserId, Guid Key, string RequestHash,
    DateTimeOffset CreatedAtUtc, string Status, string? FailureCode);
public sealed record BackupReservation(BackupOperationReceipt Receipt, bool IsNew);
public interface IBackupOperationLedger
{
    Task<BackupReservation> ReserveAsync(Guid user, Guid key, string hash, DateTimeOffset now, CancellationToken ct);
    Task CompleteAsync(BackupOperationReceipt reservation, string status, string? failureCode, CancellationToken ct);
}
// A host-private receipt avoids holding a PostgreSQL key/row lock while waiting
// for database writers to drain. Paths and bodies are never accepted from HTTP.
// An interrupted pending operation is not silently rerun, even after restart.
public sealed class FileBackupOperationLedger(BackupOptions options, IPrivateFileDurability durability) : IBackupOperationLedger
{
    private readonly SemaphoreSlim gate = new(1, 1);
    private string Name(Guid user, Guid key) => Path.Combine(options.DestinationRoot,
        "operation-" + Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(user.ToString("D") + ":" + key.ToString("D")))) + ".json");
    public async Task<BackupReservation> ReserveAsync(Guid user, Guid key, string hash, DateTimeOffset now, CancellationToken ct)
    {
        await gate.WaitAsync(ct);
        try
        {
            var path = Name(user, key);
            if (BackupArchivePaths.Exists(path))
            {
                using var stream = BackupArchivePaths.OpenRead(path);
                if (stream.Length > 4096) throw new IOException("BACKUP_RECEIPT_INVALID");
                var receipt = await JsonSerializer.DeserializeAsync<BackupOperationReceipt>(stream, ApiJson.Options, ct)
                    ?? throw new IOException("BACKUP_RECEIPT_INVALID");
                if (receipt.UserId != user || receipt.Key != key || receipt.OperationId == Guid.Empty) throw new IOException("BACKUP_RECEIPT_INVALID");
                if (receipt.RequestHash != hash) throw new ApiFailure(ProblemCode.IDEMPOTENCY_CONFLICT);
                return new(receipt, false);
            }
            var value = new BackupOperationReceipt(Guid.NewGuid(), user, key, hash, now, "Pending", null);
            await Persist(path, value, replace: false, ct);
            return new(value, true);
        }
        finally { gate.Release(); }
    }
    public async Task CompleteAsync(BackupOperationReceipt reservation, string status, string? failureCode, CancellationToken ct)
    {
        if (status is not ("Succeeded" or "Failed") || status == "Succeeded" && failureCode is not null)
            throw new ArgumentException("Invalid backup completion.");
        await gate.WaitAsync(ct);
        try
        {
            var path = Name(reservation.UserId, reservation.Key);
            using (var stream = BackupArchivePaths.OpenRead(path))
            {
                var current = await JsonSerializer.DeserializeAsync<BackupOperationReceipt>(stream, ApiJson.Options, ct);
                if (current != reservation) throw new IOException("BACKUP_RECEIPT_OWNER_CHANGED");
            }
            await Persist(path, reservation with { Status = status, FailureCode = failureCode }, replace: true, ct);
        }
        finally { gate.Release(); }
    }
    private async Task Persist(string path, BackupOperationReceipt value, bool replace, CancellationToken ct)
    {
        // Only this single-instance ledger owns these generated files. Atomic
        // replace updates its own pending receipt, never archive/user content.
        var temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            using (var stream = BackupArchivePaths.CreatePrivateFile(temporary))
            { await JsonSerializer.SerializeAsync(stream, value, ApiJson.Options, ct); await stream.FlushAsync(ct); durability.FlushFile(stream); }
            if (replace) File.Move(temporary, path, overwrite: true); else durability.RenameExclusive(temporary, path);
            durability.SyncDirectory(options.DestinationRoot);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }
}
