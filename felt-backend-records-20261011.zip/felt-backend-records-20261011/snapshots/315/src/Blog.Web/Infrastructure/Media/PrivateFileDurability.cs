using System.Runtime.InteropServices;
namespace Blog.Web.Infrastructure.Media;

// Injectable operations permit failure/order checks without pretending to simulate power loss.
public interface IPrivateFileDurability
{
    void FlushFile(FileStream file);
    void SyncDirectory(string path);
    void RenameExclusive(string source, string target);
}

// Linux deployment contract: no cross-filesystem copy or overwrite fallback.
// Inputs are private server-generated paths, never client filenames.
public sealed class LinuxPrivateFileDurability : IPrivateFileDurability
{
    public void FlushFile(FileStream file) => file.Flush(flushToDisk: true);
    public void RenameExclusive(string source, string target)
    {
        RequireLinux();
        if (RenameAt2(-100, source, -100, target, 1) != 0) throw new IOException("MEDIA_ATOMIC_RENAME_FAILED");
    }
    public void SyncDirectory(string path)
    {
        RequireLinux();
        var fd = Open(path, 0);
        if (fd < 0) throw new IOException("MEDIA_DIRECTORY_SYNC_FAILED");
        try { if (Fsync(fd) != 0) throw new IOException("MEDIA_DIRECTORY_SYNC_FAILED"); }
        finally { Close(fd); }
    }
    private static void RequireLinux()
    {
        if (!OperatingSystem.IsLinux()) throw new IOException("MEDIA_DURABILITY_REQUIRES_LINUX");
    }
    [DllImport("libc", EntryPoint = "renameat2", SetLastError = true)]
    private static extern int RenameAt2(int oldDirectory, [MarshalAs(UnmanagedType.LPUTF8Str)] string oldPath, int newDirectory, [MarshalAs(UnmanagedType.LPUTF8Str)] string newPath, uint flags);
    [DllImport("libc", EntryPoint = "open", SetLastError = true)]
    private static extern int Open([MarshalAs(UnmanagedType.LPUTF8Str)] string path, int flags);
    [DllImport("libc", EntryPoint = "fsync", SetLastError = true)]
    private static extern int Fsync(int file);
    [DllImport("libc", EntryPoint = "close", SetLastError = true)]
    private static extern int Close(int file);
}
