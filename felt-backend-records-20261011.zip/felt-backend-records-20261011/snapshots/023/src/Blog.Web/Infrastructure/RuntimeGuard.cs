using Blog.Web.Application;

namespace Blog.Web.Infrastructure;

public sealed record RuntimePresentation(bool IsLocalMock);

public static class RuntimeGuard
{
    public static RuntimePresentation Validate(IServiceProvider services)
    {
        var environment = services.GetRequiredService<IHostEnvironment>();
        var configuration = services.GetRequiredService<IConfiguration>();
        using var scope = services.CreateScope();
        var source = scope.ServiceProvider.GetRequiredService<IPublicContentQueries>();
        var mode = configuration["Blog:Mode"];
        if (mode == "LocalMock")
        {
            if (environment.EnvironmentName != "ComponentTests" || source.SourceKind != ContentSourceKind.TestFixture)
                throw new InvalidOperationException("LOCAL_MOCK_REQUIRES_ISOLATED_COMPONENT_TEST_FIXTURE");
            return new RuntimePresentation(true);
        }
        if (mode != "PostgreSql")
            throw new InvalidOperationException("CONTENT_MODE_INVALID");
        if (source.SourceKind == ContentSourceKind.TestFixture)
            throw new InvalidOperationException("TEST_FIXTURE_FORBIDDEN_IN_DATABASE_MODE");
        if (string.IsNullOrWhiteSpace(configuration.GetConnectionString("BlogDatabase")))
            throw new InvalidOperationException("PRODUCTION_DATABASE_CONFIGURATION_REQUIRED");
        _ = Media.MediaStorageOptions.Read(configuration); // F11 requires an explicit production media capacity and private root.
        if (source.SourceKind != ContentSourceKind.PostgreSql)
            throw new InvalidOperationException("POSTGRESQL_CONTENT_ADAPTER_REQUIRED");
        _ = PublicSiteOptions.Read(configuration);
        return new RuntimePresentation(false);
    }
}

public sealed class UnconfiguredContentQueries : IPublicContentQueries
{
    public ContentSourceKind SourceKind => ContentSourceKind.Unconfigured;
    private static InvalidOperationException Missing() => new("PUBLIC_CONTENT_SOURCE_NOT_CONFIGURED");
    public Task<HomeContent> GetHomeAsync(CancellationToken cancellationToken) => throw Missing();
    public Task<ArticlePage?> GetArticlesAsync(string? columnSlug, int page, int pageSize, CancellationToken cancellationToken) => throw Missing();
    public Task<ColumnContent?> GetColumnAsync(string slug, CancellationToken cancellationToken) => throw Missing();
    public Task<ArticleContent?> GetArticleAsync(string slug, CancellationToken cancellationToken) => throw Missing();
}
