using System.Text.Json;
using System.Text.RegularExpressions;
using Blog.Web.Domain;
using Blog.Web.Domain.Persistence;

namespace Blog.Web.Application.Administration;

public enum AuditAction { ArticleCreated, ArticleIdentityChanged, DraftSaved, ArticlePublished, ArticleWithdrawn, ArticleTrashed, ArticleRestored, ArticlePurged, RevisionRestored, ColumnCreated, ColumnSaved, ColumnActivated, ColumnArchived, ColumnRestored, ColumnOrderChanged, ArticleOrderChanged, HomePublished, MediaUploaded, MediaSaved, MediaTrashed, MediaRestored, MediaPurged, MediaPurgeRequested, MediaPurgeRetried, MediaPurgeFailed }
public enum AuditEntity { Article, Draft, Column, Home, Media, Site }
public enum AuditState { Draft, Published, Withdrawn, Trashed, Purged, Active, Archived, Uploading, Processing, Ready, Rejected }
public sealed record AuditFacts(int? ItemCount = null, long? ByteCount = null, AuditState? FromState = null, AuditState? ToState = null);
public sealed record AuditDescription(AuditAction Action, AuditEntity EntityType, Guid? EntityId, long? OldVersion = null, long? NewVersion = null, AuditFacts? Facts = null)
{
    public AuditEvent ToRecord(AdminActor actor, DateTimeOffset now)
    {
        if (!Enum.IsDefined(Action) || !Enum.IsDefined(EntityType) || (EntityType is AuditEntity.Home or AuditEntity.Site ? EntityId is not null : EntityId is null || EntityId == Guid.Empty) || OldVersion < 1 || NewVersion < 1 || Facts?.ItemCount < 0 || Facts?.ByteCount < 0
            || Facts?.FromState is { } from && !Enum.IsDefined(from) || Facts?.ToState is { } to && !Enum.IsDefined(to)) throw new ArgumentException("Invalid audit metadata.");
        return new() { Id = Guid.NewGuid(), ActorUserId = actor.UserId, Action = Action.ToString(), EntityType = EntityType.ToString(), EntityId = EntityId,
            OldVersion = OldVersion, NewVersion = NewVersion, OccurredAt = now, RequestId = actor.RequestId,
            Summary = JsonSerializer.Serialize(Facts ?? new AuditFacts(), ApiJson.Options) };
    }
}
public sealed record MutationResponse(int StatusCode, JsonElement? Body, string? ETag = null, string? Location = null)
{
    public static MutationResponse Json(int status, object body, EntityVersion? version = null, string? location = null) => new(status, JsonSerializer.SerializeToElement(body, ApiJson.Options), version?.ETag, location);
    public void Validate()
    {
        if (StatusCode is not (200 or 201 or 202 or 204) || (StatusCode == 204 && Body != null) || (StatusCode != 204 && Body == null) || (StatusCode == 201 && Location == null)) throw new ArgumentException("Invalid committed response.");
        if (ETag is not null && (ETag.Length > 100 || !Regex.IsMatch(ETag, "^\"[adscm]-([a-f0-9-]{36}|1)-[1-9][0-9]*\"$"))) throw new ArgumentException("Invalid ETag.");
        if (Location is not null && !IsLocalUrl(Location)) throw new ArgumentException("Invalid local Location.");
        if (StatusCode == 202 && (Body!.Value.ValueKind != JsonValueKind.Object || !Body.Value.TryGetProperty("statusUrl", out var url) || url.ValueKind != JsonValueKind.String || !IsLocalUrl(url.GetString()!))) throw new ArgumentException("Async response requires local statusUrl.");
    }
    private static bool IsLocalUrl(string value) => value.StartsWith('/') && !value.StartsWith("//") && !value.Contains('\\') && !value.Any(char.IsControl);
}
public sealed record MutationOutcome(MutationResponse Response, AuditDescription? Audit);
public sealed class MutationLocks
{
    public bool SiteState { get; }
    public IReadOnlyList<Guid> ArticlesAndDrafts { get; }
    public IReadOnlyList<Guid> Columns { get; }
    public IReadOnlyList<Guid> Media { get; }
    public MutationLocks(bool siteState, IEnumerable<Guid>? articlesAndDrafts = null, IEnumerable<Guid>? columns = null, IEnumerable<Guid>? media = null)
    {
        SiteState = siteState; ArticlesAndDrafts = Normalize(articlesAndDrafts); Columns = Normalize(columns); Media = Normalize(media);
    }
    private static IReadOnlyList<Guid> Normalize(IEnumerable<Guid>? values)
    {
        var ids = (values ?? []).ToArray();
        if (ids.Contains(Guid.Empty)) throw new ArgumentException("Empty lock ID.");
        return Array.AsReadOnly(ids.Distinct().OrderBy(x => x.ToString("N"), StringComparer.Ordinal).ToArray());
    }
}
public interface IAdminMutationTransaction
{
    Task AcquireKeyAsync(Guid actor, string scope, Guid key, CancellationToken ct);
    Task<IdempotencyRecord?> FindAsync(Guid actor, string scope, Guid key, CancellationToken ct);
    void Remove(IdempotencyRecord record);
    void Add(IdempotencyRecord record);
    void Add(AuditEvent audit);
    Task LockAsync(MutationLocks locks, CancellationToken ct);
}
public interface IAdminMutationStore
{
    Task<T> InTransactionAsync<T>(Func<IAdminMutationTransaction, CancellationToken, Task<T>> action, CancellationToken ct);
}
public sealed class AdminMutationExecutor(IAdminMutationStore store, TimeProvider clock)
{
    public Task<MutationResponse> ExecuteAsync(AdminActor actor, string scope, string target, Guid key, JsonElement body, MutationLocks locks,
        Func<IAdminMutationTransaction, CancellationToken, Task<MutationOutcome>> operation, CancellationToken ct,
        Func<CancellationToken, Task>? beforeReplay = null)
    {
        if (key == Guid.Empty) throw new ApiFailure(ProblemCode.IDEMPOTENCY_KEY_INVALID);
        var hash = CanonicalRequest.Hash(scope, target, body);
        return store.InTransactionAsync(async (tx, token) =>
        {
            // Auth/role/CSRF are HTTP prerequisites. Key serialization precedes business locks consistently.
            await tx.AcquireKeyAsync(actor.UserId, scope, key, token);
            var existing = await tx.FindAsync(actor.UserId, scope, key, token);
            var now = clock.GetUtcNow();
            // Purge replaces content-bearing receipts with this narrowly typed marker.
            // Its key remains reserved even past normal replay expiry, so retrying an
            // old create cannot recreate the article under a new generated identity.
            if (existing?.ResponseCode == 409)
            {
                if (beforeReplay is not null) await beforeReplay(token);
                if (!PurgedArticleReplay.TryRead(existing, out _)) throw new InvalidOperationException("INVALID_STORED_RESPONSE");
                if (existing.RequestHash != hash) throw new ApiFailure(ProblemCode.IDEMPOTENCY_CONFLICT);
                throw new ApiFailure(ProblemCode.STATE_CONFLICT);
            }
            if (existing is not null && existing.ExpiresAt > now)
            {
                // A purge's recent-auth window can expire while waiting for the key.
                // Only actual replays run this hook; they never take business locks.
                if (beforeReplay is not null) await beforeReplay(token);
                if (existing.RequestHash != hash) throw new ApiFailure(ProblemCode.IDEMPOTENCY_CONFLICT);
                if (existing.Status != IdempotencyState.Completed || existing.ResponseJson is null) throw new ApiFailure(ProblemCode.IDEMPOTENCY_IN_PROGRESS);
                var response = JsonSerializer.Deserialize<MutationResponse>(existing.ResponseJson, ApiJson.Options) ?? throw new InvalidOperationException("INVALID_STORED_RESPONSE"); response.Validate(); return response;
            }
            if (existing is not null) tx.Remove(existing);
            await tx.LockAsync(locks, token);
            // If-Match validation belongs here, after successful replay lookup, on the freshly locked row.
            var outcome = await operation(tx, token); outcome.Response.Validate();
            if (outcome.Audit is not null) tx.Add(outcome.Audit.ToRecord(actor, now));
            tx.Add(new IdempotencyRecord { ActorUserId = actor.UserId, Scope = scope, Key = key, RequestHash = hash, Status = IdempotencyState.Completed,
                ResponseCode = outcome.Response.StatusCode, ResponseJson = JsonSerializer.Serialize(outcome.Response, ApiJson.Options), CreatedAt = now, ExpiresAt = now.AddHours(ContentLimits.IdempotencyHours) });
            return outcome.Response;
        }, ct);
    }
    public Task<MutationResponse> ExecuteWithoutKeyAsync(AdminActor actor, MutationLocks locks, Func<IAdminMutationTransaction, CancellationToken, Task<MutationOutcome>> operation, CancellationToken ct)
        => store.InTransactionAsync(async (tx, token) =>
        { await tx.LockAsync(locks, token); var outcome = await operation(tx, token); outcome.Response.Validate(); if (outcome.Audit is not null) tx.Add(outcome.Audit.ToRecord(actor, clock.GetUtcNow())); return outcome.Response; }, ct);
}
