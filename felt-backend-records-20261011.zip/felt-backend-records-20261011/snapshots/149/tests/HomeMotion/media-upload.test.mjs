import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { JSDOM } from 'jsdom';

// Controller/DOM tests only: deterministic XHR, fetch, storage and clock. These
// do not make network requests or claim native upload/media-decoder coverage.
const source = readFileSync('src/Blog.Web/wwwroot/js/admin/media-upload.js', 'utf8');
const limits = readFileSync('src/Blog.Web/wwwroot/js/admin/media-limits.js', 'utf8').replace('export const ', 'const ');
const script = source.replace("import { MEDIA_LIMITS } from './media-limits.js';", limits).replace('export function ', 'function ')
  + '\nglobalThis.createMediaUploadController = createMediaUploadController;';
const ID = '11111111-1111-4111-8111-111111111111';
const OTHER_ID = '22222222-2222-4222-8222-222222222222';
const ACTOR_ID = '33333333-3333-4333-8333-333333333333';
const OTHER_ACTOR_ID = '44444444-4444-4444-8444-444444444444';
const STORE_KEY = 'felt.admin.media-upload.v1';
const response = (value, status = 200) => ({ status, ok: status >= 200 && status < 300, json: async () => structuredClone(value) });
const status = (state, extra = {}) => ({ id: ID, state, version: 2, errorCode: null, metadata: { kind: 'Image', mimeType: 'image/png', byteSize: 4 }, ...extra });
const accepted = { mediaId: ID, state: 'Processing', statusUrl: `/api/admin/v1/media/${ID}` };
const deferred = () => { let resolve, reject; const promise = new Promise((yes, no) => { resolve = yes; reject = no; }); return { resolve, reject, promise }; };
const flush = async () => { for (let n = 0; n < 30; n++) await Promise.resolve(); };
function file(name = '图.png', type = 'image/png', bytes = [1, 2, 3, 4], declaredSize = bytes.length) {
  const data = Uint8Array.from(bytes);
  return { name, type, size: declaredSize, async arrayBuffer() { return data.slice().buffer; },
    slice(_start, _end, mime) { return file(name, mime, bytes, declaredSize); } };
}
function memoryStorage(seed = {}) {
  const data = new Map(Object.entries(seed));
  return { data, getItem: key => data.get(key) ?? null, setItem: (key, value) => data.set(key, value), removeItem: key => data.delete(key) };
}
function environment({ storage = memoryStorage(), overrideFetch, cryptoAvailable = true, readFileImpl, startTime = 1000000 } = {}) {
  const dom = new JSDOM('<main></main>', { url: 'https://fixture.invalid/admin/media', runScripts: 'outside-only' });
  const w = dom.window, timers = new Map(), requests = [], fetches = [], changes = [], ready = [], hashes = [];
  let now = startTime, nextTimer = 0, uuidCount = 0, bootstrapCount = 0, visible = true, online = true;
  Object.defineProperty(w.document, 'visibilityState', { get: () => visible ? 'visible' : 'hidden', configurable: true });
  Object.defineProperty(w.navigator, 'onLine', { get: () => online, configurable: true });
  const cryptoImpl = { randomUUID: () => `abcdef00-0000-4000-8000-${String(++uuidCount).padStart(12, '0')}`,
    subtle: cryptoAvailable ? { async digest(algorithm, bytes) { assert.equal(algorithm, 'SHA-256'); hashes.push(Array.from(new Uint8Array(bytes)));
      return Uint8Array.from(createHash('sha256').update(new Uint8Array(bytes)).digest()).buffer; } } : null };
  class FormDataStub {
    constructor() { this.parts = []; }
    append(name, value, filename) { this.parts.push({ name, value, filename }); }
  }
  class XhrStub {
    constructor() { this.upload = {}; this.headers = {}; this.status = 0; this.responseText = ''; this.aborted = false; requests.push(this); }
    open(method, path, async) { Object.assign(this, { method, path, async }); }
    setRequestHeader(key, value) { this.headers[key] = value; }
    send(body) { this.body = body; this.sent = true; }
    abort() { this.aborted = true; this.onabort?.(); }
    respond(code, body) { this.status = code; this.responseText = typeof body === 'string' ? body : JSON.stringify(body); this.onload?.(); }
    progress(loaded, total, lengthComputable = true) { this.upload.onprogress?.({ loaded, total, lengthComputable }); }
  }
  w.eval(script);
  const controller = w.createMediaUploadController({ windowRef: w, documentRef: w.document, navigatorRef: w.navigator,
    cryptoImpl, storage, createXhr: () => new XhrStub(), FormDataImpl: FormDataStub, AbortControllerImpl: w.AbortController,
    now: () => now, setTimeoutImpl: (fn, delay) => { const id = ++nextTimer; timers.set(id, { fn, at: now + delay }); return id; },
    clearTimeoutImpl: id => timers.delete(id), readFileImpl,
    onChange: value => changes.push(value), onReady: value => ready.push(value),
    fetchImpl: async (path, options) => {
      fetches.push({ path, options });
      const custom = overrideFetch?.(path, options);
      if (custom !== undefined) return custom;
      if (path.endsWith('/bootstrap')) return response({ csrfToken: `secret-${++bootstrapCount}`, session: { user: { id: ACTOR_ID } } });
      return response(status('Processing'));
    } });
  return { w, controller, storage, requests, fetches, changes, ready, hashes, timers,
    get state() { return controller.getState(); }, get uuidCount() { return uuidCount; },
    async start(candidate = file()) { assert.equal(await controller.selectFile(candidate), true); const task = controller.start(); await flush(); return { task, request: requests.at(-1) }; },
    async retry() { const task = controller.retry(); await flush(); return { task, request: requests.at(-1) }; },
    async tick(ms) {
      const until = now + ms;
      while (true) {
        const next = [...timers].filter(([, value]) => value.at <= until).sort((a, b) => a[1].at - b[1].at || a[0] - b[0])[0];
        if (!next) break;
        now = next[1].at; timers.delete(next[0]); next[1].fn(); await flush();
      }
      now = until; await flush();
    },
    visibility(value) { visible = value; w.document.dispatchEvent(new w.Event('visibilitychange')); },
    connection(value) { online = value; w.dispatchEvent(new w.Event(value ? 'online' : 'offline')); },
    close() { controller.destroy(); dom.window.close(); } };
}
let failed = 0, passed = 0;
async function check(name, run) {
  const environments = [];
  try { await run(options => { const e = environment(options); environments.push(e); return e; }); passed++; console.log('PASS ' + name); }
  catch (error) { failed++; console.error('FAIL ' + name + '\n' + error.stack); }
  finally { for (const e of environments) e.close(); }
}

await check('Validation rejects unsupported, mismatched, empty and oversized files before hash or HTTP', async env => {
  const e = env();
  for (const candidate of [file('x.gif', 'image/gif'), file('x.jpg', 'image/png'), file('x.png', 'image/png', []),
    file('x.png', 'image/png', [1], 10485761), file('x.mp4', 'video/mp4', [1], 209715201), file('../x.png'), file('x\u0000.png')]) {
    assert.equal(await e.controller.selectFile(candidate), false);
  }
  assert.equal(e.hashes.length, 0); assert.equal(e.fetches.length, 0); assert.equal(e.requests.length, 0);
});
await check('Allowed formats and inclusive generated byte limits pass validation', async env => {
  const e = env();
  for (const candidate of [file('x.JPG', 'image/jpeg'), file('x.jpeg', 'image/jpeg'), file('x.webp', 'image/webp'),
    file('x.png', 'image/png', [1], 10485760), file('x.mp4', 'video/mp4', [1], 209715200)]) {
    assert.equal(await e.controller.selectFile(candidate), true); assert.equal(e.state.canStart, true);
  }
  assert.equal(e.fetches.length, 0); assert.equal(e.controller.hasPending(), true);
});
await check('An invalid replacement clears an unattempted file instead of uploading the earlier selection', async env => {
  const e = env(); assert.equal(await e.controller.selectFile(file()), true);
  assert.equal(await e.controller.selectFile(file('replacement.gif', 'image/gif')), false);
  assert.equal(e.state.phase, 'idle'); assert.equal(e.state.fileName, ''); assert.equal(e.state.canStart, false); assert.equal(e.state.canRetry, false);
  assert.equal(await e.controller.start(), false); assert.equal(e.requests.length, 0); assert.equal(e.controller.hasPending(), false);
});
await check('A replacement hash failure cannot retry the prior unattempted file', async env => {
  let failRead = false; const e = env({ readFileImpl: candidate => failRead ? Promise.reject(new Error('read failed')) : candidate.arrayBuffer() });
  assert.equal(await e.controller.selectFile(file()), true); failRead = true;
  assert.equal(await e.controller.selectFile(file('other.png')), false); assert.equal(e.state.canRetry, false); assert.equal(e.state.canStart, false);
  assert.equal(await e.controller.retry(), false); assert.equal(e.requests.length, 0);
});
await check('Original bytes are SHA-256 hashed and multipart fields precede the file in contract order', async env => {
  const e = env(); const { request, task } = await e.start(file('e\u0301.png', 'image/png', [9, 0, 255, 44]));
  assert.equal(request.method, 'POST'); assert.equal(request.path, '/api/admin/v1/media/uploads'); assert.equal(request.withCredentials, true);
  assert.deepEqual(request.body.parts.map(part => part.name), ['sha256', 'byteSize', 'file']);
  assert.equal(request.body.parts[0].value, createHash('sha256').update(Uint8Array.from([9, 0, 255, 44])).digest('hex'));
  assert.equal(request.body.parts[1].value, '4'); assert.equal(request.body.parts[2].filename, 'é.png');
  assert.deepEqual(e.hashes, [[9, 0, 255, 44]]); assert.equal(request.headers['X-CSRF-TOKEN'], 'secret-1');
  assert.match(request.headers['Idempotency-Key'], /^[a-f0-9-]{36}$/); assert.equal(request.headers['Content-Type'], undefined);
  assert.equal(e.fetches[0].options.credentials, 'same-origin'); assert.equal(e.fetches[0].options.cache, 'no-store');
  request.onerror(); await task;
});
await check('An empty OS MIME uses the allowed extension without changing hashed bytes', async env => {
  const e = env(); const original = file('camera.JPEG', '', [17, 22]); const { request, task } = await e.start(original);
  assert.equal(original.type, ''); assert.equal(request.body.parts[2].value.type, 'image/jpeg');
  assert.deepEqual(await request.body.parts[2].value.arrayBuffer().then(bytes => Array.from(new Uint8Array(bytes))), [17, 22]);
  assert.equal(request.body.parts[0].value, createHash('sha256').update(Uint8Array.from([17, 22])).digest('hex'));
  request.onerror(); await task;
});
await check('Anonymous bootstrap never sends an upload even when it supplies a CSRF token', async env => {
  const e = env({ overrideFetch: () => response({ csrfToken: 'anonymous-token', session: null }) });
  await e.controller.selectFile(file()); assert.equal(await e.controller.start(), false);
  assert.equal(e.state.phase, 'auth'); assert.equal(e.requests.length, 0); assert.equal(e.state.canRetry, true);
});
await check('Missing Web Crypto blocks selection and no request or recovery record is created', async env => {
  const e = env({ cryptoAvailable: false }); assert.equal(await e.controller.selectFile(file()), false);
  assert.equal(e.state.errorCode, 'CLIENT_HASH_FAILED'); assert.equal(e.requests.length, 0); assert.equal(e.storage.data.size, 0);
});
await check('Upload progress is bounded and 202 means Processing with no Ready callback', async env => {
  const e = env(); const { request, task } = await e.start();
  request.progress(25, 100); assert.equal(e.state.progress, 25); request.progress(150, 100); assert.equal(e.state.progress, 100);
  request.progress(0, 0, false); assert.equal(e.state.progress, null);
  request.respond(202, accepted); await task;
  assert.equal(e.state.phase, 'processing'); assert.equal(e.state.mediaState, 'Processing'); assert.equal(e.ready.length, 0);
  assert.equal(e.controller.hasPending(), true); await e.tick(1999); assert.equal(e.fetches.length, 1);
  await e.tick(1); assert.equal(e.fetches.length, 2); assert.equal(e.state.phase, 'processing'); assert.equal(e.timers.size, 1);
});
await check('Only verified Ready status delivers one callback and clears recovery/polling', async env => {
  const e = env({ overrideFetch: path => path.endsWith('/bootstrap') ? undefined : response(status('Ready')) });
  const { request, task } = await e.start(); request.respond(202, accepted); await task; await e.tick(2000);
  assert.equal(e.ready.length, 1); assert.equal(e.ready[0].id, ID); assert.equal(e.state.phase, 'ready');
  assert.equal(e.controller.hasPending(), false); assert.equal(e.storage.data.size, 0); assert.equal(e.timers.size, 0);
  await e.tick(60000); assert.equal(e.ready.length, 1); assert.equal(e.fetches.length, 2);
});
await check('Invalid 202 payload, untrusted status URL and non-202 success stay unknown', async env => {
  for (const [code, payload] of [[202, { ...accepted, state: 'Ready' }], [202, { ...accepted, mediaId: [ID] }], [202, { ...accepted, statusUrl: 'https://attacker.invalid/' }], [200, accepted], [202, 'bad-json']]) {
    const e = env(); const { request, task } = await e.start(); request.respond(code, payload); await task;
    assert.equal(e.state.phase, 'unknown'); assert.equal(e.state.mediaId, null); assert.equal(e.ready.length, 0); assert.equal(e.timers.size, 0);
  }
});
await check('A network-unknown retry reuses key and original bytes with a fresh authenticated bootstrap', async env => {
  const e = env(); const first = await e.start(); const key = first.request.headers['Idempotency-Key'];
  first.request.onerror(); await first.task; await e.tick(60000); assert.equal(e.requests.length, 1);
  const second = await e.retry(); assert.equal(second.request.headers['Idempotency-Key'], key); assert.equal(second.request.headers['X-CSRF-TOKEN'], 'secret-2');
  assert.equal(second.request.body.parts[0].value, first.request.body.parts[0].value); assert.equal(e.uuidCount, 1);
  second.request.respond(202, accepted); await second.task;
});
await check('401, 403, 429, conflict and 5xx retain their identity and never auto-resubmit', async env => {
  for (const code of [401, 403, 409, 429, 500, 503]) {
    const e = env(); const first = await e.start(); first.request.respond(code, { code: code === 409 ? 'IDEMPOTENCY_IN_PROGRESS' : 'SERVICE_ERROR' }); await first.task;
    await e.tick(60000); assert.equal(e.requests.length, 1); assert.equal(e.state.canRetry, true);
    const retry = await e.retry(); assert.equal(retry.request.headers['Idempotency-Key'], first.request.headers['Idempotency-Key']); retry.request.onerror(); await retry.task;
  }
});
await check('Explicit terminal validation rejection allows only explicit fresh retry to rotate the key', async env => {
  const e = env(); const first = await e.start(); first.request.respond(422, { code: 'VALIDATION_FAILED' }); await first.task;
  assert.equal(e.state.phase, 'failed'); assert.equal(e.storage.data.size, 0); assert.equal(e.controller.hasPending(), false);
  assert.equal(await e.controller.start(), false); await e.tick(60000); assert.equal(e.requests.length, 1);
  const next = await e.retry(); assert.notEqual(next.request.headers['Idempotency-Key'], first.request.headers['Idempotency-Key']); next.request.onerror(); await next.task;
});
await check('A generic proxy validation HTTP response cannot prove a terminal upload result', async env => {
  const e = env(); const first = await e.start(); first.request.respond(413, '<html>proxy error</html>'); await first.task;
  assert.equal(e.state.phase, 'unknown'); const next = await e.retry(); assert.equal(next.request.headers['Idempotency-Key'], first.request.headers['Idempotency-Key']); next.request.onerror(); await next.task;
});
await check('Cancel after send remains unknown, retains the key and ignores late progress/results', async env => {
  const e = env(); const first = await e.start(); e.controller.cancel(); await first.task;
  assert.equal(first.request.aborted, true); assert.equal(e.state.phase, 'unknown'); assert.equal(e.state.errorCode, 'UPLOAD_ABORTED');
  assert.equal(e.controller.hasPending(), true); first.request.progress(100, 100); first.request.respond(202, accepted); assert.equal(e.state.mediaId, null);
  const next = await e.retry(); assert.equal(next.request.headers['Idempotency-Key'], first.request.headers['Idempotency-Key']); next.request.onerror(); await next.task;
});
await check('Cancel during bootstrap aborts authorization and never transmits a file', async env => {
  const bootstrap = deferred(); const e = env({ overrideFetch: () => bootstrap.promise }); await e.controller.selectFile(file());
  const task = e.controller.start(); await flush(); e.controller.cancel(); assert.equal(e.fetches[0].options.signal.aborted, true);
  bootstrap.resolve(response({ csrfToken: 'late', session: { user: { id: ACTOR_ID } } })); await task;
  assert.equal(e.requests.length, 0); assert.equal(e.state.phase, 'selected'); assert.equal(e.storage.data.size, 0);
});
await check('Cancel during hashing cannot revive the cancelled selection', async env => {
  const bytes = deferred(); const e = env({ readFileImpl: () => bytes.promise }); const task = e.controller.selectFile(file());
  e.controller.cancel(); bytes.resolve(Uint8Array.from([1, 2, 3, 4]).buffer); assert.equal(await task, false);
  assert.equal(e.state.phase, 'idle'); assert.equal(e.hashes.length, 0); assert.equal(e.state.canStart, false);
});
await check('A second file selection during hashing is explicitly blocked and preserves the active file', async env => {
  const bytes = deferred(); const e = env({ readFileImpl: candidate => candidate.name === 'first.png' ? bytes.promise : candidate.arrayBuffer() });
  const firstSelection = e.controller.selectFile(file('first.png', 'image/png', [1, 2]));
  assert.equal(e.state.phase, 'hashing'); assert.equal(e.state.canSelectFile, false);
  assert.equal(await e.controller.selectFile(file('second.png', 'image/png', [8, 9])), false);
  assert.match(e.state.message, /暂不能更换.*已保留当前文件/); assert.equal(e.state.phase, 'hashing');
  assert.equal(e.hashes.length, 0); bytes.resolve(Uint8Array.from([1, 2]).buffer); assert.equal(await firstSelection, true);
  assert.equal(e.state.fileName, 'first.png'); assert.equal(e.state.canSelectFile, true); assert.equal(e.uuidCount, 1);
  const task = e.controller.start(); await flush(); const request = e.requests.at(-1);
  assert.equal(request.body.parts[2].filename, 'first.png'); assert.equal(request.body.parts[0].value, createHash('sha256').update(Uint8Array.from([1, 2])).digest('hex'));
  request.onerror(); await task;
});
await check('A selected unsent file blocks switching to a library job until explicit selected-file cancellation', async env => {
  const e = env(); assert.equal(await e.controller.selectFile(file('first.png')), true);
  assert.equal(e.state.canCancel, true); assert.equal(await e.controller.resume(ID), false);
  assert.equal(e.state.phase, 'selected'); assert.equal(e.state.fileName, 'first.png'); assert.equal(e.state.mediaId, null);
  assert.equal(e.state.canStart, true); assert.match(e.state.message, /先取消当前选择/); assert.equal(e.fetches.length, 0);
  e.controller.cancel(); assert.equal(e.state.phase, 'idle'); assert.equal(e.state.fileName, ''); assert.equal(e.state.fileSize, 0);
  assert.equal(e.state.canStart, false); assert.equal(e.state.canCancel, false); assert.equal(e.controller.hasPending(), false);
  assert.equal(await e.controller.resume(ID), true); assert.equal(e.state.mediaId, ID); assert.equal(e.state.fileName, '');
  assert.equal(e.state.phase, 'processing'); assert.equal(e.requests.length, 0); assert.equal(e.fetches.length, 1);
});
await check('A hashing file blocks library recovery and cancellation prevents its delayed selection from returning', async env => {
  const bytes = deferred(); const e = env({ readFileImpl: () => bytes.promise });
  const selection = e.controller.selectFile(file('first.png'));
  assert.equal(await e.controller.resume(ID), false); assert.equal(e.state.phase, 'hashing'); assert.equal(e.fetches.length, 0);
  assert.match(e.state.message, /先取消当前操作/); e.controller.cancel(); assert.equal(e.state.phase, 'idle');
  assert.equal(await e.controller.resume(ID), true); bytes.resolve(Uint8Array.from([1, 2, 3, 4]).buffer);
  assert.equal(await selection, false); assert.equal(e.state.mediaId, ID); assert.equal(e.state.fileName, ''); assert.equal(e.state.phase, 'processing');
});
await check('Unknown reload requires exact normalized filename, type, size and hash before same-key retry', async env => {
  const storage = memoryStorage(); const e = env({ storage }); const first = await e.start(); first.request.onerror(); await first.task; e.close();
  const recovered = env({ storage }); assert.equal(recovered.state.phase, 'unknown'); assert.equal(recovered.state.requiresFile, true);
  assert.equal(recovered.state.canRetry, false); assert.equal(await recovered.controller.selectFile(file('renamed.png')), false);
  assert.equal(await recovered.controller.selectFile(file('图.png', 'image/png', [4, 3, 2, 1])), false);
  assert.equal(await recovered.controller.selectFile(file('图.png', 'image/png', [1, 2, 3])), false);
  assert.equal(await recovered.controller.selectFile(file()), true); const retry = await recovered.retry();
  assert.equal(retry.request.headers['Idempotency-Key'], first.request.headers['Idempotency-Key']); assert.equal(recovered.uuidCount, 0); retry.request.onerror(); await retry.task;
});
await check('Invalid replacement of an unknown upload preserves its original retry identity explicitly', async env => {
  const e = env(); const first = await e.start(); first.request.onerror(); await first.task;
  assert.equal(await e.controller.selectFile(file('replacement.gif', 'image/gif')), false);
  assert.equal(e.state.phase, 'unknown'); assert.match(e.state.message, /已保留上次上传恢复记录/);
  const retry = await e.retry(); assert.equal(retry.request.headers['Idempotency-Key'], first.request.headers['Idempotency-Key']); retry.request.onerror(); await retry.task;
});
await check('Persistence contains only bounded recovery fields, with no token or file contents', async env => {
  const e = env(); const first = await e.start(file('image.png', 'image/png', [65, 66, 67])); first.request.onerror(); await first.task;
  const raw = e.storage.getItem(STORE_KEY), record = JSON.parse(raw);
  assert.deepEqual(Object.keys(record).sort(), ['actorId', 'byteSize', 'createdAt', 'key', 'mediaId', 'mime', 'name', 'sha256', 'v']);
  assert.equal(record.actorId, ACTOR_ID);
  assert.equal(raw.includes('secret-1'), false); assert.equal(raw.includes('ABC'), false); assert.ok(raw.length < 2048);
});
await check('Unknown retries cannot transmit the same key as another authenticated administrator', async env => {
  let actorId = ACTOR_ID;
  const e = env({ overrideFetch: path => path.endsWith('/bootstrap') ? response({ csrfToken: 'bound-token', session: { user: { id: actorId } } }) : undefined });
  const first = await e.start(); first.request.onerror(); await first.task; const record = e.storage.getItem(STORE_KEY);
  actorId = OTHER_ACTOR_ID; assert.equal(await e.controller.retry(), false);
  assert.equal(e.requests.length, 1); assert.equal(e.state.phase, 'auth'); assert.equal(e.state.errorCode, 'RECOVERY_ACTOR_MISMATCH');
  assert.match(e.state.message, /账户.*不同/); assert.equal(e.storage.getItem(STORE_KEY), record); assert.equal(e.uuidCount, 1);
  actorId = ACTOR_ID; const retry = await e.retry(); assert.equal(retry.request.headers['Idempotency-Key'], first.request.headers['Idempotency-Key']); retry.request.onerror(); await retry.task;
});
await check('Reload retains actor binding and rejects another administrator after exact file re-selection', async env => {
  const storage = memoryStorage(); const e = env({ storage }); const first = await e.start(); first.request.onerror(); await first.task; e.close();
  const raw = storage.getItem(STORE_KEY);
  const recovered = env({ storage, overrideFetch: () => response({ csrfToken: 'different-admin-token', session: { user: { id: OTHER_ACTOR_ID } } }) });
  assert.equal(await recovered.controller.selectFile(file()), true); assert.equal(await recovered.controller.retry(), false);
  assert.equal(recovered.state.errorCode, 'RECOVERY_ACTOR_MISMATCH'); assert.equal(recovered.requests.length, 0);
  assert.equal(storage.getItem(STORE_KEY), raw); assert.equal(recovered.state.canForgetRecovery, true);
  assert.equal(recovered.controller.forgetRecovery(), false); assert.equal(storage.getItem(STORE_KEY), raw);
});
await check('Recovery identities lacking a valid actor UUID fail closed without clearing the record', async env => {
  const storage = memoryStorage(); const e = env({ storage }); const first = await e.start(); first.request.onerror(); await first.task; e.close();
  const record = JSON.parse(storage.getItem(STORE_KEY));
  for (const actorId of [undefined, 'not-a-guid', [ACTOR_ID]]) {
    const raw = JSON.stringify({ ...record, actorId }); const invalidStorage = memoryStorage({ [STORE_KEY]: raw });
    const recovered = env({ storage: invalidStorage }); assert.equal(recovered.state.recoveryExpired, true);
    assert.equal(await recovered.controller.selectFile(file()), false); assert.equal(recovered.requests.length, 0); assert.equal(invalidStorage.getItem(STORE_KEY), raw);
  }
});
await check('Accepted upload reload does not POST and resumes its protected status URL explicitly', async env => {
  const storage = memoryStorage(); const e = env({ storage }); const first = await e.start(); first.request.respond(202, accepted); await first.task; e.close();
  const recovered = env({ storage, overrideFetch: () => response(status('Ready')) });
  assert.equal(recovered.state.phase, 'paused'); assert.equal(recovered.state.canResume, true); assert.equal(recovered.state.requiresFile, false);
  await recovered.tick(60000); assert.equal(recovered.fetches.length, 0); await recovered.controller.resume();
  assert.equal(recovered.state.phase, 'ready'); assert.equal(recovered.requests.length, 0); assert.equal(recovered.fetches[0].path, `/api/admin/v1/media/${ID}`);
});
await check('Expired unknown identity cannot rotate/replay blindly and requires explicit recovery discard', async env => {
  const storage = memoryStorage(); const e = env({ storage }); const first = await e.start(); first.request.onerror(); await first.task; e.close();
  const recovered = env({ storage, startTime: 1000000 + 86400000 }); assert.equal(recovered.state.recoveryExpired, true);
  assert.equal(await recovered.controller.selectFile(file()), false); assert.equal(await recovered.controller.retry(), false);
  assert.equal(recovered.controller.forgetRecovery(), false); assert.equal(recovered.controller.hasPending(), true);
  assert.equal(recovered.controller.forgetRecovery({ confirmed: true }), true); assert.equal(storage.data.size, 0); assert.equal(recovered.state.phase, 'idle');
  assert.match(recovered.state.message, /没有删除.*重复/); assert.equal(await recovered.controller.selectFile(file()), true);
});
await check('The recovery lifetime starts at first transmission, even after a long file-selection delay', async env => {
  const e = env(); await e.controller.selectFile(file()); await e.tick(86400001);
  const task = e.controller.start(); await flush(); const request = e.requests.at(-1); assert.ok(request);
  request.onerror(); await task; assert.equal(e.state.recoveryExpired, false); assert.equal(e.state.canRetry, true);
  assert.equal(JSON.parse(e.storage.getItem(STORE_KEY)).createdAt, 1000000 + 86400001);
});
await check('Corrupt and oversized recovery records fail closed without automatic writes', async env => {
  for (const raw of ['broken-json', JSON.stringify({ v: 1, key: 'bad' }), 'x'.repeat(2049)]) {
    const e = env({ storage: memoryStorage({ [STORE_KEY]: raw }) });
    assert.equal(e.state.recoveryExpired, true); assert.equal(e.state.canForgetRecovery, true); assert.equal(e.controller.hasPending(), true);
    assert.equal(await e.controller.selectFile(file()), false); assert.equal(e.requests.length, 0); assert.equal(e.storage.getItem(STORE_KEY), raw);
  }
});
await check('Storage failure warns that reload recovery is unavailable while same-page retry stays safe', async env => {
  const e = env({ storage: { getItem: () => null, setItem: () => { throw new Error('quota'); }, removeItem() {} } });
  const first = await e.start(); assert.equal(e.state.recoveryAvailable, false); assert.match(e.state.message, /无法保存上传恢复信息/);
  first.request.onerror(); await first.task; const retry = await e.retry(); assert.equal(retry.request.headers['Idempotency-Key'], first.request.headers['Idempotency-Key']); retry.request.onerror(); await retry.task;
});
await check('Hidden and offline pages pause polling and resume when eligible without another POST', async env => {
  const e = env(); const first = await e.start(); first.request.respond(202, accepted); await first.task;
  e.visibility(false); assert.equal(e.state.pauseReason, 'hidden'); assert.equal(e.timers.size, 0); await e.tick(60000); assert.equal(e.fetches.length, 1);
  e.visibility(true); await flush(); assert.equal(e.fetches.length, 2); assert.equal(e.state.phase, 'processing');
  e.connection(false); assert.equal(e.state.pauseReason, 'offline'); await e.tick(60000); assert.equal(e.fetches.length, 2);
  e.connection(true); await flush(); assert.equal(e.fetches.length, 3); assert.equal(e.requests.length, 1);
});
await check('401 pauses status until manual resume even after visibility and online changes', async env => {
  let loggedIn = false; const e = env({ overrideFetch: path => path.endsWith('/bootstrap') ? undefined : loggedIn ? response(status('Ready')) : response({}, 401) });
  const first = await e.start(); first.request.respond(202, accepted); await first.task; await e.tick(2000);
  assert.equal(e.state.phase, 'auth'); assert.equal(e.state.canResume, true); assert.equal(e.timers.size, 0);
  loggedIn = true; e.visibility(false); e.visibility(true); e.connection(false); e.connection(true); await e.tick(60000);
  assert.equal(e.fetches.length, 2); await e.controller.resume(); assert.equal(e.state.phase, 'ready'); assert.equal(e.requests.length, 1);
});
await check('404 and status-network errors stop automatic polling and preserve unknown identity', async env => {
  for (const mode of ['missing', 'network']) {
    const e = env({ overrideFetch: path => path.endsWith('/bootstrap') ? undefined : mode === 'missing' ? response({}, 404) : Promise.reject(new Error('offline')) });
    const first = await e.start(); first.request.respond(202, accepted); await first.task; await e.tick(2000);
    assert.equal(e.state.phase, 'unknown'); assert.equal(e.state.mediaId, ID); assert.equal(e.state.canResume, true); assert.equal(e.state.canRetry, false);
    assert.equal(e.timers.size, 0); await e.tick(60000); assert.equal(e.fetches.length, 2); assert.equal(e.controller.hasPending(), true);
  }
});
await check('Rejected processing stops polling and explicit retry starts a fresh request', async env => {
  const e = env({ overrideFetch: path => path.endsWith('/bootstrap') ? undefined : response(status('Rejected', { errorCode: 'MEDIA_DECODE_FAILED' })) });
  const first = await e.start(); first.request.respond(202, accepted); await first.task; await e.tick(2000);
  assert.equal(e.state.phase, 'failed'); assert.equal(e.state.errorCode, 'MEDIA_DECODE_FAILED'); assert.equal(e.timers.size, 0); assert.equal(e.ready.length, 0);
  const retry = await e.retry(); assert.notEqual(retry.request.headers['Idempotency-Key'], first.request.headers['Idempotency-Key']); retry.request.onerror(); await retry.task;
});
await check('Mismatched or malformed status never becomes Ready', async env => {
  for (const body of [status('Ready', { id: OTHER_ID }), status('Ready', { version: 0 }), status('Ready', { metadata: null }), status('Ready', { metadata: [] }), status('Ready', { metadata: { kind: 'Video' } }), status('Mystery')]) {
    const e = env({ overrideFetch: path => path.endsWith('/bootstrap') ? undefined : response(body) });
    const first = await e.start(); first.request.respond(202, accepted); await first.task; await e.tick(2000);
    assert.equal(e.state.phase, 'unknown'); assert.equal(e.state.errorCode, 'STATUS_INVALID'); assert.equal(e.ready.length, 0); assert.equal(e.timers.size, 0);
  }
});
await check('Cancel processing stops only status queries and manual resume follows the same media ID', async env => {
  const e = env(); const first = await e.start(); first.request.respond(202, accepted); await first.task;
  e.controller.cancel(); assert.equal(e.state.phase, 'paused'); assert.equal(e.state.pauseReason, 'cancelled'); assert.equal(e.state.mediaId, ID);
  e.visibility(false); e.visibility(true); await e.tick(60000); assert.equal(e.fetches.length, 1);
  await e.controller.resume(); assert.equal(e.state.phase, 'processing'); assert.equal(e.fetches.length, 2); assert.equal(e.requests.length, 1);
});
await check('In-flight status fetch is aborted on hide, and its late result cannot mutate state', async env => {
  const slow = deferred(); const e = env({ overrideFetch: path => path.endsWith('/bootstrap') ? undefined : slow.promise });
  const first = await e.start(); first.request.respond(202, accepted); await first.task; await e.tick(2000);
  e.visibility(false); assert.equal(e.fetches[1].options.signal.aborted, true); slow.resolve(response(status('Ready'))); await flush();
  assert.equal(e.state.phase, 'paused'); assert.equal(e.ready.length, 0); assert.equal(e.timers.size, 0);
});
await check('Library Processing recovery works without a file; unknown uploads cannot adopt arbitrary rows', async env => {
  const e = env(); await e.controller.resume(ID); assert.equal(e.state.phase, 'processing'); assert.equal(e.requests.length, 0);
  assert.equal(await e.controller.resume(OTHER_ID), false); assert.equal(e.state.mediaId, ID);
  const unknown = env(); const first = await unknown.start(); first.request.onerror(); await first.task;
  assert.equal(await unknown.controller.resume(ID), false); assert.equal(unknown.state.mediaId, null); assert.equal(unknown.fetches.length, 1);
});
await check('Offline selection re-enables start when online without uploading automatically', async env => {
  const e = env(); e.connection(false); await e.controller.selectFile(file()); assert.equal(e.state.canStart, false);
  e.connection(true); assert.equal(e.changes.at(-1).canStart, true); assert.equal(e.requests.length, 0);
});
await check('Destroy clears timers, aborts transfer and leaves recoverable identity without callbacks', async env => {
  const e = env(); const first = await e.start(); const count = e.changes.length; e.controller.destroy(); await first.task;
  first.request.respond(202, accepted); e.connection(false); e.connection(true); await e.tick(60000);
  assert.equal(first.request.aborted, true); assert.equal(e.changes.length, count); assert.equal(e.ready.length, 0); assert.equal(e.timers.size, 0);
  assert.ok(e.storage.getItem(STORE_KEY)); assert.equal(e.controller.hasPending(), false); assert.equal(await e.controller.selectFile(file()), false);
});
console.log(`Media upload controller: ${passed} passed, ${failed} failed.`);
if (failed) process.exitCode = 1;
