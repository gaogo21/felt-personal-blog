diff --git a/src/Blog.Web/wwwroot/js/admin/articles.js b/src/Blog.Web/wwwroot/js/admin/articles.js
index 55314b7..5eb9ef4 100644
--- a/src/Blog.Web/wwwroot/js/admin/articles.js
+++ b/src/Blog.Web/wwwroot/js/admin/articles.js
@@ -274,7 +274,13 @@ async function publishDraft(retry = false) {
           contentHash: result.contentHash, sourceDraftVersion: attempt.body.expectedDraftVersion } };
       draft = { ...attempt.baseDraft, draftVersion: result.draftVersion, draftEtag: result.draftEtag, basePublishedRevisionId: result.publishedRevisionId };
       publicationAttempt = null; unknownAttempt = null; pause = null;
-      if (attempt.observedServer && (!sameDraft(attempt.observedServer.draft, draft) || !sameArticle(attempt.observedServer.article, article))) {
+      // Recovery can observe the exact pre-publication baseline when the lost
+      // request never committed. Its successful replay then makes the first
+      // commit. Only a different observed state indicates intervening work.
+      const observed = attempt.observedServer;
+      const observedOriginal = observed && sameDraft(observed.draft, attempt.baseDraft) && sameArticle(observed.article, attempt.baseArticle);
+      const observedPublished = observed && sameDraft(observed.draft, draft) && sameArticle(observed.article, article);
+      if (observed && !observedOriginal && !observedPublished) {
         stopWrites('conflict', '已确认上次发布成功，但服务器随后已有更新。当前输入保留；请重新读取服务器版本并明确核对。'); return;
       }
       message(hasUnsaved() ? 'dirty' : 'published', hasUnsaved() ? '已发布提交的版本；当前较新输入尚未发布，将继续保存到工作草稿。' : '发布成功，当前工作草稿内容已上线。');
