using System.Text.Json;
using Blog.SecurityTests;
using Blog.Web.Application.Administration;
using Blog.Web.Application.Media;
using Blog.Web.Application.Security;
using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Media;

namespace Blog.MediaWorkflowTests;

// Joins the real F11 and F19 application services on one explicitly simulated transaction.
// Only generated test bytes are used. The existing MediaFixture owns cloning and rollback.
internal sealed class WorkflowLifecycleAdapter(MediaFixture store) : IMediaLifecycleStore, IAdminMutationStore, IAdminMutationTransaction
{
    private bool active;
    private readonly HashSet<Guid> locked = [];
    private static T Clone<T>(T input) => JsonSerializer.Deserialize<T>(JsonSerializer.Serialize(input))!;
    private void Require(Guid id)
    { if (!active || !locked.Contains(id)) throw new InvalidOperationException("FIXTURE_LIFECYCLE_SHARED_LOCK_REQUIRED"); }
    public Task<T> InTransactionAsync<T>(Func<IAdminMutationTransaction, CancellationToken, Task<T>> action, CancellationToken ct)
        => store.ExecuteAsync(async (_, token) =>
        {
            active = true; locked.Clear();
            try { return await action(this, token); }
            finally { active = false; locked.Clear(); }
        }, ct);
    public Task LockAsync(MutationLocks locks, CancellationToken ct)
    {
        if (!active) throw new InvalidOperationException("FIXTURE_LIFECYCLE_TRANSACTION_REQUIRED");
        foreach (var id in locks.Media) locked.Add(id); return Task.CompletedTask;
    }
    public Task AcquireKeyAsync(Guid actor, string scope, Guid key, CancellationToken ct) => Task.CompletedTask;
    public Task<IdempotencyRecord?> FindAsync(Guid actor, string scope, Guid key, CancellationToken ct)
    {
        var record = store.Keys.GetValueOrDefault((actor, key));
        return Task.FromResult(record?.Scope == scope ? record : null);
    }
    public void Add(IdempotencyRecord record) => store.Add(record);
    public void Remove(IdempotencyRecord record) => store.Remove(record);
    public void Add(AuditEvent audit) => store.Add(audit);
    public Task<MediaAsset?> ReadTrackedAsync(Guid id, CancellationToken ct)
    { Require(id); return store.MediaAsync(id, ct); }
    public Task<MediaDeletionJob?> JobTrackedAsync(Guid id, CancellationToken ct)
    { Require(id); return Task.FromResult(store.DeletionJobs.GetValueOrDefault(id)); }
    public void Add(MediaDeletionJob job) { Require(job.MediaId); store.DeletionJobs.Add(job.MediaId, job); }
    public async Task<MediaReferences> ReferencesAsync(Guid id, CancellationToken ct)
    {
        Require(id);
        return new(await store.HasReferencesAsync(id, ct) ? [new(id, "测试引用", "Trashed", "BodyImage", "DraftRetained", "/admin/articles/" + id)] : [], [], [], [], []);
    }
    public Task<MediaDeletionRead?> ReadDeletionAsync(Guid id, CancellationToken ct)
        => store.ExecuteAsync<MediaDeletionRead?>((_, _) => Task.FromResult(store.Media.TryGetValue(id, out var media)
            ? Clone(new MediaDeletionRead(media, store.DeletionJobs.GetValueOrDefault(id))) : null), ct);
    public Task<MediaDeletionCandidate?> CandidateAsync(DateTimeOffset now, CancellationToken ct)
        => Task.FromResult(PostgresMediaLifecycleStore.CandidateQuery(store.DeletionJobs.Values.AsQueryable(), now).FirstOrDefault());
}

internal sealed class WorkflowLifecycle
{
    private readonly Scenario scenario;
    private readonly TestOnlySecurityStore securityStore = new();
    private readonly AdminSecurityService security;
    private readonly AdminActor actor;
    public MediaLifecycleService Service { get; }
    public MediaDeletionService Worker { get; }
    public PrivateMediaLifecycleFiles Files { get; }
    public WorkflowLifecycle(Scenario scenario, IPrivateFileDurability durability)
    {
        this.scenario = scenario; var adapter = new WorkflowLifecycleAdapter(scenario.Store);
        security = new(securityStore, scenario.Clock); actor = Fixtures.Actor(securityStore.UserId);
        Files = new(scenario.Files, durability);
        Service = new(adapter, new(adapter, scenario.Clock), Files, security, scenario.Clock, scenario.Configuration);
        Worker = new(adapter, adapter, Files, scenario.Clock);
    }
    private string Tag(Guid id) => new EntityVersion(ResourceKind.Media, id, scenario.Store.Media[id].RowVersion).ETag;
    public Task<MutationResponse> Trash(Guid id) => Service.TrashAsync(actor, id, Tag(id), Guid.NewGuid(), new(), default);
    public Task<MutationResponse> Restore(Guid id) => Service.RestoreAsync(actor, id, Tag(id), Guid.NewGuid(), new(), default);
    public async Task<MutationResponse> Purge(Guid id)
    {
        var session = await security.LoginAsync("fixture-admin", TestOnlySecurityStore.FixturePassword, default)
            ?? throw new InvalidOperationException("FIXTURE_LIFECYCLE_LOGIN_FAILED");
        if (!await security.ReauthenticateAsync(session.Id, TestOnlySecurityStore.FixturePassword, default)) throw new InvalidOperationException("FIXTURE_LIFECYCLE_REAUTH_FAILED");
        return await Service.PurgeAsync(actor, session.Id, id, Tag(id), Guid.NewGuid(), new(id), default);
    }
    public static MediaFileIdentity Identity(MediaAsset media) => new(media.Id, media.StorageKey, media.ByteSize!.Value, media.Sha256!);
}

internal sealed class WorkflowCleanupDurability : IPrivateFileDurability
{
    private readonly LinuxPrivateFileDurability actual = new();
    public Func<string, bool>? FailDelete { get; set; }
    public Func<string, bool>? FailSync { get; set; }
    public List<(string Action, string Path)> Events { get; } = [];
    public void FlushFile(FileStream file) => actual.FlushFile(file);
    public void RenameExclusive(string source, string target) => actual.RenameExclusive(source, target);
    public void DeleteFile(string path)
    {
        if (FailDelete?.Invoke(path) == true) { Events.Add(("delete-failed", path)); throw new IOException("FIXTURE_CLEANUP_DELETE_FAILURE"); }
        actual.DeleteFile(path); Events.Add(("delete", path));
    }
    public void SyncDirectory(string path)
    {
        if (FailSync?.Invoke(path) == true) { Events.Add(("sync-failed", path)); throw new IOException("FIXTURE_CLEANUP_SYNC_FAILURE"); }
        actual.SyncDirectory(path); Events.Add(("sync", path));
    }
}

// Simulates a database committing the Ready transition, then losing its reply before cleanup starts.
// This is intentionally different from the fixture's precommit rollback injection.
internal sealed class ReadyCommitReplyLoss(MediaFixture store, Guid mediaId) : IMediaPersistence
{
    private bool lost;
    public async Task<T> ExecuteAsync<T>(Func<IMediaUnitOfWork, CancellationToken, Task<T>> action, CancellationToken ct)
    {
        var result = await store.ExecuteAsync(action, ct);
        if (!lost && store.Media.GetValueOrDefault(mediaId)?.State == MediaState.Ready && store.Reservations.ContainsKey(mediaId))
        { lost = true; throw new InvalidOperationException("FIXTURE_READY_COMMIT_REPLY_LOST"); }
        return result;
    }
    public Task<MediaAsset?> ReadAsync(Guid id, CancellationToken ct) => store.ReadAsync(id, ct);
}
