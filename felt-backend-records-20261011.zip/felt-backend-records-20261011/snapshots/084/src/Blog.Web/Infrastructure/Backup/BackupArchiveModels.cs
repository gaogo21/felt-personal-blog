namespace Blog.Web.Infrastructure.Backup;

// This allowlist is deliberately typed: connection strings, passwords, the archive
// master key and other environment variables have no manifest field.
public sealed record BackupArchiveConfiguration(string DataProtectionApplicationName, long MaxMediaBytes);

// PostgreSQL-native identifiers bind the artifact to its source without exposing
// a hostname, connection string, username or authentication material.
public sealed record BackupArchiveDatabaseIdentity(string ClusterSystemIdentifier, uint DatabaseOid);

public sealed record BackupArchiveMetadata(
    string ReleaseVersion,
    string SchemaVersion,
    int ConfigurationVersion,
    DateTimeOffset CreatedAtUtc,
    Guid OperationId,
    string DatabaseEvidence,
    BackupArchiveConfiguration Configuration,
    BackupArchiveDatabaseIdentity? DatabaseIdentity = null);

public sealed record BackupArchiveCaptureRequest(
    string DatabaseDumpPath,
    string MediaRoot,
    string DataProtectionRoot,
    string DestinationPath,
    BackupArchiveMetadata Metadata);

public sealed record BackupArchiveEntryManifest(string Path, long Length, string Sha256);

public sealed record BackupArchiveManifest(
    int FormatVersion,
    string ValidationLevel,
    BackupArchiveMetadata Metadata,
    IReadOnlyList<BackupArchiveEntryManifest> Entries);

public sealed record BackupArchiveCreateResult(string ArchivePath, long EncryptedBytes, BackupArchiveManifest Manifest);
public sealed record BackupArchiveRestoreResult(string DirectoryPath, BackupArchiveManifest Manifest);

public sealed record BackupArchiveLimits
{
    public int MaxEntries { get; init; } = 50_000;
    public int MaxDirectories { get; init; } = 50_000;
    public long MaxFileBytes { get; init; } = 8L * 1024 * 1024 * 1024;
    public long MaxTotalBytes { get; init; } = 64L * 1024 * 1024 * 1024;
    public long MaxArchiveBytes { get; init; } = 65L * 1024 * 1024 * 1024;
    public int MaxManifestBytes { get; init; } = 16 * 1024 * 1024;
    public int MaxPathBytes { get; init; } = 512;
    public int MaxCompressionRatio { get; init; } = 100;
}

// Diagnostics are stable codes only. Do not attach filesystem/crypto exceptions,
// file content, supplied key material or request configuration to these errors.
public sealed class BackupArchiveFailure(string code) : Exception(code)
{
    public string Code { get; } = code;
}
