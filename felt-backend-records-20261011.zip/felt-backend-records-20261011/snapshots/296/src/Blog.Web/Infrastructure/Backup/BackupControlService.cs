using Blog.Web.Application.Administration;
using Blog.Web.Application.Maintenance;

namespace Blog.Web.Infrastructure.Backup;

public sealed record BackupInput(string Confirm);
public sealed record BackupView(Guid OperationId, string Status, string ValidationLevel);
public sealed class BackupControlService(BackupOptions options, MaintenanceCoordinator maintenance,
    IBackupOperationLedger ledger, IBackupCapture capture, TimeProvider clock, ILogger<BackupControlService> logger)
{
    public Task<BackupView> RunAsync(AdminActor actor, Guid key, BackupInput input,
        MaintenanceOperationLease initiatingLease, CancellationToken ct)
        => RunCoreAsync(actor.UserId, key, input, initiatingLease, ct);

    // The stopped-service command has no HTTP/session identity. Empty is a
    // reserved local operator receipt owner; AdminActor rejects empty user IDs.
    // Keep the ledger, canonical request, capture and completion contract shared.
    internal Task<BackupView> RunStoppedAsync(Guid key, MaintenanceOperationLease initiatingLease, CancellationToken ct)
        => RunCoreAsync(Guid.Empty, key, new("CREATE ENCRYPTED BACKUP"), initiatingLease, ct);

    private async Task<BackupView> RunCoreAsync(Guid owner, Guid key, BackupInput input,
        MaintenanceOperationLease initiatingLease, CancellationToken ct)
    {
        if (!options.Enabled) throw new ApiFailure(ProblemCode.MAINTENANCE_READ_ONLY);
        if (input.Confirm != "CREATE ENCRYPTED BACKUP") throw new ApiFailure(ProblemCode.VALIDATION_FAILED,
            new Dictionary<string, FieldIssue[]> { ["confirm"] = [FieldIssue.Invalid] });
        var hash = CanonicalRequest.Hash("maintenance.backup", "site", System.Text.Json.JsonSerializer.SerializeToElement(input, ApiJson.Options));
        BackupReservation reservation;
        try { reservation = await ledger.ReserveAsync(owner, key, hash, clock.GetUtcNow(), ct); }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException or BackupArchiveFailure)
        { throw new ApiFailure(ProblemCode.MEDIA_STORAGE_UNAVAILABLE); }
        if (!reservation.IsNew)
        {
            if (reservation.Receipt.Status == "Succeeded") return new(reservation.Receipt.OperationId, "Succeeded", "ArtifactIntegrityOnly");
            if (reservation.Receipt.Status == "Failed") throw new ApiFailure(ProblemCode.MEDIA_STORAGE_UNAVAILABLE);
            throw new ApiFailure(ProblemCode.IDEMPOTENCY_IN_PROGRESS);
        }
        var receipt = reservation.Receipt;
        try
        {
            // No database transaction, advisory lock, or key lock survives into
            // this wait. The request's own admission is consumed atomically.
            using var frozen = await maintenance.BeginAsync(initiatingLease, ct);
            await capture.CaptureAsync(receipt.OperationId, receipt.CreatedAtUtc, ct);
            await ledger.CompleteAsync(receipt, "Succeeded", null, CancellationToken.None);
            logger.LogInformation("Backup operation {OperationId} completed with status {Status}", receipt.OperationId, "Succeeded");
            return new(receipt.OperationId, "Succeeded", "ArtifactIntegrityOnly");
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            await RecordFailure(receipt, "BACKUP_CANCELLED"); throw;
        }
        catch (Exception error)
        {
            await RecordFailure(receipt, error is TimeoutException ? "BACKUP_DRAIN_TIMEOUT" : "BACKUP_FAILED");
            logger.LogWarning("Backup operation {OperationId} completed with status {Status}", receipt.OperationId, "Failed");
            throw new ApiFailure(ProblemCode.MEDIA_STORAGE_UNAVAILABLE);
        }
    }
    private async Task RecordFailure(BackupOperationReceipt receipt, string code)
    {
        try { await ledger.CompleteAsync(receipt, "Failed", code, CancellationToken.None); }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException or BackupArchiveFailure)
        { logger.LogWarning("Backup operation {OperationId} requires receipt reconciliation", receipt.OperationId); }
    }
}
