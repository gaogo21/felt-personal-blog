using System.Globalization;
using System.Text;
using System.Text.Json;
using Blog.Web.Application.Administration;
using Blog.Web.Domain.Persistence;
using Microsoft.Extensions.Primitives;

namespace Blog.Web.Application.Articles;

public sealed class ArticlePublicationService(IArticlePublicationStore store, AdminMutationExecutor mutations,
    IDraftBodyBoundary bodies, TimeProvider clock, IConfiguration config)
{
    public Task<MutationResponse> PublishAsync(AdminActor actor, Guid id, StringValues ifMatch, Guid key,
        PublicationInput input, CancellationToken ct)
    {
        if (id == Guid.Empty) throw new ApiFailure(ProblemCode.NOT_FOUND);
        return mutations.ExecuteAsync(actor, "article.publish", id.ToString("D"), key,
            JsonSerializer.SerializeToElement(input, ApiJson.Options), new(true, [id]), async (tx, token) =>
        {
            // Replay has already returned. Resolve every mutable dependency from the locked draft,
            // never from an unlocked preliminary read or from content supplied with this request.
            if (config.GetValue<bool>("Maintenance:ReadOnly")) throw new ApiFailure(ProblemCode.MAINTENANCE_READ_ONLY);
            var read = await store.ReadAsync(id, token) ?? throw new ApiFailure(ProblemCode.NOT_FOUND);
            var article = read.Article;
            AdminArticleService.Version(article).RequireMatch(ifMatch);
            if (article.State is not (ArticleState.Draft or ArticleState.Published or ArticleState.Withdrawn)) throw new ApiFailure(ProblemCode.STATE_CONFLICT);
            var draft = read.Draft ?? throw new InvalidOperationException("ARTICLE_DRAFT_INTEGRITY_FAILURE");
            if (input.ExpectedDraftVersion is null) throw new ApiFailure(ProblemCode.VERSION_REQUIRED);
            if (input.ExpectedDraftVersion < 1) throw ArticleInput.Invalid("expectedDraftVersion");
            AdminArticleService.Version(draft).RequireNumber(input.ExpectedDraftVersion.Value);
            if ((article.State == ArticleState.Published) != (read.Published is not null)
                || (article.PublishedRevisionId is not null) != (read.Published is not null)) throw new ApiFailure(ProblemCode.STATE_CONFLICT);

            var normalized = ReadDraft(draft);
            var body = bodies.Validate(normalized.ContentJson, normalized.SchemaVersion);
            normalized = normalized with { ContentJson = Parse(body.Json) };
            var hash = ArticleInput.ContentHash(normalized);
            if (!string.Equals(hash, draft.ContentHash, StringComparison.Ordinal))
                throw new ApiFailure(ProblemCode.STATE_CONFLICT, new Dictionary<string, FieldIssue[]> { ["contentHash"] = [FieldIssue.Invalid] });
            if (!HasText(normalized.Title)) throw ArticleInput.Invalid("title", FieldIssue.Required);
            if (normalized.ColumnId is not { } columnId) throw ArticleInput.Invalid("columnId", FieldIssue.Required);

            var columnLocks = new MutationLocks(false, columns: read.Published is { } old ? [old.ColumnId, columnId] : [columnId]);
            var mediaLocks = new MutationLocks(false, media: body.References.Select(x => x.MediaId)
                .Concat(normalized.CoverMediaId is { } cover ? [cover] : []));
            await tx.LockAsync(new(false, columns: columnLocks.Columns, media: mediaLocks.Media), token);
            var column = await store.ColumnAsync(columnId, token);
            if (column is null || column.State != ColumnState.Active) throw ArticleInput.Invalid("columnId", FieldIssue.Unavailable);
            var assets = new Dictionary<Guid, MediaAsset>();
            foreach (var mediaId in mediaLocks.Media)
                if (await store.MediaAsync(mediaId, token) is { } asset) assets.Add(mediaId, asset);
            (await body.CheckMediaAsync((mediaId, _) => Task.FromResult(assets.GetValueOrDefault(mediaId)), token)).RequireNonempty();
            if (body.References.Any(x => assets[x.MediaId].Width is not > 0 || assets[x.MediaId].Height is not > 0))
                throw ArticleInput.Invalid("contentJson", FieldIssue.Unavailable);
            if (normalized.CoverMediaId is { } coverId && (!assets.TryGetValue(coverId, out var coverAsset)
                || coverAsset.State != MediaState.Ready || coverAsset.Kind != MediaKind.Image || coverAsset.Width is not > 0 || coverAsset.Height is not > 0))
                throw ArticleInput.Invalid("coverMediaId", FieldIssue.Unavailable);
            body = body.WithTrustedMedia(assets);

            var directory = await store.DirectoryAsync(id, columnLocks.Columns, token);
            ValidateDirectory(directory, article, read.Published, columnLocks.Columns);
            var site = await store.SiteAsync(token);
            var now = clock.GetUtcNow();
            var revision = new ArticleRevision
            {
                Id = Guid.NewGuid(), ArticleId = id, RevisionNo = await store.NextRevisionNumberAsync(id, token),
                Title = normalized.Title, Summary = normalized.Summary, ColumnId = columnId, CoverMediaId = normalized.CoverMediaId,
                CoverDisplayMeta = normalized.CoverDisplayMeta is null ? null : JsonSerializer.Serialize(normalized.CoverDisplayMeta, ApiJson.Options),
                ContentJson = body.Json, SchemaVersion = normalized.SchemaVersion, BodyHtml = body.Html.ToString(), PlainText = body.PlainText,
                TocJson = JsonSerializer.Serialize(body.Toc, ApiJson.Options), ReadingMinutes = body.ReadingMinutes, CreatedAt = now, CreatedBy = actor.UserId
            };
            store.AddRevision(revision, body.References.Select(x => new RevisionMediaReference { RevisionId = revision.Id, MediaId = x.MediaId, Usage = x.Usage }).ToArray());
            UpdateDirectory(directory, id, read.Published?.ColumnId, columnId);
            var previousVersion = article.RowVersion; var previousState = article.State;
            article.PublishedRevisionId = revision.Id; article.State = ArticleState.Published;
            article.FirstPublishedAt ??= now; article.LastPublishedAt = now; article.WithdrawnAt = null;
            article.RowVersion = checked(article.RowVersion + 1);
            // The base pointer is part of the draft representation and therefore invalidates its ETag.
            // ContentHash and save timestamps remain the exact saved-content baseline.
            draft.BasePublishedRevisionId = revision.Id; draft.RowVersion = checked(draft.RowVersion + 1);
            site.RowVersion = checked(site.RowVersion + 1); site.UpdatedAt = now;
            var articleVersion = AdminArticleService.Version(article); var draftVersion = AdminArticleService.Version(draft);
            var result = new PublicationView("Published", revision.Id, article.FirstPublishedAt.Value, now, "/articles/" + article.Slug,
                article.RowVersion, draft.RowVersion, articleVersion.ETag, draftVersion.ETag, hash);
            return new(MutationResponse.Json(200, result, articleVersion), new(AuditAction.ArticlePublished, AuditEntity.Article, id,
                previousVersion, article.RowVersion, new(FromState: (AuditState)(int)previousState, ToState: AuditState.Published)));
        }, ct);
    }

    private void UpdateDirectory(PublicationDirectory directory, Guid id, Guid? oldColumn, Guid newColumn)
    {
        if (oldColumn == newColumn) return;
        var nextPosition = checked(directory.Orders.Count(x => x.ColumnId == newColumn) + 1);
        var order = directory.Orders.SingleOrDefault(x => x.ArticleId == id);
        if (order is null) store.AddOrder(new() { ArticleId = id, ColumnId = newColumn, Position = nextPosition });
        else
        {
            var oldPosition = order.Position;
            foreach (var sibling in directory.Orders.Where(x => x.ColumnId == oldColumn && x.Position > oldPosition)) sibling.Position--;
            order.ColumnId = newColumn; order.Position = nextPosition;
        }
    }
    private static void ValidateDirectory(PublicationDirectory directory, Article article, ArticleRevision? old, IReadOnlyList<Guid> columns)
    {
        foreach (var column in columns)
        {
            var orders = directory.Orders.Where(x => x.ColumnId == column).OrderBy(x => x.Position).ToArray();
            var expected = directory.Published.Where(x => x.ColumnId == column).Select(x => x.ArticleId).ToHashSet();
            if (orders.Select(x => x.ArticleId).Distinct().Count() != orders.Length || !expected.SetEquals(orders.Select(x => x.ArticleId))
                || orders.Where((x, i) => x.Position != i + 1).Any()) throw new ApiFailure(ProblemCode.STATE_CONFLICT);
        }
        var own = directory.Orders.Where(x => x.ArticleId == article.Id).ToArray();
        if (old is null ? own.Length != 0 : own.Length != 1 || own[0].ColumnId != old.ColumnId)
            throw new ApiFailure(ProblemCode.STATE_CONFLICT);
    }
    private static DraftInput ReadDraft(ArticleDraft draft)
    {
        try
        {
            var meta = draft.CoverDisplayMeta is null ? null : JsonSerializer.Deserialize<DisplayMeta>(draft.CoverDisplayMeta, ApiJson.Options);
            return ArticleInput.Normalize(new(draft.Title, draft.Summary, draft.ColumnId, draft.CoverMediaId, meta, Parse(draft.ContentJson), draft.SchemaVersion));
        }
        catch (JsonException) { throw ArticleInput.Invalid("contentJson"); }
    }
    private static bool HasText(string value) => value.EnumerateRunes().Any(x => !Rune.IsWhiteSpace(x) && Rune.GetUnicodeCategory(x) is not (UnicodeCategory.Format or UnicodeCategory.Control));
    private static JsonElement Parse(string value) { using var json = JsonDocument.Parse(value); return json.RootElement.Clone(); }
}
