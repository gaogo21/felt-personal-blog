using System.Text.Json.Serialization;
using Blog.Web.Domain.Persistence;

namespace Blog.Web.Application.Columns;

public sealed record ReplaceColumnOrderInput([property: JsonRequired] IReadOnlyList<Guid> ColumnIds);
public sealed record ReplaceArticleOrderInput([property: JsonRequired] IReadOnlyList<Guid> ArticleIds);
public sealed record ColumnOrderItem(Guid Id, string Slug, string Name, string State, int SortOrder, int PublishedArticleCount);
public sealed record ColumnOrderView(IReadOnlyList<ColumnOrderItem> Items, long SiteVersion, string SiteEtag);
public sealed record ArticleOrderItem(Guid Id, string Slug, string Title, int Position);
public sealed record ArticleOrderView(Guid ColumnId, string ColumnSlug, string ColumnName, string ColumnState,
    IReadOnlyList<ArticleOrderItem> Items, long SiteVersion, string SiteEtag);
public sealed record ColumnOrderData(IReadOnlyList<ColumnListRow> Items, SiteState Site);
public sealed record CurrentArticleOrderMember(Guid Id, string Slug, string Title);
public sealed record ArticleOrderData(Column Column, IReadOnlyList<CurrentArticleOrderMember> Members,
    IReadOnlyList<ColumnArticleOrder> Orders, SiteState Site);

public interface IAdminColumnOrderStore
{
    // Detached reads own a repeatable-read transaction; tracked reads require the mutation transaction.
    Task<ColumnOrderData> ReadColumnsAsync(bool tracked, CancellationToken ct);
    Task<ArticleOrderData?> ReadArticlesAsync(Guid columnId, bool tracked, CancellationToken ct);
    Task<SiteState> SiteAsync(CancellationToken ct);
    // Discover the authoritative lock set only after the SiteState lock, then reread after row locks.
    Task<IReadOnlyList<Guid>> UnarchivedColumnIdsAsync(CancellationToken ct);
    Task<IReadOnlyList<Guid>> CurrentArticleIdsAsync(Guid columnId, CancellationToken ct);
}
