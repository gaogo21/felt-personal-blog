import assert from 'node:assert/strict';
import { JSDOM, VirtualConsole } from 'jsdom';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

// All requests below are intercepted in memory. No password, database, listener,
// browser, or deletion service is accessed by this fixture.
const source = readFileSync('src/Blog.Web/wwwroot/js/admin/article-lifecycle.js', 'utf8');
const page = readFileSync('src/Blog.Web/Pages/Admin/Articles/Manage.cshtml', 'utf8');
const id = '11111111-1111-4111-8111-111111111111', columnId = '22222222-2222-4222-8222-222222222222';
const revisionId = '33333333-3333-4333-8333-333333333333', slug = 'article-original';
const aTag = version => `"a-${id}-${version}"`, dTag = version => `"d-${id}-${version}"`;
const response = (value, status = 200, tag = value?.articleEtag ?? value?.draftEtag ?? null) => ({
  ok: status >= 200 && status < 300, status, headers: { get: key => key.toLowerCase() === 'etag' ? tag : null }, json: async () => structuredClone(value),
});
const deferred = () => { let resolve, reject; const promise = new Promise((yes, no) => { resolve = yes; reject = no; }); return { promise, resolve, reject }; };
const flush = async () => { for (let n = 0; n < 100; n++) await Promise.resolve(); };
const results = [];
async function check(name, run) {
  const environments = [];
  try { await run(value => { environments.push(value); return value; }); results.push({ name, status: 'passed' }); console.log('PASS ' + name); }
  catch (error) { results.push({ name, status: 'failed', error: error.stack }); console.error('FAIL ' + name + ': ' + error.stack); }
  finally { for (const environment of environments) environment.close(); }
}
function environment({ state = 'Trashed', override, protocol = 'https:' } = {}) {
  let version = 1, commits = 0, key = 0, time = 1000, reauthenticatedAt = null, reloads = 0;
  const cache = new Map(), calls = [];
  const server = {
    get article() { return { id, slug, state, articleVersion: version, articleEtag: aTag(version), draftVersion: state === 'Purged' ? null : 1,
      draftEtag: state === 'Purged' ? null : dTag(1), published: state === 'Published' ? { revisionId, revisionNo: 1, title: '线上标题' } : null,
      purgedAt: state === 'Purged' ? '2026-10-10T12:00:00Z' : null }; },
    get draft() { return { articleId: id, title: '<img src=x onerror=alert(1)> 当前草稿', summary: '摘要', draftVersion: 1, draftEtag: dTag(1),
      contentHash: 'fixture-content-hash', updatedAt: '2026-10-10T10:00:00Z', basePublishedRevisionId: null }; },
    get history() { return { articleVersion: version, articleEtag: aTag(version), page: 1, pageSize: 20, total: state === 'Purged' ? 0 : 1,
      items: state === 'Purged' ? [] : [{ id: revisionId, articleId: id, revisionNo: 1, title: '历史标题', summary: '历史摘要', columnId,
        createdAt: '2026-10-10T10:00:00Z', isCurrentPublished: state === 'Published' }] }; },
    changeState(value) { state = value; version++; },
    get commits() { return commits; },
    mutate(path, options) {
      assert.equal(options.headers['X-CSRF-TOKEN'], 'fixture-csrf');
      assert.equal(options.credentials, 'same-origin');
      const body = JSON.parse(options.body), key = options.headers['Idempotency-Key'];
      if (path.endsWith('/purge') && (reauthenticatedAt === null || time - reauthenticatedAt >= 600000)) return response({ code: 'REAUTH_REQUIRED' }, 403);
      if (cache.has(key)) return response(cache.get(key));
      if (options.headers['If-Match'] !== aTag(version)) return response({ code: 'VERSION_CONFLICT' }, 412);
      if (state !== 'Trashed') return response({ code: 'STATE_CONFLICT' }, 409);
      if (path.endsWith('/purge')) { assert.deepEqual(body, { confirmSlug: slug }); state = 'Purged'; }
      else if (path.endsWith('/restore')) { assert.deepEqual(body, {}); state = 'Draft'; }
      else throw new Error('Unexpected fixture mutation: ' + path);
      version++; commits++; cache.set(key, structuredClone(server.article)); return response(server.article);
    },
  };
  const virtualConsole = new VirtualConsole(); virtualConsole.on('jsdomError', error => { if (!error.message.includes('navigation')) throw error; });
  const html = page.slice(page.indexOf('<section class='), page.indexOf('@section Scripts')).replaceAll('@RouteData.Values["id"]', id);
  const dom = new JSDOM(html, { url: `${protocol}//fixture.invalid/admin/articles/${id}/manage`, runScripts: 'outside-only', virtualConsole });
  const w = dom.window;
  Object.defineProperty(w.crypto, 'randomUUID', { value: () => `44444444-4444-4444-8444-${String(++key).padStart(12, '0')}` });
  w.fetch = async (path, options = {}) => {
    calls.push({ path, options }); const special = override?.(path, options, server, calls);
    if (special !== undefined) return await special;
    if (path.endsWith('/bootstrap')) return response({ session: { user: { id: 'fixture-admin' } }, csrfToken: 'fixture-csrf' });
    if (path.endsWith('/reauth')) { assert.deepEqual(JSON.parse(options.body), { password: 'fixture-only-password' }); reauthenticatedAt = time; return response(null, 204); }
    if (options.method === 'POST') return server.mutate(path, options);
    if (path.includes('/revisions?')) return response(server.history);
    return response(path.endsWith('/draft') ? server.draft : server.article);
  };
  w.__reload = () => reloads++; w.__now = () => time;
  w.eval(source.replace('export function createArticleLifecycleAdmin', 'function createArticleLifecycleAdmin')
    .replace('if (root) createArticleLifecycleAdmin(root);', 'if (root) window.__lifecycle = createArticleLifecycleAdmin(root, { reloadPage: window.__reload, now: window.__now });'));
  const $ = selector => w.document.querySelector(selector);
  return { w, server, calls, $, get state() { return $('[data-article-lifecycle]').dataset.state; }, get reloads() { return reloads; },
    get posts() { return calls.filter(call => call.options.method === 'POST'); },
    get purges() { return calls.filter(call => call.path.endsWith('/purge')); },
    get auths() { return calls.filter(call => call.path.endsWith('/reauth')); },
    clock(value) { time += value; },
    click(selector) { $(selector).click(); }, synthetic(selector) { $(selector).dispatchEvent(new w.Event('click', { bubbles: true })); },
    input(selector, value) { $(selector).value = value; $(selector).dispatchEvent(new w.Event('input', { bubbles: true })); },
    auth() { $('[data-password]').value = 'fixture-only-password'; $('[data-reauth-form]').dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true })); },
    link(selector, type = 'click') { const event = new w.MouseEvent(type, { bubbles: true, cancelable: true }); $(selector).dispatchEvent(event); return event.defaultPrevented; },
    beforeUnload() { const event = new w.Event('beforeunload', { cancelable: true }); w.dispatchEvent(event); return event.defaultPrevented; },
    pagehide(persisted = false) { const event = new w.Event('pagehide'); Object.defineProperty(event, 'persisted', { value: persisted }); w.dispatchEvent(event); },
    close() { w.__lifecycle.destroy(); dom.window.close(); },
  };
}
async function prepare(e) { e.click('[data-action="purge"]'); await flush(); }
async function second(e) { await prepare(e); e.click('[data-confirm]'); await flush(); }
async function authenticated(e) { await second(e); e.input('[data-confirm-slug]', slug); e.auth(); await flush(); }
async function purge(e) { await authenticated(e); e.click('[data-confirm]'); await flush(); }
async function replay(e) { e.click('[data-reload]'); await flush(); e.click('[data-continue]'); await flush(); }
function tombstone(e) {
  assert.equal(e.$('[data-draft-link]').hidden, true); assert.equal(e.$('[data-history-section]').hidden, true);
  assert.equal(e.$('[data-history-list]').children.length, 0); assert.equal(e.$('[data-restore-revision]').disabled, true);
  assert.equal(e.$('[data-action="restore"]').hidden, true); assert.equal(e.$('[data-action="purge"]').hidden, true);
  assert.match(e.$('[data-publication]').textContent, /草稿及历史已删除.*无法恢复.*共享媒体文件未删除/);
  assert.equal(e.$('[data-article-list]').getAttribute('href'), '/admin/articles');
}

for (const state of ['Draft', 'Published', 'Withdrawn', 'Purged']) await check(`${state} cannot expose or synthesize a purge`, async track => {
  const e = track(environment({ state })); await flush(); assert.equal(e.$('[data-action="purge"]').hidden, true);
  e.synthetic('[data-action="purge"]'); e.synthetic('[data-confirm]'); e.auth(); await flush(); assert.equal(e.posts.length, 0);
  if (state === 'Purged') { tombstone(e); assert.equal(e.calls.some(call => call.path.endsWith('/draft') || call.path.includes('/revisions?')), false); assert.equal(e.link('[data-article-list]'), false); }
});
await check('Purge uses two deliberate confirmations, exact slug, reauth, CAS, CSRF and one immutable UUID request', async track => {
  const e = track(environment()); await flush(); await prepare(e);
  assert.equal(e.posts.length, 0); assert.equal(e.$('[data-purge-fields]').hidden, true);
  assert.match(e.$('[data-confirmation-text]').textContent, /无法恢复.*工作草稿.*全部发布历史.*文章媒体引用.*墓碑.*审计.*共享媒体文件不会删除/);
  assert.doesNotMatch(e.$('[data-confirmation-text]').textContent, /预览令牌/);
  assert.equal(e.w.document.querySelector('[data-confirmation-text] img'), null);
  e.click('[data-confirm]'); await flush(); assert.equal(e.posts.length, 0); assert.equal(e.$('[data-confirm]').disabled, true);
  e.input('[data-confirm-slug]', slug); e.auth(); assert.equal(e.$('[data-password]').value, ''); await flush();
  assert.equal(e.auths.length, 1); assert.equal(e.purges.length, 0); assert.equal(e.$('[data-confirm]').disabled, false);
  e.click('[data-confirm]'); e.synthetic('[data-confirm]'); await flush();
  assert.equal(e.purges.length, 1); assert.equal(e.server.commits, 1);
  const sent = e.purges[0]; assert.deepEqual(JSON.parse(sent.options.body), { confirmSlug: slug });
  assert.equal(sent.options.headers['If-Match'], aTag(1)); assert.equal(sent.options.headers['X-CSRF-TOKEN'], 'fixture-csrf');
  assert.match(sent.options.headers['Idempotency-Key'], /^[0-9a-f-]{36}$/); assert.equal(e.$('[data-password]').value, '');
  assert.equal(e.beforeUnload(), false); tombstone(e); assert.equal(e.link('[data-article-list]'), false);
  e.click('[data-use-server]'); await flush(); tombstone(e);
});
for (const value of ['', ' article-original', 'article-original ', 'ARTICLE-ORIGINAL', 'https://fixture.invalid/articles/article-original', 'another-article']) await check(`Slug must match ordinally: ${JSON.stringify(value)}`, async track => {
  const e = track(environment()); await flush(); await second(e); e.input('[data-confirm-slug]', value);
  e.auth(); e.synthetic('[data-confirm]'); await flush(); assert.equal(e.posts.length, 0); assert.equal(e.$('[data-password]').value, '');
});
await check('Reauthentication is unavailable over insecure non-local HTTP', async track => {
  const e = track(environment({ protocol: 'http:' })); await flush(); await second(e); e.input('[data-confirm-slug]', slug); e.auth(); await flush();
  assert.equal(e.posts.length, 0); assert.equal(e.$('[data-password]').value, ''); assert.match(e.$('[data-reauth-status]').textContent, /HTTPS/);
});
for (const phase of ['first', 'second', 'verified']) await check(`Cancel from ${phase} confirmation clears input and never purges`, async track => {
  const e = track(environment()); await flush();
  if (phase === 'first') await prepare(e); else if (phase === 'second') await second(e); else await authenticated(e);
  e.$('[data-password]').value = 'fixture-only-password'; e.click('[data-cancel]'); e.synthetic('[data-confirm]'); await flush();
  assert.equal(e.purges.length, 0); assert.equal(e.$('[data-password]').value, ''); assert.equal(e.$('[data-confirm-slug]').value, '');
  assert.equal(e.$('[data-confirmation]').hidden, true); assert.equal(e.beforeUnload(), false);
});
for (const interruption of ['cancel', 'dirty', 'read', 'pagehide']) await check(`${interruption} during reauth bootstrap prevents transmitting the captured fixture password`, async track => {
  const delayed = deferred(); let hold = false;
  const e = track(environment({ override: path => hold && path.endsWith('/bootstrap') ? delayed.promise : undefined })); await flush(); await second(e);
  e.input('[data-confirm-slug]', slug); hold = true; e.auth(); await flush();
  if (interruption === 'cancel') e.click('[data-cancel]');
  if (interruption === 'dirty') e.input('[data-confirm-slug]', slug + '-changed');
  if (interruption === 'read') { e.click('[data-reload]'); await flush(); }
  if (interruption === 'pagehide') e.pagehide();
  delayed.resolve(response({ session: { user: { id: 'fixture-admin' } }, csrfToken: 'fixture-csrf' })); await flush();
  assert.equal(e.posts.length, 0); assert.equal(e.$('[data-password]').value, '');
});
for (const interruption of ['cancel', 'dirty', 'read', 'pagehide']) for (const outcome of ['success', '401', 'network']) await check(`${interruption} owns state after stale reauth ${outcome}`, async track => {
  const delayed = deferred(); let denyRead = false;
  const e = track(environment({ override: path => path.endsWith('/reauth') ? delayed.promise : denyRead && path === `/api/admin/v1/articles/${id}` ? response({}, 401) : undefined }));
  await flush(); await second(e); e.input('[data-confirm-slug]', slug); e.auth(); await flush(); assert.equal(e.auths.length, 1);
  if (interruption === 'cancel') e.click('[data-cancel]');
  if (interruption === 'dirty') e.input('[data-confirm-slug]', slug + '-changed');
  if (interruption === 'read') { denyRead = true; e.click('[data-reload]'); await flush(); }
  if (interruption === 'pagehide') e.pagehide();
  if (outcome === 'network') delayed.reject(new Error('fixture lost reauth')); else delayed.resolve(response(null, outcome === 'success' ? 204 : 401));
  await flush(); e.synthetic('[data-confirm]'); await flush(); assert.equal(e.purges.length, 0); assert.equal(e.$('[data-password]').value, '');
  if (interruption === 'read') assert.equal(e.state, 'auth');
  if (interruption === 'cancel') { assert.equal(e.state, 'ready'); assert.equal(e.beforeUnload(), false); }
});
await check('An old reauth finally cannot unlock a newer verification for a replacement confirmation', async track => {
  const old = deferred(), latest = deferred(); let count = 0;
  const e = track(environment({ override: path => path.endsWith('/reauth') ? (++count === 1 ? old.promise : latest.promise) : undefined }));
  await flush(); await second(e); e.input('[data-confirm-slug]', slug); e.auth(); await flush(); e.click('[data-cancel]');
  await second(e); e.input('[data-confirm-slug]', slug); e.auth(); await flush(); old.resolve(response(null, 204)); await flush();
  assert.equal(e.$('[data-reauth]').disabled, true); assert.equal(e.$('[data-confirm]').disabled, true);
  latest.resolve(response(null, 204)); await flush(); assert.equal(e.$('[data-confirm]').disabled, false); assert.equal(e.purges.length, 0);
});
await check('Changing confirmation text after successful reauth invalidates it even when the text is restored', async track => {
  const e = track(environment()); await flush(); await authenticated(e); e.input('[data-confirm-slug]', slug + '-changed'); e.input('[data-confirm-slug]', slug);
  e.synthetic('[data-confirm]'); await flush(); assert.equal(e.purges.length, 0); assert.equal(e.$('[data-confirm]').disabled, true);
  e.auth(); await flush(); assert.equal(e.$('[data-confirm]').disabled, false);
});
for (const phase of ['before-final', 'during-bootstrap']) await check(`Ten minute reauth expiry ${phase} blocks sending purge`, async track => {
  const delayed = deferred(); let hold = false;
  const e = track(environment({ override: path => hold && path.endsWith('/bootstrap') ? delayed.promise : undefined })); await flush(); await authenticated(e);
  if (phase === 'before-final') e.clock(600000); else hold = true;
  e.click('[data-confirm]'); await flush();
  if (phase === 'during-bootstrap') { e.clock(600000); delayed.resolve(response({ session: { user: { id: 'fixture-admin' } }, csrfToken: 'fixture-csrf' })); await flush(); }
  assert.equal(e.purges.length, 0); assert.equal(e.$('[data-confirm]').disabled, true);
});
for (const outcome of ['network', '503', 'bad-json', 'bad-etag']) await check(`Unknown purge ${outcome} requires read, explicit continuation, new reauth and exact request replay`, async track => {
  let first = true;
  const e = track(environment({ override: (path, options, server) => {
    if (!path.endsWith('/purge') || !first) return; first = false; const result = server.mutate(path, options);
    if (outcome === 'network') return Promise.reject(new Error('fixture lost receipt'));
    if (outcome === '503') return response({}, 503);
    if (outcome === 'bad-json') return { ...result, json: async () => { throw new Error('fixture bad JSON'); } };
    return { ...result, headers: { get: () => '"wrong"' } };
  } })); await flush(); await purge(e); assert.equal(e.state, 'unknown'); assert.equal(e.beforeUnload(), true);
  assert.equal(e.$('[data-cancel]').disabled, true); e.synthetic('[data-retry]'); assert.equal(e.purges.length, 1);
  await replay(e); tombstone(e); assert.equal(e.$('[data-retry]').disabled, true); assert.equal(e.purges.length, 1);
  e.input('[data-confirm-slug]', 'different-slug'); assert.equal(e.$('[data-confirm-slug]').value, slug);
  e.auth(); await flush(); assert.equal(e.$('[data-retry]').disabled, false); assert.equal(e.purges.length, 1);
  e.click('[data-retry]'); e.synthetic('[data-retry]'); await flush();
  assert.equal(e.purges.length, 2); assert.equal(e.auths.length, 2); assert.equal(e.server.commits, 1);
  assert.equal(e.purges[1].options.body, e.purges[0].options.body);
  assert.equal(e.purges[1].options.headers['Idempotency-Key'], e.purges[0].options.headers['Idempotency-Key']);
  assert.equal(e.purges[1].options.headers['If-Match'], e.purges[0].options.headers['If-Match']);
  assert.equal(e.beforeUnload(), false); tombstone(e);
});
await check('Server REAUTH_REQUIRED preserves original key, body and CAS and requires explicit reauthorization', async track => {
  let first = true;
  const e = track(environment({ override: path => path.endsWith('/purge') && first ? (first = false, response({ code: 'REAUTH_REQUIRED' }, 403)) : undefined }));
  await flush(); await purge(e); assert.equal(e.state, 'auth'); assert.match(e.$('[data-status]').textContent, /密码重验/); assert.equal(e.server.commits, 0);
  await replay(e); assert.equal(e.$('[data-retry]').disabled, true); e.auth(); await flush(); e.click('[data-retry]'); await flush();
  assert.equal(e.purges.length, 2); assert.deepEqual(e.purges[1].options.headers, e.purges[0].options.headers); assert.equal(e.purges[1].options.body, e.purges[0].options.body); tombstone(e);
});
for (const status of [401, 403, 429, 503]) await check(`Reauth HTTP ${status} never grants purge confirmation`, async track => {
  const e = track(environment({ override: path => path.endsWith('/reauth') ? response({}, status) : undefined }));
  await flush(); await authenticated(e); e.synthetic('[data-confirm]'); await flush();
  assert.equal(e.auths.length, 1); assert.equal(e.purges.length, 0); assert.equal(e.$('[data-password]').value, ''); assert.equal(e.$('[data-confirm]').disabled, true);
});
await check('Unsent final bootstrap failure requires server choice and new reauth before sending the retained purge', async track => {
  let blocked = false;
  const e = track(environment({ override: path => blocked && path.endsWith('/bootstrap') ? response({ csrfToken: '' }) : undefined }));
  await flush(); await authenticated(e); blocked = true; e.click('[data-confirm]'); await flush();
  assert.equal(e.state, 'auth'); assert.equal(e.purges.length, 0); assert.equal(e.beforeUnload(), true);
  blocked = false; await replay(e); assert.equal(e.$('[data-retry]').disabled, true);
  e.auth(); await flush(); e.click('[data-retry]'); await flush(); assert.equal(e.purges.length, 1); assert.equal(e.auths.length, 2); tombstone(e);
});
for (const status of [409, 412, 422, 428]) await check(`A rejected unknown purge HTTP ${status} permits only explicit abandonment after reread`, async track => {
  let count = 0;
  const e = track(environment({ override: path => path.endsWith('/purge')
    ? ++count === 1 ? Promise.reject(new Error('fixture unknown before commit')) : response({}, status) : undefined }));
  await flush(); await purge(e); await replay(e); e.auth(); await flush(); e.click('[data-retry]'); await flush();
  assert.equal(e.purges.length, 2); assert.equal(e.beforeUnload(), true); assert.equal(e.$('[data-use-server]').disabled, true);
  e.click('[data-reload]'); await flush(); assert.equal(e.$('[data-use-server]').disabled, false); e.click('[data-use-server]'); await flush();
  assert.equal(e.beforeUnload(), false); assert.equal(e.purges.length, 2); assert.equal(e.server.commits, 0); assert.equal(e.$('[data-action="restore"]').disabled, false);
});
await check('Replay reauthentication also expires before an explicit retry and sends no automatic request', async track => {
  let first = true;
  const e = track(environment({ override: path => path.endsWith('/purge') && first ? (first = false, Promise.reject(new Error('fixture unknown'))) : undefined }));
  await flush(); await purge(e); await replay(e); e.auth(); await flush(); e.clock(600000); e.click('[data-retry]'); await flush();
  assert.equal(e.purges.length, 1); assert.equal(e.$('[data-retry]').disabled, true); assert.match(e.$('[data-reauth-status]').textContent, /重新验证/);
});
await check('Changed article state during purge preparation never permits slug/password confirmation', async track => {
  const e = track(environment()); await flush(); e.server.changeState('Draft'); await second(e); e.input('[data-confirm-slug]', slug); e.auth(); await flush();
  assert.equal(e.posts.length, 0); assert.equal(e.$('[data-confirm]').disabled, true); assert.equal(e.$('[data-review]').hidden, false);
});
for (const outcome of ['success', '403', 'network', 'bad-json']) await check(`A newer auth freeze survives an in-flight purge ${outcome}`, async track => {
  const delayed = deferred(); let deny = false, receipt;
  const e = track(environment({ override: (path, options, server) => {
    if (path.endsWith('/purge')) { receipt = server.mutate(path, options); return delayed.promise; }
    if (deny && path === `/api/admin/v1/articles/${id}`) return response({}, 401);
  } })); await flush(); await authenticated(e); e.click('[data-confirm]'); await flush(); deny = true; e.click('[data-reload]'); await flush(); assert.equal(e.state, 'auth');
  if (outcome === 'network') delayed.reject(new Error('fixture lost receipt'));
  else delayed.resolve(outcome === 'success' ? receipt : outcome === '403' ? response({ code: 'REAUTH_REQUIRED' }, 403) : { ...receipt, json: async () => { throw new Error('fixture JSON'); } });
  await flush(); assert.equal(e.state, 'auth'); assert.equal(e.$('[data-retry]').disabled, true); assert.equal(e.$('[data-review]').hidden, true); assert.equal(e.beforeUnload(), true);
});
for (const outcome of ['success', 'network']) await check(`A decoding purge error ${outcome} cannot replace newer authentication state`, async track => {
  const delayed = deferred(); let deny = false;
  const e = track(environment({ override: path => path.endsWith('/purge') ? { ...response({}, 403), json: () => delayed.promise }
    : deny && path === `/api/admin/v1/articles/${id}` ? response({}, 401) : undefined }));
  await flush(); await purge(e); deny = true; e.click('[data-reload]'); await flush();
  if (outcome === 'network') delayed.reject(new Error('fixture late JSON')); else delayed.resolve({ code: 'REAUTH_REQUIRED' });
  await flush(); assert.equal(e.state, 'auth'); assert.equal(e.$('[data-retry]').disabled, true); assert.equal(e.purges.length, 1);
});
for (const defect of ['slug', 'draft', 'publication', 'version', 'status']) await check(`A malformed purge receipt (${defect}) is not success`, async track => {
  const e = track(environment({ override: (path, options, server) => {
    if (!path.endsWith('/purge')) return; server.mutate(path, options); const result = structuredClone(server.article);
    if (defect === 'slug') result.slug = 'different-slug';
    if (defect === 'draft') { result.draftVersion = 1; result.draftEtag = dTag(1); }
    if (defect === 'publication') result.published = { revisionId, revisionNo: 1, title: 'leaked' };
    if (defect === 'version') { result.articleVersion = 1; result.articleEtag = aTag(1); }
    return response(result, defect === 'status' ? 202 : 200);
  } })); await flush(); await purge(e); assert.equal(e.state, 'unknown'); assert.equal(e.beforeUnload(), true); assert.equal(e.$('[data-retry]').disabled, true);
});
await check('Verified purge receipt removes stale body controls even if its follow-up read fails', async track => {
  let deny = false;
  const e = track(environment({ override: (path, options, server) => {
    if (path.endsWith('/purge')) { const receipt = server.mutate(path, options); deny = true; return receipt; }
    if (deny && path === `/api/admin/v1/articles/${id}`) return response({}, 401);
  } })); await flush(); await purge(e); assert.equal(e.state, 'auth'); assert.equal(e.beforeUnload(), false); tombstone(e); assert.equal(e.link('[data-article-list]'), false);
});
await check('A cached successful Purged receipt remains final when the follow-up read fails', async track => {
  let count = 0, deny = false;
  const e = track(environment({ override: (path, options, server) => {
    if (path.endsWith('/purge')) { const receipt = server.mutate(path, options); if (++count === 1) return Promise.reject(new Error('fixture lost receipt')); deny = true; return receipt; }
    if (deny && path === `/api/admin/v1/articles/${id}`) return response({}, 403);
  } })); await flush(); await purge(e); await replay(e); e.auth(); await flush(); e.click('[data-retry]'); await flush();
  assert.equal(e.state, 'auth'); assert.equal(e.beforeUnload(), false); assert.equal(e.server.commits, 1); tombstone(e); assert.equal(e.link('[data-article-list]'), false);
});
await check('A Purged recovery read immediately removes old restore/history controls before server adoption', async track => {
  const e = track(environment()); await flush(); assert.equal(e.$('[data-history-list]').children.length, 1);
  e.server.changeState('Purged'); e.click('[data-reload]'); await flush(); tombstone(e);
  assert.equal(e.$('[data-use-server]').disabled, false); assert.equal(e.purges.length, 0);
});
await check('A cached reversible restore receipt never resurrects body links after observing Purged', async track => {
  let first = true;
  const e = track(environment({ override: (path, options, server) => {
    if (path.endsWith('/restore') && first) { first = false; server.mutate(path, options); return Promise.reject(new Error('fixture lost restore')); }
  } })); await flush(); e.click('[data-action="restore"]'); await flush(); e.click('[data-confirm]'); await flush(); e.server.changeState('Purged');
  await replay(e); tombstone(e); e.click('[data-retry]'); await flush(); tombstone(e); assert.equal(e.beforeUnload(), false);
});
await check('An older non-Purged snapshot cannot undo a previously observed tombstone', async track => {
  let stale = false, oldArticle, oldDraft;
  const e = track(environment({ override: path => stale && path === `/api/admin/v1/articles/${id}` ? response(oldArticle) : stale && path.endsWith('/draft') ? response(oldDraft) : undefined }));
  await flush(); oldArticle = e.server.article; oldDraft = e.server.draft; e.server.changeState('Purged'); e.click('[data-reload]'); await flush();
  e.click('[data-use-server]'); await flush(); stale = true; e.click('[data-reload]'); await flush(); tombstone(e); assert.equal(e.$('[data-review]').hidden, true);
});
await check('Dirty confirmation and in-flight purge guard list/draft navigation and keep original intent', async track => {
  const delayed = deferred();
  const e = track(environment({ override: path => path.endsWith('/purge') ? delayed.promise : undefined })); await flush(); await authenticated(e);
  assert.equal(e.beforeUnload(), true); assert.equal(e.link('[data-article-list]'), true); assert.equal(e.link('[data-article-list]', 'auxclick'), true);
  assert.equal(e.link('[data-draft-link]'), true); e.click('[data-confirm]'); await flush(); assert.equal(e.link('[data-article-list]'), true);
  e.synthetic('[data-action="restore"]'); e.synthetic('[data-cancel]'); assert.equal(e.purges.length, 1); delayed.reject(new Error('fixture lost')); await flush(); assert.equal(e.beforeUnload(), true);
});
await check('Pagehide clears password, aborts handlers, and retained BFCache pageshow reloads once', async track => {
  const e = track(environment()); await flush(); await second(e); e.input('[data-confirm-slug]', slug); e.$('[data-password]').value = 'fixture-only-password';
  e.pagehide(true); assert.equal(e.$('[data-password]').value, ''); assert.equal(e.calls[0].options.signal.aborted, true);
  const count = e.calls.length; e.synthetic('[data-reload]'); e.auth(); await flush(); assert.equal(e.calls.length, count);
  const event = new e.w.Event('pageshow'); Object.defineProperty(event, 'persisted', { value: true }); e.w.dispatchEvent(event); e.w.dispatchEvent(event); assert.equal(e.reloads, 1);
});

mkdirSync('artifacts/f20', { recursive: true });
const failed = results.filter(result => result.status === 'failed').length;
writeFileSync('artifacts/f20/admin-article-purge-results.json', JSON.stringify({ scope: 'Actual shipped article lifecycle module and Razor markup in JSDOM; deterministic in-memory API and clock. No genuine passwords, deletions, database, listener, native browser, or visual-layout proof.', total: results.length, failed, checks: results }, null, 2));
console.log(`F20 article purge UI simulation checks: ${results.length - failed}/${results.length} passed.`);
if (failed) process.exitCode = 1;
