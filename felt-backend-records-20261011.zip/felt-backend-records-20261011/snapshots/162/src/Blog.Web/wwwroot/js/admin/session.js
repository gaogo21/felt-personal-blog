const form = document.querySelector('#admin-login');
const logout = document.querySelector('#admin-logout');
const status = document.querySelector('#auth-status');
const controller = new AbortController();
const request = (path, options = {}) => fetch(`/api/admin/v1${path}`, { credentials: 'same-origin', cache: 'no-store', signal: controller.signal, ...options });
async function token() {
  const response = await request('/session/bootstrap');
  if (!response.ok) throw new Error('无法取得安全验证信息，请刷新重试。');
  return (await response.json()).csrfToken;
}
async function submit(event) {
  event.preventDefault(); const button = form.querySelector('button'); if (button.disabled) return;
  button.disabled = true; status.textContent = '正在登录…';
  try {
    const csrf = await token();
    const response = await request('/session', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf }, body: JSON.stringify({ userName: form.elements.userName.value, password: form.elements.password.value }) });
    form.elements.password.value = '';
    if (!response.ok) { status.textContent = response.status === 429 ? '尝试次数过多，请稍后重试。' : response.status === 503 ? '服务暂不可用，请稍后重试。' : '无法登录，请检查账户信息或稍后重试。'; return; }
    location.assign(form.dataset.returnUrl || '/admin');
  } catch (error) { if (error.name !== 'AbortError') status.textContent = '登录未完成，请重试。'; }
  finally { button.disabled = false; }
}
async function signOut() {
  if (logout.disabled) return; logout.disabled = true;
  try {
    const csrf = await token(); const response = await request('/session', { method: 'DELETE', headers: { 'X-CSRF-TOKEN': csrf } });
    if (response.status === 204 || response.status === 401) location.assign('/admin/login');
    else status.textContent = '退出未确认，请重试。';
  } catch (error) { if (error.name !== 'AbortError') status.textContent = '退出未确认，请重试。'; }
  finally { logout.disabled = false; }
}
form?.addEventListener('submit', submit, { signal: controller.signal });
logout?.addEventListener('click', signOut, { signal: controller.signal });
window.addEventListener('pagehide', () => controller.abort(), { once: true });
window.addEventListener('pageshow', event => { if (event.persisted) location.reload(); });
