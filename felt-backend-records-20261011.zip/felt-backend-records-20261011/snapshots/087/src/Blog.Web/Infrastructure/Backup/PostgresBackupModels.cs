using System.Data.Common;
using System.Diagnostics;
using System.Globalization;
using Npgsql;

namespace Blog.Web.Infrastructure.Backup;

public interface IPostgresBackupDatabase
{
    PostgresBackupDatabaseIdentity? CapturedIdentity { get; }
    // The caller must hold the global Frozen maintenance lease until this settles.
    Task<string> CaptureAsync(string newDumpPath, CancellationToken cancellationToken);
}

public sealed record PostgresBackupOptions(string PgDumpPath, string PgRestorePath,
    TimeSpan CommandTimeout, long MaxDumpBytes = 8L * 1024 * 1024 * 1024)
{
    internal void Validate()
    {
        RequirePath(PgDumpPath); RequirePath(PgRestorePath);
        if (CommandTimeout <= TimeSpan.Zero || CommandTimeout > TimeSpan.FromDays(1) || MaxDumpBytes < 5)
            throw new PostgresBackupFailure("BACKUP_DATABASE_OPTIONS_INVALID");
    }

    internal static void RequirePath(string? value)
    {
        if (string.IsNullOrWhiteSpace(value) || !Path.IsPathFullyQualified(value) || value.Any(char.IsControl) ||
            value.Split(Path.DirectorySeparatorChar).Any(x => x is "." or ".."))
            throw new PostgresBackupFailure("BACKUP_DATABASE_OPTIONS_INVALID");
    }
}

// Never include provider/process exception text, stderr, connection strings or
// an InnerException. Codes are the complete externally observable diagnostic.
public sealed class PostgresBackupFailure(string code) : Exception(code)
{
    public string Code { get; } = code;
}

public sealed record PostgresBackupDatabaseIdentity(string ClusterSystemIdentifier, uint DatabaseOid);
public sealed record PostgresBackupSourceMetadata(PostgresBackupDatabaseIdentity Identity, string SchemaVersion, int ServerMajor);
public sealed record PostgresBackupTargetMetadata(PostgresBackupDatabaseIdentity Identity, bool HasUserObjects, bool HasOtherConnections, int ServerMajor);

public interface IPostgresBackupMetadata
{
    Task<PostgresBackupSourceMetadata> ReadSourceAsync(PostgresBackupConnection source, CancellationToken cancellationToken);
    Task<PostgresBackupTargetMetadata> InspectTargetAsync(PostgresBackupConnection target, CancellationToken cancellationToken);
}

// This is intentionally a class, not a positional record: automatic ToString
// must never expose authentication material.
public sealed class PostgresBackupConnection
{
    private readonly NpgsqlConnectionStringBuilder settings;
    private static readonly HashSet<string> Supported = new(StringComparer.OrdinalIgnoreCase)
    {
        "Host", "Port", "Database", "Username", "Password", "Passfile", "SSL Mode",
        "Root Certificate", "Channel Binding", "Timeout", "Application Name"
    };

    private PostgresBackupConnection(NpgsqlConnectionStringBuilder settings) => this.settings = settings;

    public static PostgresBackupConnection Parse(string connectionString)
    {
        try
        {
            // Npgsql canonicalizes aliases. Enumerating a plain builder over the
            // canonical string includes only supplied options, not every default.
            var parsed = new NpgsqlConnectionStringBuilder(connectionString);
            var supplied = new DbConnectionStringBuilder { ConnectionString = parsed.ConnectionString };
            if (supplied.Keys.Cast<string>().Any(key => !Supported.Contains(key))) Fail();
            if (string.IsNullOrWhiteSpace(parsed.Host) || parsed.Host.Contains(',') || parsed.Host.Any(char.IsControl) ||
                string.IsNullOrWhiteSpace(parsed.Database) || parsed.Database.Any(c => !(char.IsAsciiLetterOrDigit(c) || c is '_' or '-')) ||
                string.IsNullOrWhiteSpace(parsed.Username) || parsed.Username.Any(char.IsControl) || parsed.Timeout is < 1 or > 600)
                Fail();
            // Prefer/Allow can downgrade transport, and Require has different CA
            // fallback semantics in libpq. Reject instead of silently translating.
            if (!supplied.ContainsKey("SSL Mode") || parsed.SslMode is not (SslMode.Disable or SslMode.VerifyCA or SslMode.VerifyFull)) Fail();
            var password = !string.IsNullOrEmpty(parsed.Password);
            var passfile = !string.IsNullOrEmpty(parsed.Passfile);
            if (password == passfile || parsed.Password?.Contains('\0') == true) Fail();
            if (passfile) PostgresBackupOptions.RequirePath(parsed.Passfile);
            if (parsed.SslMode != SslMode.Disable) PostgresBackupOptions.RequirePath(parsed.RootCertificate);
            else if (!string.IsNullOrEmpty(parsed.RootCertificate)) Fail();
            if (parsed.SslMode == SslMode.Disable && parsed.ChannelBinding == ChannelBinding.Require) Fail();
            return new(parsed);
        }
        catch (PostgresBackupFailure) { throw; }
        catch { throw new PostgresBackupFailure("BACKUP_DATABASE_CONNECTION_UNSUPPORTED"); }
    }

    internal string Database => settings.Database!;
    internal NpgsqlConnection OpenableConnection()
    {
        // Neither constructor opens a connection. Pooling is disabled so metadata
        // sessions cannot remain behind and invalidate target exclusivity checks.
        var copy = new NpgsqlConnectionStringBuilder(settings.ConnectionString) { Pooling = false, Enlist = false };
        return new NpgsqlConnection(copy.ConnectionString);
    }

    internal Dictionary<string, string> Environment()
    {
        var result = new Dictionary<string, string>(StringComparer.Ordinal)
        {
            ["LC_ALL"] = "C", ["PGHOST"] = settings.Host!, ["PGPORT"] = settings.Port.ToString(CultureInfo.InvariantCulture),
            ["PGDATABASE"] = settings.Database!, ["PGUSER"] = settings.Username!,
            ["PGCONNECT_TIMEOUT"] = settings.Timeout.ToString(CultureInfo.InvariantCulture),
            ["PGAPPNAME"] = "felt-blog-backup", ["PGGSSENCMODE"] = "disable", ["PGSSLCERTMODE"] = "disable",
            ["PGSSLMODE"] = settings.SslMode switch { SslMode.Disable => "disable", SslMode.VerifyCA => "verify-ca", _ => "verify-full" },
            ["PGCHANNELBINDING"] = settings.ChannelBinding switch { ChannelBinding.Disable => "disable", ChannelBinding.Require => "require", _ => "prefer" }
        };
        if (!string.IsNullOrEmpty(settings.Password)) result["PGPASSWORD"] = settings.Password;
        else result["PGPASSFILE"] = settings.Passfile!;
        if (!string.IsNullOrEmpty(settings.RootCertificate)) result["PGSSLROOTCERT"] = settings.RootCertificate;
        return result;
    }

    public override string ToString() => "PostgresBackupConnection [redacted]";
    private static void Fail() => throw new PostgresBackupFailure("BACKUP_DATABASE_CONNECTION_UNSUPPORTED");
}

public sealed class PostgresBackupCommand
{
    private readonly string executable;
    private readonly string[] arguments;
    private readonly IReadOnlyDictionary<string, string> environment;

    internal PostgresBackupCommand(string executable, string[] arguments, IReadOnlyDictionary<string, string> environment,
        TimeSpan timeout, long maxOutputBytes)
    {
        this.executable = executable; this.arguments = arguments; this.environment = environment;
        Timeout = timeout; MaxOutputBytes = maxOutputBytes;
    }

    public TimeSpan Timeout { get; }
    public long MaxOutputBytes { get; }

    // For the process factory only. It contains credentials in the environment;
    // callers must never log or serialize this object.
    public ProcessStartInfo CreateStartInfo()
    {
        var info = new ProcessStartInfo(executable)
        {
            UseShellExecute = false, CreateNoWindow = true, RedirectStandardInput = true,
            RedirectStandardOutput = true, RedirectStandardError = true
        };
        info.Environment.Clear();
        foreach (var (key, value) in environment) info.Environment[key] = value;
        foreach (var value in arguments) info.ArgumentList.Add(value);
        return info;
    }

    public override string ToString() => "PostgresBackupCommand [redacted]";
}

public interface IPostgresBackupProcessRunner
{
    // Must not return/throw until the child has actually exited and ALL redirected
    // stream operations have settled, including cancellation and failure paths.
    Task RunAsync(PostgresBackupCommand command, Stream? standardInput, Stream standardOutput, CancellationToken cancellationToken);
}
