using Blog.Web.Application.Administration;
using Blog.Web.Application.Columns;
using Blog.Web.Application.Security;
using Blog.Web.Domain;
using Blog.Web.Infrastructure.Administration;

namespace Blog.Web.Api.Admin.V1;

public static class ColumnEndpoints
{
    public static void MapAdminColumnEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/admin/v1/columns").RequireAuthorization(AdminSecurityService.Policy);
        group.MapAdminColumnOrderEndpoints();
        group.MapGet("", async (HttpContext context, AdminColumnService service, CancellationToken ct) =>
        {
            var query = context.Request.Query;
            foreach (var item in query) if (item.Value.Count != 1 || item.Key is not ("state" or "q" or "page" or "pageSize")) throw new ApiFailure(ProblemCode.MALFORMED_REQUEST);
            int Integer(string name, int fallback) { if (!query.TryGetValue(name, out var text)) return fallback; return int.TryParse(text, out var value) ? value : throw ColumnInput.Invalid(name); }
            var filter = ColumnInput.Filter(query.TryGetValue("state", out var state) ? state.ToString() : null,
                query.TryGetValue("q", out var q) ? q.ToString() : null, Integer("page", 1), Integer("pageSize", ContentLimits.AdminPageSize));
            var result = await service.ListAsync(filter, ct); context.Response.Headers.ETag = result.SiteEtag;
            return Results.Json(result);
        });
        group.MapPost("", async (HttpContext context, AdminColumnService service) =>
        {
            var input = await AdminJsonBody.Read<CreateColumnInput>(context, 16384);
            await AdminApiHosting.WriteMutation(context, await service.CreateAsync(Actor(context), IdempotencyKey.Require(context.Request.Headers["Idempotency-Key"]), input, context.RequestAborted));
        });
        group.MapGet("/{id:guid}", async (Guid id, HttpContext context, AdminColumnService service) =>
        { var result = await service.ReadAsync(id, context.RequestAborted); context.Response.Headers.ETag = result.ColumnEtag; return Results.Json(result); });
        group.MapPut("/{id:guid}", async (Guid id, HttpContext context, AdminColumnService service) =>
        {
            var input = await AdminJsonBody.Read<SaveColumnInput>(context, 16384);
            await AdminApiHosting.WriteMutation(context, await service.SaveAsync(Actor(context), id, context.Request.Headers.IfMatch, input, context.RequestAborted));
        });
        foreach (var action in Enum.GetValues<ColumnAction>())
        {
            group.MapPost("/{id:guid}/" + action.ToString().ToLowerInvariant(), async (Guid id, HttpContext context, AdminColumnService service) =>
            {
                await AdminJsonBody.Read<ColumnActionInput>(context, 1024);
                await AdminApiHosting.WriteMutation(context, await service.ChangeStateAsync(Actor(context), id, context.Request.Headers.IfMatch,
                    IdempotencyKey.Require(context.Request.Headers["Idempotency-Key"]), action, context.RequestAborted));
            });
        }
    }
    private static AdminActor Actor(HttpContext context) => AdminActor.From(context.User, context.TraceIdentifier);
}
