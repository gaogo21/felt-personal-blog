namespace Blog.Web.Infrastructure;

// Read failures stay failures: never turn database or integrity errors into a
// fabricated empty blog or disclose an exception/connection string in HTML.
public sealed class PublicContentBoundary(RequestDelegate next, ILogger<PublicContentBoundary> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        var path = context.Request.Path;
        var reading = HttpMethods.IsGet(context.Request.Method) || HttpMethods.IsHead(context.Request.Method);
        if (!reading || !(path == "/" || path.StartsWithSegments("/articles") || path.StartsWithSegments("/columns")))
        { await next(context); return; }
        try { await next(context); }
        catch (OperationCanceledException) when (context.RequestAborted.IsCancellationRequested) { throw; }
        catch (Exception) when (!context.Response.HasStarted)
        {
            logger.LogWarning("Public content unavailable. Code: PUBLIC_CONTENT_UNAVAILABLE");
            context.Response.Clear(); context.Response.StatusCode = StatusCodes.Status503ServiceUnavailable;
            context.Response.Headers.CacheControl = "private, no-store";
        }
    }
}
