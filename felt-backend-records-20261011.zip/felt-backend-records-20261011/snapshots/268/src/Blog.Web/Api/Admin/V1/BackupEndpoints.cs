using Blog.Web.Application.Administration;
using Blog.Web.Application.Security;
using Blog.Web.Infrastructure.Administration;
using Blog.Web.Infrastructure.Backup;

namespace Blog.Web.Api.Admin.V1;
public static class BackupEndpoints
{
    public static void MapAdminBackupEndpoints(this WebApplication app)
    {
        app.MapPost("/api/admin/v1/maintenance/backup", async (HttpContext context, AdminSecurityService security,
            BackupControlService service) =>
        {
            if (context.Request.Query.Count != 0) throw new ApiFailure(ProblemCode.MALFORMED_REQUEST);
            var actor = AdminActor.From(context.User, context.TraceIdentifier);
            var session = AdminSecurityService.SessionId(context.User) ?? throw new ApiFailure(ProblemCode.SESSION_REQUIRED);
            if (!await security.HasRecentAuthenticationAsync(session, context.RequestAborted)) throw new ApiFailure(ProblemCode.REAUTH_REQUIRED);
            var input = await AdminJsonBody.Read<BackupInput>(context, 1024);
            var key = IdempotencyKey.Require(context.Request.Headers["Idempotency-Key"]);
            var lease = MaintenanceAdmissionMiddleware.GetCurrentLease(context)
                ?? throw new ApiFailure(ProblemCode.MAINTENANCE_READ_ONLY);
            await context.Response.WriteAsJsonAsync(await service.RunAsync(actor, key, input, lease, context.RequestAborted),
                ApiJson.Options, cancellationToken: context.RequestAborted);
        }).RequireAuthorization(AdminSecurityService.Policy);
    }
}
