using Blog.Web.Api.Admin.V1;
using Blog.Web.Application.Media;
using Blog.Web.Application.Maintenance;
namespace Blog.Web.Infrastructure.Media;
public static class MediaHosting
{
    public static IServiceCollection AddMediaPipeline(this IServiceCollection services)
    {
        services.AddSingleton(sp => MediaStorageOptions.Read(sp.GetRequiredService<IConfiguration>()));
        services.AddSingleton<IPrivateFileDurability, LinuxPrivateFileDurability>();
        services.AddSingleton<PrivateMediaStorage>();
        services.AddSingleton<UploadSlots>();
        services.AddSingleton(sp => sp.GetRequiredService<IConfiguration>().GetSection("Media:Tools").Get<MediaToolOptions>() ?? new MediaToolOptions());
        services.AddSingleton<IMediaFileProcessor, ToolMediaFileProcessor>();
        services.AddScoped<IMediaPersistence, PostgresMediaPersistence>();
        services.AddScoped<IMediaReadStore, PostgresMediaReadStore>();
        services.AddScoped<IMediaLibraryStore, PostgresMediaLibraryStore>();
        services.AddScoped<MediaLibraryService>();
        services.AddScoped<IMediaLifecycleStore, PostgresMediaLifecycleStore>();
        services.AddScoped<MediaLifecycleService>();
        services.AddScoped<MediaDeletionService>();
        services.AddSingleton<IProtectedMediaFiles, ProtectedMediaFiles>();
        services.AddSingleton<IMediaLifecycleFiles, PrivateMediaLifecycleFiles>();
        services.AddScoped<MediaUploadService>(); services.AddScoped<MediaProcessingService>();
        services.AddHostedService<MediaProcessingWorker>();
        services.AddHostedService<MediaDeletionWorker>();
        return services;
    }
}
public sealed class MediaProcessingWorker(IServiceScopeFactory scopes, IHostEnvironment environment, IConfiguration config,
    TimeProvider clock, ILogger<MediaProcessingWorker> logger, MaintenanceCoordinator maintenance) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Component tests drive leases explicitly through isolated stores; never contact PostgreSQL in a test host.
        if (environment.EnvironmentName == "ComponentTests") return;
        var sweepAt = clock.GetUtcNow();
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var processed = false;
                // Admit before constructing any scoped service. Pending persistent work belongs
                // in the snapshot; maintenance waits only for already admitted operations.
                using (var operation = config.GetValue<bool>("Maintenance:ReadOnly") ? null : maintenance.TryEnter())
                {
                    if (operation is not null)
                    {
                        await using var scope = scopes.CreateAsyncScope();
                        var service = scope.ServiceProvider.GetRequiredService<MediaProcessingService>();
                        processed = await service.RunOneAsync(stoppingToken, operation);
                    }
                }
                if (clock.GetUtcNow() >= sweepAt)
                {
                    using var sweep = config.GetValue<bool>("Maintenance:ReadOnly") ? null : maintenance.TryEnter();
                    if (sweep is not null)
                    {
                        await using var scope = scopes.CreateAsyncScope();
                        await scope.ServiceProvider.GetRequiredService<MediaProcessingService>().SweepOrphansAsync(stoppingToken, sweep);
                        sweepAt = clock.GetUtcNow().AddHours(1);
                    }
                }
                if (!processed) await Task.Delay(TimeSpan.FromSeconds(1), stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { break; }
            catch (Exception)
            {
                logger.LogWarning("Media worker is unavailable; private tasks remain pending. Code: MEDIA_WORKER_UNAVAILABLE");
                await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
            }
        }
    }
}
