using Blog.Web.Application.Administration;
using Blog.Web.Application.Maintenance;
using Blog.Web.Infrastructure.Backup;

namespace Blog.Web.Infrastructure.Operations;

// Dispatch without starting the web host or any hosted workers. The terminal
// attestation is required even when the cooperating local-process lock succeeds.
public sealed class OperatorCaptureStoppedCommand(IOperatorConsole console, OperatorCaptureOptions options,
    BackupOptions backup, IBackupLocalInstanceLock instanceLock, IOperatorCapturePreflight preflight,
    MaintenanceCoordinator maintenance, BackupControlService control)
{
    public const string Command = "capture-stopped";
    public const string Confirmation = "CREATE ENCRYPTED BACKUP; SERVICE STOPPED; NO EXTERNAL WRITERS";

    public async Task<int> RunAsync(IReadOnlyList<string> arguments, CancellationToken ct)
    {
        try
        {
            if (arguments.Count != 1 || arguments[0] != Command)
                return Finish(OperatorExitCode.InvalidCommand, "OPERATOR_COMMAND_INVALID");
            if (!console.IsInteractive) return Finish(OperatorExitCode.InteractiveRequired, "OPERATOR_INTERACTIVE_TERMINAL_REQUIRED");
            ct.ThrowIfCancellationRequested();
            if (!options.Enabled || !backup.Enabled)
                return Finish(OperatorExitCode.PreflightFailed, "OPERATOR_CAPTURE_CONFIGURATION_REQUIRED");
            console.Write("The application service must already be stopped. Exclude all other database, media, Data Protection, setup, migration, and filesystem writers.\n");
            console.Write("The local lock covers only cooperating processes using this backup destination; it does not prove that other or remote writers have stopped.\n");
            var input = OperatorInput.ReadLine(console, "Operation idempotency key (UUID; reuse only to query this same attempt): ", false, ct);
            if (!Guid.TryParseExact(input, "D", out var key) || key == Guid.Empty)
                return Finish(OperatorExitCode.InputRejected, "OPERATOR_INPUT_REJECTED");
            var confirmation = OperatorInput.ReadLine(console, "Type " + Confirmation + " to continue: ", false, ct);
            if (confirmation != Confirmation) return Finish(OperatorExitCode.Cancelled, "OPERATOR_CANCELLED");
            ct.ThrowIfCancellationRequested();
            using var exclusive = instanceLock.Acquire();
            try { preflight.Validate(); }
            catch (Exception error) when (error is not OutOfMemoryException)
            { return Finish(OperatorExitCode.PreflightFailed, "OPERATOR_CAPTURE_CONFIGURATION_REQUIRED"); }
            ct.ThrowIfCancellationRequested();
            using var admission = maintenance.TryEnter();
            if (admission is null) return Finish(OperatorExitCode.OperationFailed, "OPERATOR_CAPTURE_UNAVAILABLE");
            // Await the real task, including receipt completion and cleanup.
            // Cancellation never abandons capture or releases another owner's lock.
            var result = await control.RunStoppedAsync(key, admission, ct);
            if (result.Status != "Succeeded" || result.ValidationLevel != "ArtifactIntegrityOnly")
                return Finish(OperatorExitCode.OperationFailed, "OPERATOR_CAPTURE_RESULT_INVALID");
            console.Write("Operation: " + result.OperationId.ToString("D") + "\n");
            return Finish(OperatorExitCode.Success, "OPERATOR_CAPTURE_SUCCEEDED_ARTIFACT_INTEGRITY_ONLY");
        }
        catch (BackupLocalInstanceLockFailure)
        { return Finish(OperatorExitCode.PreflightFailed, "OPERATOR_CAPTURE_EXCLUSIVE_ACCESS_REQUIRED"); }
        catch (OperatorInputException error)
        {
            return error.Failure switch
            {
                OperatorInputFailure.Cancelled => Finish(OperatorExitCode.Cancelled, "OPERATOR_CANCELLED"),
                OperatorInputFailure.InteractiveRequired => Finish(OperatorExitCode.InteractiveRequired, "OPERATOR_INTERACTIVE_TERMINAL_REQUIRED"),
                _ => Finish(OperatorExitCode.InputRejected, "OPERATOR_INPUT_REJECTED")
            };
        }
        catch (OperationCanceledException) { return Finish(OperatorExitCode.Cancelled, "OPERATOR_CANCELLED"); }
        catch (ApiFailure error) when (error.Code == ProblemCode.IDEMPOTENCY_IN_PROGRESS)
        { return Finish(OperatorExitCode.OperationFailed, "OPERATOR_CAPTURE_PENDING_RECONCILIATION_REQUIRED"); }
        catch (Exception error) when (error is not OutOfMemoryException)
        { return Finish(OperatorExitCode.OperationFailed, "OPERATOR_CAPTURE_FAILED"); }
    }

    private int Finish(int code, string message)
    {
        try { console.Write(Environment.NewLine + message + Environment.NewLine); }
        catch (Exception error) when (error is not OutOfMemoryException) { }
        return code;
    }
}
