// Two five-image rows, animated by elapsed time at a constant screen-space speed.
// The duplicate groups are visual loop buffers; the viewer still contains ten works.
export function mountGallery(root,art){
 const rails=[...root.querySelectorAll('.art-rail')],tracks=[...root.querySelectorAll('.art-track')],groups=[...root.querySelectorAll('.art-sequence[data-original]')],originalCards=[...root.querySelectorAll('[data-art]')],rows=root.querySelector('.art-rows'),dialog=root.querySelector('.art-lightbox'),hint=root.querySelector('.art-scroll-hint'),toggle=root.querySelector('.art-motion-toggle'),media=matchMedia('(prefers-reduced-motion: reduce)');
 const SPEED=36;let raf=0,last=null,selected=0,opener=null,disposed=false,visible=false,hovered=false,focused=false,userPaused=false,widths=[0,0],distance=[0,0],cycles=[0,0],initialized=false;
 const events=[];const on=(el,name,fn,opts)=>{el.addEventListener(name,fn,opts);events.push(()=>el.removeEventListener(name,fn,opts))};
 const reason=()=>media.matches?'static':userPaused?'paused':document.hidden?'hidden':!visible?'offscreen':dialog.open?'viewer':hovered?'hover':focused?'focus':'playing';
 function paint(){tracks.forEach((track,i)=>{const x=i===0?distance[i]-widths[i]:-distance[i];track.style.transform=`translate3d(${x}px,0,0)`});root.dataset.distance=JSON.stringify(distance.map(n=>+n.toFixed(3)));root.dataset.cycles=JSON.stringify(cycles)}
 function frame(now){raf=0;if(disposed||reason()!=='playing'){last=null;return}if(last!==null){const dt=Math.min((now-last)/1000,.064);widths.forEach((width,i)=>{if(!width)return;const next=distance[i]+dt*SPEED;cycles[i]+=Math.floor(next/width);distance[i]=next%width});paint()}last=now;raf=requestAnimationFrame(frame)}
 function sync(){if(disposed)return;cancelAnimationFrame(raf);raf=0;last=null;const state=reason();root.dataset.playback=state;toggle.disabled=media.matches;toggle.textContent=media.matches?'STATIC':userPaused?'PLAY':'PAUSE';toggle.setAttribute('aria-pressed',String(userPaused||media.matches));toggle.setAttribute('aria-label',userPaused?'Play artwork motion':'Pause artwork motion');hint.textContent=state==='playing'?'AUTOPLAY · 10 IMAGES':state==='static'?'SWIPE TO EXPLORE':state==='paused'?'MOTION PAUSED':state==='hover'||state==='focus'||state==='viewer'?'TAKE A CLOSER LOOK':'10 IMAGES';if(state==='playing')raf=requestAnimationFrame(frame)}
 function measure(){if(disposed)return;root.classList.toggle('is-marquee',!media.matches);root.classList.toggle('is-static',media.matches);root.dataset.mode=media.matches?'static':'marquee';originalCards.forEach(card=>card.tabIndex=media.matches?0:-1);tracks.forEach(track=>track.querySelectorAll('[data-clone]').forEach(el=>el.remove()));
  if(media.matches){tracks.forEach(track=>track.style.removeProperty('transform'));sync();return}
  groups.forEach((group,i)=>{const width=group.getBoundingClientRect().width;distance[i]=initialized&&widths[i]?distance[i]/widths[i]*width:i===0?0:width*.1;widths[i]=width;const copies=Math.max(2,Math.ceil(rails[i].clientWidth/Math.max(1,width))+1);for(let c=1;c<copies;c++){const clone=group.cloneNode(true);clone.removeAttribute('data-original');clone.dataset.clone='';clone.setAttribute('aria-hidden','true');clone.querySelectorAll('a').forEach(a=>a.tabIndex=-1);clone.querySelectorAll('img').forEach(img=>{img.loading='eager';img.alt='' });tracks[i].append(clone)}});initialized=true;root.dataset.cycleWidth=JSON.stringify(widths.map(n=>+n.toFixed(3)));root.dataset.speed=String(SPEED);paint();sync();
 }
 function show(index){if(disposed||!art.length)return;selected=(index+art.length)%art.length;const a=art[selected],image=dialog.querySelector('figure>img'),credit=dialog.querySelector('.art-lightbox-credit');image.src=a.src;image.alt=a.alt;dialog.querySelector('h3').textContent=a.title;dialog.querySelector('.art-lightbox-count').textContent=String(selected+1).padStart(2,'0')+' / '+String(art.length).padStart(2,'0');credit.replaceChildren();  const append=(text,url,fallback)=>{
   if(!text&&!url)return;let safe=false;
   try{const target=new URL(url);safe=target.protocol==='https:'&&!target.username&&!target.password&&!/[\u0000-\u0020\\]/.test(url)}catch{}
   const item=document.createElement(safe?'a':'span');item.textContent=text||fallback;
   if(safe){item.href=url;item.target='_blank';item.rel='noopener noreferrer'}
   if(credit.childNodes.length)credit.append(document.createTextNode(' · '));credit.append(item);
  };
  append([a.author,a.provider].filter(Boolean).join(' / '),a.source,'来源');append(a.license,a.licenseUrl,'许可');
  if(!credit.childNodes.length)credit.textContent='未填写来源与许可说明';root.dataset.selected=String(selected)}
 function open(index,el){opener=el;show(index);if(!dialog.open)dialog.showModal();sync()}
 on(rows,'click',e=>{const card=e.target.closest('[data-art]');if(card){e.preventDefault();open(Number(card.dataset.art),card)}});
 on(root.querySelector('.art-view-all'),'click',e=>open(0,e.currentTarget));on(toggle,'click',()=>{userPaused=!userPaused;sync()});on(dialog.querySelector('.art-lightbox-close'),'click',()=>dialog.close());
 dialog.querySelectorAll('[data-art-step]').forEach(button=>on(button,'click',()=>show(selected+Number(button.dataset.artStep))));on(dialog,'keydown',e=>{if(e.key==='Escape'){e.preventDefault();dialog.close();return}if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();show(selected+(e.key==='ArrowRight'?1:-1))}});
 on(dialog,'click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close()}});
 on(dialog,'close',()=>{if(opener?.isConnected){if(opener.closest('[data-clone]'))root.querySelector('.art-view-all').focus({preventScroll:true});else opener.focus({preventScroll:true})}focused=!!document.activeElement?.matches(':focus-visible');sync()});
 on(rows,'pointerenter',e=>{if(e.pointerType==='mouse'){hovered=true;sync()}});on(rows,'pointerleave',()=>{hovered=false;sync()});
 on(root,'focusin',()=>{focused=!!document.activeElement?.matches(':focus-visible');sync()});on(root,'focusout',()=>queueMicrotask(()=>{focused=root.contains(document.activeElement)&&!!document.activeElement?.matches(':focus-visible');sync()}));
 on(document,'visibilitychange',sync);on(window,'resize',measure,{passive:true});on(media,'change',measure);
 const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting&&entries[0].intersectionRatio>.1;sync()},{threshold:[0,.1]});observer.observe(root);
 originalCards.forEach(card=>{const img=card.querySelector('img');img.loading='eager';on(img,'error',()=>card.classList.add('art-failed'));if(img.complete&&!img.naturalWidth)card.classList.add('art-failed')});
 measure();return()=>{if(disposed)return;disposed=true;cancelAnimationFrame(raf);observer.disconnect();events.forEach(fn=>fn());if(dialog.open)dialog.close();tracks.forEach(t=>{t.querySelectorAll('[data-clone]').forEach(c=>c.remove());t.style.removeProperty('transform')});originalCards.forEach(c=>c.removeAttribute('tabindex'));root.classList.remove('is-marquee','is-static')};
}
