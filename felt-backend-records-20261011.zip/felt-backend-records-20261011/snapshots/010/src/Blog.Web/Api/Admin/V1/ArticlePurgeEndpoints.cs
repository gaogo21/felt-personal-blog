using Blog.Web.Application.Administration;
using Blog.Web.Application.Articles;
using Blog.Web.Application.Security;
using Blog.Web.Infrastructure.Administration;

namespace Blog.Web.Api.Admin.V1;

public static class ArticlePurgeEndpoints
{
    public static void MapAdminArticlePurgeEndpoints(this WebApplication app)
    {
        app.MapPost("/api/admin/v1/articles/{id:guid}/purge", async (Guid id, HttpContext context, ArticlePurgeService service) =>
        {
            if (context.Request.Query.Count != 0) throw new ApiFailure(ProblemCode.MALFORMED_REQUEST);
            var input = await AdminJsonBody.Read<ArticlePurgeInput>(context, 1024);
            await AdminApiHosting.WriteMutation(context, await service.PurgeAsync(
                AdminActor.From(context.User, context.TraceIdentifier),
                AdminSecurityService.SessionId(context.User) ?? throw new ApiFailure(ProblemCode.SESSION_REQUIRED),
                id, context.Request.Headers.IfMatch, IdempotencyKey.Require(context.Request.Headers["Idempotency-Key"]),
                input, context.RequestAborted));
        }).RequireAuthorization(AdminSecurityService.Policy);
    }
}
