using Blog.Web.Application;
using Blog.Web.Application.Articles;
using Blog.Web.Application.Home;
using Blog.Web.Infrastructure.Articles;
using Blog.Web.Infrastructure.Columns;
using Blog.Web.Infrastructure.Home;
using Blog.Web.Infrastructure.Media;
using Blog.Web.Infrastructure.Administration;
using Blog.Web.Infrastructure.Security;
using Blog.Web.Api.Admin.V1;
using Blog.Web.Api.Media;
using Blog.Web.Infrastructure;
using Blog.Web.Application.Public;
using Blog.Web.Infrastructure.Public;
using Microsoft.AspNetCore.Diagnostics;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddRazorPages(options =>
{
    options.Conventions.AuthorizeFolder("/Admin", "Admin");
    options.Conventions.AllowAnonymousToPage("/Admin/Login");
});
builder.Services.AddAdminSecurity(builder.Configuration);
builder.Services.AddAdminApiFoundation();
builder.Services.AddMediaPipeline();
builder.Services.AddAdminColumns();
builder.Services.AddScoped<IAdminArticleStore, PostgresAdminArticleStore>();
builder.Services.AddScoped<AdminArticleService>();
builder.Services.AddScoped<IArticlePublicationStore, PostgresArticlePublicationStore>();
builder.Services.AddScoped<ArticlePublicationService>();
builder.Services.AddScoped<IArticleLifecycleStore, PostgresArticleLifecycleStore>();
builder.Services.AddScoped<ArticleLifecycleService>();
builder.Services.AddScoped<IArticlePurgeStore, PostgresArticlePurgeStore>();
builder.Services.AddScoped<ArticlePurgeService>();
builder.Services.AddScoped<IHomeConfigurationStore, PostgresHomeConfigurationStore>();
builder.Services.AddScoped<HomeConfigurationService>();
builder.Services.AddScoped<IPublicHomeQueries, PostgresPublicHomeQueries>();
builder.Services.AddSingleton<Blog.Web.Application.RichText.RichTextSchema>();
builder.Services.AddSingleton<IDraftBodyBoundary>(services => services.GetRequiredService<Blog.Web.Application.RichText.RichTextSchema>());
builder.Services.AddScoped<DraftPreviewService>();
// These framework categories can include request URLs, SQL, or exception details.
// The administration boundary emits a deliberately limited request summary instead.
builder.Logging.AddFilter("Blog.Web.Infrastructure.Administration.AdminApiBoundary", LogLevel.Information);
builder.Logging.AddFilter("Microsoft.AspNetCore.Hosting.Diagnostics", LogLevel.None);
builder.Logging.AddFilter("Microsoft.AspNetCore.Diagnostics", LogLevel.None);
builder.Logging.AddFilter("Microsoft.EntityFrameworkCore", LogLevel.None);
builder.Services.AddSingleton(new LegacyNavigationPolicy(
    builder.Configuration.GetValue("LegacyNavigation:Enabled", true),
    builder.Configuration.GetValue<DateTimeOffset?>("LegacyNavigation:RetireAfterUtc")));
builder.Services.AddScoped<IPublicContentStore, PostgresPublicContentStore>();
builder.Services.AddScoped<PublicContentService>();
builder.Services.AddScoped<IPublicContentQueries>(services =>
    services.GetRequiredService<IConfiguration>()["Blog:Mode"] == "PostgreSql"
        ? services.GetRequiredService<PublicContentService>() : new UnconfiguredContentQueries());
builder.Services.AddSingleton(services => PublicSiteOptions.Read(services.GetRequiredService<IConfiguration>()));
builder.Services.AddSingleton<RuntimePresentation>(services => RuntimeGuard.Validate(services));
var app = builder.Build();
// Resolve before Run: an incomplete production setup must fail before any listener starts.
_ = app.Services.GetRequiredService<RuntimePresentation>();
app.UseStaticFiles(new StaticFileOptions { FileProvider = new ProtectedStaticFiles(app.Environment.WebRootFileProvider) });
app.Use(async (context, next) =>
{
    context.Response.Headers.CacheControl = "private, no-store";
    await next(context);
});
app.UseStatusCodePagesWithReExecute("/errors/{0}");
app.Use(async (context, next) =>
{
    // Re-executing a rejected POST into a GET-only Razor error page can replace
    // its genuine 405 with an antiforgery error. Preserve non-read status codes.
    if ((context.Request.Path.StartsWithSegments("/api/admin") || !HttpMethods.IsGet(context.Request.Method) && !HttpMethods.IsHead(context.Request.Method))
        && context.Features.Get<IStatusCodePagesFeature>() is { } statusPages)
        statusPages.Enabled = false;
    await next(context);
});
app.UseRouting();
app.UseMiddleware<PublicContentBoundary>();
app.UseMiddleware<AdminApiBoundary>();
app.UseMiddleware<AdminRequestBoundary>();
app.UseMiddleware<ProtectedMediaBoundary>();
app.UseAuthentication();
app.UseAuthorization();
app.UseMiddleware<AdminCsrfBoundary>();
app.MapAdminSessionEndpoints();
app.MapAdminArticleEndpoints();
app.MapAdminArticlePublicationEndpoints();
app.MapAdminArticleLifecycleEndpoints();
app.MapAdminArticlePurgeEndpoints();
app.MapAdminMediaEndpoints();
app.MapAdminMediaLibraryEndpoints();
app.MapAdminMediaLifecycleEndpoints();
app.MapAdminColumnEndpoints();
app.MapAdminHomeEndpoints();
app.MapProtectedMedia();
// Fragments are handled in the browser; these are the two real-path aliases
// explicitly named in the migration contract. Targets never use request input.
app.MapMethods("/about", ["GET", "HEAD"], () => Results.Redirect("/#about", permanent: true));
app.MapMethods("/knowledge", ["GET", "HEAD"], () => Results.Redirect("/#columns", permanent: true));
app.MapRazorPages();
app.Run();

public partial class Program;

namespace Blog.Web { public sealed class AssemblyMarker; }
