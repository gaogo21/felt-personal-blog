using System.Text.Json.Serialization;
using Blog.Web.Domain.Persistence;

namespace Blog.Web.Application.Media;

public sealed record MediaStateInput;
public sealed record MediaPurgeInput([property: JsonRequired] Guid ConfirmMediaId);

// Titles are administrator-only display text. URLs/reasons/usages are constructed by the server.
// Body JSON, physical paths, filenames, hashes and user identities never enter the wire projection.
public sealed record MediaReferenceItem(Guid? OwnerId, string Title, string State, string Usage, string Reason, string Url,
    Guid? RevisionId = null, int? RevisionNo = null, int? Slot = null, string? Key = null, bool IsCurrent = false);
public sealed record MediaReferences(IReadOnlyList<MediaReferenceItem> Drafts, IReadOnlyList<MediaReferenceItem> Revisions,
    IReadOnlyList<MediaReferenceItem> Columns, IReadOnlyList<MediaReferenceItem> Gallery, IReadOnlyList<MediaReferenceItem> Design)
{
    public int Total => Drafts.Count + Revisions.Count + Columns.Count + Gallery.Count + Design.Count;
}

public sealed record MediaDeletionStatus(Guid MediaId, string State, long Version, Guid? JobId, string? JobState,
    int AttemptCount, string? ErrorCode, string StatusUrl, bool CanRetry)
{
    public static MediaDeletionStatus From(MediaAsset media, MediaDeletionJob? job) => new(media.Id, media.State.ToString(), media.RowVersion,
        job?.Id, job?.State.ToString(), job?.AttemptCount ?? 0, job?.LastError, Url(media.Id),
        media.State == MediaState.Trashed && job?.State == Blog.Web.Domain.Persistence.JobState.Failed);
    public static string Url(Guid id) => $"/api/admin/v1/media/{id:D}/deletion";
}

// Internal snapshots used to keep EF projection and file identities off the wire.
public sealed record MediaDeletionRead(MediaAsset Media, MediaDeletionJob? Job);
public sealed record MediaDeletionCandidate(Guid JobId, Guid MediaId);
public sealed record MediaReferenceRow(Guid? OwnerId, string Title, short State, short Usage,
    Guid? RevisionId = null, int? RevisionNo = null, int? Slot = null, string? Key = null, bool IsCurrent = false);
public sealed record MediaDeletionLease(Guid JobId, Guid MediaId, Guid Token, DateTimeOffset LeaseUntil,
    long MediaVersion, MediaFileIdentity Identity);

public interface IMediaLifecycleStore
{
    Task<MediaAsset?> ReadTrackedAsync(Guid id, CancellationToken ct);
    Task<MediaDeletionJob?> JobTrackedAsync(Guid mediaId, CancellationToken ct);
    Task<MediaReferences> ReferencesAsync(Guid mediaId, CancellationToken ct);
    // One statement joins the media and job so the returned ETag describes this job status.
    Task<MediaDeletionRead?> ReadDeletionAsync(Guid mediaId, CancellationToken ct);
    Task<MediaDeletionCandidate?> CandidateAsync(DateTimeOffset now, CancellationToken ct);
    void Add(MediaDeletionJob job);
}
