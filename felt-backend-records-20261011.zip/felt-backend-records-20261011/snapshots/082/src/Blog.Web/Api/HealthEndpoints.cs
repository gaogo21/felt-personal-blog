using Blog.Web.Infrastructure.Operations;

namespace Blog.Web.Api;

public static class HealthEndpoints
{
    // Install before static files, authentication and the maintenance admission
    // middleware. Health must never validate/refresh cookies or acquire leases.
    public static IApplicationBuilder UseOperationsHealthEndpoints(this IApplicationBuilder app)
        => app.Use(async (context, next) =>
        {
            var live = context.Request.Path.Equals("/health/live", StringComparison.Ordinal);
            var ready = context.Request.Path.Equals("/health/ready", StringComparison.Ordinal);
            if (!live && !ready) { await next(context); return; }
            context.Response.Headers.CacheControl = "no-store";
            context.Response.Headers["X-Content-Type-Options"] = "nosniff";
            if (!HttpMethods.IsGet(context.Request.Method) && !HttpMethods.IsHead(context.Request.Method))
            {
                context.Response.StatusCode = StatusCodes.Status405MethodNotAllowed;
                context.Response.Headers.Allow = "GET, HEAD";
                return;
            }
            var available = live;
            if (ready)
            {
                try { available = await context.RequestServices.GetRequiredService<IOperationsReadiness>().CheckAsync(context.RequestAborted); }
                catch (Exception error) when (error is not OutOfMemoryException) { available = false; }
            }
            context.Response.StatusCode = available ? StatusCodes.Status200OK : StatusCodes.Status503ServiceUnavailable;
            context.Response.ContentType = "application/json; charset=utf-8";
            var body = live ? "{\"status\":\"live\"}" : available ? "{\"status\":\"ready\"}" : "{\"status\":\"unavailable\"}";
            context.Response.ContentLength = body.Length;
            if (!HttpMethods.IsHead(context.Request.Method)) await context.Response.WriteAsync(body, context.RequestAborted);
        });
}
