using System.Security.Claims;
using Blog.Web.Application.Administration;
using Blog.Web.Infrastructure.Administration;
using Blog.Web.Application.Security;
using Blog.Web.Domain;
using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Persistence;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Blog.Web.Infrastructure.Security;

public static class AdminSecurityHosting
{
    public const string CookieName = "__Host-blog-admin";
    public const string AntiforgeryCookieName = "__Host-blog-csrf";
    public static IServiceCollection AddAdminSecurity(this IServiceCollection services, IConfiguration configuration)
    {
        services.TryAddSingleton(TimeProvider.System);
        services.AddDbContext<BlogDbContext>(options =>
        {
            var connection = configuration.GetConnectionString("BlogDatabase");
            if (string.IsNullOrWhiteSpace(connection)) options.UseNpgsql(o => o.SetPostgresVersion(17, 0));
            else options.UseNpgsql(connection, o => o.SetPostgresVersion(17, 0));
        });
        services.AddIdentityCore<AdminUser>(options =>
        {
            options.Lockout.AllowedForNewUsers = true;
            options.Lockout.MaxFailedAccessAttempts = ContentLimits.LoginFailures;
            options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(ContentLimits.LockoutMinutes);
        }).AddRoles<IdentityRole<Guid>>().AddEntityFrameworkStores<BlogDbContext>().AddDefaultTokenProviders();
        services.AddScoped<IAdminSecurityStore, PostgresAdminSecurityStore>();
        services.AddScoped<AdminSecurityService>(); services.AddScoped<AdminAccountRecovery>(); services.AddScoped<AdminAccountSetup>();
        services.AddSingleton<LoginAttemptLimiter>(); services.AddScoped<AdminCookieEvents>();
        services.AddAuthentication(AdminSecurityService.Scheme).AddCookie(AdminSecurityService.Scheme, options =>
        {
            options.Cookie.Name = CookieName; options.Cookie.HttpOnly = true; options.Cookie.Path = "/";
            options.Cookie.SecurePolicy = CookieSecurePolicy.Always; options.Cookie.SameSite = SameSiteMode.Strict;
            options.Cookie.Domain = null; options.Cookie.IsEssential = true;
            options.ExpireTimeSpan = TimeSpan.FromHours(ContentLimits.AbsoluteSessionHours); options.SlidingExpiration = false;
            options.LoginPath = "/admin/login"; options.EventsType = typeof(AdminCookieEvents);
        });
        services.AddOptions<CookieAuthenticationOptions>(AdminSecurityService.Scheme).Configure<TimeProvider>((options, clock) => options.TimeProvider = clock);
        services.AddAuthorization(options => options.AddPolicy(AdminSecurityService.Policy, p => p.RequireAuthenticatedUser().RequireRole("Admin")));
        services.AddAntiforgery(options =>
        {
            options.HeaderName = "X-CSRF-TOKEN"; options.Cookie.Name = AntiforgeryCookieName;
            options.Cookie.HttpOnly = true; options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
            options.Cookie.SameSite = SameSiteMode.Strict; options.Cookie.Path = "/"; options.Cookie.Domain = null;
        });
        return services;
    }
    public static Task WriteError(HttpContext context, int status, string code)
    {
        if (!Enum.TryParse<ProblemCode>(code, out var parsed) || AdminApiHosting.Status(parsed) != status) throw new InvalidOperationException("INVALID_PROBLEM_CONTRACT");
        return AdminApiHosting.WriteProblem(context, new ApiFailure(parsed));
    }
    public static bool IsAdminPath(PathString path) => path.StartsWithSegments("/admin") || path.StartsWithSegments("/api/admin");
    public static string SafeReturnUrl(string? value)
    {
        if (string.IsNullOrEmpty(value) || value.Length > 2048 || value.Any(char.IsControl) || value.Contains('\\') || value.Contains('%') || value.Contains('#')) return "/admin";
        var path = value.Split('?')[0];
        if (path.Split('/').Any(segment => segment is "." or "..")) return "/admin";
        return (path == "/admin" || path.StartsWith("/admin/", StringComparison.Ordinal)) && path != "/admin/login" ? value : "/admin";
    }
}

public sealed class AdminCookieEvents(AdminSecurityService security) : CookieAuthenticationEvents
{
    public override async Task ValidatePrincipal(CookieValidatePrincipalContext context)
    {
        var id = context.Principal is null ? null : AdminSecurityService.SessionId(context.Principal);
        var session = id is { } sessionId ? await security.ValidateAsync(sessionId, context.HttpContext.RequestAborted) : null;
        if (session is null)
        {
            context.RejectPrincipal(); await context.HttpContext.SignOutAsync(AdminSecurityService.Scheme); return;
        }
        context.ReplacePrincipal(AdminSecurityService.Principal(session));
        context.ShouldRenew = false;
        context.HttpContext.Items[typeof(AdminSessionView)] = session;
    }
    public override Task RedirectToLogin(RedirectContext<CookieAuthenticationOptions> context)
    {
        if (context.Request.Path.StartsWithSegments("/api/admin")) return AdminSecurityHosting.WriteError(context.HttpContext, 401, "SESSION_REQUIRED");
        var target = AdminSecurityHosting.SafeReturnUrl(context.Request.Path + context.Request.QueryString);
        context.Response.Redirect("/admin/login?returnUrl=" + Uri.EscapeDataString(target)); return Task.CompletedTask;
    }
    public override Task RedirectToAccessDenied(RedirectContext<CookieAuthenticationOptions> context) => AdminSecurityHosting.WriteError(context.HttpContext, 403, "FORBIDDEN");
}

public sealed class AdminRequestBoundary(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context)
    {
        var isAdmin = AdminSecurityHosting.IsAdminPath(context.Request.Path);
        if (isAdmin)
        {
            context.Response.Headers.CacheControl = "private, no-store";
            context.Response.Headers["X-Content-Type-Options"] = "nosniff";
            context.Response.Headers["Referrer-Policy"] = "strict-origin-when-cross-origin";
            context.Response.Headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'";
            if (!context.Request.IsHttps) { await AdminSecurityHosting.WriteError(context, 400, "HTTPS_REQUIRED"); return; }

        }
        try { await next(context); }
        catch (SecurityStoreUnavailableException) { if (!context.Response.HasStarted) await AdminSecurityHosting.WriteError(context, 503, "SECURITY_STORE_UNAVAILABLE"); else throw; }
    }
}

public sealed class AdminCsrfBoundary(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context, IAntiforgery antiforgery)
    {
        if (AdminSecurityHosting.IsAdminPath(context.Request.Path))
        {
            if (!HttpMethods.IsGet(context.Request.Method) && !HttpMethods.IsHead(context.Request.Method) && !HttpMethods.IsOptions(context.Request.Method))
            {
                if (!SameOrigin(context.Request)) { await AdminSecurityHosting.WriteError(context, 403, "CSRF_INVALID"); return; }
                // Do not let antiforgery fall back to ReadFormAsync and spool an untrusted multipart upload.
                if (context.GetEndpoint()?.Metadata.GetMetadata<Blog.Web.Api.Admin.V1.StreamingUploadMarker>() is not null
                    && (context.Request.Headers["X-CSRF-TOKEN"].Count != 1 || string.IsNullOrWhiteSpace(context.Request.Headers["X-CSRF-TOKEN"][0])))
                { await AdminSecurityHosting.WriteError(context, 403, "CSRF_INVALID"); return; }
                try { await antiforgery.ValidateRequestAsync(context); }
                catch (AntiforgeryValidationException) { await AdminSecurityHosting.WriteError(context, 403, "CSRF_INVALID"); return; }
            }
        }
        await next(context);
    }
    private static bool SameOrigin(HttpRequest request)
    {
        if (request.Headers["Sec-Fetch-Site"].ToString() == "cross-site") return false;
        if (!request.Headers.TryGetValue("Origin", out var header)) return true; // CSRF remains mandatory.
        if (header.Count != 1 || !Uri.TryCreate(header[0], UriKind.Absolute, out var origin) || origin.UserInfo.Length != 0 || origin.AbsolutePath != "/" || origin.Query.Length != 0 || origin.Fragment.Length != 0) return false;
        return Uri.TryCreate(request.Scheme + "://" + request.Host, UriKind.Absolute, out var local)
            && origin.Scheme == local.Scheme && origin.IdnHost.Equals(local.IdnHost, StringComparison.OrdinalIgnoreCase) && origin.Port == local.Port;
    }
}
