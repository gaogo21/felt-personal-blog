using System.Buffers.Binary;
using System.Diagnostics;
using System.IO.Compression;
using System.Text;

namespace Blog.MediaFileTests;

// All fixtures are synthetic and stay below artifacts/. No uploads, listener or database is used.
internal static class MediaFixtures
{
    public static async Task RunAsync(params string[] args)
    {
        using var stop = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var start = new ProcessStartInfo("/usr/bin/ffmpeg") { UseShellExecute = false, RedirectStandardError = true, RedirectStandardOutput = true };
        foreach (var arg in new[] { "-hide_banner", "-v", "error", "-nostdin", "-y", "-filter_threads", "1", "-filter_complex_threads", "1" }.Concat(args)) start.ArgumentList.Add(arg);
        using var process = Process.Start(start)!;
        using var registration = stop.Token.Register(() => { try { process.Kill(true); } catch (InvalidOperationException) { } });
        var error = process.StandardError.ReadToEndAsync(stop.Token);
        var output = process.StandardOutput.ReadToEndAsync(stop.Token);
        await process.WaitForExitAsync(stop.Token);
        await output;
        if (process.ExitCode != 0) throw new InvalidOperationException("Synthetic fixture generation failed: " + await error);
    }

    public static async Task MakeAsync(string directory)
    {
        await File.WriteAllBytesAsync(Path.Combine(directory, "still.png"), Png(32, 24));
        await RunAsync("-i", Path.Combine(directory, "still.png"), "-frames:v", "1", "-threads", "1", Path.Combine(directory, "still.jpg"));
        await RunAsync("-i", Path.Combine(directory, "still.png"), "-frames:v", "1", "-threads", "1", "-c:v", "libwebp", Path.Combine(directory, "still.webp"));
        await RunAsync("-f", "lavfi", "-i", "testsrc2=s=32x24:r=2", "-t", "1", "-c:v", "libx264", "-threads", "1", "-pix_fmt", "yuv420p", Path.Combine(directory, "silent.mp4"));
        await RunAsync("-f", "lavfi", "-i", "testsrc2=s=32x24:r=2", "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=44100", "-t", "1", "-c:v", "libx264", "-c:a", "aac", "-threads", "1", "-pix_fmt", "yuv420p", Path.Combine(directory, "audio.mp4"));
        await RunAsync("-f", "lavfi", "-i", "testsrc2=s=32x24:r=2", "-t", "1", "-c:v", "mpeg4", "-threads", "1", Path.Combine(directory, "wrong-codec.mp4"));
        await RunAsync("-f", "lavfi", "-i", "testsrc2=s=32x24:r=2", "-t", "1", "-c:v", "apng", "-threads", "1", "-f", "apng", Path.Combine(directory, "animated.png"));
        await RunAsync("-f", "lavfi", "-i", "testsrc2=s=32x24:r=2", "-t", "1", "-c:v", "libwebp_anim", "-threads", "1", Path.Combine(directory, "animated.webp"));
    }

    public static byte[] Png(int width, int height)
    {
        using var png = new MemoryStream();
        png.Write(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 });
        var ihdr = new byte[13];
        BinaryPrimitives.WriteInt32BigEndian(ihdr, width);
        BinaryPrimitives.WriteInt32BigEndian(ihdr.AsSpan(4), height);
        ihdr[8] = 8; ihdr[9] = 2;
        png.Write(Chunk("IHDR", ihdr));
        using var pixels = new MemoryStream();
        using (var zlib = new ZLibStream(pixels, CompressionLevel.Fastest, true))
        {
            var row = new byte[1 + 3 * width];
            for (var x = 1; x < row.Length; x += 3) { row[x] = 18; row[x + 1] = 40; row[x + 2] = 80; }
            for (var y = 0; y < height; y++) zlib.Write(row);
        }
        png.Write(Chunk("IDAT", pixels.ToArray()));
        png.Write(Chunk("IEND", []));
        return png.ToArray();
    }

    public static byte[] Chunk(string name, byte[] data)
    {
        var chunk = new byte[data.Length + 12];
        BinaryPrimitives.WriteInt32BigEndian(chunk, data.Length);
        Encoding.ASCII.GetBytes(name).CopyTo(chunk, 4);
        data.CopyTo(chunk, 8);
        var crc = uint.MaxValue;
        foreach (var value in chunk.AsSpan(4, data.Length + 4))
        {
            crc ^= value;
            for (var bit = 0; bit < 8; bit++) crc = crc >> 1 ^ (0xedb88320u & (uint)-(int)(crc & 1));
        }
        BinaryPrimitives.WriteUInt32BigEndian(chunk.AsSpan(data.Length + 8), ~crc);
        return chunk;
    }

    public static byte[] JpegSegment(byte[] jpeg, byte marker, byte[] data)
    {
        var output = new byte[jpeg.Length + data.Length + 4];
        jpeg.AsSpan(0, 2).CopyTo(output);
        output[2] = 0xff; output[3] = marker;
        BinaryPrimitives.WriteUInt16BigEndian(output.AsSpan(4), checked((ushort)(data.Length + 2)));
        data.CopyTo(output, 6); jpeg.AsSpan(2).CopyTo(output.AsSpan(data.Length + 6));
        return output;
    }

    public static byte[] ExifWithOrientationAndGps()
    {
        var exif = new byte[98]; "Exif\0\0"u8.CopyTo(exif);
        var tiff = exif.AsSpan(6); "II"u8.CopyTo(tiff);
        BinaryPrimitives.WriteUInt16LittleEndian(tiff[2..], 42);
        BinaryPrimitives.WriteUInt32LittleEndian(tiff[4..], 8);
        BinaryPrimitives.WriteUInt16LittleEndian(tiff[8..], 2);
        BinaryPrimitives.WriteUInt16LittleEndian(tiff[10..], 0x0112); // Rotate 90 degrees clockwise for display.
        BinaryPrimitives.WriteUInt16LittleEndian(tiff[12..], 3);
        BinaryPrimitives.WriteUInt32LittleEndian(tiff[14..], 1);
        BinaryPrimitives.WriteUInt16LittleEndian(tiff[18..], 6);
        BinaryPrimitives.WriteUInt16LittleEndian(tiff[22..], 0x8825); // GPS IFD pointer.
        BinaryPrimitives.WriteUInt16LittleEndian(tiff[24..], 4);
        BinaryPrimitives.WriteUInt32LittleEndian(tiff[26..], 1);
        BinaryPrimitives.WriteUInt32LittleEndian(tiff[30..], 38);
        BinaryPrimitives.WriteUInt16LittleEndian(tiff[38..], 2);
        BinaryPrimitives.WriteUInt16LittleEndian(tiff[40..], 1); // GPSLatitudeRef = N.
        BinaryPrimitives.WriteUInt16LittleEndian(tiff[42..], 2);
        BinaryPrimitives.WriteUInt32LittleEndian(tiff[44..], 2); tiff[48] = (byte)'N';
        BinaryPrimitives.WriteUInt16LittleEndian(tiff[52..], 2); // GPSLatitude = 1 degree, 2 minutes, 3 seconds.
        BinaryPrimitives.WriteUInt16LittleEndian(tiff[54..], 5);
        BinaryPrimitives.WriteUInt32LittleEndian(tiff[56..], 3);
        BinaryPrimitives.WriteUInt32LittleEndian(tiff[60..], 68);
        for (var i = 0; i < 3; i++)
        {
            BinaryPrimitives.WriteInt32LittleEndian(tiff[(68 + i * 8)..], i + 1);
            BinaryPrimitives.WriteUInt32LittleEndian(tiff[(72 + i * 8)..], 1);
        }
        return exif;
    }
}
