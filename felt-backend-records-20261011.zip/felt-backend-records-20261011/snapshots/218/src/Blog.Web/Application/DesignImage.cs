diff --git a/src/Blog.Web/Application/DesignImage.cs b/src/Blog.Web/Application/DesignImage.cs
index 40b97c8..2ce8a6f 100644
--- a/src/Blog.Web/Application/DesignImage.cs
+++ b/src/Blog.Web/Application/DesignImage.cs
@@ -1,2 +1,3 @@
 namespace Blog.Web.Application;
-public sealed record DesignImage(string Src, string Alt, string Title, string Author, string Provider, string Source, string License, string LicenseUrl);
+public sealed record DesignImage(string Src, string Alt, string Title, string Author, string Provider, string Source, string License, string LicenseUrl,
+    int Width = 1240, int Height = 800);
diff --git a/src/Blog.Web/Application/PublicContent.cs b/src/Blog.Web/Application/PublicContent.cs
index 8ff090e..f25c67c 100644
--- a/src/Blog.Web/Application/PublicContent.cs
+++ b/src/Blog.Web/Application/PublicContent.cs
@@ -2,7 +2,7 @@ namespace Blog.Web.Application;
 
 public enum ContentSourceKind { Unconfigured, TestFixture, PostgreSql }
 
-// A read boundary only. Publication, persistence and authentication come in later gates.
+// Public reads are supplied by the production snapshot facade or explicit test fixtures.
 public interface IPublicContentQueries
 {
     ContentSourceKind SourceKind { get; }
@@ -17,9 +17,10 @@ public sealed record ColumnSummary(string Slug, string Name, string Introduction
 public sealed record HomeContent(string AboutText, IReadOnlyList<ArticleSummary> Featured, IReadOnlyList<ColumnSummary> Columns, IReadOnlyList<DesignImage> Gallery);
 public sealed record ArticlePage(IReadOnlyList<ArticleSummary> Items, int Total, string? ColumnName);
 public sealed record ColumnContent(ColumnSummary Column, IReadOnlyList<ArticleSummary> Articles);
-// F03 consumes a controlled presentation model. The F09 JSON schema/publisher will
-// project validated published content into this model; no raw HTML is accepted.
+// Encoded fixture blocks and schema-validated publication documents share this
+// controlled presentation model. No stored or caller-supplied raw HTML is accepted.
 public sealed record ArticleContent(ArticleSummary Article, IReadOnlyList<ReadingBlock> Blocks,
     ReadingImage? Cover = null, DateTimeOffset? RevisedAt = null,
-    ArticleSibling? Previous = null, ArticleSibling? Next = null);
+    ArticleSibling? Previous = null, ArticleSibling? Next = null,
+    RichText.RichTextDocument? PublishedDocument = null);
 public sealed record ArticleSibling(string Slug, string Title, string ColumnSlug);
diff --git a/src/Blog.Web/Application/ReadingDocument.cs b/src/Blog.Web/Application/ReadingDocument.cs
index a0bcb82..dcd0669 100644
--- a/src/Blog.Web/Application/ReadingDocument.cs
+++ b/src/Blog.Web/Application/ReadingDocument.cs
@@ -23,7 +23,8 @@ public sealed record ReadingList(IReadOnlyList<string> Items, bool Ordered = fal
 public sealed record ReadingTable(IReadOnlyList<IReadOnlyList<string>> Rows, bool HasHeader = true) : ReadingBlock;
 public sealed record ReadingImageBlock(ReadingImage Image) : ReadingBlock;
 public sealed record ReadingVideo(string Src, int Width, int Height, string Caption, string? Poster = null) : ReadingBlock;
-public sealed record ReadingImage(string Src, string Alt, int Width, int Height, string Caption = "", string Credit = "", string? SourceUrl = null);
+public sealed record ReadingImage(string Src, string Alt, int Width, int Height, string Caption = "", string Credit = "", string? SourceUrl = null,
+    string LicenseName = "", string? LicenseUrl = null);
 public enum CodeLanguage { Plaintext, Javascript, Typescript, Csharp, Sql, Json, Bash, Html, Css, Python }
 public sealed record TocEntry(string Id, int Level, string Text);
 
@@ -70,6 +71,12 @@ public sealed record ReadingPresentation(IReadOnlyList<TocEntry> Toc, string Pla
                 throw new InvalidOperationException("Reading neighbors must belong to this column and never loop to the same article.");
         if (article.RevisedAt is not null && article.RevisedAt < article.Article.FirstPublishedAt)
             throw new InvalidOperationException("Revision time cannot precede first publication.");
+        if (article.PublishedDocument is { } document)
+        {
+            if (article.Blocks.Count != 0 || article.Article.ReadingMinutes != document.ReadingMinutes)
+                throw new InvalidOperationException("Published presentation must have one validated body and matching derived reading time.");
+            return new ReadingPresentation(document.Toc, document.PlainText, document.ReadingMinutes);
+        }
         var text = string.Join("\n", plain).Normalize(NormalizationForm.FormC);
         return new ReadingPresentation(headings, text, ReadingTime.FromPlainText(text));
     }
@@ -79,8 +86,9 @@ public sealed record ReadingPresentation(IReadOnlyList<TocEntry> Toc, string Pla
         ValidateMediaPath(image.Src);
         if (string.IsNullOrWhiteSpace(image.Alt) || image.Width < 1 || image.Height < 1)
             throw new InvalidOperationException("Reading images need alt text and dimensions.");
-        if (image.SourceUrl is not null && (!Uri.TryCreate(image.SourceUrl, UriKind.Absolute, out var url) || url.Scheme != "https" || url.UserInfo.Length != 0 || image.SourceUrl.Any(char.IsControl) || image.SourceUrl.Contains('\\')))
-            throw new InvalidOperationException("Image source credit must be a plain HTTPS URL.");
+        foreach (var source in new[] { image.SourceUrl, image.LicenseUrl })
+            if (source is not null && (!Uri.TryCreate(source, UriKind.Absolute, out var url) || url.Scheme != "https" || url.UserInfo.Length != 0 || source.Any(char.IsControl) || source.Contains('\\')))
+                throw new InvalidOperationException("Image source and license must be plain HTTPS URLs.");
     }
     private static void ValidateMediaPath(string path)
     {
diff --git a/src/Blog.Web/Infrastructure/PublicSiteOptions.cs b/src/Blog.Web/Infrastructure/PublicSiteOptions.cs
new file mode 100644
index 0000000..1ae433a
--- /dev/null
+++ b/src/Blog.Web/Infrastructure/PublicSiteOptions.cs
@@ -0,0 +1,27 @@
+namespace Blog.Web.Infrastructure;
+
+// Only an explicitly supplied deployment origin may produce absolute SEO URLs.
+// Request Host/forwarded headers and fixture domains never supply this value.
+public sealed record PublicSiteOptions(string? Origin)
+{
+    public static PublicSiteOptions Read(IConfiguration configuration)
+    {
+        var value = configuration["Blog:PublicOrigin"];
+        if (string.IsNullOrEmpty(value)) return new((string?)null);
+        if (value.Any(char.IsControl) || value.Contains('\\') || value != value.Trim()
+            || !Uri.TryCreate(value, UriKind.Absolute, out var origin)
+            || origin.Scheme != "https" || origin.Host.Length == 0 || origin.UserInfo.Length != 0
+            || origin.AbsolutePath != "/" || origin.Query.Length != 0 || origin.Fragment.Length != 0)
+            throw new InvalidOperationException("PUBLIC_ORIGIN_INVALID");
+        return new(origin.GetLeftPart(UriPartial.Authority));
+    }
+
+    public string? Canonical(string path)
+    {
+        if (Origin is null) return null;
+        if (!path.StartsWith('/') || path.StartsWith("//", StringComparison.Ordinal)
+            || path.Any(char.IsControl) || path.Contains('\\') || path.Contains('#'))
+            throw new InvalidOperationException("CANONICAL_PATH_INVALID");
+        return Origin + path;
+    }
+}
