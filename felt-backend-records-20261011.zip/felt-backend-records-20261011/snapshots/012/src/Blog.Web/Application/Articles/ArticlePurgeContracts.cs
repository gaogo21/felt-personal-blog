using System.Text.Json.Serialization;

namespace Blog.Web.Application.Articles;

public sealed record ArticlePurgeInput([property: JsonRequired] string ConfirmSlug);

// Internal metadata only: every retained draft/revision cover, image, video and
// poster participates in the same lock set as concurrent media lifecycle work.
public sealed record ArticlePurgeDependencies(IReadOnlyList<Guid> ColumnIds, IReadOnlyList<Guid> MediaIds,
    int RevisionCount, bool HasPublicMembership);

public interface IArticlePurgeStore
{
    // These methods share the enclosing administrator mutation transaction.
    Task<ArticleRead?> ReadAsync(Guid id, CancellationToken ct);
    Task<ArticlePurgeDependencies> DependenciesAsync(Guid articleId, CancellationToken ct);
    // Flush the staged tombstone/base-pointer changes before guarded child deletes.
    // Also invalidate old article receipts without deleting their keys/hashes.
    // No MediaAsset row or physical file is modified by this operation.
    Task DeleteContentAsync(Guid articleId, int expectedRevisionCount, CancellationToken ct);
}
