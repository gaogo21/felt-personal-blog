using System.Text.Json;
using Blog.Web.Application.Administration;
using Blog.Web.Domain;
using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Media;

namespace Blog.Web.Application.Media;
public sealed class MediaUploadService(IMediaPersistence store, PrivateMediaStorage files, TimeProvider clock, IConfiguration config)
{
    public const string Scope = "media.upload";
    public Task<UploadAdmission> BeginAsync(AdminActor actor, Guid key, UploadManifest manifest, CancellationToken ct)
    {
        var hash = CanonicalRequest.Hash(Scope, "", JsonSerializer.SerializeToElement(manifest, ApiJson.Options));
        return store.ExecuteAsync(async (tx, token) =>
        {
            var now = clock.GetUtcNow(); var existing = await tx.KeyAsync(actor.UserId, key, token);
            if (existing is not null && existing.ExpiresAt > now)
            {
                if (existing.RequestHash != hash) throw new ApiFailure(ProblemCode.IDEMPOTENCY_CONFLICT);
                if (existing.Status == IdempotencyState.Completed)
                {
                    if (existing.ResponseCode != 202)
                    {
                        using var failure = JsonDocument.Parse(existing.ResponseJson ?? "{}");
                        var code = failure.RootElement.TryGetProperty("code", out var storedCode)
                            && Enum.TryParse<ProblemCode>(storedCode.GetString(), out var parsed)
                            && parsed is ProblemCode.MALFORMED_REQUEST or ProblemCode.VALIDATION_FAILED or ProblemCode.FILE_TOO_LARGE or ProblemCode.REQUEST_TOO_LARGE or ProblemCode.MEDIA_STORAGE_UNAVAILABLE
                                ? parsed : ProblemCode.VALIDATION_FAILED;
                        throw new ApiFailure(code);
                    }
                    var response = JsonSerializer.Deserialize<MutationResponse>(existing.ResponseJson!, ApiJson.Options)!; response.Validate();
                    return new UploadAdmission(response.Body!.Value.GetProperty("mediaId").GetGuid(), Guid.Empty, true, response);
                }
                var reservations = await tx.ReservationsAsync(token);
                var prior = reservations.SingleOrDefault(x => x.ActorUserId == actor.UserId && x.IdempotencyKey == key);
                if (prior is null || prior.UploadLeaseUntil > now) throw new ApiFailure(ProblemCode.IDEMPOTENCY_IN_PROGRESS);
                var media = await tx.MediaAsync(prior.MediaId, token);
                if (media?.State != MediaState.Uploading) throw new ApiFailure(ProblemCode.IDEMPOTENCY_IN_PROGRESS);
                EnsureWritable(); EnsureCapacity(reservations.Sum(x => x.ReservedBytes), 0);
                var activeUploads = reservations.Count(x => x.UploadLeaseUntil > now && x.MediaId != prior.MediaId);
                var pendingJobs = (await tx.JobsAsync(token)).Count(x => x.State == JobState.Pending);
                if (activeUploads >= ContentLimits.ConcurrentUploads || pendingJobs + activeUploads >= ContentLimits.PendingJobs)
                    throw new ApiFailure(ProblemCode.RATE_LIMITED);
                prior.UploadToken = Guid.NewGuid(); prior.UploadLeaseUntil = Min(now.AddSeconds(MediaStorageOptions.UploadLeaseSeconds), prior.ExpiresAt);
                return new UploadAdmission(prior.MediaId, prior.UploadToken, false, null);
            }
            EnsureWritable();
            var all = (await tx.ReservationsAsync(token)).ToList(); var jobs = await tx.JobsAsync(token);
            var expiredReservation = all.SingleOrDefault(x => x.ActorUserId == actor.UserId && x.IdempotencyKey == key);
            if (expiredReservation is not null)
            {
                // An old physical copy remains charged by UsedBytes. Do not take a key away from an active processing task.
                if (expiredReservation.ExpiresAt > now || jobs.Any(x => x.MediaId == expiredReservation.MediaId && x.State is JobState.Pending or JobState.Leased))
                    throw new ApiFailure(ProblemCode.IDEMPOTENCY_IN_PROGRESS);
                var oldMedia = await tx.MediaAsync(expiredReservation.MediaId, token);
                if (oldMedia?.State == MediaState.Uploading) { oldMedia.State = MediaState.Rejected; oldMedia.ErrorCode = "MEDIA_UPLOAD_EXPIRED"; oldMedia.RowVersion++; }
                tx.Remove(expiredReservation); all.Remove(expiredReservation);
            }
            if (all.Count(x => x.UploadLeaseUntil > now) >= ContentLimits.ConcurrentUploads || jobs.Count(x => x.State == JobState.Pending) + all.Count(x => x.UploadLeaseUntil > now) >= ContentLimits.PendingJobs)
                throw new ApiFailure(ProblemCode.RATE_LIMITED);
            EnsureCapacity(all.Sum(x => x.ReservedBytes), manifest.Reservation);
            if (existing is not null) tx.Remove(existing);
            var id = Guid.NewGuid(); var lease = Guid.NewGuid();
            tx.Add(new MediaAsset { Id = id, StorageKey = files.FinalKey(id, lease, manifest.MimeType), Kind = manifest.Kind, State = MediaState.Uploading,
                Origin = "user_upload", OriginalFileName = manifest.OriginalFileName, MimeType = manifest.MimeType, CreatedAt = now, CreatedBy = actor.UserId });
            tx.Add(new MediaUploadReservation { MediaId = id, ActorUserId = actor.UserId, IdempotencyKey = key, RequestHash = hash,
                DeclaredBytes = manifest.ByteSize, DeclaredSha256 = manifest.Sha256, ReservedBytes = manifest.Reservation,
                UploadToken = lease, UploadLeaseUntil = now.AddSeconds(MediaStorageOptions.UploadLeaseSeconds), CreatedAt = now, ExpiresAt = now.AddHours(ContentLimits.IdempotencyHours) });
            tx.Add(new IdempotencyRecord { ActorUserId = actor.UserId, Scope = Scope, Key = key, RequestHash = hash, Status = IdempotencyState.InProgress,
                CreatedAt = now, ExpiresAt = now.AddHours(ContentLimits.IdempotencyHours) });
            return new UploadAdmission(id, lease, false, null);
        }, ct);
    }
    private void EnsureWritable() { if (config.GetValue<bool>("Maintenance:ReadOnly")) throw new ApiFailure(ProblemCode.MAINTENANCE_READ_ONLY); }
    private void EnsureCapacity(long reserved, long addition)
    {
        // Conservative: every physical private byte (including failed/orphan copies) plus outstanding reservations.
        // Sample under the same admission lock that releases reservations; growing in-flight files retain their full bound.
        var used = files.UsedBytes();
        if (reserved < 0 || addition < 0 || used > files.Quota || reserved > files.Quota - used || addition > files.Quota - used - reserved)
            throw new ApiFailure(ProblemCode.FILE_TOO_LARGE);
    }
    public Task<MutationResponse> CompleteAsync(AdminActor actor, UploadAdmission admission, CancellationToken ct)
        => store.ExecuteAsync(async (tx, token) =>
        {
            var now = clock.GetUtcNow(); var reservation = await tx.ReservationAsync(admission.MediaId, token);
            var media = await tx.MediaAsync(admission.MediaId, token);
            if (reservation is null || media is null || media.State != MediaState.Uploading || reservation.ActorUserId != actor.UserId || reservation.UploadToken != admission.Token || reservation.UploadLeaseUntil <= now)
                throw new ApiFailure(ProblemCode.STATE_CONFLICT);
            var key = await tx.KeyAsync(actor.UserId, reservation.IdempotencyKey, token);
            if (key is null || key.Status != IdempotencyState.InProgress || key.ExpiresAt <= now) throw new ApiFailure(ProblemCode.IDEMPOTENCY_IN_PROGRESS);
            media.UploadSha256 = reservation.DeclaredSha256; media.State = MediaState.Processing; media.RowVersion++;
            reservation.UploadLeaseUntil = reservation.CreatedAt; // no active upload slot; reservation remains through processing
            tx.Add(new MediaProcessingJob { Id = Guid.NewGuid(), MediaId = media.Id, State = JobState.Pending, CreatedAt = now, UpdatedAt = now });
            var response = MutationResponse.Json(202, new { mediaId = media.Id, state = "Processing", statusUrl = "/api/admin/v1/media/" + media.Id.ToString("D") });
            key.Status = IdempotencyState.Completed; key.ResponseCode = 202; key.ResponseJson = JsonSerializer.Serialize(response, ApiJson.Options);
            tx.Add(new AuditDescription(AuditAction.MediaUploaded, AuditEntity.Media, media.Id, 1, media.RowVersion, new(ByteCount: reservation.DeclaredBytes, FromState: AuditState.Uploading, ToState: AuditState.Processing)).ToRecord(actor, now));
            return response;
        }, ct);
    public Task FailAsync(AdminActor actor, UploadAdmission admission, string code, CancellationToken ct, ProblemCode responseCode = ProblemCode.VALIDATION_FAILED)
        => store.ExecuteAsync(async (tx, token) =>
        {
            var reservation = await tx.ReservationAsync(admission.MediaId, token); var media = await tx.MediaAsync(admission.MediaId, token);
            // A delayed old receiver cannot reject or release a newer token's upload.
            if (reservation is null || media?.State != MediaState.Uploading || reservation.UploadToken != admission.Token || reservation.ActorUserId != actor.UserId) return false;
            media.State = MediaState.Rejected; media.ErrorCode = code; media.RowVersion++;
            var key = await tx.KeyAsync(actor.UserId, reservation.IdempotencyKey, token);
            if (key is not null)
            {
                key.Status = IdempotencyState.Completed;
                key.ResponseCode = Blog.Web.Infrastructure.Administration.AdminApiHosting.Status(responseCode);
                key.ResponseJson = JsonSerializer.Serialize(new { code = responseCode.ToString() }, ApiJson.Options);
            }
            reservation.UploadLeaseUntil = reservation.CreatedAt;
            // Keep quota charged until the failed private bytes are removed by the bounded orphan sweep.
            return true;
        }, ct);
    public Task CleanupRejectedAsync(AdminActor actor, UploadAdmission admission, CancellationToken ct)
        => store.ExecuteAsync(async (tx, token) =>
        {
            var media = await tx.MediaAsync(admission.MediaId, token); var reservation = await tx.ReservationAsync(admission.MediaId, token);
            if (media?.State != MediaState.Rejected || reservation is null || reservation.ActorUserId != actor.UserId || reservation.UploadToken != admission.Token
                || (await tx.JobsAsync(token)).Any(x => x.MediaId == media.Id && x.State is JobState.Pending or JobState.Leased) || await tx.HasReferencesAsync(media.Id, token)) return false;
            try { files.Remove(files.UploadPath(media.Id, admission.Token)); }
            catch (IOException) { return false; }
            tx.Remove(reservation); return true;
        }, ct);
    public async Task<MediaStatus> ReadAsync(Guid id, CancellationToken ct)
    {
        var media = await store.ReadAsync(id, ct) ?? throw new ApiFailure(ProblemCode.NOT_FOUND);
        return new(media.Id, media.State.ToString(), media.ErrorCode, media.RowVersion,
            new { media.OriginalFileName, media.MimeType, media.ByteSize, media.UploadSha256, media.Sha256, media.Width, media.Height, media.DurationMs });
    }
    private static DateTimeOffset Min(DateTimeOffset a, DateTimeOffset b) => a < b ? a : b;
}
