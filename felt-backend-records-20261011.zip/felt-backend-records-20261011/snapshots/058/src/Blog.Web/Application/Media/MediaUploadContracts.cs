using System.Text;
using System.Text.RegularExpressions;
using Blog.Web.Application.Administration;
using Blog.Web.Domain;
using Blog.Web.Domain.Persistence;

namespace Blog.Web.Application.Media;
public sealed record UploadManifest(string OriginalFileName, string MimeType, MediaKind Kind, long ByteSize, string Sha256)
{
    public long Limit => Kind == MediaKind.Image ? ContentLimits.ImageBytes : ContentLimits.VideoBytes;
    public long Reservation => checked(ByteSize + Limit);
    public static UploadManifest Parse(string name, string mime, string bytes, string hash)
    {
        // The display name never becomes a disk path. Reject path/control syntax instead of silently normalizing it.
        try { name = name.Normalize(NormalizationForm.FormC); }
        catch (ArgumentException) { throw Invalid("file"); }
        if (name.EnumerateRunes().Count() is < 1 or > 255 || name.Any(char.IsControl) || name.IndexOfAny(['/', '\\']) >= 0) throw Invalid("file");
        var extension = Path.GetExtension(name).ToLowerInvariant();
        var expected = extension switch { ".jpg" or ".jpeg" => "image/jpeg", ".png" => "image/png", ".webp" => "image/webp", ".mp4" => "video/mp4", _ => throw new ApiFailure(ProblemCode.MEDIA_TYPE_UNSUPPORTED) };
        if (mime != expected) throw new ApiFailure(ProblemCode.MEDIA_TYPE_UNSUPPORTED);
        var kind = mime == "video/mp4" ? MediaKind.Video : MediaKind.Image;
        if (!Regex.IsMatch(bytes, "\\A[1-9][0-9]{0,9}\\z") || !long.TryParse(bytes, out var size)) throw Invalid("byteSize");
        if (size > (kind == MediaKind.Image ? ContentLimits.ImageBytes : ContentLimits.VideoBytes)) throw new ApiFailure(ProblemCode.FILE_TOO_LARGE);
        if (!Regex.IsMatch(hash, "\\A[a-f0-9]{64}\\z")) throw Invalid("sha256");
        return new(name, mime, kind, size, hash);
    }
    private static ApiFailure Invalid(string field) => new(ProblemCode.VALIDATION_FAILED, new Dictionary<string, FieldIssue[]> { [field] = [FieldIssue.Invalid] });
}
public sealed record UploadAdmission(Guid MediaId, Guid Token, bool Replay, MutationResponse? Response);
public sealed record MediaStatus(Guid Id, string State, string? ErrorCode, long Version, object Metadata);
public sealed record MediaLease(Guid JobId, Guid MediaId, Guid Token, DateTimeOffset LeaseUntil, string InputPath, string OutputPath, string StorageKey, MediaKind Kind, string MimeType);
