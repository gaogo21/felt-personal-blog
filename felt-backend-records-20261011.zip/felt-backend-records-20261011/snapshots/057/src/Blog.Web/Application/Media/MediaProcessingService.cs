using System.Security.Cryptography;
using Blog.Web.Domain;
using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Media;

namespace Blog.Web.Application.Media;
public sealed class MediaProcessingService(IMediaPersistence store, PrivateMediaStorage files, IMediaFileProcessor processor, TimeProvider clock)
{
    public Task<MediaLease?> ClaimAsync(CancellationToken ct) => store.ExecuteAsync(async (tx, token) =>
    {
        var now = clock.GetUtcNow(); var jobs = await tx.JobsAsync(token);
        if (jobs.Any(x => x.State == JobState.Leased && x.LeaseUntil > now)) return null;
        // Reclaim the one persisted expired Leased row before selecting Pending work. Its unique
        // database slot must be reused/released even if another row has an earlier CreatedAt.
        var job = jobs.Where(x => x.State == JobState.Pending || x.State == JobState.Leased && x.LeaseUntil <= now)
            .OrderBy(x => x.State == JobState.Leased ? 0 : 1).ThenBy(x => x.CreatedAt).ThenBy(x => x.MediaId).FirstOrDefault();
        if (job is null) return null;
        var media = await tx.MediaAsync(job.MediaId, token); var reservation = await tx.ReservationAsync(job.MediaId, token);
        if (media?.State != MediaState.Processing || reservation is null || job.AttemptCount >= ContentLimits.AutomaticRetries + 1)
        {
            job.State = JobState.Failed; job.LeaseToken = null; job.LeaseUntil = null; job.LastError = "MEDIA_RETRY_EXHAUSTED"; job.UpdatedAt = now;
            if (media?.State == MediaState.Processing) { media.State = MediaState.Rejected; media.ErrorCode = job.LastError; media.RowVersion++; }
            return null;
        }
        // Reconcile an expired attempt before allocating its replacement copy. The locked Processing row
        // proves this path is not a committed Ready object. A late worker cannot commit the new token.
        if (job.LeaseToken is { } previousToken)
        {
            files.Remove(files.WorkPath(media.Id, previousToken));
            files.Remove(files.WorkPath(media.Id, previousToken) + ".stage");
            files.Remove(files.Resolve(files.FinalKey(media.Id, previousToken, media.MimeType)));
        }
        var lease = Guid.NewGuid(); var until = now.AddSeconds(MediaStorageOptions.ProcessingLeaseSeconds);
        job.State = JobState.Leased; job.AttemptCount++; job.LeaseToken = lease; job.LeaseUntil = until; job.UpdatedAt = now;
        media.StorageKey = files.FinalKey(media.Id, lease, media.MimeType); media.RowVersion++;
        return new MediaLease(job.Id, media.Id, lease, until, files.UploadPath(media.Id, reservation.UploadToken), files.WorkPath(media.Id, lease), media.StorageKey, media.Kind, media.MimeType);
    }, ct);
    public async Task<bool> RunOneAsync(CancellationToken ct)
    {
        var lease = await ClaimAsync(ct); if (lease is null) return false;
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct); timeout.CancelAfter(TimeSpan.FromSeconds(ContentLimits.ProcessingTimeoutSeconds));
        try
        {
            var result = await processor.ProcessAsync(new(lease.InputPath, lease.OutputPath, lease.Kind, lease.MimeType), timeout.Token).WaitAsync(timeout.Token);
            if (clock.GetUtcNow() >= lease.LeaseUntil) throw new MediaProcessingFailure("MEDIA_LEASE_EXPIRED", true);
            await VerifyOutputAsync(lease, result, timeout.Token);
            files.Commit(lease.OutputPath, lease.StorageKey);
            var accepted = await store.ExecuteAsync(async (tx, token) =>
            {
                var media = await tx.MediaAsync(lease.MediaId, token); var job = (await tx.JobsAsync(token)).SingleOrDefault(x => x.Id == lease.JobId);
                if (media?.State != MediaState.Processing || media.StorageKey != lease.StorageKey || job?.State != JobState.Leased || job.LeaseToken != lease.Token || job.LeaseUntil <= clock.GetUtcNow()) return false;
                if (lease.Kind == MediaKind.Video && media.UploadSha256 != result.Sha256) throw new MediaProcessingFailure("MEDIA_VIDEO_BYTES_CHANGED", false);
                media.MimeType = result.MimeType; media.ByteSize = result.ByteSize; media.Sha256 = result.Sha256; media.Width = result.Width; media.Height = result.Height; media.DurationMs = result.DurationMs;
                media.State = MediaState.Ready; media.ErrorCode = null; media.RowVersion++;
                job.State = JobState.Succeeded; job.LeaseToken = null; job.LeaseUntil = null; job.LastError = null; job.UpdatedAt = clock.GetUtcNow();
                return true;
            }, timeout.Token);
            if (accepted) await CleanupReadyAsync(lease, ct);
        }
        catch (OperationCanceledException)
        {
            await RejectAttemptAsync(lease, "MEDIA_PROCESSING_TIMEOUT", true, CancellationToken.None);
        }
        catch (MediaProcessingFailure failure)
        {
            await RejectAttemptAsync(lease, failure.Code, failure.IsTransient, CancellationToken.None);
        }
        catch (IOException)
        {
            await RejectAttemptAsync(lease, "MEDIA_STORAGE_UNAVAILABLE", true, CancellationToken.None);
        }
        // Database errors intentionally bubble: a lost commit reply cannot safely be treated as a rejected file.
        // A private final object is never public without a committed Ready row; a later lease/sweep reconciles it.
        return true;
    }
    private static async Task VerifyOutputAsync(MediaLease lease, ProcessedMedia result, CancellationToken ct)
    {
        var info = new FileInfo(lease.OutputPath); PrivateMediaStorage.NoLinks(info.FullName);
        if (!info.Exists || info.Length != result.ByteSize || result.ByteSize <= 0 || result.MimeType != lease.MimeType || result.Width <= 0 || result.Height <= 0
            || (lease.Kind == MediaKind.Image && (result.ByteSize > ContentLimits.ImageBytes || result.Width > ContentLimits.ImageLongestEdge || result.Height > ContentLimits.ImageLongestEdge || (long)result.Width * result.Height > ContentLimits.ImagePixels || result.DurationMs is not null))
            || (lease.Kind == MediaKind.Video && (result.ByteSize > ContentLimits.VideoBytes || (long)result.Width * result.Height > ContentLimits.VideoFramePixels || result.DurationMs is null or <= 0 or > ContentLimits.VideoSeconds * 1000)))
            throw new MediaProcessingFailure("MEDIA_OUTPUT_INVALID", false);
        await using var stream = File.OpenRead(lease.OutputPath);
        if (Convert.ToHexStringLower(await SHA256.HashDataAsync(stream, ct)) != result.Sha256) throw new MediaProcessingFailure("MEDIA_OUTPUT_INVALID", false);
    }
    public Task RejectAttemptAsync(MediaLease lease, string code, bool transient, CancellationToken ct) => store.ExecuteAsync(async (tx, token) =>
    {
        var media = await tx.MediaAsync(lease.MediaId, token); var job = (await tx.JobsAsync(token)).SingleOrDefault(x => x.Id == lease.JobId);
        if (media?.State != MediaState.Processing || job?.State != JobState.Leased || job.LeaseToken != lease.Token) return false;
        job.LastError = code; job.UpdatedAt = clock.GetUtcNow(); job.LeaseToken = null; job.LeaseUntil = null;
        job.State = transient && job.AttemptCount <= ContentLimits.AutomaticRetries ? JobState.Pending : JobState.Failed;
        if (job.State == JobState.Failed)
        {
            media.State = MediaState.Rejected; media.ErrorCode = code; media.RowVersion++;
            var reservation = await tx.ReservationAsync(media.Id, token);
            if (reservation is not null && files.UploadPath(media.Id, reservation.UploadToken) == lease.InputPath && !await tx.HasReferencesAsync(media.Id, token))
            {
                try { files.Remove(lease.InputPath); files.Remove(lease.OutputPath); files.Remove(lease.OutputPath + ".stage"); files.Remove(files.Resolve(lease.StorageKey)); tx.Remove(reservation); }
                catch (IOException) { /* Keep charged reservation if cleanup cannot finish. */ }
            }
        }
        else
        {
            // One processing-copy reservation must not accumulate a final file per retry.
            // If cleanup fails, leave the lease token and an expired lease for ClaimAsync to reconcile.
            try { files.Remove(lease.OutputPath); files.Remove(lease.OutputPath + ".stage"); files.Remove(files.Resolve(lease.StorageKey)); }
            catch (IOException) { job.State = JobState.Leased; job.LeaseToken = lease.Token; job.LeaseUntil = clock.GetUtcNow(); }
        }
        return true;
    }, ct);
    private async Task CleanupReadyAsync(MediaLease lease, CancellationToken ct)
    {
        await store.ExecuteAsync(async (tx, token) =>
        {
            var media = await tx.MediaAsync(lease.MediaId, token); var reservation = await tx.ReservationAsync(lease.MediaId, token);
            var jobs = await tx.JobsAsync(token); var deletion = await tx.DeletionJobAsync(lease.MediaId, token);
            if (media?.State != MediaState.Ready || media.StorageKey != lease.StorageKey || reservation is null
                || files.UploadPath(media.Id, reservation.UploadToken) != lease.InputPath
                || reservation.UploadLeaseUntil > clock.GetUtcNow()
                || jobs.Any(x => x.MediaId == media.Id && x.State is JobState.Pending or JobState.Leased)
                || !jobs.Any(x => x.Id == lease.JobId && x.MediaId == media.Id && x.State == JobState.Succeeded)
                || deletion is not null) return false;
            // Retain the admission and media locks through cleanup. A concurrent lifecycle
            // action either waits for this cleanup or leaves its obsolete attempts to the sweep.
            try
            {
                files.RemoveOrphanDurably(lease.InputPath);
                files.RemoveOrphanDurably(lease.OutputPath);
                files.RemoveOrphanDurably(lease.OutputPath + ".stage");
                if (!HasAttemptBytes(media, media.Id))
                {
                    files.SyncAttemptDirectories();
                    tx.Remove(reservation);
                }
            }
            catch (Exception error) when (error is IOException or UnauthorizedAccessException)
            { return false; } // Retain the charge; absent-file/fsync recovery is retried by the sweep.
            return true;
        }, ct);
    }
    public async Task<int> SweepOrphansAsync(CancellationToken ct)
    {
        var count = 0; var cutoff = clock.GetUtcNow().AddHours(-ContentLimits.OrphanFileHours);
        await store.ExecuteAsync(async (tx, token) =>
        {
            var jobs = await tx.JobsAsync(token);
            foreach (var reservation in (await tx.ReservationsAsync(token)).Where(x => x.ExpiresAt <= clock.GetUtcNow()).OrderBy(x => x.MediaId))
            {
                if (reservation.UploadLeaseUntil > clock.GetUtcNow()
                    || jobs.Any(x => x.MediaId == reservation.MediaId && x.State is JobState.Pending or JobState.Leased)) continue;
                var media = await tx.MediaAsync(reservation.MediaId, token);
                var deletion = await tx.DeletionJobAsync(reservation.MediaId, token);
                if (deletion?.State is JobState.Pending or JobState.Leased) continue;
                if (media?.State == MediaState.Uploading)
                {
                    media.State = MediaState.Rejected; media.ErrorCode = "MEDIA_UPLOAD_EXPIRED"; media.RowVersion++;
                    var key = await tx.KeyAsync(reservation.ActorUserId, reservation.IdempotencyKey, token);
                    if (key is not null && key.Status == IdempotencyState.InProgress) { key.Status = IdempotencyState.Completed; key.ResponseCode = 422; key.ResponseJson = "{}"; }
                }
                if (!CanCleanAttempts(media, deletion) || media?.State != MediaState.Ready && await tx.HasReferencesAsync(reservation.MediaId, token)) continue;
                // An expired reservation must survive failed deletion or still-fresh attempt
                // bytes, including when the media moved to Trashed/Purged after Ready committed.
                if (!HasAttemptBytes(media, reservation.MediaId))
                {
                    files.SyncAttemptDirectories();
                    tx.Remove(reservation);
                }
            }
            return true;
        }, ct);
        foreach (var item in files.Orphans().Where(x => x.Modified <= cutoff).OrderBy(x => x.MediaId).ToArray())
        {
            var removed = await store.ExecuteAsync(async (tx, token) =>
            {
                var media = await tx.MediaAsync(item.MediaId, token); var reservation = await tx.ReservationAsync(item.MediaId, token);
                if ((await tx.JobsAsync(token)).Any(x => x.MediaId == item.MediaId && x.State is JobState.Pending or JobState.Leased) || reservation?.UploadLeaseUntil > clock.GetUtcNow()) return false;
                var deletion = await tx.DeletionJobAsync(item.MediaId, token);
                if (!CanCleanAttempts(media, deletion) || IsCanonicalPath(media, item.Path)) return false;
                // Ready references address only the protected canonical file. Trashed/Purged
                // and rejected/unknown rows require no references before any old copy is removed.
                if (media?.State != MediaState.Ready && await tx.HasReferencesAsync(item.MediaId, token)) return false;
                // Discovery happened outside the lock: a changed/fresh attempt is not stale.
                if (File.GetLastWriteTimeUtc(item.Path) > cutoff.UtcDateTime) return false;
                files.RemoveOrphanDurably(item.Path);
                if (reservation is not null && !HasAttemptBytes(media, item.MediaId))
                {
                    files.SyncAttemptDirectories();
                    tx.Remove(reservation);
                }
                return true;
            }, ct);
            if (removed) count++;
        }
        return count;
    }
    private static bool CanCleanAttempts(MediaAsset? media, MediaDeletionJob? deletion)
        => deletion?.State is not (JobState.Pending or JobState.Leased)
            && (media is null || media.State is MediaState.Ready or MediaState.Rejected or MediaState.Trashed
                || media.State == MediaState.Purged && deletion?.State == JobState.Succeeded);
    private bool IsCanonicalPath(MediaAsset? media, string path)
        => media?.State is MediaState.Ready or MediaState.Trashed or MediaState.Purged
            && Path.GetRelativePath(files.Root, path).Replace(Path.DirectorySeparatorChar, '/') == media.StorageKey;
    private bool HasAttemptBytes(MediaAsset? media, Guid id)
        => files.Orphans().Any(x => x.MediaId == id
            && (media?.State is not (MediaState.Ready or MediaState.Trashed) || !IsCanonicalPath(media, x.Path)));
}
