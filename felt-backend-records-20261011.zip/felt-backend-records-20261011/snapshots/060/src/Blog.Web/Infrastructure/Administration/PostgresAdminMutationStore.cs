using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;
using Blog.Web.Application.Administration;
using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Blog.Web.Infrastructure.Administration;

// One scoped DbContext is shared with the operation callback's business service.
// No automatic retries: a lost commit reply is resolved by the same idempotency key.
public sealed class PostgresAdminMutationStore(BlogDbContext db) : IAdminMutationStore
{
    public async Task<T> InTransactionAsync<T>(Func<IAdminMutationTransaction, CancellationToken, Task<T>> action, CancellationToken ct)
    {
        if (db.Database.CurrentTransaction is not null) throw new InvalidOperationException("NESTED_ADMIN_TRANSACTION");
        if (db.ChangeTracker.Entries().Any()) throw new InvalidOperationException("MUTATION_REQUIRES_FRESH_TRACKER");
        await using var transaction = await db.Database.BeginTransactionAsync(System.Data.IsolationLevel.ReadCommitted, ct);
        try
        {
            var result = await action(new Transaction(db), ct);
            await db.SaveChangesAsync(ct);
            await transaction.CommitAsync(ct);
            return result;
        }
        catch
        {
            await transaction.RollbackAsync(CancellationToken.None);
            throw;
        }
        finally { db.ChangeTracker.Clear(); }
    }
    public static long KeyLockId(Guid actor, string scope, Guid key)
        => BinaryPrimitives.ReadInt64BigEndian(SHA256.HashData(Encoding.UTF8.GetBytes($"blog-idempotency:{actor:D}:{scope}:{key:D}")));

    // Commands are parameterized; SQL identifiers come only from this server-owned list.
    public static IReadOnlyList<FormattableString> LockCommands(MutationLocks locks)
    {
        var commands = new List<FormattableString>();
        if (locks.SiteState) commands.Add($"SELECT id FROM site_state WHERE id = {1} FOR UPDATE");
        foreach (var id in locks.ArticlesAndDrafts)
        {
            commands.Add($"SELECT id FROM articles WHERE id = {id} FOR UPDATE");
            commands.Add($"SELECT article_id FROM article_drafts WHERE article_id = {id} FOR UPDATE");
        }
        foreach (var id in locks.Columns) commands.Add($"SELECT id FROM columns WHERE id = {id} FOR UPDATE");
        foreach (var id in locks.Media) commands.Add($"SELECT id FROM media_assets WHERE id = {id} FOR UPDATE");
        return commands;
    }
    private sealed class Transaction(BlogDbContext db) : IAdminMutationTransaction
    {
        private readonly Dictionary<(Guid, string, Guid), IdempotencyRecord> expired = [];
        public async Task AcquireKeyAsync(Guid actor, string scope, Guid key, CancellationToken ct)
            => await db.Database.ExecuteSqlInterpolatedAsync($"SELECT pg_advisory_xact_lock({KeyLockId(actor, scope, key)})", ct);
        public Task<IdempotencyRecord?> FindAsync(Guid actor, string scope, Guid key, CancellationToken ct)
            => db.Set<IdempotencyRecord>().SingleOrDefaultAsync(x => x.ActorUserId == actor && x.Scope == scope && x.Key == key, ct);
        // Reuse the tracked expired row to avoid a delete/insert tracking collision on its composite key.
        public void Remove(IdempotencyRecord record) => expired.Add((record.ActorUserId, record.Scope, record.Key), record);
        public void Add(IdempotencyRecord record)
        {
            if (expired.Remove((record.ActorUserId, record.Scope, record.Key), out var old)) db.Entry(old).CurrentValues.SetValues(record);
            else db.Set<IdempotencyRecord>().Add(record);
        }
        public void Add(AuditEvent audit) => db.Set<AuditEvent>().Add(audit);
        public async Task LockAsync(MutationLocks locks, CancellationToken ct)
        { foreach (var command in LockCommands(locks)) await db.Database.ExecuteSqlInterpolatedAsync(command, ct); }
    }
}
