using System.Security.Cryptography;
using Blog.Web.Application.Administration;
using Blog.Web.Application.Media;
using Blog.Web.Domain;

namespace Blog.Web.Infrastructure.Media;
public sealed record MediaStorageOptions(string PrivateRoot, long MaxMediaBytes)
{
    public const int UploadTimeoutSeconds = 300;
    public const int UploadLeaseSeconds = 330;
    public const int ProcessingLeaseSeconds = ContentLimits.ProcessingTimeoutSeconds + 30;
    public static MediaStorageOptions Read(IConfiguration config)
    {
        var raw = config["MAX_MEDIA_BYTES"] ?? config["Media:MaxMediaBytes"];
        if (!long.TryParse(raw, out var limit) || limit <= 0) throw new InvalidOperationException("MAX_MEDIA_BYTES_REQUIRED");
        var path = config["Media:PrivateRoot"];
        if (string.IsNullOrWhiteSpace(path) || !Path.IsPathFullyQualified(path)) throw new InvalidOperationException("PRIVATE_MEDIA_ROOT_REQUIRED");
        return new(path, limit);
    }
}
public sealed class PrivateMediaStorage
{
    public string Root { get; }
    public long Quota { get; }
    private readonly IPrivateFileDurability durability;
    public PrivateMediaStorage(MediaStorageOptions options, IWebHostEnvironment environment, IPrivateFileDurability? durability = null)
    {
        this.durability = durability ?? new LinuxPrivateFileDurability();
        Root = Path.GetFullPath(options.PrivateRoot).TrimEnd(Path.DirectorySeparatorChar);
        Quota = options.MaxMediaBytes;
        if (Quota <= 0 || Root.Length < 2) throw new InvalidOperationException("PRIVATE_MEDIA_CONFIGURATION_INVALID");
        var web = Path.GetFullPath(environment.WebRootPath ?? Path.Combine(environment.ContentRootPath, "wwwroot")).TrimEnd(Path.DirectorySeparatorChar);
        if (Root == web || Root.StartsWith(web + Path.DirectorySeparatorChar, StringComparison.Ordinal) || web.StartsWith(Root + Path.DirectorySeparatorChar, StringComparison.Ordinal))
            throw new InvalidOperationException("PRIVATE_MEDIA_OVERLAPS_WEBROOT");
        NoLinks(Root);
        CreateDurableDirectory(Root);
        // An existing ancestor may be a leftover from a failed earlier initialization. Synchronize
        // every existing ancestor entry up to the filesystem root before the storage is usable.
        // This only opens read-only directory descriptors; it creates no ancestors or permissions.
        for (string? ancestor = Root; !string.IsNullOrEmpty(ancestor); ancestor = Path.GetDirectoryName(ancestor))
            this.durability.SyncDirectory(ancestor);
        foreach (var area in new[] { "quarantine", "work", "objects" }) CreateDurableDirectory(Path.Combine(Root, area));
    }
    private void CreateDurableDirectory(string path)
    {
        NoLinks(path);
        var missing = new Stack<string>(); var current = path;
        while (!Directory.Exists(current))
        {
            missing.Push(current);
            current = Path.GetDirectoryName(current) ?? throw new IOException("PRIVATE_MEDIA_PARENT_MISSING");
        }
        while (missing.TryPop(out var directory))
        {
            Directory.CreateDirectory(directory);
            durability.SyncDirectory(directory);
            durability.SyncDirectory(Path.GetDirectoryName(directory)!);
        }
        // Also synchronize this configured root/area and its immediate entry if they existed.
        durability.SyncDirectory(path);
        durability.SyncDirectory(Path.GetDirectoryName(path)!);
    }
    public string UploadPath(Guid media, Guid token) => Resolve($"quarantine/{media:N}-{token:N}.upload");
    public string WorkPath(Guid media, Guid token) => Resolve($"work/{media:N}-{token:N}.partial");
    public string FinalKey(Guid media, Guid token, string mime) => $"objects/{media:N}-{token:N}" + (mime switch { "image/jpeg" => ".jpg", "image/png" => ".png", "image/webp" => ".webp", "video/mp4" => ".mp4", _ => throw new InvalidOperationException("INVALID_MEDIA_MIME") });
    public string Resolve(string key)
    {
        if (!System.Text.RegularExpressions.Regex.IsMatch(key, "\\A(quarantine|work|objects)/[a-f0-9]{32}-[a-f0-9]{32}\\.(upload|partial|jpg|png|webp|mp4)\\z")) throw new InvalidOperationException("PRIVATE_MEDIA_KEY_INVALID");
        var path = Path.GetFullPath(Path.Combine(Root, key)); NoLinks(path); return path;
    }
    public long UsedBytes()
    {
        NoLinks(Root); long size = 0; var pending = new Stack<string>(); pending.Push(Root);
        while (pending.TryPop(out var directory))
        {
            NoLinks(directory);
            foreach (var entry in Directory.EnumerateFileSystemEntries(directory))
            {
                NoLinks(entry);
                if (Directory.Exists(entry)) pending.Push(entry);
                else size = checked(size + new FileInfo(entry).Length);
            }
        }
        return size;
    }
    public async Task ReceiveAsync(Stream input, UploadManifest manifest, string? path, CancellationToken ct)
    {
        if (path is not null) NoLinks(path);
        await using var output = path is null ? Stream.Null : new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None, 65536, FileOptions.Asynchronous | FileOptions.SequentialScan);
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256); var buffer = new byte[65536]; long size = 0;
        while (true)
        {
            ct.ThrowIfCancellationRequested();
            var count = await input.ReadAsync(buffer, ct); ct.ThrowIfCancellationRequested(); if (count == 0) break;
            size = checked(size + count);
            if (size > manifest.Limit) throw new ApiFailure(ProblemCode.FILE_TOO_LARGE);
            if (size > manifest.ByteSize) throw new ApiFailure(ProblemCode.VALIDATION_FAILED);
            hash.AppendData(buffer, 0, count); await output.WriteAsync(buffer.AsMemory(0, count), ct);
        }
        if (size != manifest.ByteSize || Convert.ToHexStringLower(hash.GetHashAndReset()) != manifest.Sha256) throw new ApiFailure(ProblemCode.VALIDATION_FAILED);
        await output.FlushAsync(ct);
        if (output is FileStream file)
        {
            durability.FlushFile(file);
            durability.SyncDirectory(Path.GetDirectoryName(file.Name)!);
        }
    }
    public void Commit(string work, string key)
    {
        NoLinks(work); var target = Resolve(key);
        // All areas are beneath the same configured filesystem root. Never overwrite a prior attempt.
        using (var stream = new FileStream(work, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) durability.FlushFile(stream);
        durability.RenameExclusive(work, target);
        durability.SyncDirectory(Path.GetDirectoryName(target)!);
        durability.SyncDirectory(Path.GetDirectoryName(work)!);
    }
    // Delete is already idempotent for a missing file. File.Exists would silently turn access-denied
    // into false and could incorrectly release a reservation for bytes that still exist.
    public void Remove(string path) { NoLinks(path); durability.DeleteFile(path); }
    public void RemoveOrphanDurably(string path)
    {
        Remove(path);
        durability.SyncDirectory(Path.GetDirectoryName(path)!);
    }
    // Reconcile an unlink whose reply/fsync/DB commit was lost before freeing its reservation.
    // These are fixed private areas, never a caller-supplied directory or a canonical-file delete.
    public void SyncAttemptDirectories()
    {
        foreach (var area in new[] { "quarantine", "work", "objects" })
        {
            var path = Path.Combine(Root, area); NoLinks(path); durability.SyncDirectory(path);
        }
    }
    public IEnumerable<(string Path, Guid MediaId, DateTimeOffset Modified)> Orphans()
    {
        foreach (var area in new[] { "quarantine", "work", "objects" }) foreach (var path in Directory.EnumerateFiles(Path.Combine(Root, area)))
        {
            NoLinks(path); var name = Path.GetFileName(path);
            if (name.Length >= 33 && Guid.TryParseExact(name[..32], "N", out var id)) yield return (path, id, File.GetLastWriteTimeUtc(path));
        }
    }
    public static void NoLinks(string path)
    {
        var current = Path.GetFullPath(path);
        while (!string.IsNullOrEmpty(current))
        {
            if (new FileInfo(current).LinkTarget is not null || Path.Exists(current) && (File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0) throw new InvalidOperationException("PRIVATE_MEDIA_LINK_FORBIDDEN");
            current = Path.GetDirectoryName(current)!;
        }
    }
}
