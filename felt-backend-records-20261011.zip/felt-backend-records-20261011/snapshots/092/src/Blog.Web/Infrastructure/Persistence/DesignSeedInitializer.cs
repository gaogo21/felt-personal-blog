using System.Security.Cryptography;
using System.Text.Json;
using Blog.Web.Domain.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;

namespace Blog.Web.Infrastructure.Persistence;

public sealed record DesignSeedAsset(Guid Id, string Key, string RelativePath, string StorageKey,
    long ByteSize, string Sha256, int Width, int Height, string MimeType, string Alt, string Credit,
    string SourceUrl, string LicenseName, string LicenseUrl, short? GallerySlot);

public static class DesignSeedCatalog
{
    public const string AboutText = "I’m a developer who loves turning ideas into things you can use. This is where I share what I build, what I learn, and the moments I want to remember. From code and side projects to everyday discoveries, I’m always curious about what comes next.";
    private static readonly string[] Keys = ["hero.green", "hero.pink", "hero.blue", "about.moon", "about.brick", "about.smile", "about.cursor", "sky.stars", "sky.nebula", .. Enumerable.Range(1, 10).Select(x => $"gallery.{x:00}")];
    public static IReadOnlyList<DesignSeedAsset> Load()
    {
        using var stream = typeof(DesignSeedCatalog).Assembly.GetManifestResourceStream("Blog.Web.Infrastructure.Persistence.design-seed-v1.json")
            ?? throw new InvalidOperationException("DESIGN_SEED_MANIFEST_MISSING");
        var items = JsonSerializer.Deserialize<DesignSeedAsset[]>(stream, new JsonSerializerOptions(JsonSerializerDefaults.Web))
            ?? throw new InvalidOperationException("DESIGN_SEED_MANIFEST_INVALID");
        if (items.Length != 19 || !items.Select(x => x.Key).SequenceEqual(Keys) || items.Select(x => x.Id).Distinct().Count() != 19
            || items.Select(x => x.Sha256).Distinct().Count() != 19 || items.Select(x => x.StorageKey).Distinct().Count() != 19
            || !items.Where(x => x.GallerySlot != null).Select(x => x.GallerySlot!.Value).SequenceEqual(Enumerable.Range(1, 10).Select(x => (short)x)))
            throw new InvalidOperationException("DESIGN_SEED_WHITELIST_INVALID");
        foreach (var item in items)
        {
            if (item.Id != StableId(item.Key) || item.ByteSize <= 0 || item.Width <= 0 || item.Height <= 0
                || !System.Text.RegularExpressions.Regex.IsMatch(item.Sha256, "^[0-9a-f]{64}$")
                || !item.RelativePath.StartsWith("assets/", StringComparison.Ordinal)
                || item.StorageKey != "design-v1/" + Path.GetFileName(item.RelativePath))
                throw new InvalidOperationException("DESIGN_SEED_ENTRY_INVALID");
        }
        return Array.AsReadOnly(items);
    }
    // UUID v5, namespace URL. IDs remain fixed across installs; no random IDs or user identity is seeded.
    private static Guid StableId(string key)
    {
        var ns = Guid.Parse("6ba7b811-9dad-11d1-80b4-00c04fd430c8").ToByteArray(bigEndian: true);
        var bytes = SHA1.HashData([.. ns, .. System.Text.Encoding.UTF8.GetBytes("felt-blog/design/v1/" + key)])[..16];
        bytes[6] = (byte)((bytes[6] & 0x0f) | 0x50); bytes[8] = (byte)((bytes[8] & 0x3f) | 0x80);
        return new Guid(bytes, bigEndian: true);
    }
    public static MediaAsset ToMedia(DesignSeedAsset asset, DateTimeOffset now) => new()
    {
        Id = asset.Id, StorageKey = asset.StorageKey, Kind = MediaKind.Image, State = MediaState.Ready,
        Origin = "system_design_seed", CreatedBy = null, CreatedAt = now, RowVersion = 1,
        OriginalFileName = Path.GetFileName(asset.RelativePath), MimeType = asset.MimeType,
        ByteSize = asset.ByteSize, Width = asset.Width, Height = asset.Height,
        Sha256 = asset.Sha256, UploadSha256 = asset.Sha256,
        AltText = asset.Alt, Credit = asset.Credit, SourceUrl = asset.SourceUrl,
        LicenseName = asset.LicenseName, LicenseUrl = asset.LicenseUrl
    };
    public static string DisplayMeta(DesignSeedAsset a) => JsonSerializer.Serialize(new
    { alt = a.Alt, caption = "", credit = a.Credit, sourceUrl = a.SourceUrl, licenseName = a.LicenseName, licenseUrl = a.LicenseUrl });
}

// Explicit offline-preparable initial installation operation. Not registered or invoked by web startup.
// Future protected media serving is F12; this does not make arbitrary files anonymously readable.
public sealed class DesignSeedInitializer(BlogDbContext db)
{
    public async Task<bool> InitializeAsync(string approvedWebRoot, string privateMediaRoot, DateTimeOffset now, CancellationToken ct = default)
    {
        await using var transaction = await db.Database.BeginTransactionAsync(ct);
        await db.Database.ExecuteSqlRawAsync("SELECT pg_advisory_xact_lock(713025091)", ct);
        if (await db.Set<SiteSettings>().AnyAsync(ct)) { await transaction.CommitAsync(ct); return false; }
        foreach (var table in db.Model.GetEntityTypes().Select(x => x.GetTableName()!).Distinct())
        {
            // Table names are model constants, never input. Fail rather than resetting a partly initialized database.
            var identifier = db.GetService<ISqlGenerationHelper>().DelimitIdentifier(table);
            var query = "SELECT EXISTS (SELECT 1 FROM " + identifier + ") AS \"Value\"";
            var occupied = await db.Database.SqlQueryRaw<bool>(query).SingleAsync(ct);
            if (occupied) throw new InvalidOperationException("INITIALIZATION_REQUIRES_EMPTY_DATABASE");
        }
        var assets = DesignSeedCatalog.Load();
        await PrepareFilesAsync(approvedWebRoot, privateMediaRoot, ct);
        db.AddRange(assets.Select(x => DesignSeedCatalog.ToMedia(x, now)));
        db.AddRange(assets.Where(x => x.GallerySlot != null).Select(x => new GallerySlot { Slot = x.GallerySlot!.Value, MediaId = x.Id, DisplayMeta = DesignSeedCatalog.DisplayMeta(x) }));
        db.AddRange(assets.Where(x => x.GallerySlot == null).Select(x => new DesignAssetSlot { Key = x.Key, MediaId = x.Id }));
        db.Add(new SiteSettings { AboutText = DesignSeedCatalog.AboutText });
        db.Add(new SiteState { UpdatedAt = now });
        await db.SaveChangesAsync(ct);
        await transaction.CommitAsync(ct);
        return true;
    }

    public static async Task PrepareFilesAsync(string approvedWebRoot, string privateMediaRoot, CancellationToken ct = default)
    {
        var source = Path.GetFullPath(approvedWebRoot); var destination = Path.GetFullPath(privateMediaRoot);
        if (destination == source || destination.StartsWith(source + Path.DirectorySeparatorChar, StringComparison.Ordinal)
            || source.StartsWith(destination + Path.DirectorySeparatorChar, StringComparison.Ordinal))
            throw new InvalidOperationException("PRIVATE_MEDIA_ROOT_MUST_BE_SEPARATE");
        var assets = DesignSeedCatalog.Load();
        // Validate all inputs before the first copy. Files are read, never rewritten in wwwroot.
        foreach (var a in assets) await VerifyFileAsync(SafePath(source, a.RelativePath), a, ct);
        Directory.CreateDirectory(destination);
        foreach (var a in assets)
        {
            var target = SafePath(destination, a.StorageKey);
            Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            if (File.Exists(target)) { await VerifyFileAsync(target, a, ct); continue; }
            var temporary = target + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                await using (var input = File.OpenRead(SafePath(source, a.RelativePath)))
                await using (var output = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    await input.CopyToAsync(output, ct);
                await VerifyFileAsync(temporary, a, ct);
                File.Move(temporary, target); // Same-directory atomic installation; never overwrite changed bytes.
            }
            finally { if (File.Exists(temporary)) File.Delete(temporary); }
        }
    }
    private static string SafePath(string root, string relative)
    {
        if (Path.IsPathRooted(relative) || relative.Contains('\\') || relative.Split('/').Any(x => x is "" or "." or ".."))
            throw new InvalidOperationException("DESIGN_SEED_PATH_INVALID");
        var path = Path.GetFullPath(Path.Combine(root, relative));
        if (!path.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.Ordinal)) throw new InvalidOperationException("DESIGN_SEED_PATH_ESCAPE");
        for (var cursor = new FileInfo(path) as FileSystemInfo; cursor != null; cursor = Directory.GetParent(cursor.FullName))
            if (cursor.LinkTarget != null) throw new InvalidOperationException("DESIGN_SEED_SYMLINK_REJECTED");
        return path;
    }
    private static async Task VerifyFileAsync(string path, DesignSeedAsset a, CancellationToken ct)
    {
        if (new FileInfo(path).Length != a.ByteSize) throw new InvalidOperationException("DESIGN_SEED_SIZE_MISMATCH");
        await using var stream = File.OpenRead(path);
        var hash = Convert.ToHexStringLower(await SHA256.HashDataAsync(stream, ct));
        if (hash != a.Sha256) throw new InvalidOperationException("DESIGN_SEED_HASH_MISMATCH");
    }
}
