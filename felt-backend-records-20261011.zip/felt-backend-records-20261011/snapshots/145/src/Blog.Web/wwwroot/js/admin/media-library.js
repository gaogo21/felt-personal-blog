import { MEDIA_LIMITS } from './media-limits.js';
import { createMediaUploadController } from './media-upload.js';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const stateNames = { Uploading: '上传中', Processing: '处理中', Ready: '可使用', Rejected: '处理失败', Trashed: '已回收', Purged: '已清空' };
const fields = ['alt', 'caption', 'credit', 'sourceUrl', 'licenseName', 'licenseUrl'];
const limits = { alt: 'AltScalars', caption: 'CaptionScalars', credit: 'CreditScalars', sourceUrl: 'LinkScalars', licenseName: 'LicenseScalars', licenseUrl: 'LinkScalars' };
const blankMeta = () => Object.fromEntries(fields.map(key => [key, '']));
const defaults = media => ({ ...blankMeta(), alt: media.metadata.altText ?? '', ...Object.fromEntries(['credit', 'sourceUrl', 'licenseName', 'licenseUrl'].map(key => [key, media.metadata[key] ?? ''])) });
const valid = value => value && UUID.test(value.id) && Number.isSafeInteger(value.version) && value.version > 0 && Object.hasOwn(stateNames, value.state)
  && value.metadata && ['Image', 'Video'].includes(value.metadata.kind);
const https = value => { if (!value) return true; try { const url = new URL(value); return url.protocol === 'https:' && !url.username && !url.password && !/[\s\\\u0000-\u001f\u007f]/u.test(value); } catch { return false; } };

/** Authenticated UI only. Server independently checks Ready/type/references at draft save and publish. */
export function createMediaLibrary(element, { onInsert = null, onAuthRequired = () => {}, onPendingChange = () => {}, fetchImpl = globalThis.fetch, uploadFactory = createMediaUploadController } = {}) {
  const abort = new AbortController(), options = { signal: abort.signal };
  let destroyed = false, enabled = true, selected = null, poster = null, mode = 'body', selectingPoster = false;
  let page = 1, total = 0, listSerial = 0, chooseSerial = 0, busy = false, returnFocus = null, metaBaseline = null, posterBaseline = null;
  element.classList.add('media-library');
  element.innerHTML = `<div class="media-library-heading"><h2 tabindex="-1">图片与视频媒体库</h2><button type="button" data-close>收起媒体库</button></div>
<p>媒体保持私有，只有就绪后才能插入。上传、正文保存与发布是不同步骤；来源说明以插入时的副本保留。</p>
<div class="media-upload"><label>选择图片或 MP4<input type="file" data-file accept="image/jpeg,image/png,image/webp,video/mp4,.jpg,.jpeg,.png,.webp,.mp4"></label>
<p>图片最多 10 MiB；MP4 最多 200 MiB、10 分钟。一次处理本页一个文件，不能上传音频或普通附件。</p>
<progress data-progress max="100" value="0" aria-label="上传进度"></progress><p data-upload-status role="status"></p>
<div class="media-actions"><button type="button" data-start>开始上传</button><button type="button" data-retry>重试 / 继续</button><button type="button" data-cancel>取消当前传输</button><button type="button" data-resume>查询处理状态</button><button type="button" data-forget>放弃本页上传恢复记录</button></div></div>
<div class="media-filter"><label>类型<select data-kind><option value="">全部</option><option>Image</option><option>Video</option></select></label>
<label>状态<select data-state><option value="Ready">可使用</option><option value="">全部</option><option value="Uploading">上传中</option><option value="Processing">处理中</option><option value="Rejected">处理失败</option></select></label>
<label>说明搜索<input data-query type="search" placeholder="替代文字、来源或许可"></label><button type="button" data-search>读取媒体列表</button></div>
<p data-status role="status" aria-live="polite"></p><div data-list class="media-library-grid"></div>
<div class="media-actions"><button type="button" data-prev>上一页</button><span data-page></span><button type="button" data-next>下一页</button></div>
<section data-selected hidden aria-label="所选媒体说明"><h3 data-selection-title></h3><div data-preview class="media-selection-preview"></div>
<p>这些说明用于本次正文或封面。“保存为媒体库默认说明”不会回写旧文章；图片替代文字必填，视频只保存说明和可选海报。</p>
${[['alt','图片替代文字'],['caption','标题 / 说明'],['credit','作者 / 来源署名'],['sourceUrl','来源网址（HTTPS）'],['licenseName','许可名称'],['licenseUrl','许可网址（HTTPS）']].map(([key,label]) => `<label>${label}<input data-meta="${key}" autocomplete="off"></label>`).join('')}
<div data-poster-row><p data-poster-label>视频海报：未选择（可选）</p><button type="button" data-poster>从媒体库选择海报图片</button><button type="button" data-poster-clear>移除海报</button></div>
<div class="media-actions"><button type="button" data-defaults>保存为媒体库默认说明</button><button type="button" data-reload>重新读取默认说明</button><button type="button" data-insert>插入正文</button></div></section>`;
  const $ = selector => element.querySelector(selector);
  const status = $('[data-status]');
  const say = text => { if (!destroyed) status.textContent = text; };
  const event = (selector, action, type = 'click') => $(selector).addEventListener(type, action, options);
  const request = (path, init = {}) => fetchImpl(`/api/admin/v1${path}`, { credentials: 'same-origin', cache: 'no-store', signal: abort.signal, ...init });
  async function read(path) {
    const response = await request(path);
    if (destroyed) throw new DOMException('Disposed media library', 'AbortError');
    if (!response.ok) {
      if (response.status === 401) onAuthRequired();
      throw new Error(response.status === 401 ? '登录已过期，请登录后重新读取。当前选择保留。' : `读取失败（HTTP ${response.status}），当前说明保留。`);
    }
    return response.json();
  }
  function controls() {
    if (destroyed) return;
    $('[data-insert]').disabled = !enabled || busy || !selected || !onInsert;
    $('[data-defaults]').disabled = !enabled || busy || !selected;
    $('[data-reload]').disabled = busy || !selected;
    $('[data-prev]').disabled = page <= 1;
    $('[data-next]').disabled = page * 20 >= total;
    $('[data-poster]').disabled = !enabled || busy;
  }
  function metadata(requireAlt) {
    const result = {};
    for (const key of fields) {
      const raw = $(`[data-meta="${key}"]`).value;
      if (Array.from(raw).some(character => character.length === 1 && /[\uD800-\uDFFF]/u.test(character))) throw new Error('说明包含无效字符。');
      const value = raw.normalize('NFC');
      if (Array.from(value).length > MEDIA_LIMITS[limits[key]]) throw new Error('说明文字超过允许长度。');
      result[key] = value;
    }
    if (requireAlt && !result.alt.trim()) throw new Error('请填写图片替代文字。');
    if (!https(result.sourceUrl) || !https(result.licenseUrl)) throw new Error('来源与许可网址必须是无用户名密码的 HTTPS 地址。');
    return result;
  }
  function fill(value) { for (const key of fields) $(`[data-meta="${key}"]`).value = value[key]; metaBaseline = JSON.stringify(value); posterBaseline = poster?.id ?? null; }
  const rawMetadata = () => JSON.stringify(Object.fromEntries(fields.map(key => [key, $(`[data-meta="${key}"]`).value])));
  const metadataPending = () => Boolean(selected && (metaBaseline !== rawMetadata() || posterBaseline !== (poster?.id ?? null)));
  function renderSelected() {
    $('[data-selected]').hidden = !selected;
    if (!selected) return;
    $('[data-selection-title]').textContent = `${mode === 'cover' ? '文章封面' : '正文媒体'} · ${selected.metadata.kind === 'Image' ? '图片' : '视频'}`;
    $('[data-insert]').textContent = mode === 'cover' ? '设为文章封面' : mode === 'edit' ? '更新所选媒体说明' : '插入正文';
    $('[data-insert]').hidden = !onInsert;
    $('[data-poster-row]').hidden = !onInsert || selected.metadata.kind !== 'Video' || mode === 'cover';
    $('[data-poster-label]').textContent = poster ? `视频海报：${poster.metadata.altText || poster.id}` : '视频海报：未选择（可选）';
    const preview = document.createElement(selected.metadata.kind === 'Image' ? 'img' : 'video');
    preview.src = `/media/${selected.id}`;
    if (selected.metadata.kind === 'Image') preview.alt = selected.metadata.altText || '所选图片预览';
    else { preview.controls = true; preview.preload = 'metadata'; if (poster) preview.poster = `/media/${poster.id}`; }
    $('[data-preview]').replaceChildren(preview); controls();
  }
  async function readyMedia(id, expectedKind) {
    if (!UUID.test(id)) throw new Error('媒体标识不正确。');
    const media = await read(`/media/${id}`);
    if (!valid(media) || media.id !== id || media.state !== 'Ready' || (expectedKind && media.metadata.kind !== expectedKind)) throw new Error('媒体尚未就绪、已不可用或类型不符，请重新选择。');
    return media;
  }
  async function choose(id) {
    const sequence = ++chooseSerial;
    try {
      const media = await readyMedia(id, selectingPoster || mode === 'cover' ? 'Image' : null);
      if (destroyed || sequence !== chooseSerial) return;
      if (selectingPoster) { poster = media; selectingPoster = false; say('海报已选择；插入时会再次检查。'); }
      else { selected = media; poster = null; fill(defaults(media)); say('媒体已就绪。请核对本次说明，再插入或保存默认说明。'); }
      renderSelected();
    } catch (error) { if (!destroyed && sequence === chooseSerial) say(error.message); }
  }
  async function load() {
    const sequence = ++listSerial;
    say(selectingPoster ? '读取海报图片…' : '读取媒体列表…');
    const params = new URLSearchParams({ page: String(page), pageSize: '20' });
    const kind = selectingPoster || mode === 'cover' ? 'Image' : $('[data-kind]').value;
    const state = selectingPoster ? 'Ready' : $('[data-state]').value;
    if (kind) params.set('kind', kind); if (state) params.set('state', state);
    if ($('[data-query]').value) params.set('q', $('[data-query]').value);
    try {
      const result = await read(`/media?${params}`);
      if (destroyed || sequence !== listSerial) return;
      if (!Array.isArray(result.items) || !result.items.every(valid) || !Number.isSafeInteger(result.total) || result.total < 0) throw new Error('媒体列表响应无法确认。');
      total = result.total; $('[data-list]').replaceChildren();
      for (const media of result.items) {
        const button = document.createElement('button'); button.type = 'button'; button.className = 'media-library-item'; button.dataset.mediaId = media.id;
        if (media.state === 'Ready' && media.metadata.kind === 'Image') { const image = document.createElement('img'); image.src = `/media/${media.id}`; image.alt = ''; image.loading = 'lazy'; button.append(image); }
        const title = document.createElement('strong'); title.textContent = media.metadata.altText || `${media.metadata.kind === 'Image' ? '图片' : '视频'} ${media.id.slice(0,8)}`;
        const description = document.createElement('span'); description.textContent = `${stateNames[media.state]} · ${media.metadata.width ?? '?'} × ${media.metadata.height ?? '?'}`; button.append(title, description);
        button.disabled = !['Ready','Uploading','Processing'].includes(media.state);
        button.addEventListener('click', () => { if (media.state === 'Ready') { if (mode === 'edit' && !selectingPoster) { say('正在编辑已有媒体说明；需插入其他媒体时请重新打开普通媒体库。'); return; } void choose(media.id); } else upload.resume(media.id); }, options);
        $('[data-list]').append(button);
      }
      $('[data-page]').textContent = `第 ${page} 页 · ${total} 项`;
      say(result.items.length ? (selectingPoster ? '请选择一张就绪图片作为海报。' : '点击就绪媒体填写说明；点击处理中媒体继续查询。') : '没有符合条件的媒体。'); controls();
    } catch (error) { if (!destroyed && sequence === listSerial) say(error.message); }
  }
  const upload = uploadFactory({ onChange(value) {
    if (destroyed) return;
    if (value.phase === 'auth') onAuthRequired();
    $('[data-upload-status]').textContent = (value.fileName ? `文件：${value.fileName}。 ` : '') + value.message + (value.recoveryAvailable === false ? ' 本浏览器无法保存恢复标识，请保持当前页面。' : '');
    const progress = $('[data-progress]'); if (value.progress === null) progress.removeAttribute('value'); else progress.value = value.progress;
    $('[data-start]').disabled = !enabled || !value.canStart; $('[data-retry]').disabled = !enabled || !value.canRetry;
    $('[data-cancel]').disabled = !value.canCancel; $('[data-resume]').disabled = !value.canResume; $('[data-forget]').disabled = !value.canForgetRecovery;
    onPendingChange();
  }, onReady(media) { if (!destroyed) { void load(); void choose(media.id); } } });
  event('[data-file]', event => { const file = event.target.files?.[0]; if (file) void upload.selectFile(file); }, 'change');
  event('[data-forget]', () => { if (window.confirm('请先检查媒体库。放弃恢复记录不会删除服务器文件，再次上传可能产生重复媒体。确认仅清除本页恢复记录？')) upload.forgetRecovery({ confirmed: true }); });
  event('[data-start]', () => { if (enabled) void upload.start(); });
  event('[data-retry]', () => { if (enabled) void upload.retry(); });
  event('[data-cancel]', () => upload.cancel());
  event('[data-resume]', () => { const id = upload.getState().mediaId; if (id) upload.resume(id); else void upload.retry(); });
  event('[data-search]', () => { page = 1; void load(); });
  event('[data-prev]', () => { if (page > 1) { page--; void load(); } });
  event('[data-next]', () => { if (page * 20 < total) { page++; void load(); } });
  event('[data-close]', () => { element.hidden = true; returnFocus?.focus(); });
  event('[data-poster]', () => { selectingPoster = true; page = 1; void load(); });
  event('[data-poster-clear]', () => { poster = null; selectingPoster = false; renderSelected(); });
  event('[data-reload]', async () => { if (!selected || busy) return; const snapshotId = selected.id; const before = JSON.stringify(Object.fromEntries(fields.map(key => [key, $(`[data-meta="${key}"]`).value]))); busy = true; controls(); try { const media = await readyMedia(snapshotId); if (!destroyed && selected?.id === snapshotId) { if (before !== JSON.stringify(Object.fromEntries(fields.map(key => [key, $(`[data-meta="${key}"]`).value])))) { say('读取期间出现了新说明，已保留；请重新确认是否载入默认说明。'); return; } selected = media; fill(defaults(media)); say('已明确载入媒体库默认说明。'); renderSelected(); } } catch (error) { say(error.message); } finally { busy = false; controls(); } });
  event('[data-defaults]', async () => {
    if (!enabled || busy || !selected) return;
    let meta; try { meta = metadata(false); } catch (error) { say(error.message); return; }
    const snapshot = selected, submittedFields = rawMetadata(); busy = true; controls();
    try {
      const bootstrap = await read('/session/bootstrap');
      if (destroyed) return;
      if (!bootstrap.session?.user?.id || !bootstrap.csrfToken) { onAuthRequired(); throw new Error('登录已过期，请重新登录后再保存。当前输入保留。'); }
      if (destroyed || !enabled) return;
      const response = await request(`/media/${snapshot.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': bootstrap.csrfToken, 'If-Match': `"m-${snapshot.id}-${snapshot.version}"` }, body: JSON.stringify({ altText: meta.alt, credit: meta.credit, sourceUrl: meta.sourceUrl, licenseName: meta.licenseName, licenseUrl: meta.licenseUrl }) });
      if (destroyed) return;
      if (!response.ok) { if (response.status === 401) onAuthRequired(); throw new Error(response.status === 412 ? '默认说明已被其他操作更新。本次输入保留，请明确重新读取后再处理。' : `默认说明保存失败（HTTP ${response.status}）。本次输入保留。`); }
      const saved = await response.json(); if (!valid(saved) || saved.id !== snapshot.id) throw new Error('保存结果无法确认，请读取服务器版本。');
      if (!destroyed && selected?.id === snapshot.id) { selected = saved; const savedFields = JSON.parse(submittedFields); if (onInsert) savedFields.caption = JSON.parse(metaBaseline ?? submittedFields).caption; metaBaseline = JSON.stringify(savedFields); say('媒体库默认说明已保存。正文和封面的已有快照未改变；本页较新输入保留。'); }
    } catch (error) { if (!destroyed) say(error.message); } finally { busy = false; controls(); }
  });
  event('[data-insert]', async () => {
    if (!enabled || busy || !selected || !onInsert) return;
    let meta; try { meta = metadata(selected.metadata.kind === 'Image'); } catch (error) { say(error.message); return; }
    const submittedFields = rawMetadata();
    const snapshot = { id: selected.id, kind: selected.metadata.kind, poster: poster?.id ?? null, mode }; busy = true; controls();
    try {
      const media = await readyMedia(snapshot.id, snapshot.kind);
      if (snapshot.poster) await readyMedia(snapshot.poster, 'Image');
      if (destroyed || !enabled) return;
      const node = media.metadata.kind === 'Image' ? { type: 'image', attrs: { mediaId: media.id, alt: meta.alt, caption: meta.caption, displayMeta: meta } }
        : { type: 'video', attrs: { mediaId: media.id, posterMediaId: snapshot.poster, caption: meta.caption } };
      if (onInsert({ mode: snapshot.mode, media, meta, node }) !== false) { metaBaseline = submittedFields; posterBaseline = snapshot.poster; say('媒体已插入本页工作草稿。请检查正文保存状态；这不表示已经发布。'); }
      else say('当前无法插入。正文和说明均保留，请回到可编辑的普通段落后再试。');
    } catch (error) { if (!destroyed) say(error.message); } finally { busy = false; controls(); }
  });
  const api = {
    open(purpose = 'body', existingNode = null) { if (destroyed) return; returnFocus = document.activeElement; chooseSerial++; mode = purpose; selectingPoster = false; element.hidden = false; $('[data-selection-title]').textContent = ''; if (mode === 'cover' && selected?.metadata.kind !== 'Image') selected = null; renderSelected(); $('h2').focus(); void load();
      if (purpose === 'edit' && existingNode && ['image','video'].includes(existingNode.type)) {
        const sequence = chooseSerial;
        selected = null; renderSelected();
        (async () => { try {
          const media = await readyMedia(existingNode.attrs.mediaId, existingNode.type === 'image' ? 'Image' : 'Video');
          const selectedPoster = existingNode.attrs.posterMediaId ? await readyMedia(existingNode.attrs.posterMediaId, 'Image') : null;
          if (destroyed || sequence !== chooseSerial) return;
          selected = media; poster = selectedPoster;
          fill(existingNode.type === 'image' ? { ...existingNode.attrs.displayMeta } : { ...defaults(media), caption: existingNode.attrs.caption });
          renderSelected(); say('编辑的是这篇文章中的说明副本。保持原媒体选中后应用修改；不会重写其他文章。');
        } catch (error) { if (!destroyed && sequence === chooseSerial) say(error.message); } })();
      }
    },
    files(files) { api.open('body'); if (files.length !== 1) { say('请一次选择一个媒体文件，已有正文不会改变。'); return; } void upload.selectFile(files[0]); },
    setEnabled(value) { enabled = Boolean(value); controls(); const state = upload.getState(); $('[data-start]').disabled = !enabled || !state.canStart; $('[data-retry]').disabled = !enabled || !state.canRetry; },
    hasPending: () => busy || upload.hasPending() || metadataPending(),
    destroy() { if (destroyed) return; destroyed = true; abort.abort(); upload.destroy(); element.replaceChildren(); }
  };
  if (!onInsert) $('[data-meta="caption"]').closest('label').hidden = true;
  controls(); return api;
}
