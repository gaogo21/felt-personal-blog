"""F27 documentation checks only: no build, database, browser or service action."""
from pathlib import Path
import hashlib
import json
import re
import sys

root = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(root / 'eng'))
from publication_contract import verify_publication, replacement_digest
checks = []
def record(name, passed):
    checks.append({'name': name, 'passed': bool(passed)})
def read(path):
    return json.loads((root / path).read_text())

approved = read('docs/development/acceptance-cases.json')
gate = read('docs/development/f27/acceptance-status.json')
f23 = read('docs/development/f23/acceptance-evidence.json')
record('All 36 approved IDs and scenarios preserved',
       [(c['id'], c['givenWhen'], c['then']) for c in approved] ==
       [(c['id'], c['givenWhen'], c['expected']) for c in gate['cases']])
record('No overall or preproduction case promoted', len(gate['cases']) == 36 and all(
       c['overallStatus'] == c['preproductionStatus'] == c['productionStatus'] == 'pending' for c in gate['cases']))
record('S10 both phases pending', gate['S10'] == {'isolated': 'pending', 'production': 'pending', 'overall': 'pending'})
record('No launch or F12 retry authorization', gate['launchAuthorized'] is False and gate['F12ExtraProbe'] == 'blocked; not retried')
hashes = read('docs/development/f23/source-hashes.json')
packaging_hashes = {'eng/cleanup_contract.py', 'eng/f23/README.md'}
record('70 reviewed hashes unchanged and 2 exact public-packaging substitutions registered',
       len(hashes) == 72 and packaging_hashes <= set(hashes) and all(
       hashlib.sha256((root / p).read_bytes()).hexdigest() ==
       (replacement_digest(p, digest) if p in packaging_hashes else digest)
       for p, digest in hashes.items()))
publication = verify_publication()
record('Delivered product tree preserved with exact public-packaging changes',
       publication['productFilesByteIdentical'] > 0)
coverage = read('docs/development/f23/final-independent-evidence/branch-coverage.json')
record('Figures match final instrumented evidence',
       coverage['coreBusiness']['branches'] == {'covered': 2227, 'total': 2533, 'percent': 87.9195} and
       coverage['overallWeb']['branches'] == {'covered': 5037, 'total': 6598, 'percent': 76.3413})
missing = []
for path in (root / 'docs/development/f27').glob('*.md'):
    for target in re.findall(r'\]\(([^)]+)\)', path.read_text()):
        if '://' not in target and not (path.parent / target.split('#')[0]).exists():
            missing.append({'file': str(path.relative_to(root)), 'target': target})
record('All F27 local Markdown links exist', not missing)
record('Root README exact replacement hash registered',
       hashlib.sha256((root / 'README.md').read_bytes()).hexdigest() ==
       replacement_digest('README.md', read('docs/development/f23/documentation-rewrites.json')['replacementSha256']))
record('Derived case requirements and gaps agree with F23', all(
       left['id'] == right['id'] and left['remainingProof'] == right['remainingProof'] and
       left['exactScenarioGaps'] == right['exactScenarioGaps']
       for left, right in zip(f23['cases'], gate['cases'])))

# Only current guidance, not immutable historical run logs, is reconciled.
current = ['README.md', 'DEVELOPMENT.md', 'TODOS.md',
           'docs/development/f23/ACCEPTANCE-EVIDENCE.md',
           'docs/development/f23/acceptance-evidence.json',
           'docs/development/f23/readiness-checklist.json',
           'docs/development/f27/RELEASE-DECISION.md',
           'docs/development/f27/ADMIN-GUIDE.md',
           'docs/development/f27/ACCEPTANCE-MATRIX.md',
           'docs/development/f27/acceptance-status.json']
stale = re.compile(r'no production isolation[- ]guard implementation or restore HTTP/CLI entry point exists|'
                   r'no production isolation guard is implemented|'
                   r'restore adapter also lacks the production external-writer isolation guard', re.I)
record('Current guidance contains no obsolete missing-guard/entry claim',
       all(stale.search((root / p).read_text()) is None for p in current))
record('Negative controls detect obsolete guard assertions', all(stale.search(text) is not None for text in [
       'No production isolation-guard implementation or restore HTTP/CLI entry point exists in the adapter contract.',
       'NO PRODUCTION ISOLATION GUARD IS IMPLEMENTED.',
       'The PostgreSQL restore adapter also lacks the production external-writer isolation guard.']))
record('Actual implemented-but-unverified wording is permitted', stale.search(
       'F23 implements the production isolation guard and controlled restore-isolated CLI; actual PostgreSQL remains unverified.') is None)
report = {'scope': __doc__, 'codeCommit': 'b3b81c0e1f168e355ec9cbe2d26bf5353535cfd7',
          'checks': checks, 'passed': sum(c['passed'] for c in checks), 'total': len(checks),
          'missingLinks': missing, 'quickCleanup': 'Not run by this documentation command; see artifacts/f22/cleanup-results.json',
          'publicExport': publication,
          'decision': 'NO-GO', 'fullSuiteRerun': False}
output = root / 'artifacts/publication'
output.mkdir(parents=True, exist_ok=True)
(output / 'document-check-results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(f"F27 documentation checks: {report['passed']}/{report['total']} passed; product hash unchanged; NO-GO")
raise SystemExit(0 if all(c['passed'] for c in checks) else 1)
