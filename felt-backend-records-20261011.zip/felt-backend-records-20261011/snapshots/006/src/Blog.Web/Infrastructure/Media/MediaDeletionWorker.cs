using Blog.Web.Application.Media;

namespace Blog.Web.Infrastructure.Media;

public sealed class MediaDeletionWorker(IServiceScopeFactory scopes, IHostEnvironment environment,
    ILogger<MediaDeletionWorker> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (environment.EnvironmentName == "ComponentTests") return;
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await using var scope = scopes.CreateAsyncScope();
                // Already accepted jobs may drain during maintenance; lifecycle requests are
                // gated in the service, so no new purge enters the queue in read-only mode.
                var processed = await scope.ServiceProvider.GetRequiredService<MediaDeletionService>().RunOneAsync(stoppingToken);
                if (!processed) await Task.Delay(TimeSpan.FromSeconds(1), stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { break; }
            catch (Exception)
            {
                logger.LogWarning("Media deletion worker is unavailable; private tasks remain pending. Code: MEDIA_DELETION_WORKER_UNAVAILABLE");
                await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
            }
        }
    }
}
