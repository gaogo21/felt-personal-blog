using Blog.Web.Infrastructure.Media;

namespace Blog.Web.Infrastructure.Backup;

public sealed record BackupOptions(bool Enabled, string DestinationRoot, string DataProtectionRoot,
    string EncryptionKeyFile, string ApplicationName, int ConfigurationVersion)
{
    public static BackupOptions Read(IConfiguration configuration)
    {
        if (!configuration.GetValue<bool>("Backup:Enabled")) return new(false, "", "", "", "", 0);
        if (!configuration.GetValue<bool>("Backup:SingleInstanceConfirmed") ||
            !configuration.GetValue<bool>("Backup:NoExternalWritersConfirmed") ||
            !configuration.GetValue<bool>("Backup:ExistingKeyRotationManaged"))
            throw new InvalidOperationException("BACKUP_EXCLUSIVE_DEPLOYMENT_REQUIRED");
        string PathValue(string key) => BackupArchivePaths.Full(configuration[key] ?? "");
        var destination = PathValue("Backup:DestinationRoot");
        var protection = PathValue("Backup:DataProtectionRoot");
        var encryption = PathValue("Backup:EncryptionKeyFile");
        var media = BackupArchivePaths.Full(MediaStorageOptions.Read(configuration).PrivateRoot);
        var name = configuration["Backup:ApplicationName"];
        var version = configuration.GetValue<int>("Backup:ConfigurationVersion");
        if (string.IsNullOrWhiteSpace(name) || name.Length > 100 || !name.All(c => char.IsAsciiLetterOrDigit(c) || c is '.' or '_' or '-' or '+') || version < 1)
            throw new InvalidOperationException("BACKUP_SAFE_CONFIGURATION_REQUIRED");
        foreach (var pair in new[] { (destination, protection), (destination, media), (protection, media),
                     (destination, encryption), (protection, encryption), (media, encryption) })
            BackupArchivePaths.RequireSeparate(pair.Item1, pair.Item2);
        return new(true, destination, protection, encryption, name, version);
    }
    // No provisioning, permissions changes, new keys, or best-effort fallback here.
    public void ValidateExistingFiles(string webRoot)
    {
        if (!Enabled) return;
        foreach (var path in new[] { DestinationRoot, DataProtectionRoot, EncryptionKeyFile })
            BackupArchivePaths.RequireSeparate(path, Path.GetFullPath(webRoot));
        BackupArchivePaths.CheckDirectory(DestinationRoot);
        BackupArchivePaths.CheckDirectory(DataProtectionRoot);
        if (!OperatingSystem.IsLinux()) throw new InvalidOperationException("BACKUP_REQUIRES_LINUX");
        foreach (var path in new[] { DestinationRoot, DataProtectionRoot, EncryptionKeyFile })
            if ((File.GetUnixFileMode(path) & (UnixFileMode.GroupRead | UnixFileMode.GroupWrite | UnixFileMode.GroupExecute |
                    UnixFileMode.OtherRead | UnixFileMode.OtherWrite | UnixFileMode.OtherExecute)) != 0)
                throw new InvalidOperationException("BACKUP_PRIVATE_PERMISSIONS_REQUIRED");
        using (var key = BackupArchivePaths.OpenRead(EncryptionKeyFile))
            if (key.Length != 32) throw new InvalidOperationException("BACKUP_ENCRYPTION_KEY_INVALID");
    }
}
