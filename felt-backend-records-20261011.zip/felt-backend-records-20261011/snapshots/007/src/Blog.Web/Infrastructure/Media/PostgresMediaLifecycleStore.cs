using Blog.Web.Application.Media;
using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Blog.Web.Infrastructure.Media;

// Writes share the scoped context/transaction and the exact media row lock acquired by
// AdminMutationExecutor or MediaDeletionService. The immutable Trashed row is the durable
// file identity: no API may restore or alter it after a deletion job has been created.
public sealed class PostgresMediaLifecycleStore(BlogDbContext db) : IMediaLifecycleStore
{
    public Task<MediaAsset?> ReadTrackedAsync(Guid id, CancellationToken ct)
    { RequireTransaction(); return db.Set<MediaAsset>().SingleOrDefaultAsync(x => x.Id == id, ct); }
    public Task<MediaDeletionJob?> JobTrackedAsync(Guid mediaId, CancellationToken ct)
    { RequireTransaction(); return db.Set<MediaDeletionJob>().SingleOrDefaultAsync(x => x.MediaId == mediaId, ct); }
    public void Add(MediaDeletionJob job) { RequireTransaction(); db.Set<MediaDeletionJob>().Add(job); }

    public static IQueryable<MediaDeletionRead> DeletionQuery(IQueryable<MediaAsset> media, IQueryable<MediaDeletionJob> jobs, Guid id)
        => from m in media where m.Id == id
           join j in jobs on m.Id equals j.MediaId into matches
           from j in matches.DefaultIfEmpty()
           select new MediaDeletionRead(m, j);
    public Task<MediaDeletionRead?> ReadDeletionAsync(Guid mediaId, CancellationToken ct)
        => DeletionQuery(db.Set<MediaAsset>().AsNoTracking(), db.Set<MediaDeletionJob>().AsNoTracking(), mediaId).SingleOrDefaultAsync(ct);

    public static IQueryable<MediaDeletionCandidate> CandidateQuery(IQueryable<MediaDeletionJob> jobs, DateTimeOffset now)
        => jobs.Where(x => x.State == JobState.Pending || x.State == JobState.Leased && x.LeaseUntil <= now)
            .OrderBy(x => x.State == JobState.Leased ? 0 : 1).ThenBy(x => x.CreatedAt).ThenBy(x => x.MediaId)
            .Select(x => new MediaDeletionCandidate(x.Id, x.MediaId));
    public Task<MediaDeletionCandidate?> CandidateAsync(DateTimeOffset now, CancellationToken ct)
    { RequireTransaction(); return CandidateQuery(db.Set<MediaDeletionJob>().AsNoTracking(), now).FirstOrDefaultAsync(ct); }

    // No article/column state filters: Trashed articles and Archived columns retain references.
    // Covers are distinct foreign keys and unioned with body/video/poster reference rows.
    public static IQueryable<MediaReferenceRow> DraftsQuery(IQueryable<Article> articles, IQueryable<ArticleDraft> drafts,
        IQueryable<DraftMediaReference> references, Guid id)
    {
        var covers = from d in drafts join a in articles on d.ArticleId equals a.Id where d.CoverMediaId == id
                     select new { OwnerId = a.Id, d.Title, State = (short)a.State, Usage = (short)0 };
        var body = from r in references join d in drafts on r.ArticleId equals d.ArticleId
                   join a in articles on d.ArticleId equals a.Id where r.MediaId == id
                   select new { OwnerId = a.Id, d.Title, State = (short)a.State, Usage = (short)r.Usage };
        // Keep the UNION ALL entirely scalar/server-side; construct the public-safe row only
        // after the set operation so EF does not attempt a union after a client projection.
        return covers.Concat(body).Select(x => new MediaReferenceRow(x.OwnerId, x.Title, x.State, x.Usage, null, null, null, null, false));
    }
    public static IQueryable<MediaReferenceRow> RevisionsQuery(IQueryable<Article> articles, IQueryable<ArticleRevision> revisions,
        IQueryable<RevisionMediaReference> references, Guid id)
    {
        var covers = from r in revisions join a in articles on r.ArticleId equals a.Id where r.CoverMediaId == id
                     select new { OwnerId = a.Id, r.Title, State = (short)a.State, Usage = (short)0,
                         RevisionId = r.Id, r.RevisionNo, IsCurrent = a.PublishedRevisionId == r.Id };
        var body = from reference in references join r in revisions on reference.RevisionId equals r.Id
                   join a in articles on r.ArticleId equals a.Id where reference.MediaId == id
                   select new { OwnerId = a.Id, r.Title, State = (short)a.State, Usage = (short)reference.Usage,
                       RevisionId = r.Id, r.RevisionNo, IsCurrent = a.PublishedRevisionId == r.Id };
        return covers.Concat(body).Select(x => new MediaReferenceRow(x.OwnerId, x.Title, x.State, x.Usage,
            x.RevisionId, x.RevisionNo, null, null, x.IsCurrent));
    }
    public static IQueryable<MediaReferenceRow> ColumnsQuery(IQueryable<Column> columns, IQueryable<ColumnMediaSlot> slots, Guid id)
        => from s in slots join c in columns on s.ColumnId equals c.Id where s.MediaId == id
           select new MediaReferenceRow(c.Id, c.Name, (short)c.State, 0, null, null, s.Slot, null, false);
    public static IQueryable<MediaReferenceRow> GalleryQuery(IQueryable<GallerySlot> slots, Guid id)
        => slots.Where(x => x.MediaId == id).Select(x => new MediaReferenceRow(null, "", 0, 0, null, null, x.Slot, null, false));
    public static IQueryable<MediaReferenceRow> DesignQuery(IQueryable<DesignAssetSlot> slots, Guid id)
        => slots.Where(x => x.MediaId == id).Select(x => new MediaReferenceRow(null, "", 0, 0, null, null, null, x.Key, false));

    public static MediaReferences BuildReferences(Guid mediaId, IEnumerable<MediaReferenceRow> drafts, IEnumerable<MediaReferenceRow> revisions,
        IEnumerable<MediaReferenceRow> columns, IEnumerable<MediaReferenceRow> gallery, IEnumerable<MediaReferenceRow> design)
    {
        static string Usage(short usage) => usage == 0 ? "Cover" : ((MediaUsage)usage).ToString();
        return new(
            drafts.OrderBy(x => x.OwnerId).ThenBy(x => x.Usage).Select(x => new MediaReferenceItem(x.OwnerId, x.Title,
                ((ArticleState)x.State).ToString(), Usage(x.Usage), "DraftRetained", $"/admin/articles/{x.OwnerId:D}")).ToArray(),
            revisions.OrderBy(x => x.OwnerId).ThenByDescending(x => x.RevisionNo).ThenBy(x => x.Usage).Select(x => new MediaReferenceItem(x.OwnerId, x.Title,
                ((ArticleState)x.State).ToString(), Usage(x.Usage), x.IsCurrent ? "CurrentRevision" : "HistoricalRevision",
                $"/admin/articles/{x.OwnerId:D}/manage", x.RevisionId, x.RevisionNo, IsCurrent: x.IsCurrent)).ToArray(),
            columns.OrderBy(x => x.OwnerId).ThenBy(x => x.Slot).Select(x => new MediaReferenceItem(x.OwnerId, x.Title,
                ((ColumnState)x.State).ToString(), "ColumnImage", "ColumnRetained", $"/admin/columns/{x.OwnerId:D}", Slot: x.Slot)).ToArray(),
            gallery.OrderBy(x => x.Slot).Select(x => new MediaReferenceItem(null, "", "", "GalleryImage", "GalleryRetained", "/admin/home", Slot: x.Slot)).ToArray(),
            design.OrderBy(x => x.Key, StringComparer.Ordinal).Select(x => new MediaReferenceItem(null, "", "", "DesignImage", "FixedDesignAsset",
                $"/admin/media/{mediaId:D}/manage", Key: x.Key)).ToArray());
    }

    public async Task<MediaReferences> ReferencesAsync(Guid mediaId, CancellationToken ct)
    {
        RequireTransaction();
        var articles = db.Set<Article>().AsNoTracking();
        // Sequential queries deliberately share one context and the caller's media row lock.
        var drafts = await DraftsQuery(articles, db.Set<ArticleDraft>().AsNoTracking(), db.Set<DraftMediaReference>().AsNoTracking(), mediaId).ToListAsync(ct);
        var revisions = await RevisionsQuery(articles, db.Set<ArticleRevision>().AsNoTracking(), db.Set<RevisionMediaReference>().AsNoTracking(), mediaId).ToListAsync(ct);
        var columns = await ColumnsQuery(db.Set<Column>().AsNoTracking(), db.Set<ColumnMediaSlot>().AsNoTracking(), mediaId).ToListAsync(ct);
        var gallery = await GalleryQuery(db.Set<GallerySlot>().AsNoTracking(), mediaId).ToListAsync(ct);
        var design = await DesignQuery(db.Set<DesignAssetSlot>().AsNoTracking(), mediaId).ToListAsync(ct);
        return BuildReferences(mediaId, drafts, revisions, columns, gallery, design);
    }
    private void RequireTransaction()
    { if (db.Database.CurrentTransaction is null) throw new InvalidOperationException("MEDIA_LIFECYCLE_REQUIRES_TRANSACTION"); }
}
