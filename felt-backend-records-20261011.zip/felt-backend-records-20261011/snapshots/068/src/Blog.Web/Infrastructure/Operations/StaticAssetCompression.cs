using System.IO.Compression;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Options;
using Microsoft.Net.Http.Headers;

namespace Blog.Web.Infrastructure.Operations;

// Compression is an opt-in of the existing static-file response, not a new file
// route. In particular, the protected media provider and endpoints remain in charge.
public static class StaticAssetCompression
{
    private static readonly object EligibleResponse = new();
    private static readonly string[] MimeTypes = ["text/css", "text/javascript", "application/x-font-ttf"];

    public static IServiceCollection AddStaticAssetCompression(this IServiceCollection services)
    {
        services.AddResponseCompression(options =>
        {
            // Only the nonsecret source files explicitly opted in below can use
            // HTTPS compression. HTML, JSON and media never receive that opt-in.
            options.EnableForHttps = true;
            options.MimeTypes = MimeTypes;
            options.Providers.Add<BrotliCompressionProvider>();
            options.Providers.Add<GzipCompressionProvider>();
        });
        services.Configure<BrotliCompressionProviderOptions>(options => options.Level = CompressionLevel.Fastest);
        services.Configure<GzipCompressionProviderOptions>(options => options.Level = CompressionLevel.Fastest);
        services.Replace(ServiceDescriptor.Singleton<IResponseCompressionProvider>(provider =>
            new StaticOnlyCompressionProvider(provider, provider.GetRequiredService<IOptions<ResponseCompressionOptions>>())));
        return services;
    }

    // Place immediately before the existing UseStaticFiles call. Its
    // OnPrepareResponse must call PrepareResponse; omitting it fails closed.
    public static IApplicationBuilder UseStaticAssetCompression(this IApplicationBuilder app) => app.UseResponseCompression();

    public static void PrepareResponse(StaticFileResponseContext file)
    {
        var context = file.Context;
        var response = context.Response;
        if (!HttpMethods.IsGet(context.Request.Method) && !HttpMethods.IsHead(context.Request.Method)) return;
        if (response.StatusCode is not (StatusCodes.Status200OK or StatusCodes.Status206PartialContent or StatusCodes.Status304NotModified)) return;
        var expectedMime = Path.GetExtension(file.File.Name).ToLowerInvariant() switch
        {
            ".css" => "text/css",
            ".js" => "text/javascript",
            ".ttf" => "application/x-font-ttf",
            _ => null
        };
        if (expectedMime is null) return;
        if (response.StatusCode != StatusCodes.Status304NotModified && !string.Equals(response.ContentType, expectedMime, StringComparison.OrdinalIgnoreCase)) return;

        context.Items[EligibleResponse] = true;
        // Identity (including an absent Accept-Encoding) and conditional responses
        // must use the same cache key as compressed representations.
        var vary = response.Headers.GetCommaSeparatedValues(HeaderNames.Vary);
        if (!vary.Contains("*", StringComparer.Ordinal) && !vary.Contains(HeaderNames.AcceptEncoding, StringComparer.OrdinalIgnoreCase))
            response.Headers.AppendCommaSeparatedValues(HeaderNames.Vary, HeaderNames.AcceptEncoding);

        // A source-only strong ETag cannot also identify gzip/br bytes. Retain
        // Last-Modified for encoded revalidation and the original ETag for identity
        // and ranges. No request validator is rewritten or custom-parsed here.
        response.OnStarting(() =>
        {
            var encodedConditional = response.StatusCode == StatusCodes.Status304NotModified
                && !string.IsNullOrEmpty(context.Request.Headers.AcceptEncoding)
                && context.RequestServices.GetRequiredService<IResponseCompressionProvider>().GetCompressionProvider(context) is not null;
            if (response.Headers.ContainsKey(HeaderNames.ContentEncoding) || encodedConditional) response.Headers.Remove(HeaderNames.ETag);
            return Task.CompletedTask;
        });
    }

    private sealed class StaticOnlyCompressionProvider(IServiceProvider services, IOptions<ResponseCompressionOptions> options)
        : ResponseCompressionProvider(services, options)
    {
        public override bool ShouldCompressResponse(HttpContext context) =>
            context.Items.ContainsKey(EligibleResponse)
            && context.Response.StatusCode == StatusCodes.Status200OK
            && !context.Response.Headers.ContainsKey(HeaderNames.SetCookie)
            && context.Response.GetTypedHeaders().CacheControl is not { NoStore: true }
            && context.Response.GetTypedHeaders().CacheControl is not { Private: true }
            && base.ShouldCompressResponse(context);

        public override ICompressionProvider? GetCompressionProvider(HttpContext context)
        {
            var selected = base.GetCompressionProvider(context);
            // Explicit q=0 still forbids an encoding if a wildcard also names it.
            // Retain identity rather than risk sending an explicitly refused form.
            if (selected is not null && StringWithQualityHeaderValue.TryParseList(context.Request.Headers.AcceptEncoding, out var values)
                && values.Any(value => string.Equals(value.Value.Value, selected.EncodingName, StringComparison.OrdinalIgnoreCase)
                    && value.Quality == 0)) return null;
            return selected;
        }
    }
}
