import json
import re
from pathlib import Path

ROOT = Path('.')
OUT = ROOT / 'docs/development/f23'
OUT.mkdir(parents=True, exist_ok=True)
register = json.loads((ROOT / 'docs/development/acceptance-cases.json').read_text())
catalog = {}
names = {}

def suite(key, stem, source, layer, boundary, result=None, extra_sources=()):
    result = result or f'docs/development/f26/{stem}-results.json'
    payload = json.loads((ROOT / result).read_text())
    checks = next(payload[k] for k in ('checks', 'tests', 'results') if isinstance(payload.get(k), list))
    names[key] = [x['name'] for x in checks]
    catalog[key] = {
        'resultPath': result,
        'testSources': [source, *extra_sources],
        'toolLayer': layer,
        'recordedChecks': len(checks),
        'recordedFailures': sum(x.get('status') == 'failed' for x in checks),
        'evidenceBoundary': boundary,
        'freshRunByThisAudit': False,
    }

def log_suite(key, source, input_path, result_path, layer, boundary, prefix='PASS '):
    lines = (ROOT / input_path).read_text().splitlines()
    if prefix == 'tap':
        tests = [x[len('# Subtest: '):] for x in lines if x.startswith('# Subtest: ')]
    elif prefix == 'node':
        tests = [re.sub(r' \([0-9.]+ms\)$', '', x[2:]) for x in lines if x.startswith('✔ ')]
    elif prefix == 'unittest':
        tests = [x.split(' ', 1)[0] for x in lines if x.startswith('test_') and x.endswith(' ... ok')]
    else:
        tests = [x[len(prefix):] for x in lines if x.startswith(prefix)]
    assert tests, key
    names[key] = tests
    catalog[key] = {
        'resultPath': result_path,
        'testSources': source if isinstance(source, list) else [source],
        'toolLayer': layer,
        'recordedChecks': len(tests),
        'evidenceBoundary': boundary,
        'freshRunByThisAudit': False,
    }
    # Every selected recorded assertion must also exist in the durable linked log.
    linked = (ROOT / result_path).read_text()
    assert all(t in linked for t in tests), (key, 'linked log differs')

HTTP = 'ASP.NET Core TestServer / real routing, authentication, CSRF and service code; isolated in-memory persistence'
GRAPH = 'Production query/projection expressions on explicit in-memory graphs; closed Npgsql SQL translation'
DOM = 'Node + JSDOM; actual shipped modules with synthetic events, deterministic clock and mocked HTTP/browser services'
OFFLINE = 'EF PostgreSQL metadata / migration generation / closed-connection SQL inspection'
FILES = 'Real generated private files and native media tools; no production files or relational database'
DB_LIMIT = 'No live PostgreSQL connection, relational constraints, row locks, cross-process transaction or durability proof.'
DOM_LIMIT = 'No browser layout/compositor, native event/IME/clipboard/download behavior, accessibility tree or device proof.'

suite('ssr', 'ssr', 'tests/Blog.ComponentTests/Program.cs', 'TestServer Razor/HTTP with controlled query fixtures; CSS source assertions', 'The archived JSON has 93 pre-F24 cases. F24 adds four actual application checks documented separately. Controlled HTML and CSS declarations do not prove geometry, real glyphs or persisted publication.', extra_sources=['tests/Blog.ComponentTests/FixtureFactory.cs'])
suite('public', 'public-content', 'tests/Blog.PublicContentTests/Program.cs', HTTP + '; ' + GRAPH, 'The production facade is retained, but GraphPublicStore substitutes its persisted snapshot. A PostgreSql source label is not a database connection. ' + DB_LIMIT, extra_sources=['tests/Blog.PublicContentTests/PublicContentFixture.cs', 'tests/Blog.PublicContentTests/PublicGraph.cs'])
suite('motion', 'home-motion', 'tests/HomeMotion/motion.test.mjs', DOM, 'Geometry, image decode, WebAnimation, IntersectionObserver and native dialog are explicitly stubbed. Thirty mount/dispose cycles are not thirty real navigations. ' + DOM_LIMIT)
suite('navigation', 'navigation', 'tests/HomeMotion/navigation.test.mjs', DOM + '; pure legacy resolver', 'Injected navigation does not establish actual browser history, server redirects for fragments, or existence of mapped live content. ' + DOM_LIMIT)
suite('persistence', 'persistence', 'tests/Blog.PersistenceTests/Program.cs', OFFLINE + '; generated design-file preparation', 'Migration SQL, restrictive foreign keys, deferred guards and seeds are inspected, not applied to a database. ' + DB_LIMIT)
suite('article', 'article', 'tests/Blog.ArticleTests/Program.cs', HTTP + '; ' + OFFLINE, DB_LIMIT, extra_sources=['tests/Blog.ArticleTests/ArticleFixture.cs'])
suite('api', 'api-foundation', 'tests/Blog.ApiFoundationTests/Program.cs', HTTP + '; ' + OFFLINE, 'Concurrent requests share an explicit in-process transaction simulation. ' + DB_LIMIT, extra_sources=['tests/Blog.ApiFoundationTests/MutationFixture.cs'])
suite('security', 'security', 'tests/Blog.SecurityTests/Program.cs', 'TestServer real cookie/CSRF pipeline; fake security store and fake time; closed SQL translation', 'Cookie flags and signed-ticket handling are exercised in-process; persistence, native SameSite/cookie behavior and production HTTPS/proxy trust are unverified.', extra_sources=['tests/Blog.SecurityTests/SecurityFixture.cs'])
suite('preview', 'draft-workflow', 'tests/Blog.DraftWorkflowTests/Program.cs', HTTP + '; actual protected Razor preview', 'Exact-version safe HTML is rendered from an isolated store. Real concurrent PostgreSQL snapshots and native viewing remain unverified.')
suite('autosave', 'admin-autosave', 'tests/HomeMotion/admin-autosave.test.mjs', DOM, DOM_LIMIT)
suite('autosave_editor', 'admin-autosave-editor', 'tests/HomeMotion/admin-autosave-editor.test.mjs', DOM + '; actual shipped Tiptap bundle', 'The actual bundle does not turn JSDOM selections or synthetic composition into native caret, IME or clipboard proof. ' + DOM_LIMIT)
suite('publication', 'publication', 'tests/Blog.PublicationTests/Program.cs', HTTP + '; ' + OFFLINE, 'Clone/rollback fixture serializes requests; EF command preparation does not execute a commit. ' + DB_LIMIT, extra_sources=['tests/Blog.PublicationTests/PublicationFixture.cs'])
suite('publication_ui', 'admin-publication', 'tests/HomeMotion/admin-publication.test.mjs', DOM + '; final integration uses shipped Tiptap', DOM_LIMIT)
suite('schema', 'rich-text', 'tests/Blog.RichTextTests/Program.cs', 'Pure strict schema/canonical renderer; TestServer saves with isolated persistence', 'Rejected/encoded input and canonical JSON are component evidence. Native public/preview script execution, paste sources, stored PostgreSQL data and layout remain unverified.')
suite('home', 'home-configuration', 'tests/Blog.HomeConfigurationTests/Program.cs', HTTP + '; ' + GRAPH + '; EF command inspection', 'The fixture serializes its transactions with an in-process semaphore. Existing 42 checks have no exact competing third-slot home-PUT scenario. ' + DB_LIMIT, extra_sources=['tests/Blog.HomeConfigurationTests/HomeConfigurationFixture.cs'])
suite('home_ui', 'admin-home', 'tests/HomeMotion/admin-home.test.mjs', DOM, DOM_LIMIT)
suite('lifecycle', 'article-lifecycle', 'tests/Blog.ArticleLifecycleTests/Program.cs', HTTP + '; production media predicate over graph; ' + OFFLINE, DB_LIMIT, extra_sources=['tests/Blog.ArticleLifecycleTests/ArticleLifecycleFixture.cs'])
suite('lifecycle_ui', 'admin-article-lifecycle', 'tests/HomeMotion/admin-article-lifecycle.test.mjs', DOM, DOM_LIMIT)
suite('order', 'column-order', 'tests/Blog.ColumnOrderTests/Program.cs', HTTP + '; competing-state simulation; ' + OFFLINE, 'Parallel HTTP writers use fixture serialization; injected add/remove/move does not prove concurrent publication versus sorting in PostgreSQL. ' + DB_LIMIT, extra_sources=['tests/Blog.ColumnOrderTests/ColumnOrderFixture.cs'])
suite('column', 'column', 'tests/Blog.ColumnTests/Program.cs', HTTP + '; ' + OFFLINE, DB_LIMIT, extra_sources=['tests/Blog.ColumnTests/ColumnFixture.cs'])
suite('public_column', 'public-column', 'tests/Blog.PublicColumnTests/Program.cs', GRAPH, DB_LIMIT, extra_sources=['tests/Blog.PublicColumnTests/ColumnGraph.cs'])
suite('media_read', 'media-read', 'tests/Blog.MediaReadTests/Program.cs', 'TestServer real HTTP and generated private files; production visibility expression over EnumerableQuery; fake authentication store', 'Original 32 assertions are existing bounded evidence. The separately denied enhanced dynamic normalization/FileProvider probe remains blocked and was not retried. No deployed proxy/cache/static-root or PostgreSQL visibility proof.', extra_sources=['tests/Blog.MediaReadTests/MediaReadFixture.cs'])
suite('media_workflow', 'media-workflow', 'tests/Blog.MediaWorkflowTests/Program.cs', HTTP + '; generated private files; stub scanner/decoder; controlled fsync failures', 'Byte/quota caps and injected storage/commit failures are not an actual ENOSPC filesystem, network disconnect, live database outage or power-loss test. ' + DB_LIMIT, extra_sources=['tests/Blog.MediaWorkflowTests/MediaFixture.cs'])
suite('media_native', 'media-file', 'tests/Blog.MediaFileTests/Program.cs', FILES, 'The scanner/decoder and malformed harmless media fixtures are real. This does not establish deployed path permissions, available disk, production processor configuration or PostgreSQL rollback.', extra_sources=['tests/Blog.MediaFileTests/MediaFixtures.cs'])
suite('media_lifecycle', 'media-lifecycle', 'tests/Blog.MediaLifecycleTests/Program.cs', HTTP + '; reference/file identity simulation; ' + OFFLINE, 'Late references are inserted directly into the fixture; concurrent publication-versus-delete on one relational store is not executed. ' + DB_LIMIT, extra_sources=['tests/Blog.MediaLifecycleTests/MediaLifecycleFixture.cs'])
suite('media_lifecycle_files', 'media-lifecycle-file', 'tests/Blog.MediaLifecycleFileTests/Program.cs', 'Real disposable private-file identity, unlink and directory durability adapter', 'Physical deletion is limited to generated fixtures; not a production delete, power failure or database/file atomicity proof.')
suite('restart', 'restart-recovery', 'tests/Blog.RestartRecoveryTests/Program.cs', 'Service-graph reconstruction with generated JSON queue, real fixture files and receipt adapters', 'One assembly and simulated compatible code descriptors are reused; keys are ordinary explanatory key-marker bytes. No OS process restart, distinct-binary switch, PostgreSQL restart or actual Data Protection-key recovery.', extra_sources=['tests/Blog.RestartRecoveryTests/PersistedQueueFixture.cs', 'tests/Blog.RestartRecoveryTests/README.md'])
suite('backup_control', 'backup-control', 'tests/Blog.BackupControlTests/Program.cs', 'TestServer backup control, explicit capture/ledger fixtures, generated receipts', 'Generated capture and fake database restore handoff only; no PostgreSQL or production backup.', extra_sources=['tests/Blog.BackupControlTests/BackupKeyValidationCases.cs'])

log_suite('f24_accessibility', ['tests/HomeMotion/accessibility.test.mjs', 'tests/HomeMotion/admin-accessibility.test.mjs', 'tests/HomeMotion/compressed-artifacts.test.mjs'], 'docs/development/f24/node-output.txt', 'docs/development/f24/node-output.txt', DOM + '; static contrast arithmetic / artifact negative fixtures', 'Six ABOUT/contrast plus twenty admin-accessibility cases are among the 39 Node cases; the other thirteen are compressed-artifact cases. No whole-site WCAG or browser-memory result.', 'tap')
log_suite('editor', 'frontend/editor/tests/editor.test.mjs', 'docs/development/f22/editor-test-output.txt', 'docs/development/f22/editor-test-output.txt', 'Actual Tiptap in JSDOM with synthetic clipboard/keyboard and stub geometry', DOM_LIMIT, 'node')
log_suite('upload_ui', 'tests/HomeMotion/media-upload.test.mjs', 'docs/development/f22/media-upload-output.txt', 'docs/development/f22/media-upload-output.txt', DOM + '; XMLHttpRequest, hashing and polling stubs', 'Transport interruption is simulated; no live browser upload or dropped network connection.', 'PASS ')
for key, name, boundary in [
    ('maintenance', 'MaintenanceGate', 'Fake time and in-process request/worker admission; not distributed writer exclusion or crash durability.'),
    ('backup_archive', 'BackupArchive', 'Real generated encrypted archive/file integrity only. Generated PGDMP bytes are not a database dump; generated keys are not production key provisioning.'),
    ('backup_database', 'BackupDatabase', 'Fake native processes/metadata/isolation lease. No pg_dump/pg_restore is started, no PostgreSQL socket is opened, and no production isolation guard is implemented.'),
]:
    log_suite(key, f'tests/Blog.{name}Tests/Program.cs', f'artifacts/f25/{name}-output.txt', 'docs/development/f24/check-output.txt', 'Generated isolated component fixtures', boundary)
log_suite('health', 'tests/Blog.OperationsHealthTests/Program.cs', 'artifacts/f26/OperationsHealth-output.txt', 'docs/development/f24/check-output.txt', 'In-process health HTTP, fake database readiness and read-only generated private storage/key fixtures', 'Minimal health response and dependency failure contracts only. No actual systemd, network/TLS or production readiness claim.')
log_suite('release', 'tests/OperationsArtifacts/test_release_artifact.py', 'artifacts/f26/release-artifact-output.txt', 'docs/development/f24/check-output.txt', 'Python unittest with generated payload files and non-executable compatibility plans', 'Local release inventory, path safety and plan rejection only. No actual deployment, distinct-binary rollback or database/media restore.', 'unittest')

def evidence(key, *prefixes):
    selected = []
    for prefix in prefixes:
        matches = [name for name in names[key] if name.startswith(prefix)]
        assert matches, (key, prefix)
        for name in matches:
            if name not in selected:
                selected.append(name)
    return {'suite': key, 'exactRecordedTests': selected}

def spec(capability, implementation, ev, pg, browser, environment='', gaps=()):
    return {
        'implementedCapability': capability,
        'implementationPaths': implementation,
        'componentEvidence': ev,
        'remainingProof': {'postgresql': pg, 'browser': browser, 'environment': environment},
        'exactScenarioGaps': list(gaps),
    }

P = 'src/Blog.Web/'
paths = lambda *items: [P + x for x in items]
specs = {}
specs['V01'] = spec(
    'Empty-content SSR retains the five homepage sections; seed manifest has 19 approved design images and ten gallery slots, with no sample articles, columns or administrator.',
    paths('Pages/Index.cshtml', 'Application/Public/PublicContentService.cs', 'Infrastructure/Persistence/DesignSeedInitializer.cs'),
    [evidence('public', 'Actual facade reports PostgreSql and empty', 'Empty SSR homepage'), evidence('persistence', 'Seed catalog contains exactly', 'Seed rows contain no fake')],
    'Apply all migrations to a truly empty isolated PostgreSQL database; initialize approved private design bytes; read / and /articles through production repositories and verify zero user content.',
    'Five actual viewports with no-JS empty states and preserved first three scenes.',
    'Verify production-equivalent seed/configuration separation; destructive setup belongs only to an isolated target.')
specs['V02'] = spec(
    'Current immutable published JSON renders as server HTML with title, body, captured media and column links; public templates exclude the admin editor.',
    paths('Pages/Articles/Read.cshtml', 'Application/Public/PublicContentService.cs', 'Application/RichText/RichTextSchema.cs'),
    [evidence('public', 'Actual facade SSR renders canonical JSON body'), evidence('ssr', 'V02 component: readable article', 'F03 SSR: one H1')],
    'Create/publish through real PostgreSQL transactions and directly fetch the persisted URL through actual adapters.',
    'Disable JavaScript in native browsers and verify direct navigation, complete readable content and working column links.',
    'Verify deployed origin/status and response HTML; TestServer is not a listener or deployed host.')
specs['V03'] = spec(
    'Only an owned current Published revision is public; draft, withdrawn, trashed, purged and unknown URLs return 404 without private content.',
    paths('Application/Public/PublicContentService.cs', 'Infrastructure/Public/PostgresPublicContentStore.cs', 'Pages/Articles/Read.cshtml.cs'),
    [evidence('public', 'Only owned current Published revisions', 'SSR nonpublic publication state is HTTP 404:')],
    'Exercise real create/publish/withdraw/trash transitions and unknown slugs, then verify fresh anonymous reads and no title/body/media-list disclosure.',
    'Direct URLs and history/back/cache behavior after state changes.',
    'Verify no reverse-proxy caching resurrects previously public content.')
specs['V04'] = spec(
    'Homepage source retains ordered five sections, three characters, ten logical gallery works, English ABOUT, starfield and column cards; artwork/preservation hashes are recorded.',
    paths('Pages/Index.cshtml', 'Pages/Shared/Home/_About.cshtml', 'wwwroot/js/home/home.js'),
    [evidence('public', 'Empty SSR homepage'), evidence('motion', 'SSR structure:', 'ABOUT completes without'), evidence('f24_accessibility', 'Actual ABOUT template')],
    'Load the homepage from initialized PostgreSQL configuration and media rather than controlled graphs.',
    'Pixel/layout comparison at 1440×900, 1280×720, 390×844, 360×640 and 844×390 across required browsers, including short screens and the new ABOUT pause control.',
    'Protected-file equality is a source-preservation check, not rendered visual equivalence.')
specs['V05'] = spec(
    'Hero implements approximately three-second automatic cycles, staged depth animation and explicit hover/focus/manual/visibility/reduced-motion pause ownership.',
    paths('wwwroot/js/home/collectible.js', 'wwwroot/css/home/collectible.css'),
    [evidence('motion', 'Hero: nine automatic starts', 'Hero depth staging:', 'Hero: hover/focus/manual/pause/hidden/offscreen', 'Hero: failure fallback')],
    'No new relational behavior beyond V01/V04 seed/media integration.',
    'Observe multiple real animation cycles, crops/depth, decoded-image failure, native keyboard/touch controls and pause at every required viewport.',
    'Measure real loading/layout; all three high-priority hero PNGs total 6,699,338 bytes.')
specs['V06'] = spec(
    'Gallery has ten originals, hidden non-tabbable motion copies and a ten-item viewer with escaped attribution, previous/next and Escape handling.',
    paths('wwwroot/js/home/gallery.js', 'Pages/Shared/Home/_Gallery.cshtml'),
    [evidence('motion', 'Gallery:36px/s', 'Gallery viewer:', 'F21 viewer accepts HTTPS'), evidence('home', 'Gallery requires exactly ten', 'Distinct IDs with the same final bytes')],
    'Persist ten distinct final media hashes and display snapshots; verify the same ten current entries are read publicly.',
    'Inspect native accessibility tree/screen reader for duplicates; traverse all works, actual dialog modality, Escape and return focus to a visible surviving trigger.',
    'JSDOM showModal/close and focus are explicit stubs; no native focus-trap result exists.')
specs['V07'] = spec(
    'Reduced-motion, offscreen and hidden-page states pause continuous home effects; readable content and manual gallery access remain.',
    paths('wwwroot/js/home/home.js', 'wwwroot/js/home/about-stage.js', 'wwwroot/js/home/article-sky.js'),
    [evidence('motion', 'Visibility lifecycle pauses', 'Reduced motion:', 'Coarse pointer'), evidence('f24_accessibility', 'Reduced motion stops decoration', 'Decorative pause persists')],
    'No distinct PostgreSQL requirement beyond loading the current homepage.',
    'Change actual OS reduced-motion setting, hide/background tabs, scroll offscreen and return; verify manual controls and readable text on desktop/touch devices.',
    'Synthetic media queries and document.hidden cannot establish compositor/background scheduling.')
specs['V08'] = spec(
    'Featured content is a manually saved ordered selection of zero to three current publications; one or two selections remain one or two with no sample/latest backfill.',
    paths('Application/Home/HomeConfigurationService.cs', 'Infrastructure/Home/PostgresPublicHomeQueries.cs', 'Application/Public/PublicContentService.cs'),
    [evidence('public', 'Manual featured count 1 ', 'Manual featured count 2 '), evidence('home', 'Manual featured selection accepts zero through three'), evidence('home_ui', 'Manual featured candidates show current'), evidence('ssr', 'F02 SSR fixture: 1 selected articles; 0 columns', 'F02 SSR fixture: 2 selected articles; 0 columns')],
    'Save real home configuration after publishing exactly one/two articles; verify ordered current references and honest counts through production transactions.',
    'Inspect actual cards and reading links for one/two items at all five viewports.',
    'No production samples or automatic feature filling may be introduced.')
specs['V09'] = spec(
    'Display numerals and public queries support more than four articles/columns; lists paginate and homepage columns have no artificial four-item cap.',
    paths('Application/DisplayNumerals.cs', 'Infrastructure/Columns/PostgresPublicColumnQueries.cs', 'Application/Public/PublicContentService.cs'),
    [evidence('ssr', 'F02 SSR fixture: 3 selected articles; 12 columns'), evidence('public_column', 'Homepage supports arbitrary column count', 'Homepage SQL requires active'), evidence('public', 'Article list uses 12 rows')],
    'Persist at least five published articles and five active columns, including later pages; execute actual ordering/count queries.',
    'Inspect fifth/later numerals and SVG rendering, cards, overlap and links; check no undefined text or empty vector in real layout.',
    'Fixture count coverage and string assertions do not prove rasterized glyph/SVG appearance.')
specs['V10'] = spec(
    'Reading CSS bounds text/media and isolates code/table scroll regions; strict schema caps tables and takes dimensions only from trusted Ready media.',
    paths('wwwroot/css/content.css', 'Pages/Shared/_RichTextBody.cshtml', 'Application/RichText/RichTextSchema.cs'),
    [evidence('ssr', 'F03 keyboard/overflow structure:', 'F03 CSS source contracts:'), evidence('schema', 'Tables accept 1x1', 'Publication rendering takes image and video dimensions')],
    'Publish representative long Chinese, unbroken URL, table/code and portrait media through actual database-backed workflows.',
    'Measure actual page/control overflow at all five viewports plus 200%/400% zoom and text spacing; only intended code/table regions may scroll horizontally.',
    'F24 compression/preservation does not establish rendered overlap, CLS, image aspect ratio or LCP.')
specs['V11'] = spec(
    'Arbitrary reading text uses system/CJK fallbacks rather than the old partial font subset; schema and reading calculations accept supplementary CJK scalars.',
    paths('wwwroot/css/content.css', 'Application/RichText/RichTextSchema.cs', 'Application/ReadingDocument.cs'),
    [evidence('ssr', 'F03 SSR: one H1', 'F03 CSS source contracts:', 'F03 reading formula: 400 supplementary CJK'), evidence('schema', 'Unicode NFC and scalar limits')],
    'Persist and round-trip rare CJK and supplementary characters without normalization/collation truncation.',
    'Visually inspect actual glyph fallback on required desktop/mobile OS/browser versions with missing-font and font-network-failure conditions.',
    'Unicode text in HTML and CSS-family declarations do not prove installed fonts or absence of missing-glyph boxes.')
specs['V12'] = spec(
    'Column directory and adjacent reading links derive from the same current published ordered membership; endpoint navigation does not loop.',
    paths('Application/Columns/AdminColumnOrderService.cs', 'Infrastructure/Columns/PostgresPublicColumnQueries.cs', 'Application/Public/PublicContentService.cs'),
    [evidence('public_column', 'F16 singleton navigation', 'F16 directory and both navigation', 'F16 reordering changes navigation'), evidence('public', 'SSR hidden-home directory and boundary neighbors')],
    'Persist three publications, reorder via real CAS transaction, then compare directory/middle/first/last links through a consistent snapshot.',
    'Follow previous/next/directory links after reordering and verify no stale browser/proxy state.',
    'In-memory expression ordering is not proof of transaction isolation across real requests.')
specs['V13'] = spec(
    'Only H2/H3 create stable UUID anchors; repeated heading text remains uniquely addressable and documents without headings omit both TOCs.',
    paths('Application/RichText/RichTextSchema.cs', 'Application/ReadingDocument.cs', 'Pages/Articles/Read.cshtml'),
    [evidence('ssr', 'F03 TOC: repeated text', 'F03 no headings and no cover'), evidence('schema', 'Only H2/H3 are valid'), evidence('editor', 'DOM simulation: new headings and duplicated headings')],
    'Save/publish/reload repeated headings and no-heading bodies through real database state; preserve heading IDs across edits.',
    'Activate desktop/mobile TOC links and verify actual target, scrolling, sticky offsets and focus at all sizes.',
    'HTML ID/link equality cannot prove accurate native jump position.')
specs['V14'] = spec(
    'Explicit legacy-fragment mapping accepts local allowlisted targets, leaves unmapped samples retired and provides safe missing notices; fixed real-path aliases use HTTP 301.',
    paths('wwwroot/js/navigation/legacy-resolver.js', 'wwwroot/js/navigation/legacy-navigation.js', 'Application/SiteNavigation.cs'),
    [evidence('navigation', 'F04 production maps are empty', 'F04 invalid map target rejected https://', 'F04 DOM: exact target', 'F04 DOM: missing content notice'), evidence('ssr', 'F04 actual path: GET /about', 'F04 actual path: HEAD /knowledge')],
    'Any future explicit content mapping must point to an actually public owned current revision/Active column; production content maps are currently empty.',
    'Real legacy URLs, back/forward, hash change, reload, dismissal and native focus; fragment handling is client-side, never a claimed server 301.',
    'F22 cleanup and F24 decoded compressed-artifact scan establish local retirement only; inspect actual deployed output when authorized.')
specs['V15'] = spec(
    'Unknown/deleted resources return 404, active empty columns return readable zero states, invalid pages return 400 and beyond-last pages retain useful previous navigation.',
    paths('Pages/Articles/Index.cshtml.cs', 'Pages/Columns/Directory.cshtml.cs', 'Application/Public/PublicContentService.cs'),
    [evidence('public', 'SSR missing resources and filters', 'SSR out-of-range and maximum integer'), evidence('public_column', 'Active empty column remains valid'), evidence('ssr', 'F04 internal links:')],
    'Check real publication removal, column activation/archival, invalid query and pagination against persisted data.',
    'Follow empty-state/back/previous links and confirm navigation remains possible at browser boundaries.',
    'Verify externally observed status codes and no cached deleted body.')
specs['V16'] = spec(
    'Native controls/labels, skip/TOC regions, visible-focus CSS, dialog keyboard handlers, validation associations and cancellation focus restoration exist.',
    paths('wwwroot/css/content.css', 'wwwroot/js/home/gallery.js', 'wwwroot/js/admin/articles.js', 'wwwroot/js/admin/article-lifecycle.js', 'wwwroot/js/admin/media-lifecycle.js'),
    [evidence('ssr', 'F03 keyboard/overflow structure:'), evidence('motion', 'Gallery viewer:'), evidence('f24_accessibility', 'create HTTP 422 retains', 'article withdraw Cancel returns', 'media trash Cancel returns')],
    'Run authenticated native workflows against real saved content and real session persistence.',
    'Complete keyboard/AT traversal of public navigation, reading, all ten works, native dialog, login/editor/media/reorder/validation/recovery/Cancel; check order, visible focus, exit and restoration under zoom/forced colors/reduced motion.',
    'WCAG 2.2 AA needs automated rendered-page scan plus manual keyboard, screen reader and zoom; no accessibility-tree or native focus proof exists.')
specs['D01'] = spec(
    'Draft CAS requires its exact ETag; stale saves return 412; UI freezes and preserves complete local content until an explicit recovery decision.',
    paths('Application/Articles/AdminArticleService.cs', 'wwwroot/js/admin/articles.js'),
    [evidence('article', 'Two simulated editor tabs cannot overwrite'), evidence('autosave', '412 retains the whole local draft', 'Recovery JSON is gesture-only'), evidence('autosave_editor', 'Actual editor conflict freezes')],
    'Two independent connections save the same real draft version; prove one commit and one 412 with no overwriting, audit drift or partial reference change.',
    'Two native tabs, complete body/caret preservation and actual clipboard/download recovery; DOM stubs do not establish exports or native IME.',
    'Use isolated content and verify same authenticated owner/session boundaries.')
specs['D02'] = spec(
    'One-in-flight autosave drains all queued/newer input before publishing an exact confirmed draft version; composition blocks partial saves and publication.',
    paths('wwwroot/js/admin/articles.js', 'Application/Articles/PublicationService.cs'),
    [evidence('autosave', 'Only one save remains in flight'), evidence('publication_ui', 'Publishing flushes every queued edit', 'IME beginning during publication preparation'), evidence('publication', 'Saved working edits leave public snapshot')],
    'Delay actual save response/commit, issue publish and verify published immutable revision/hash equals the newest confirmed saved draft.',
    'Native typing/IME starts and ends during autosave/publish, delayed network and repeated clicks; no partial composition or stale-body publication.',
    'Synthetic compositionend and controllable promises are component scheduling evidence only.')
specs['D03'] = spec(
    'Publication stores its immutable result, ledger and audit atomically; explicit retry pins the original UUID/body/CAS and returns the same result before stale CAS checks.',
    paths('Application/Administration/AdminMutations.cs', 'Application/Articles/PublicationService.cs', 'wwwroot/js/admin/articles.js'),
    [evidence('api', 'Lost successful reply replays'), evidence('publication', 'Same-key retry replays original', 'Concurrent identical key serializes'), evidence('publication_ui', 'Unknown publication preserves the same UUID')],
    'Lose a real post-commit response, retry over separate connections/processes and verify exactly one revision, audit and key; test concurrent same-key and rollback boundaries.',
    'Native network interruption and explicit recovery/retry without changing the pinned request; newer unsaved content must survive.',
    'No actual transport response loss or durable ledger replay was exercised; injected failures/HTTP promise rejection are bounded substitutes.')
specs['D04'] = spec(
    'Working draft and immutable public pointer are separate; private preview requires live authentication and an exact saved draft version.',
    paths('Application/Articles/AdminArticleService.cs', 'Application/Articles/DraftPreviewService.cs', 'Application/Public/PublicContentService.cs'),
    [evidence('article', 'Published working edits preserve'), evidence('preview', 'Published article working preview', 'Authenticated preview is SSR'), evidence('public', 'Only owned current Published revisions')],
    'Publish, edit without publishing and compare public/preview reads from production repositories under real transactions.',
    'Independent anonymous and authenticated contexts; preview version mismatch, expired session and back/cache behavior.',
    'Verify no-store/proxy behavior prevents draft or previous preview disclosure.')
specs['D05'] = spec(
    'Publication revalidates title, actual body/schema, active column and all typed Ready media under dependency locks; failures return field-specific 422 and roll back all effects.',
    paths('Application/Articles/PublicationService.cs', 'Application/RichText/RichTextSchema.cs', 'wwwroot/js/admin/articles.js'),
    [evidence('publication', 'Publication revalidates title', 'Missing, wrong-kind, non-Ready', 'Failed update preserves prior revision'), evidence('schema', 'Invalid schema and missing media produce safe 422')],
    'Execute each invalid branch against PostgreSQL, checking old public revision, all references, directory, audit and ledger after rollback.',
    'Render actual field messages and verify accessible association/readability while complete local draft remains.',
    'Fixture clone rollback and EF batch preparation are not relational atomicity evidence.')
specs['D06'] = spec(
    'Home replacement requires SiteState CAS, at most three distinct currently published IDs and compact slots, with one aggregate transaction.',
    paths('Application/Home/HomeConfigurationService.cs', 'Infrastructure/Home/PostgresHomeConfigurationStore.cs', 'Infrastructure/Persistence/SchemaGuardsV1.cs'),
    [evidence('home', 'Site If-Match is required', 'Manual featured selection accepts zero through three', 'Featured IDs reject excess', 'Failure after clearing, gallery insertion')],
    'Run competing home saves through distinct connections with the same site version and different third items; verify at most one commit, exactly three unique slots and relational constraints.',
    'Two forms/tabs show correct conflict/reload behavior and preserve unsaved selection.',
    'Do not infer concurrency acceptance from validation or sequential stale-CAS tests.',
    ['At this audit snapshot the existing 42 HomeConfiguration checks contain no exact simultaneous third-slot allocation test. F23 supplemental work is not counted until executed evidence is attached.'])
specs['D07'] = spec(
    'Withdraw/trash clears the public pointer/membership and featured row in one state mutation; remaining featured positions compact and current public queries exclude removed content.',
    paths('Application/Articles/ArticleLifecycleService.cs', 'Infrastructure/Articles/PostgresArticleLifecycleStore.cs', 'Infrastructure/Home/PostgresPublicHomeQueries.cs'),
    [evidence('lifecycle', 'Withdrawal and trash remove middle', 'Directory, featured, audit, key and commit failures'), evidence('home', 'A committed withdrawal invalidates', 'Public featured graph excludes')],
    'Commit real withdraw and trash of featured publications; confirm fresh article/home/media reads share safe state and rollbacks retain all original references.',
    'Refresh/read through anonymous contexts and any open home editor; actual cards shrink without sample filling.',
    'Verify uncached deployed responses; no independently committed stale public feature remains.')
specs['D08'] = spec(
    'Full-list SiteState CAS reorders authoritative membership under ordered dependency locks; stale or changed membership yields 412/409 and failures roll back.',
    paths('Application/Columns/AdminColumnOrderService.cs', 'Infrastructure/Columns/PostgresAdminColumnOrderStore.cs', 'Application/Articles/PublicationService.cs'),
    [evidence('order', 'Competing committed add, removal and move', 'Parallel HTTP writers with one s ETag', 'Failures after audit insertion', 'Post-lock revalidation rejects')],
    'Interleave real article publication/move and column/member reorder across database connections; verify deferred uniqueness, no missing/duplicate member and no cross-column contamination.',
    'Native reorder and conflict recovery, including delayed/stale responses and keyboard order controls.',
    'Injected competing graph state plus simulated parallel ordering does not execute the real sort-versus-move race.')
specs['D09'] = spec(
    'Column archival rejects owned current Published revisions; draft/history-only references allow archive while identities and restrictive foreign keys remain.',
    paths('Application/Columns/AdminColumnService.cs', 'Infrastructure/Columns/PostgresAdminColumnStore.cs'),
    [evidence('column', 'Archive rejects an owned current', 'Draft, history, stale order', 'Every invalid transition returns 409'), evidence('persistence', 'All foreign keys restrict deletes')],
    'Archive in real PostgreSQL with published/draft/historical/wrong-owner states and simultaneous publication; verify 409 or safe archive with retained FKs.',
    'Actual admin error/archived state and public empty/404 transitions.',
    'Offline FK metadata is not proof that PostgreSQL enforces it.')
specs['D10'] = spec(
    'Trashed article restoration returns Draft, preserving slug, working content and history without restoring the public revision/featured membership.',
    paths('Application/Articles/ArticleLifecycleService.cs', 'wwwroot/js/admin/article-lifecycle.js'),
    [evidence('lifecycle', 'All fifteen lifecycle state/action', 'A never-published empty draft can be trashed'), evidence('lifecycle_ui', 'Trashed → restore → Draft'), evidence('public', 'SSR nonpublic publication state is HTTP 404: draft')],
    'Persist trash/restore for never-published and formerly published articles; verify unchanged content/slug and no public pointer, order or featured row.',
    'Actual confirmation/reload and anonymous direct URL; restoration must not publish without a later explicit publish.',
    'Keep historical revision copy-to-draft distinct from restoring an article out of Trash.')
specs['S01'] = spec(
    'Protected APIs authenticate before parsing/persistence and return JSON 401; management pages redirect locally; unknown APIs remain JSON 404.',
    paths('Infrastructure/Security/AdminSecurityHosting.cs', 'Api', 'Application/Security/AdminSecurity.cs'),
    [evidence('security', 'Anonymous protected APIs return JSON 401'), evidence('article', 'All six article API operations'), evidence('media_lifecycle', 'Anonymous references, deletion status'), evidence('api', 'Unknown API returns JSON 404', 'OpenAPI inventories exactly')],
    'Exercise the complete current OpenAPI route inventory with missing/revoked sessions and guessed IDs against actual security stores; verify no persistence or data disclosure.',
    'Actual login redirect, secure cookie/session and fetch handling without 200 login HTML at API routes.',
    'Include home, ordering, publish, lifecycle, media, purge and backup added after the original F06 suite; per-suite route guards are component coverage, not a deployed inventory scan.')
specs['S02'] = spec(
    'Cookie-authenticated writes and login require server antiforgery; Origin and Fetch Metadata provide additional checks before body spooling or state writes.',
    paths('Infrastructure/Security/AdminSecurityHosting.cs', 'Application/Security/AdminSecurity.cs', 'Api/Media'),
    [evidence('security', 'Login itself rejects missing', 'Cross-site Origin and Fetch Metadata', 'Authenticated logout requires CSRF'), evidence('media_workflow', 'HTTP missing, invalid and cross-origin CSRF')],
    'Real relational state remains byte/row-equivalent after rejected writes, including multipart and all mutations.',
    'Real cross-site forms/fetch, missing/invalid tokens, same-site distinctions and cookie sending under native browsers.',
    'Verify HTTPS/trusted proxy deployment and cookie attributes; SameSite headers in TestServer alone do not prove browser enforcement.')
specs['S03'] = spec(
    'Closed rich-text grammar rejects unknown active nodes/attrs and unsafe URLs; canonical renderer encodes text and publishes/previews only validated content.',
    paths('Application/RichText/RichTextSchema.cs', 'Application/RichText/RichTextUrl.cs') + ['frontend/editor/src/paste.mjs'],
    [evidence('schema', 'Unknown nodes, marks, properties', 'Links reject dangerous schemes', 'Image/video schemas extract'), evidence('editor', 'DOM simulation: safe HTML paste'), evidence('preview', 'Corrupt stored JSON or hash')],
    'Persist malicious boundary inputs and corrupted stored content in isolated PostgreSQL; verify rejects/422/no public revision and safe preview failures.',
    'Actual pasted script/onerror/javascript/unknown attrs in both preview and published pages, with execution/network sentinels and native clipboard sources.',
    'Encoded output and JSDOM are meaningful component protection evidence, not a browser script-execution or full security audit.')
specs['S04'] = spec(
    'Manifest/path/type/size checks precede admission; native scan/decode verifies actual signatures/content and safe outputs stay within private storage with bounded cleanup.',
    paths('Application/Media/MediaUploadService.cs', 'Infrastructure/Media/PrivateMediaStorage.cs', 'Infrastructure/Media/ToolMediaFileProcessor.cs'),
    [evidence('media_workflow', 'Manifest rejects path names', 'Storage paths reject traversal', 'HTTP rejects invalid file names'), evidence('media_native', 'MIME declarations must match', 'PNG with valid signature', 'Image 10 MiB and video 200 MiB')],
    'Verify reservation/job/idempotency/quota rollback and bounded temporary-file retention/cleanup with real PostgreSQL transactions.',
    'Native multipart upload, oversize selection/streaming, cancellation and UI failure preservation.',
    'Real generated-file/native-tool tests passed; verify deployed private root, permissions, capacity and scanner/decoder configuration. Cleanup can be safely deferred/charged on failure, never presented as immediate deletion.')
specs['S05'] = spec(
    'Anonymous media reads re-evaluate current references and Ready metadata before any file access; draft/history-only media are hidden for GET, HEAD, Range and conditionals.',
    paths('Infrastructure/Media/PostgresMediaReadStore.cs', 'Api/Media/ProtectedMediaEndpoints.cs', 'Infrastructure/Media/ProtectedStaticFiles.cs'),
    [evidence('media_read', 'Unreferenced draft cover draft body', 'Invisible requests do not resolve', 'Private object quarantine work', 'Approved legacy design URLs')],
    'Use actual persisted draft/private-reference graphs and production Npgsql visibility query; verify no bytes or metadata under all read variants.',
    'Native image/video requests, HEAD/Range/conditional/cache behavior on the authorized host.',
    'The separately denied enhanced normalization/FileProvider probe stays blocked, was not retried and cannot be treated as covered by original alias cases or F24 compression.')
specs['S06'] = spec(
    'Current shared publication references grant media access; withdrawing the last public reference hides all new requests while an already accepted stream may finish.',
    paths('Infrastructure/Media/PostgresMediaReadStore.cs', 'Application/Articles/ArticleLifecycleService.cs', 'Api/Media/ProtectedMediaEndpoints.cs'),
    [evidence('media_read', 'Shared current references survive one withdrawal', 'Already accepted stream may finish'), evidence('public', 'Actual media endpoint authorizes the same current'), evidence('lifecycle', 'The production public-media predicate revokes')],
    'Commit withdrawal from two actual published references in sequence and concurrently with reads; assert last-reference revocation across connections.',
    'New GET/HEAD/Range/conditional requests, native image/video playback and browser cache behavior after each withdrawal.',
    'Verify proxy/media responses are not cached; do not confuse permitted existing-stream completion with permission for new reads.')
specs['S07'] = spec(
    'Publication takes ordered media locks and rechecks Ready references; lifecycle/purge rechecks every reference under the same media row-lock contract and deletion keeps ownership through file removal.',
    paths('Application/Articles/PublicationService.cs', 'Application/Media/MediaLifecycleService.cs', 'Application/Media/MediaDeletionService.cs'),
    [evidence('publication', 'Site, article/draft, sorted old/new'), evidence('media_lifecycle', 'References committed immediately before', 'A reference appearing after admission', 'The media row lock remains held')],
    'Run actual publication-versus-trash/purge/delete races across real connections and task workers; verify safe winner, reference/FK integrity and no published broken media.',
    'Observe both administrative conflict feedback and resulting public media after the race.',
    'Source lock order, an in-process semaphore and injected references cannot establish PostgreSQL lock behavior.',
    ['Existing suites inject late references or race same-service operations; they do not execute publication and media deletion concurrently through one shared relational store.'])
specs['S08'] = spec(
    'Draft/UI recovery keeps local content on uncertain/failed writes; upload/processing/deletion use safe failure codes, bounded retries, leases, reservations and private orphan cleanup; readiness fails closed.',
    paths('wwwroot/js/admin/articles.js', 'Application/Media/MediaProcessingService.cs', 'Application/Media/MediaDeletionService.cs', 'Infrastructure/Operations/OperationsReadiness.cs'),
    [evidence('autosave', 'Network-unknown never automatically', 'HTTP 503 is an unknown outcome'), evidence('media_workflow', 'Database Ready-commit failure', 'HTTP quarantine directory fsync failure', 'Orphan sweep removes only'), evidence('media_native', 'Shared processing deadline kills'), evidence('media_lifecycle_files', 'Access-denied unlink', 'Directory fsync failure never completes'), evidence('upload_ui', 'A network-unknown retry reuses key')],
    'Safely fault an isolated real database at save/admission/Ready/deletion/backup commit boundaries; verify durable rollback/unknown-state reconciliation after recovery.',
    'Native interrupted upload/network loss, 401/412/503, unsaved draft recovery, clipboard/download and no false success.',
    'Exercise controlled actual storage-full/out-of-space, permission and processor outage scenarios in an approved isolated environment. Existing injected fsync/quota/process failures do not prove physical crash or ENOSPC handling.',
    ['No actual filesystem-full or live database/network outage end-to-end evidence was located.'])
specs['S09'] = spec(
    'Authentication uses bounded account/IP attempts, uniform public errors, idle/absolute session limits and server revocation on logout/reset/disable.',
    paths('Application/Security/AdminSecurity.cs', 'Infrastructure/Security/PostgresAdminSecurityStore.cs'),
    [evidence('security', 'Five consecutive wrong passwords', 'Unknown, wrong, disabled', 'IP limit allows 10', 'Logout revokes server row', 'Security store failure denies')],
    'Verify persisted lockout/time/session revocation and races across connections/process restarts; replay cookies after durable logout and account changes.',
    'Native cookie/CSRF behavior, expiry/re-login and copied-cookie replay through authorized HTTPS.',
    'Actual production key persistence, trusted proxy/IP configuration and secure administrator setup remain pending.')
specs['S10'] = spec(
    'Component capabilities include admission/drain/freeze, generated encrypted archive integrity, official PostgreSQL command adapters, isolated-restore contracts, durable receipt reconstruction, health checks and immutable release/compatibility planning.',
    paths('Application/Maintenance/MaintenanceCoordinator.cs', 'Infrastructure/Backup/BackupArchiveStore.cs', 'Infrastructure/Backup/PostgresBackupDatabase.cs', 'Infrastructure/Backup/IsolatedBackupRestoreService.cs', 'Infrastructure/Operations/OperationsReadiness.cs') + ['eng/operations/release_artifact.py'],
    [evidence('maintenance', 'Beginning maintenance consumes', 'Exactly five minutes'), evidence('backup_control', 'Accepted independent work must drain', 'Verified archive restore handoff'), evidence('backup_archive', 'Byte-exact multi-chunk capture', 'Synthetic PostgreSQL magic tests'), evidence('backup_database', 'Restore verifies file digest', 'Restore refuses missing isolation', 'Isolated fake restore holds'), evidence('restart', 'Post-release generated content, media and key-marker'), evidence('health', 'Real private-storage/DP adapter validates'), evidence('release', 'test_exact_compatible_plan_still_cannot_execute', 'test_fixture_backup_cannot_authorize_plan', 'test_plan_never_touches_new_content')],
    'Real pg_dump/pg_restore round trip, all migrations/constraints/sequences, content/media counts and hashes, order/drafts/current references, sessions and restored administrative login. No real restore has run.',
    'After actual isolated restart/redeploy/restore, run login/write/publish/anonymous read/upload and permission checks with real browser sessions.',
    'Implement/operator-provide external-writer isolation guard; use an authorized disposable target, persistent real DP keys/media, separate secrets/configuration, actual service restart/code switch and compatible distinct binaries. Production additionally requires explicit authorized host/domain/TLS, costs, backup/key destinations, alerts/ownership and release instruction. Off-host schedule/RPO≤24h/RTO≤4h remain unconfigured/unmeasured.',
    ['No production isolation-guard implementation or restore HTTP/CLI entry point exists in the adapter contract.', 'Generated PGDMP bytes and fake process adapters do not establish a database restore.', 'F26 graph reconstruction uses the same assembly and explanatory key-marker bytes; no real process restart, distinct-binary rollback or Data Protection key recovery.'])

for row in register:
    assert row['id'] in specs
    detail = specs[row['id']]
    detail.update({
        'id': row['id'],
        'givenWhen': row['givenWhen'],
        'expected': row['then'],
        'featureIds': row['featureIds'],
        'overallStatus': 'pending',
        'preproductionStatus': 'pending',
        'productionStatus': 'pending',
        'statusBasis': 'Existing component evidence is bounded; real acceptance has not been executed. No promotion by cumulative assertion count.',
    })

specs['S10']['substatus'] = {
    'isolated': {'status': 'pending', 'realDatabaseRestore': 'not_executed_blocked', 'realServiceRestartAndCompatibleRollback': 'not_executed', 'gate': 'F23', 'componentPassDoesNotClose': True},
    'production': {'status': 'pending', 'realDatabaseRestore': 'not_executed', 'deployment': 'not_authorized_or_executed_by_component_gates', 'gate': 'F27', 'componentPassDoesNotClose': True},
    'overall': 'pending',
}

document = {
    'schemaVersion': 1,
    'feature': 'F23',
    'auditDateUtc': '2026-10-10',
    'auditKind': 'read-only evidence and source audit; only these two new audit documents written',
    'reviewedProductCommit': 'da5093fcd39f080cccb345edf98861cae958f811',
    'authoritativeLatestComponentReview': 'docs/development/f24/INDEPENDENT-REVIEW.md',
    'independentCumulativeRunEvidence': 'artifacts/f24/independent-review/full-check.txt',
    'independentSourceVerification': 'artifacts/f24/independent-review/source-verification.json',
    'sourceContracts': ['docs/development/approved-plan.txt', 'docs/development/acceptance-cases.json', 'docs/development/tasks.json', 'TODOS.md'],
    'auditActions': {'applicationChanged': False, 'buildsRun': False, 'testsRun': False, 'listenersStarted': False, 'databaseAccessed': False, 'browserAccessed': False, 'remoteStateWritten': False, 'deniedF12ProbeRetried': False},
    'acceptanceSummary': {'total': 36, 'passed': 0, 'pending': 36, 'failedByThisAudit': 0, 'f23Gate': 'blocked_pending_real_environment_evidence', 'f27Gate': 'pending'},
    'statusRules': [
        'F24 independent component PASS at the reviewed commit is authoritative for that bounded scope; historical owner reports are not a later rejection.',
        'A successful component suite or cumulative shell chain is not a PostgreSQL integration, native browser, preproduction or production pass.',
        'F23 requires V01-V16, D01-D10 and S01-S09 real preproduction proof plus S10.isolated. S10.production and S10 overall remain pending until F27.',
        'A test title containing PostgreSql, real, concurrent, restore or restart must be read with its actual fixture/tool layer.',
        'No new F23 journey assertion/result is claimed here; append only actual executed supplemental evidence and preserve the original tool-layer limits.',
    ],
    'crossCuttingProof': {
        'postgresql': {'status': 'blocked', 'reason': 'Recorded PostgreSQL socket restriction; no retry or alternate-protocol workaround authorized in this audit.', 'needed': ['Real fresh migration apply and seed initialization', 'Constraint rejection, deferred triggers and immutable revision guards', 'Independent-connection CAS/idempotency/deadlock/rollback and media reference races', 'Production repository SQL execution and snapshot isolation', 'Actual backup/restore, physical persistence and recovery']},
        'browser': {'status': 'pending', 'viewports': ['1440x900', '1280x720', '390x844', '360x640', '844x390'], 'versions': 'Execution-time current and preceding stable Chrome, Edge, Firefox and Safari; also iOS Safari and Android Chrome. Record exact browser/OS/device versions.', 'needed': ['Native layout/compositor/font fallback and image-backed contrast', 'Native keyboard/touch/dialog and focus restoration', 'Accessibility tree, automated scan and manual screen reader/zoom for WCAG 2.2 AA', 'Actual IME, caret, native clipboard/paste/download and browser history/BFCache', 'JavaScript-disabled direct reading and native media playback/seeking', 'Real thirty-navigation listeners/timers and memory trend']},
        'performance': {'status': 'unmeasured', 'planChapter': 23, 'targets': {'LCP_ms': 2500, 'CLS': 0.1, 'INP_ms_when_measurable': 200, 'publicReadP95_ms': 300, 'saveP95_ms_excluding_media': 800, 'persistedArticleCount': 1000, 'concurrentReaders': 10}, 'conditions': 'Real preproduction device/network and warmed database; record machine specification. Lab data cannot be labelled real-user statistics.', 'heroPngBytes': 6699338, 'glassPngBytes': 4841450, 'assetEvidence': 'docs/development/f24/asset-size-report.json', 'staticCompressionPassIsCwvPass': False, 'publicBundleBoundaryIsNetworkTrace': False},
        'branchCoverage': {'status': 'not_measured', 'targetPercent': 85, 'basis': 'No instrumented branch-coverage report was located. Assertion counts are not coverage percentages; a failing safety/data-integrity case blocks release regardless of coverage.'},
        'f12ExtraProbe': {'status': 'blocked_not_retried', 'scope': 'Previously denied enhanced dynamic normalization/FileProvider probe', 'originalEvidence': 'docs/development/f26/media-read-results.json', 'rule': 'Original 32 bounded checks remain usable at their recorded scope; F24 static compression and artifact decoding do not replace the denied probe.'},
        'operations': {'isolatedRestore': 'not_executed', 'productionRestore': 'not_executed', 'offHostBackup': 'not_configured_or_verified', 'measuredRpoRto': False, 'actualCodeRollback': False, 'implementationPrerequisite': 'Operator-owned external-writer isolation guard and an approved disposable target are still required by the restore contract.', 'sources': ['tests/Blog.BackupDatabaseTests/README.md', 'tests/Blog.BackupArchiveTests/README.md', 'tests/Blog.RestartRecoveryTests/README.md', 'docs/development/f25/OPERATIONS.md', 'docs/development/f26/OPERATIONS.md']},
    },
    'f23SupplementalEvidence': [],
    'evidenceCatalog': catalog,
    'cases': [specs[row['id']] for row in register],
}

# Document integrity only: no application tests/builds or environmental probes.
assert len(specs) == len(register) == 36
assert {x['id'] for x in register} == {f'V{i:02}' for i in range(1,17)} | {f'D{i:02}' for i in range(1,11)} | {f'S{i:02}' for i in range(1,11)}
for suite_key, item in catalog.items():
    for path in [item['resultPath'], *item['testSources']]:
        assert (ROOT / path).exists(), (suite_key, path)
for case in specs.values():
    for path in case['implementationPaths']:
        assert (ROOT / path).exists(), (case['id'], path)
    for ref in case['componentEvidence']:
        assert set(ref['exactRecordedTests']) <= set(names[ref['suite']])
        catalog[ref['suite']]['usedByCases'] = sorted(set(catalog[ref['suite']].get('usedByCases', []) + [case['id']]))

(OUT / 'acceptance-evidence.json').write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n')

def link(path, label=None):
    # Markdown is in docs/development/f23, three directories below repo root.
    return f'[{label or path}](../../../{path})'

lines = [
    '# F23 acceptance evidence audit',
    '',
    'Audit date: 2026-10-10 UTC. Product baseline: `da5093fcd39f080cccb345edf98861cae958f811`.',
    '',
    '**All 36 overall acceptance cases remain pending. F23 is blocked/pending real environment evidence; F27 remains pending.** The latest ' + link('docs/development/f24/INDEPENDENT-REVIEW.md', 'F24 independent review') + ' is a PASS for bounded source, artifacts and component behavior. It does not establish PostgreSQL integration, native browser acceptance, actual restore, preproduction readiness or production approval.',
    '',
    'This audit read contracts, actual test/fixture sources and existing result files. It ran no build, test, listener, database or browser and made no application or remote change. The forbidden PostgreSQL socket path and separately denied enhanced F12 normalization/FileProvider probe were not retried. Only this report and its machine-readable companion were created.',
    '',
    'Machine-readable mapping: [acceptance-evidence.json](acceptance-evidence.json). The map includes all V01–V16, D01–D10 and S01–S10, exact recorded assertion names, actual test sources/tool layers, implementation paths and outstanding proof. No F23 journey result is pre-counted; later executed evidence must be appended with its own scope.',
    '',
    '## Evidence interpretation',
    '',
    '- TestServer executes the actual ASP.NET HTTP pipeline in-process. Its graph/dictionary stores are substitutes for PostgreSQL; semaphore serialization and clone rollback do not prove relational locks or durability.',
    '- Closed Npgsql query translation, EF command preparation and generated migration SQL do not apply migrations or execute a database transaction.',
    '- JSDOM uses fake geometry, synthetic keyboard/composition, stub native dialog, clipboard/download/navigation and controlled HTTP. Actual shipped Tiptap still runs in that simulated environment.',
    '- Real native scanner/decoder and private-file tests exercise disposable generated bytes. They do not prove production root permissions, full-disk behavior or database/file atomicity.',
    '- Generated archive recovery checks byte/hash/encryption integrity. Fake PGDMP content and fake pg_dump/pg_restore adapters are not a database backup/restore.',
    '- F26 reconstructs services using JSON queues and ordinary key-marker bytes. It does not restart an OS service, switch distinct binaries or restore actual Data Protection keys.',
    '',
    'The independent F24 cumulative execution is retained at ' + link(document['independentCumulativeRunEvidence']) + '; its source verification is ' + link(document['independentSourceVerification']) + '. The case links below deliberately point to specific archived assertions, not an invented sum of every cumulative rerun.',
    '',
    '## Material missing proof',
    '',
    '1. Real PostgreSQL migration/seed, constraint, query, independent-connection concurrency, rollback and restore evidence is blocked by the recorded runtime restriction.',
    '2. No actual five-viewport/cross-browser/AT acceptance exists. Required sizes are 1440×900, 1280×720, 390×844, 360×640 and 844×390. Record execution-time current and previous stable Chrome/Edge/Firefox/Safari plus iOS Safari/Android Chrome versions.',
    '3. Native keyboard/focus/dialog, touch, IME/caret, clipboard/paste/download, glyph fallback, JavaScript-disabled navigation, media playback, history/BFCache and actual accessibility-tree/zoom checks remain pending. Synthetic events do not close these items.',
    '4. Chapter 23 targets remain unmeasured: LCP ≤2.5 s, CLS ≤0.1, measurable INP ≤200 ms; warmed 1,000-article/10-reader PostgreSQL public-read p95 ≤300 ms and save p95 ≤800 ms, excluding media processing. Thirty component disposal cycles do not establish thirty real navigations or memory stability.',
    '5. The preserved high-priority hero PNGs total **6,699,338 bytes**; the four glass PNGs add **4,841,450 bytes**. ' + link('docs/development/f24/asset-size-report.json', 'Static sizes') + ' and passing gzip/Brotli checks are not measured transfer, LCP or CLS. Public module inspection is not a browser network trace.',
    '6. The existing 42 HomeConfiguration checks lack D06’s exact simultaneous competing third-slot save. S07 uses lock contracts and injected references, not concurrent publication versus deletion on one relational store. New F23 component journeys must be labelled as such when executed.',
    '7. S08 uses controlled failure injection, limits and native-process failures. No actual filesystem-full/live database outage/dropped network end-to-end evidence was located.',
    '8. Both S10.isolated and S10.production real restores are untested. The PostgreSQL restore adapter also lacks the production external-writer isolation guard and a wired restore HTTP/CLI entry point. F26 simulated code descriptors use one assembly and non-cryptographic key markers.',
    '9. No instrumented report establishes the proposed 85% core business branch-coverage target. Passing assertion counts do not establish that percentage.',
    '',
    'F24’s ' + link('docs/development/f24/ACCESSIBILITY-AUDIT.md', 'accessibility audit') + ' also calls out unmeasured image/gradient-backed contrast, potential rapid keyboard traversal before article reveal, new ABOUT-control placement and content-dependent video captions/transcripts. These are open native/content checks, not declared source-test failures.',
    '',
    '## Gate boundary and S10 split',
    '',
    '| Gate/case | Current status | Required completion evidence |',
    '| --- | --- | --- |',
    '| F23 | Blocked/pending | Real preproduction V01–V16, D01–D10, S01–S09 plus S10.isolated, required browser evidence and closure of blocking defects |',
    '| S10.isolated | Pending; real DB restore blocked/unexecuted | Approved disposable target, external-writer exclusion, real PostgreSQL backup/restore, hashes/counts/keys/login/permissions and actual restart/redeploy/compatible rollback |',
    '| S10.production | Pending; real restore unexecuted | Authorized production host/domain/TLS/budget/destinations/ownership, explicit release instruction and actual production persistence/restore evidence under F27 |',
    '| S10 overall / F27 | Pending | Both environment-specific evidence sets and final release conditions; F23 approval alone never grants production permission |',
    '',
    'Off-host backup scheduling, controlled real key provisioning, RPO ≤24 h and RTO ≤4 h remain unconfigured or unmeasured. The immutable local publish and non-executable deployment plan are artifacts, not an executed deployment. See ' + link('tests/Blog.BackupDatabaseTests/README.md', 'database adapter boundaries') + ', ' + link('tests/Blog.BackupArchiveTests/README.md', 'archive boundaries') + ' and ' + link('tests/Blog.RestartRecoveryTests/README.md', 'restart boundaries') + '.',
    '',
    '## Evidence catalog: source and actual tool layer',
    '',
    'Every case below references these suite IDs. The exact recorded assertion is not broader than its catalog boundary. The JSON includes every fixture source and the recorded suite counts; those counts are never an acceptance score.',
    '',
    '| Suite | Recorded evidence and test sources | Actual tool layer and boundary |',
    '| --- | --- | --- |',
]
for key, item in catalog.items():
    sources = ', '.join(link(p) for p in item['testSources'])
    lines.append(f"| {key} | {link(item['resultPath'], 'Recorded result')}; {sources} | {item['toolLayer']}. {item['evidenceBoundary']} |")
lines += ['', '## Case-by-case mapping']
for row in register:
    case = specs[row['id']]
    lines += ['', f"### {case['id']} — pending", '', f"**Contract:** {case['givenWhen']} → {case['expected']}", '', '**Implemented capability:** ' + case['implementedCapability'], '', '**Exact existing component evidence:**', '']
    for ref in case['componentEvidence']:
        item = catalog[ref['suite']]
        labels = '; '.join('“' + x + '”' for x in ref['exactRecordedTests'])
        lines.append(f"- {link(item['resultPath'], ref['suite'])}: {labels}.")
    lines += ['', '**Still required:**', '', '- PostgreSQL: ' + case['remainingProof']['postgresql'], '- Browser: ' + case['remainingProof']['browser'], '- Environment/limits: ' + case['remainingProof']['environment']]
    for gap in case['exactScenarioGaps']:
        lines.append('- Exact scenario gap: ' + gap)
    if case['id'] == 'S10':
        lines += ['- S10.isolated = pending; S10.production = pending; S10 overall = pending. Neither real database restore was executed.']
    lines += ['', 'Implementation: ' + ', '.join(link(p) for p in case['implementationPaths']) + '.']

lines += ['', '## Audit provenance and maintenance', '',
    'The JSON evidence catalog records source paths and fixture limits for every cited suite. Test names were selected from existing recorded results, and all linked local paths were checked for existence while writing these documents. These are document-integrity checks only; no application suite was run by this audit.', '',
    'When adding F23 evidence, preserve exact command/run target, product commit, actual tool layer, failed attempts and residual limitations. Do not upgrade overall statuses by copying a component PASS or by counting repeated cumulative assertions. Independently verify real evidence before changing the acceptance register. The authoritative latest F24 independent record supersedes its earlier owner-review-pending text; transient bookkeeping updates are not permanent acceptance gaps.', '']
(OUT / 'ACCEPTANCE-EVIDENCE.md').write_text('\n'.join(lines))
print(json.dumps({'cases': len(document['cases']), 'suites': len(catalog), 'status': '36 pending', 'json': str(OUT / 'acceptance-evidence.json'), 'markdown': str(OUT / 'ACCEPTANCE-EVIDENCE.md')}, ensure_ascii=False))
