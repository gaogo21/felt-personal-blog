import { MEDIA_LIMITS } from './media-limits.js';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const stateNames = { Draft: '草稿', Active: '公开', Archived: '归档' };
const clone = value => JSON.parse(JSON.stringify(value));
const equal = (left, right) => JSON.stringify(left) === JSON.stringify(right);
const positive = value => Number.isSafeInteger(value) && value > 0;
const textFields = ['name', 'slug', 'introduction'];
const dateValid = value => typeof value === 'string' && !Number.isNaN(new Date(value).getTime());
const validItem = value => value && UUID.test(value.id) && Object.hasOwn(stateNames, value.state)
  && textFields.every(key => typeof value[key] === 'string') && typeof value.showOnHome === 'boolean'
  && Number.isSafeInteger(value.publishedArticleCount) && value.publishedArticleCount >= 0
  && positive(value.columnVersion) && value.columnEtag === `"c-${value.id}-${value.columnVersion}"`
  && dateValid(value.updatedAt) && (value.activatedAt === null || dateValid(value.activatedAt));
const validSite = value => positive(value.siteVersion) && value.siteEtag === `"s-1-${value.siteVersion}"`;
const validColumn = value => validItem(value) && validSite(value) && Array.isArray(value.media) && value.media.length <= 3
  && (value.state !== 'Active' || (value.media.length === 3 && Boolean(value.name.trim())))
  && value.media.every((item, index) => item.slot === index + 1 && UUID.test(item.mediaId) && item.displayMeta
    && ['alt', 'caption', 'credit', 'sourceUrl', 'licenseName', 'licenseUrl'].every(key => typeof item.displayMeta[key] === 'string'))
  && new Set(value.media.map(item => item.mediaId.toLowerCase())).size === value.media.length;
const rawFromServer = value => ({ name: value.name, slug: value.slug, introduction: value.introduction,
  showOnHome: value.showOnHome, media: value.media.map(item => ({ mediaId: item.mediaId, displayMeta: clone(item.displayMeta) })) });

/** Explicit, memory-only forms. Every write is independently validated by the server. */
export function createColumnAdmin(root, { fetchImpl = globalThis.fetch, loadMediaLibrary = () => import('./media-library.js') } = {}) {
  const abort = new AbortController(), eventOptions = { signal: abort.signal };
  const $ = selector => root.querySelector(selector), form = $('[data-column-form]');
  const editing = root.dataset.columnAdmin === 'edit', id = root.dataset.columnId?.toLowerCase();
  let disposed = false, busy = false, loaded = !editing, pause = null, server = null, fresh = null, attempt = null;
  let revision = 0, readSerial = 0, listSerial = 0, pickerSerial = 0, writeEpoch = 0, page = 1, total = 0;
  let library = null, baseline = null, reviewRevision = null;
  let slots = [null, null, null];
  const request = (path, init = {}) => fetchImpl(`/api/admin/v1${path}`, { credentials: 'same-origin', cache: 'no-store', signal: abort.signal, ...init });
  const say = (state, text) => { if (!disposed) { root.dataset.saveState = state; $('[data-status]').textContent = text; } };
  const raw = () => ({ ...Object.fromEntries(textFields.map(key => [key, form.elements[key].value])),
    showOnHome: form.elements.showOnHome.checked, media: slots.filter(Boolean).map(clone) });
  baseline = raw();
  const dirty = () => !equal(raw(), baseline);
  const frozen = () => pause !== null;
  const pending = () => busy || dirty() || Boolean(attempt) || Boolean(library?.hasPending());
  const canEdit = () => loaded && !frozen() && (!editing || server?.state !== 'Archived');
  function controls() {
    if (disposed) return;
    for (const key of textFields) {
      form.elements[key].disabled = !loaded || (editing && server?.state === 'Archived');
      form.elements[key].readOnly = frozen() || (!editing && busy) || (editing && key === 'slug' && Boolean(server?.activatedAt));
    }
    form.elements.showOnHome.disabled = !canEdit() || (!editing && busy);
    const submit = $('[data-save]') || $('[data-create]'); submit.disabled = !canEdit() || busy;
    $('[data-reload]').disabled = busy;
    const retry = $('[data-retry]'); retry.hidden = pause !== 'unknown' || !attempt?.key; retry.disabled = busy;
    $('[data-review]').hidden = !fresh;
    $('[data-keep-local]').disabled = busy || !fresh || (!editing && Boolean(attempt));
    if ($('[data-use-server]')) $('[data-use-server]').disabled = busy || !fresh;
    for (const button of root.querySelectorAll('[data-slot-action]')) button.disabled = !canEdit() || busy || button.dataset.unavailable === 'true';
    library?.setEnabled(canEdit() && !busy);
    if (editing) {
      for (const button of root.querySelectorAll('[data-action]')) {
        const action = button.dataset.action;
        button.hidden = action === 'activate' ? server?.state !== 'Draft' : action === 'archive' ? server?.state !== 'Active' : server?.state !== 'Archived';
        button.disabled = !loaded || busy || frozen() || dirty() || Boolean(library?.hasPending())
          || (action === 'archive' && server?.publishedArticleCount !== 0);
      }
      if (server) {
        $('[data-identity]').textContent = `${stateNames[server.state]} · 当前已发布文章 ${server.publishedArticleCount} 篇 · ${server.slug}`;
        $('[data-version]').textContent = `专栏版本 ${server.columnVersion} · 站点版本 ${server.siteVersion} · 保存时间（UTC）${new Date(server.updatedAt).toISOString()}`;
        $('[data-slug-help]').textContent = server.activatedAt ? '首次激活后地址已永久冻结；归档恢复也不解冻。' : '可使用小写字母、数字和单连字符；首次激活后地址永久冻结。';
        $('[data-action-help]').textContent = server.state === 'Archived' ? '已归档，需先恢复为草稿才能编辑。'
          : server.state === 'Active' && server.publishedArticleCount > 0 ? `仍有 ${server.publishedArticleCount} 篇已发布文章，不能归档。`
            : dirty() ? '本页有未保存修改，请先保存并应用。' : '';
      }
    }
  }
  function renderSlots() {
    if (!editing || disposed) return;
    $('[data-slots]').replaceChildren(...slots.map((slot, index) => {
      const item = document.createElement('li'); item.className = 'column-slot';
      const heading = document.createElement('h3'); heading.textContent = `图片 ${index + 1}`; item.append(heading);
      if (slot) { const image = document.createElement('img'); image.src = `/media/${slot.mediaId}`; image.alt = slot.displayMeta.alt; item.append(image); }
      const description = document.createElement('p'); description.textContent = slot ? slot.displayMeta.alt || '尚无替代文字' : '尚未选择图片'; item.append(description);
      const actions = document.createElement('div'); actions.className = 'column-actions';
      for (const [action, label, unavailable] of [['choose', slot ? '更换图片' : '选择图片', false], ['remove', '移除此图', !slot], ['left', '前移一格', index === 0], ['right', '后移一格', index === 2]]) {
        const button = document.createElement('button'); button.type = 'button'; button.dataset.slot = String(index); button.dataset.slotAction = action;
        button.dataset.unavailable = String(unavailable); button.textContent = label; button.setAttribute('aria-label', `图片 ${index + 1}：${label}`); actions.append(button);
      }
      item.append(actions); return item;
    })); controls();
  }
  function fill(value) {
    for (const key of textFields) form.elements[key].value = value[key];
    form.elements.showOnHome.checked = value.showOnHome;
    slots = [...value.media.map(item => ({ mediaId: item.mediaId, displayMeta: clone(item.displayMeta) }))];
    while (slots.length < 3) slots.push(null);
    baseline = raw(); revision++; pickerSerial++; renderSlots();
  }
  function edited() {
    if (disposed) return;
    revision++; pickerSerial++; fresh = null;
    if (!frozen()) say('dirty', '修改尚未保存。点击“保存并应用”后生效。');
    controls();
  }
  function freeze(reason, text) { pause = reason; fresh = null; pickerSerial++; writeEpoch++; say(reason, text); controls(); }
  async function failure(response, writing, writeContext = null) {
    let problem = null; try { problem = await response.json(); } catch { /* Status remains authoritative. */ }
    if (disposed) return;
    if (writing && writeContext && writeContext.epoch !== writeEpoch) {
      // Reading an error body can finish after a newer auth/conflict signal.
      // Settle only this request; never release or replace the newer freeze.
      if (attempt === writeContext.attempt) {
        if (response.status >= 500) attempt.uncertain = true;
        else if (!attempt.uncertain || ![401, 403].includes(response.status)) attempt = null;
      }
      controls(); return;
    }
    const detail = typeof problem?.detail === 'string' ? ` ${problem.detail}` : '';
    if (response.status === 401 || response.status === 403) {
      if (!attempt?.uncertain) attempt = null;
      freeze('auth', '会话或防伪验证已失效。当前输入已保留，写入暂停；请在新标签页登录，再读取服务器版本并明确选择继续。');
    } else if (response.status === 412 || response.status === 428) {
      attempt = null;
      freeze('conflict', '专栏版本已变化，当前输入已保留。请读取服务器版本，核对后明确选择；不会自动覆盖。');
    } else if (writing && response.status >= 500) {
      if (attempt) attempt.uncertain = true;
      freeze('unknown', '请求结果尚未确认，当前输入已保留，写入暂停。请读取服务器版本核对；有重试按钮时，可用相同请求标识确认原请求。');
    } else if (writing) {
      attempt = null; pause = null;
      say('error', `操作未成功（HTTP ${response.status}）。${response.status === 409 ? '请检查当前状态、地址是否重复及图片是否仍可用。' : '请检查输入和图片选择。'}${detail} 当前输入已保留。`); controls();
    } else {
      freeze(pause || 'review', `无法读取服务器版本（HTTP ${response.status}）。${detail} 当前输入已保留，写入暂停；请重新读取。`);
    }
  }
  async function session() {
    const response = await request('/session/bootstrap');
    if (!response.ok) { await failure(response, false); return null; }
    const value = await response.json();
    if (!value.session?.user?.id || typeof value.csrfToken !== 'string' || !value.csrfToken) {
      freeze('auth', '尚未确认有效登录。当前输入已保留，请登录后重新读取。'); return null;
    }
    return value;
  }
  function payload() {
    const value = raw();
    for (const [key, limit] of [['name', MEDIA_LIMITS.ColumnNameScalars], ['slug', MEDIA_LIMITS.SlugScalars], ['introduction', MEDIA_LIMITS.SummaryScalars]]) {
      value[key] = value[key].normalize('NFC');
      if (/\p{Surrogate}/u.test(value[key]) || Array.from(value[key]).length > limit) throw new Error(`${key === 'name' ? '名称' : key === 'slug' ? '地址标识' : '介绍'}最多 ${limit} 个字符，且不能包含无效字符。`);
    }
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value.slug)) throw new Error('地址标识需使用小写字母、数字和单连字符，不能以连字符开头或结尾。');
    if (editing && server?.state === 'Active' && (!value.name.trim() || value.media.length !== 3)) throw new Error('公开专栏必须有名称和三张图片。');
    const mediaIds = value.media.map(item => item.mediaId);
    if (new Set(mediaIds.map(item => item.toLowerCase())).size !== mediaIds.length) throw new Error('三张图片不能重复，请重新选择。');
    const body = { name: value.name, slug: value.slug, introduction: value.introduction, showOnHome: value.showOnHome };
    return editing ? { ...body, mediaIds } : body;
  }
  async function execute(current) {
    if (disposed || busy) return;
    const epoch = writeEpoch;
    busy = true; fresh = null; attempt = current; pickerSerial++; controls(); say('saving', current.action === 'save' ? '正在保存并应用…' : '正在提交，请等待服务器确认…');
    try {
      const context = await session(); if (!context || disposed || epoch !== writeEpoch) return;
      const headers = { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': context.csrfToken };
      if (current.etag) headers['If-Match'] = current.etag;
      if (current.key) headers['Idempotency-Key'] = current.key;
      const response = await request(current.path, { method: current.method, headers, body: current.body });
      if (disposed) return;
      if (!response.ok) { await failure(response, true, { epoch, attempt: current }); return; }
      const result = await response.json();
      if (!validColumn(result) || (editing && result.id !== id) || (editing && result.columnVersion < server.columnVersion)) throw new Error('无法确认服务器返回的专栏版本。');
      if (disposed) return;
      if (epoch !== writeEpoch) {
        attempt = null;
        if (editing) { server = clone(result); baseline = rawFromServer(result); }
        // A later auth/conflict signal still requires an explicit reconciliation.
        return;
      }
      attempt = null; pause = null; fresh = null;
      if (editing) {
        server = clone(result); baseline = rawFromServer(result);
        if (revision === current.revision && equal(raw(), current.raw)) fill(result);
        say(dirty() ? 'dirty' : 'saved', dirty() ? '服务器已确认提交的版本；较新输入仍在本页，尚未保存。'
          : current.action === 'activate' ? '专栏已激活并公开。' : current.action === 'archive' ? '专栏已归档，不再公开。'
            : current.action === 'restore' ? '已恢复为草稿，尚未公开。' : '专栏已保存并应用。');
      } else {
        const created = $('[data-created]'); created.hidden = false;
        const link = document.createElement('a'); link.href = `/admin/columns/${result.id}`; link.textContent = `编辑新专栏：${result.name || result.slug}`; created.replaceChildren(link);
        if (revision === current.revision && equal(raw(), current.raw)) {
          form.reset(); baseline = raw(); revision++;
          say('saved', '草稿专栏已创建。打开编辑页选择图片，再明确激活。');
        } else say('dirty', '草稿专栏已创建；提交之后的较新输入仍保留，尚未创建。');
        void loadList();
      }
    } catch (error) {
      if (!disposed) { current.uncertain = true; freeze('unknown', '请求结果尚未确认，当前输入已保留，写入暂停。请读取服务器版本核对；可重试的状态操作会沿用原请求标识。'); }
    } finally { busy = false; controls(); }
  }
  async function submit(action = editing ? 'save' : 'create') {
    if (disposed || busy || !loaded || frozen()) return;
    if (editing && action === 'save' && server.state === 'Archived') return;
    let body;
    try {
      if (action === 'create' || action === 'save') body = payload();
      else {
        if (dirty() || library?.hasPending()) throw new Error('请先保存本页修改，处理完媒体库中的未提交内容，再执行状态操作。');
        if (action === 'activate' && (server.state !== 'Draft' || !server.name.trim() || server.media.length !== 3)) throw new Error('请先保存名称和三张图片，再激活专栏。');
        if (action === 'archive' && (server.state !== 'Active' || server.publishedArticleCount !== 0)) throw new Error('只有当前已发布文章数为 0 的公开专栏才能归档。');
        if (action === 'restore' && server.state !== 'Archived') throw new Error('只有归档专栏才能恢复为草稿。');
        body = {};
      }
    } catch (error) { say('validation', error.message); return; }
    await execute({ action, method: action === 'save' ? 'PUT' : 'POST', path: action === 'create' ? '/columns' : `/columns/${id}${action === 'save' ? '' : `/${action}`}`,
      body: JSON.stringify(body), key: action === 'save' ? null : crypto.randomUUID(), etag: editing ? server.columnEtag : null, raw: raw(), revision });
  }
  async function loadList() {
    if (editing || disposed) return false;
    const serial = ++listSerial, query = $('[data-filter]');
    const params = new URLSearchParams({ page: String(page), pageSize: '20' });
    if (query.elements.state.value) params.set('state', query.elements.state.value);
    if (query.elements.q.value) params.set('q', query.elements.q.value.normalize('NFC'));
    $('[data-list-status]').textContent = '正在读取专栏列表…';
    try {
      const response = await request(`/columns?${params}`); if (disposed || serial !== listSerial) return false;
      if (!response.ok) { await failure(response, false); return false; }
      const value = await response.json(); if (disposed || serial !== listSerial) return false;
      if (!Array.isArray(value.items) || !value.items.every(validItem) || !Number.isSafeInteger(value.total) || value.total < 0 || !positive(value.page) || !positive(value.pageSize) || !validSite(value)) throw new Error('列表响应无法确认。');
      page = value.page; total = value.total;
      $('[data-column-list]').replaceChildren(...value.items.map(item => {
        const li = document.createElement('li'), link = document.createElement('a'), name = document.createElement('strong'), detail = document.createElement('span');
        link.href = `/admin/columns/${item.id}`; name.textContent = item.name || '未命名专栏';
        detail.textContent = `${stateNames[item.state]} · ${item.slug} · 已发布 ${item.publishedArticleCount} 篇 · ${item.showOnHome ? '首页卡片开启' : '首页卡片关闭'}`;
        link.append(name, detail); li.append(link); return li;
      }));
      $('[data-list-status]').textContent = value.items.length ? '' : '本页没有专栏。';
      $('[data-page]').textContent = `共 ${total} 个 · 第 ${page} 页`;
      $('[data-prev]').disabled = page <= 1; $('[data-next]').disabled = page * value.pageSize >= total;
      return true;
    } catch (error) { if (!disposed && serial === listSerial) { $('[data-list-status]').textContent = '列表读取失败，当前输入已保留。请重新读取。'; freeze(pause || 'review', '未能确认服务器状态，写入暂停；请重新读取后明确继续。'); } return false; }
  }
  async function readServer(initial = false) {
    if (disposed || busy) return;
    const serial = ++readSerial, startedAt = revision; busy = true; fresh = null; controls();
    try {
      const context = await session(); if (!context || disposed || serial !== readSerial) return;
      if (!editing) {
        if (!await loadList() || disposed) return;
        if (attempt?.uncertain) pause = 'unknown';
        fresh = { session: true }; reviewRevision = revision;
        $('[data-server-details]').textContent = attempt ? '已确认登录并重新读取列表。原创建请求的结果仍需确认，请使用“重试同一次请求”；沿用原标识不会重复创建。' : '已确认登录并重新读取列表。请核对列表中的地址，再明确选择保留本页输入继续。';
      } else {
        const response = await request(`/columns/${id}`); if (disposed || serial !== readSerial) return;
        if (!response.ok) { await failure(response, false); return; }
        const value = await response.json(); if (disposed || serial !== readSerial) return;
        if (!validColumn(value) || value.id !== id) throw new Error('响应无法确认。');
        if (initial && revision === startedAt) { server = clone(value); loaded = true; fill(value); pause = null; say('saved', '已读取保存的专栏。修改后请点击“保存并应用”。'); }
        else {
          fresh = clone(value); reviewRevision = revision; pause ||= 'review';
          $('[data-server-details]').textContent = `服务器版本 ${value.columnVersion} · ${stateNames[value.state]} · 已发布 ${value.publishedArticleCount} 篇\n名称：${value.name || '（空）'}\n地址：${value.slug}\n介绍：${value.introduction || '（空）'}\n首页卡片：${value.showOnHome ? '显示' : '隐藏'}\n图片：${value.media.map(item => `${item.slot}. ${item.displayMeta.alt} (${item.mediaId})`).join('；') || '无'}\n保存时间（UTC）：${new Date(value.updatedAt).toISOString()}`;
          say('review', '已读取服务器版本，本页输入仍保留。请核对后明确选择如何继续。');
        }
      }
    } catch (error) { if (!disposed && serial === readSerial) freeze(pause || 'review', '无法确认服务器版本。当前输入已保留，写入仍暂停，请重新读取。'); }
    finally { busy = false; controls(); }
  }
  function acceptServer(keepLocal) {
    if (!fresh || busy || disposed || revision !== reviewRevision || (!editing && attempt)) return;
    if (library?.hasPending()) { say('review', '媒体库中仍有未提交内容或上传，请先处理，再选择如何继续。'); return; }
    if (editing) {
      server = clone(fresh); loaded = true;
      if (keepLocal) {
        // A newly frozen slug is server identity, never a local overwrite choice.
        if (server.activatedAt) form.elements.slug.value = server.slug;
        baseline = rawFromServer(server); revision++; pickerSerial++;
      } else fill(server);
    }
    attempt = null; fresh = null; pause = null;
    say(dirty() ? 'dirty' : 'saved', keepLocal ? '已保留本页输入。请检查后手动提交；尚未保存的修改不会自动提交。' : '已载入服务器版本，本页之前未保存的输入已替换。'); controls();
  }
  async function chooseSlot(index) {
    if (!canEdit() || busy || disposed) return;
    if (library?.hasPending()) { say('dirty', '媒体库中仍有未提交说明或上传，请先处理，再切换图片槽位。'); return; }
    const intention = { index, revision, serial: ++pickerSerial };
    try {
      const module = await loadMediaLibrary();
      if (disposed || !canEdit() || busy || intention.serial !== pickerSerial || intention.revision !== revision) return;
      library?.destroy();
      library = module.createMediaLibrary($('[data-media-library]'), {
        fetchImpl,
        onAuthRequired: () => freeze('auth', '媒体库登录已过期。专栏输入已保留，写入暂停；请登录后读取服务器版本并明确继续。'),
        onPendingChange: controls,
        onInsert: ({ mode, media, meta }) => {
          if (disposed || busy || !canEdit() || mode !== 'column' || intention.serial !== pickerSerial || intention.revision !== revision) return false;
          if (!media || !UUID.test(media.id) || media.state !== 'Ready' || media.metadata?.kind !== 'Image' || !meta?.alt?.trim()) { say('validation', '请选择已就绪且已保存替代文字的图片。'); return false; }
          if (slots.some((item, other) => other !== index && item?.mediaId.toLowerCase() === media.id.toLowerCase())) { say('validation', '此图片已在其他槽位，请选择不同图片。'); return false; }
          slots[index] = { mediaId: media.id, displayMeta: clone(meta) }; edited(); renderSlots();
          say('dirty', '图片已选入本页，尚未保存。点击“保存并应用”时将使用当时已保存的媒体库默认说明；服务器会最终检查图片状态及内容重复。'); return true;
        },
      });
      library.open('column'); controls();
    } catch (error) { if (!disposed && intention.serial === pickerSerial) say('error', '媒体库暂时无法打开，本页输入已保留。请再次选择图片。'); }
  }
  form.addEventListener('input', edited, eventOptions);
  form.addEventListener('change', event => { if (event.target === form.elements.showOnHome) edited(); }, eventOptions);
  form.addEventListener('submit', event => { event.preventDefault(); void submit(); }, eventOptions);
  $('[data-reload]').addEventListener('click', () => void readServer(), eventOptions);
  $('[data-retry]').addEventListener('click', () => { if (pause === 'unknown' && attempt?.key && !busy) void execute(attempt); }, eventOptions);
  $('[data-keep-local]').addEventListener('click', () => acceptServer(true), eventOptions);
  $('[data-use-server]')?.addEventListener('click', () => acceptServer(false), eventOptions);
  root.addEventListener('click', event => {
    const button = event.target.closest('button'); if (!button || button.disabled) return;
    if (button.dataset.action) { void submit(button.dataset.action); return; }
    if (!button.dataset.slotAction || !canEdit() || busy) return;
    const index = Number(button.dataset.slot), action = button.dataset.slotAction;
    if (action === 'choose') { void chooseSlot(index); return; }
    if (action === 'remove') slots[index] = null;
    else { const target = index + (action === 'left' ? -1 : 1); if (target < 0 || target > 2) return; [slots[index], slots[target]] = [slots[target], slots[index]]; }
    edited(); renderSlots();
  }, eventOptions);
  if (!editing) {
    $('[data-filter]').addEventListener('submit', event => { event.preventDefault(); page = 1; void loadList(); }, eventOptions);
    $('[data-prev]').addEventListener('click', () => { if (page > 1) { page--; void loadList(); } }, eventOptions);
    $('[data-next]').addEventListener('click', () => { page++; void loadList(); }, eventOptions);
  }
  window.addEventListener('beforeunload', event => { if (pending()) { event.preventDefault(); event.returnValue = ''; } }, eventOptions);
  const api = { hasPending: pending, destroy() { if (disposed) return; disposed = true; pickerSerial++; readSerial++; listSerial++; abort.abort(); library?.destroy(); } };
  window.addEventListener('pagehide', () => api.destroy(), { once: true, signal: abort.signal });
  window.addEventListener('pageshow', event => { if (event.persisted) location.reload(); }, eventOptions);
  renderSlots(); controls();
  if (editing) void readServer(true); else void loadList();
  return api;
}

const root = document.querySelector('[data-column-admin]');
if (root) createColumnAdmin(root);
