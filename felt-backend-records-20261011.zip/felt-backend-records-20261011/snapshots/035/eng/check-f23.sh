#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p artifacts/f23
: "${BLOG_COVERLET_DLL:?Set BLOG_COVERLET_DLL to the verified coverlet.console 10.1.0 net10.0 assembly; see eng/f23/README.md}"
export BLOG_REAL_DOTNET_BIN="${BLOG_REAL_DOTNET_BIN:-${BLOG_DOTNET_BIN:-dotnet}}"
export BLOG_COVERAGE_DIR="${BLOG_COVERAGE_DIR:-$PWD/artifacts/f23/coverage-$(date -u +%Y%m%dT%H%M%SZ)}"
export BLOG_DOTNET_BIN="$PWD/eng/f23/dotnet-coverage"
printf '%s\n' "$BLOG_COVERAGE_DIR" > artifacts/f23/coverage-location.txt

# One complete build/test chain. The wrapper collects actual branch hits while
# preserving the original programs and verifying all restored DLL/PDB bytes.
bash eng/check-f24.sh
for item in Journey OperatorSetup DesignSeed IsolatedRestore OperatorCapture; do
  "$BLOG_DOTNET_BIN" run --project "tests/Blog.${item}Tests" --no-build --no-restore | tee "artifacts/f23/${item}-output.txt"
done
python3 eng/f23/test_coverage.py | tee artifacts/f23/coverage-harness-output.txt
python3 eng/f23/check_delivery.py

# Below-target coverage is a recorded unmet gate, not a falsely passing test or
# an incomplete collector. Preserve the exact status for independent review.
set +e
python3 eng/f23/coverage.py aggregate "$BLOG_COVERAGE_DIR" --expect-all-tests
coverage_status=$?
set -e
printf '%s\n' "$coverage_status" > artifacts/f23/coverage-exit.txt
python3 eng/f23/summarize.py
exit "$coverage_status"
