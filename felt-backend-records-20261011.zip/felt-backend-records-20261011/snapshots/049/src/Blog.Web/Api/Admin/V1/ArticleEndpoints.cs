using Blog.Web.Application.Administration;
using Blog.Web.Application.Articles;
using Blog.Web.Application.Security;
using Blog.Web.Domain;
using Blog.Web.Infrastructure.Administration;

namespace Blog.Web.Api.Admin.V1;

public static class ArticleEndpoints
{
    public static void MapAdminArticleEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/admin/v1/articles").RequireAuthorization(AdminSecurityService.Policy);
        group.MapGet("", async (HttpContext context, AdminArticleService service, CancellationToken ct) =>
        {
            var query = context.Request.Query;
            foreach (var item in query) if (item.Value.Count != 1 || item.Key is not ("state" or "q" or "columnId" or "page" or "pageSize")) throw new ApiFailure(ProblemCode.MALFORMED_REQUEST);
            Guid? column = null; if (query.TryGetValue("columnId", out var id)) { if (!Guid.TryParseExact(id, "D", out var value)) throw ArticleInput.Invalid("columnId"); column = value; }
            int Integer(string name, int fallback) { if (!query.TryGetValue(name, out var text)) return fallback; return int.TryParse(text, out var value) ? value : throw ArticleInput.Invalid(name); }
            var filter = ArticleInput.Filter(query.TryGetValue("state", out var state) ? state.ToString() : null, query.TryGetValue("q", out var q) ? q.ToString() : null, column, Integer("page", 1), Integer("pageSize", ContentLimits.AdminPageSize));
            return Results.Json(await service.ListAsync(filter, ct));
        });
        group.MapPost("", async (HttpContext context, AdminArticleService service) =>
        {
            var input = await AdminJsonBody.Read<CreateArticleInput>(context, 16384);
            await AdminApiHosting.WriteMutation(context, await service.CreateAsync(Actor(context), IdempotencyKey.Require(context.Request.Headers["Idempotency-Key"]), input, context.RequestAborted));
        });
        group.MapGet("/{id:guid}", async (Guid id, HttpContext context, AdminArticleService service) =>
        { var result = await service.ReadAsync(id, context.RequestAborted); context.Response.Headers.ETag = result.ArticleEtag; return Results.Json(result); });
        group.MapPatch("/{id:guid}/identity", async (Guid id, HttpContext context, AdminArticleService service) =>
        { var input = await AdminJsonBody.Read<IdentityInput>(context, 16384); await AdminApiHosting.WriteMutation(context, await service.ChangeIdentityAsync(Actor(context), id, context.Request.Headers.IfMatch, input, context.RequestAborted)); });
        group.MapGet("/{id:guid}/draft", async (Guid id, HttpContext context, AdminArticleService service) =>
        { var result = await service.ReadDraftAsync(id, context.RequestAborted); context.Response.Headers.ETag = result.DraftEtag; return Results.Json(result); });
        group.MapPut("/{id:guid}/draft", async (Guid id, HttpContext context, AdminArticleService service) =>
        { var input = await AdminJsonBody.Read<DraftInput>(context, ContentLimits.JsonBytes + 32768); await AdminApiHosting.WriteMutation(context, await service.SaveDraftAsync(Actor(context), id, context.Request.Headers.IfMatch, input, context.RequestAborted)); });
    }
    private static AdminActor Actor(HttpContext context) => AdminActor.From(context.User, context.TraceIdentifier);
}
