using Blog.Web.Domain.Persistence;
using Blog.Web.Infrastructure.Persistence;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace Blog.Web.Infrastructure.Security;

// Unexposed operator-only boundary. No HTTP route, default password or automatic startup call.
// The controlled host UI/command and the user's own credential entry are a separate production prerequisite.
public sealed class AdminAccountSetup(BlogDbContext db, UserManager<AdminUser> users, RoleManager<IdentityRole<Guid>> roles, Blog.Web.Application.Maintenance.MaintenanceCoordinator? maintenance = null)
{
    public async Task<IdentityResult> InitializeAsync(string userEnteredName, string userEnteredPassword, CancellationToken ct)
    {
        using var admission = maintenance?.TryEnter();
        if (maintenance is not null && admission is null) throw new Blog.Web.Application.Administration.ApiFailure(Blog.Web.Application.Administration.ProblemCode.MAINTENANCE_READ_ONLY);
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        _ = await db.Set<SiteState>().FromSqlRaw("SELECT * FROM site_state WHERE id = 1 FOR UPDATE").SingleAsync(ct);
        if (await db.Users.AnyAsync(ct))
            return IdentityResult.Failed(new IdentityError { Code = "SETUP_ALREADY_COMPLETED", Description = "Initial account setup is unavailable." });
        if (!await roles.RoleExistsAsync("Admin"))
        {
            var roleResult = await roles.CreateAsync(new IdentityRole<Guid>("Admin") { Id = Guid.NewGuid() });
            if (!roleResult.Succeeded) { db.ChangeTracker.Clear(); return roleResult; }
        }
        var user = new AdminUser { Id = Guid.NewGuid(), UserName = userEnteredName, IsEnabled = true, LockoutEnabled = true };
        var result = await users.CreateAsync(user, userEnteredPassword);
        if (!result.Succeeded) { db.ChangeTracker.Clear(); return result; }
        result = await users.AddToRoleAsync(user, "Admin");
        if (!result.Succeeded) { db.ChangeTracker.Clear(); return result; }
        await tx.CommitAsync(ct); return IdentityResult.Success;
    }
}
