using System.Security.Claims;
using System.Text.Json;
using Blog.Web.Infrastructure.Administration;
using Blog.Web.Application.Security;
using Blog.Web.Domain;
using Blog.Web.Infrastructure.Security;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;

namespace Blog.Web.Api.Admin.V1;

public static class SessionEndpoints
{
    private sealed record LoginInput(string UserName, string Password);
    private sealed record ReauthInput(string Password);
    public static void MapAdminSessionEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/admin/v1").RequireAuthorization(AdminSecurityService.Policy);
        group.MapGet("/session/bootstrap", Bootstrap).AllowAnonymous();
        group.MapPost("/session", Login).AllowAnonymous();
        group.MapGet("/session", (HttpContext context) => Results.Json(PublicSession(context.Items[typeof(AdminSessionView)] as AdminSessionView)));
        group.MapDelete("/session", Logout);
        group.MapPost("/session/reauth", Reauthenticate);
    }
    private static object? PublicSession(AdminSessionView? session) => session is null ? null : new
    {
        user = new { id = session.Identity.Id, userName = session.Identity.UserName },
        idleExpiresAt = session.LastSeenAt.AddMinutes(ContentLimits.IdleSessionMinutes).UtcDateTime, absoluteExpiresAt = session.AbsoluteExpiresAt.UtcDateTime,
        reauthenticatedAt = session.ReauthenticatedAt?.UtcDateTime
    };
    private static IResult Bootstrap(HttpContext context, IAntiforgery antiforgery) => Results.Json(new
    { csrfToken = antiforgery.GetAndStoreTokens(context).RequestToken, session = PublicSession(context.Items[typeof(AdminSessionView)] as AdminSessionView) });
    private static async Task Login(HttpContext context, AdminSecurityService security, LoginAttemptLimiter limiter, IAntiforgery antiforgery)
    {
        if (!Acquire(context, limiter, out var retry)) { context.Response.Headers.RetryAfter = retry.ToString(); await AdminSecurityHosting.WriteError(context, 429, "RATE_LIMITED"); return; }
        var input = await Read<LoginInput>(context);
        if (input is null) return;
        if (string.IsNullOrWhiteSpace(input.UserName) || input.UserName.Length > 256 || string.IsNullOrEmpty(input.Password) || input.Password.Length > 1024)
        { await AdminSecurityHosting.WriteError(context, 401, "LOGIN_FAILED"); return; }
        var session = await security.LoginAsync(input.UserName, input.Password, context.RequestAborted);
        if (session is null) { await AdminSecurityHosting.WriteError(context, 401, "LOGIN_FAILED"); return; }
        // The protected ticket carries only a random session ID; identity/role is re-read on every request.
        var ticket = new ClaimsPrincipal(new ClaimsIdentity(new[] { new Claim(AdminSecurityService.SessionClaim, session.Id.ToString()) }, AdminSecurityService.Scheme));
        await context.SignInAsync(AdminSecurityService.Scheme, ticket, new AuthenticationProperties { IsPersistent = false, AllowRefresh = false, IssuedUtc = session.CreatedAt, ExpiresUtc = session.AbsoluteExpiresAt });
        context.User = AdminSecurityService.Principal(session);
        context.Items[typeof(AdminSessionView)] = session;
        await context.Response.WriteAsJsonAsync(new { session = PublicSession(session), csrfToken = antiforgery.GetAndStoreTokens(context).RequestToken });
    }
    private static async Task Logout(HttpContext context, AdminSecurityService security)
    {
        await security.LogoutAsync(AdminSecurityService.SessionId(context.User)!.Value, context.RequestAborted);
        await context.SignOutAsync(AdminSecurityService.Scheme);
        context.Response.Cookies.Delete(AdminSecurityHosting.AntiforgeryCookieName, new CookieOptions { Secure = true, HttpOnly = true, SameSite = SameSiteMode.Strict, Path = "/" });
        context.Response.StatusCode = 204;
    }
    private static async Task Reauthenticate(HttpContext context, AdminSecurityService security, LoginAttemptLimiter limiter)
    {
        if (!Acquire(context, limiter, out var retry)) { context.Response.Headers.RetryAfter = retry.ToString(); await AdminSecurityHosting.WriteError(context, 429, "RATE_LIMITED"); return; }
        var input = await Read<ReauthInput>(context); if (input is null) return;
        if (string.IsNullOrEmpty(input.Password) || input.Password.Length > 1024 || !await security.ReauthenticateAsync(AdminSecurityService.SessionId(context.User)!.Value, input.Password, context.RequestAborted))
        { await AdminSecurityHosting.WriteError(context, 401, "REAUTH_FAILED"); return; }
        context.Response.StatusCode = 204;
    }
    private static bool Acquire(HttpContext context, LoginAttemptLimiter limiter, out int retry) => limiter.TryAcquire(context.Connection.RemoteIpAddress?.ToString() ?? "unknown", out retry);
    private static Task<T> Read<T>(HttpContext context) where T : class => AdminJsonBody.Read<T>(context, 16384);
}
