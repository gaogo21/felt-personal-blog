using System.Reflection;
using System.Security.Cryptography;
using Blog.Web.Infrastructure.Media;

namespace Blog.Web.Infrastructure.Backup;

public interface IBackupCapture
{
    Task CaptureAsync(Guid operationId, DateTimeOffset createdAt, CancellationToken ct);
}
public sealed class BackupCaptureService(BackupOptions options, MediaStorageOptions media,
    IPostgresBackupDatabase database, BackupArchiveStore archive, IPrivateFileDurability durability,
    IWebHostEnvironment environment, TimeProvider clock, IBackupKeyValidator keyValidator) : IBackupCapture
{
    public async Task CaptureAsync(Guid operationId, DateTimeOffset createdAt, CancellationToken ct)
    {
        options.ValidateExistingFiles(environment.WebRootPath);
        keyValidator.Validate(options.DataProtectionRoot, clock.GetUtcNow());
        var work = Path.Combine(options.DestinationRoot, "work-" + operationId.ToString("N"));
        BackupArchivePaths.CreatePrivateDirectory(work);
        byte[]? key = null;
        try
        {
            durability.SyncDirectory(options.DestinationRoot);
            var dump = Path.Combine(work, "database.dump");
            var schema = await database.CaptureAsync(dump, ct);
            var databaseIdentity = database.CapturedIdentity ?? throw new IOException("BACKUP_DATABASE_IDENTITY_REQUIRED");
            using (var source = BackupArchivePaths.OpenRead(options.EncryptionKeyFile))
            {
                if (source.Length != 32) throw new IOException("BACKUP_ENCRYPTION_KEY_INVALID");
                key = new byte[32]; await source.ReadExactlyAsync(key, ct);
            }
            var release = typeof(BackupCaptureService).Assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion ?? "unknown";
            await archive.CreateAsync(new BackupArchiveCaptureRequest(dump, media.PrivateRoot, options.DataProtectionRoot,
                Path.Combine(options.DestinationRoot, operationId.ToString("N") + ".blogbackup"),
                new(release, schema, options.ConfigurationVersion, createdAt, operationId, "PostgreSqlCustomDump",
                    new(options.ApplicationName, media.MaxMediaBytes), new(databaseIdentity.ClusterSystemIdentifier, databaseIdentity.DatabaseOid))), key, ct);
        }
        finally
        {
            if (key is not null) CryptographicOperations.ZeroMemory(key);
            // Work belongs to this operation and contains only its private dump.
            // Native/database/archive tasks have settled before cleanup begins.
            if (Directory.Exists(work)) Directory.Delete(work, recursive: true);
            durability.SyncDirectory(options.DestinationRoot);
        }
    }
}
