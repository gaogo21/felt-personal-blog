using System.Security.Cryptography;
using Blog.Web.Application.Administration;
using Blog.Web.Application.Media;
using Blog.Web.Domain;

namespace Blog.Web.Infrastructure.Media;
public sealed record MediaStorageOptions(string PrivateRoot, long MaxMediaBytes)
{
    public const int UploadTimeoutSeconds = 300;
    public const int UploadLeaseSeconds = 330;
    public const int ProcessingLeaseSeconds = ContentLimits.ProcessingTimeoutSeconds + 30;
    public static MediaStorageOptions Read(IConfiguration config)
    {
        var raw = config["MAX_MEDIA_BYTES"] ?? config["Media:MaxMediaBytes"];
        if (!long.TryParse(raw, out var limit) || limit <= 0) throw new InvalidOperationException("MAX_MEDIA_BYTES_REQUIRED");
        var path = config["Media:PrivateRoot"];
        if (string.IsNullOrWhiteSpace(path) || !Path.IsPathFullyQualified(path)) throw new InvalidOperationException("PRIVATE_MEDIA_ROOT_REQUIRED");
        return new(path, limit);
    }
}
public sealed class PrivateMediaStorage
{
    public string Root { get; }
    public long Quota { get; }
    public PrivateMediaStorage(MediaStorageOptions options, IWebHostEnvironment environment)
    {
        Root = Path.GetFullPath(options.PrivateRoot).TrimEnd(Path.DirectorySeparatorChar);
        Quota = options.MaxMediaBytes;
        if (Quota <= 0 || Root.Length < 2) throw new InvalidOperationException("PRIVATE_MEDIA_CONFIGURATION_INVALID");
        var web = Path.GetFullPath(environment.WebRootPath ?? Path.Combine(environment.ContentRootPath, "wwwroot")).TrimEnd(Path.DirectorySeparatorChar);
        if (Root == web || Root.StartsWith(web + Path.DirectorySeparatorChar, StringComparison.Ordinal) || web.StartsWith(Root + Path.DirectorySeparatorChar, StringComparison.Ordinal))
            throw new InvalidOperationException("PRIVATE_MEDIA_OVERLAPS_WEBROOT");
        NoLinks(Root);
        Directory.CreateDirectory(Root);
        foreach (var area in new[] { "quarantine", "work", "objects" }) { NoLinks(Path.Combine(Root, area)); Directory.CreateDirectory(Path.Combine(Root, area)); }
    }
    public string UploadPath(Guid media, Guid token) => Resolve($"quarantine/{media:N}-{token:N}.upload");
    public string WorkPath(Guid media, Guid token) => Resolve($"work/{media:N}-{token:N}.partial");
    public string FinalKey(Guid media, Guid token, string mime) => $"objects/{media:N}-{token:N}" + (mime switch { "image/jpeg" => ".jpg", "image/png" => ".png", "image/webp" => ".webp", "video/mp4" => ".mp4", _ => throw new InvalidOperationException("INVALID_MEDIA_MIME") });
    public string Resolve(string key)
    {
        if (!System.Text.RegularExpressions.Regex.IsMatch(key, "\\A(quarantine|work|objects)/[a-f0-9]{32}-[a-f0-9]{32}\\.(upload|partial|jpg|png|webp|mp4)\\z")) throw new InvalidOperationException("PRIVATE_MEDIA_KEY_INVALID");
        var path = Path.GetFullPath(Path.Combine(Root, key)); NoLinks(path); return path;
    }
    public long UsedBytes()
    {
        NoLinks(Root); long size = 0;
        foreach (var directory in new[] { "quarantine", "work", "objects" })
        {
            var path = Path.Combine(Root, directory); NoLinks(path);
            foreach (var file in Directory.EnumerateFileSystemEntries(path))
            {
                NoLinks(file); if (Directory.Exists(file)) throw new InvalidOperationException("UNEXPECTED_PRIVATE_MEDIA_DIRECTORY");
                size = checked(size + new FileInfo(file).Length);
            }
        }
        return size;
    }
    public async Task ReceiveAsync(Stream input, UploadManifest manifest, string? path, CancellationToken ct)
    {
        if (path is not null) NoLinks(path);
        await using var output = path is null ? Stream.Null : new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None, 65536, FileOptions.Asynchronous | FileOptions.SequentialScan);
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256); var buffer = new byte[65536]; long size = 0;
        while (true)
        {
            ct.ThrowIfCancellationRequested();
            var count = await input.ReadAsync(buffer, ct); ct.ThrowIfCancellationRequested(); if (count == 0) break;
            size = checked(size + count);
            if (size > manifest.Limit) throw new ApiFailure(ProblemCode.FILE_TOO_LARGE);
            if (size > manifest.ByteSize) throw new ApiFailure(ProblemCode.VALIDATION_FAILED);
            hash.AppendData(buffer, 0, count); await output.WriteAsync(buffer.AsMemory(0, count), ct);
        }
        if (size != manifest.ByteSize || Convert.ToHexStringLower(hash.GetHashAndReset()) != manifest.Sha256) throw new ApiFailure(ProblemCode.VALIDATION_FAILED);
        await output.FlushAsync(ct);
        if (output is FileStream file) file.Flush(flushToDisk: true);
    }
    public void Commit(string work, string key)
    {
        NoLinks(work); var target = Resolve(key);
        // All areas are beneath the same configured filesystem root. Never overwrite a prior attempt.
        PrivateFileDurability.Commit(work, target);
    }
    public void Remove(string path) { NoLinks(path); if (File.Exists(path)) File.Delete(path); }
    public IEnumerable<(string Path, Guid MediaId, DateTimeOffset Modified)> Orphans()
    {
        foreach (var area in new[] { "quarantine", "work", "objects" }) foreach (var path in Directory.EnumerateFiles(Path.Combine(Root, area)))
        {
            NoLinks(path); var name = Path.GetFileName(path);
            if (name.Length >= 33 && Guid.TryParseExact(name[..32], "N", out var id)) yield return (path, id, File.GetLastWriteTimeUtc(path));
        }
    }
    public static void NoLinks(string path)
    {
        var current = Path.GetFullPath(path);
        while (!string.IsNullOrEmpty(current))
        {
            if (new FileInfo(current).LinkTarget is not null || Path.Exists(current) && (File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0) throw new InvalidOperationException("PRIVATE_MEDIA_LINK_FORBIDDEN");
            current = Path.GetDirectoryName(current)!;
        }
    }
}
