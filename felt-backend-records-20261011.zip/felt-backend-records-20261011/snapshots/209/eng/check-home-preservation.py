import subprocess, hashlib, json

GALLERY_METADATA_BEFORE = b"const who=document.createElement('a');who.href=a.source;who.target='_blank';who.rel='noopener noreferrer';who.textContent=a.author+' / '+a.provider;const license=document.createElement('a');license.href=a.licenseUrl;license.target='_blank';license.rel='noopener noreferrer';license.textContent=a.license;credit.append(who,document.createTextNode(' \xc2\xb7 '),license,document.createTextNode(' \xc2\xb7 \xe8\x89\xba\xe6\x9c\xaf\xe5\x9b\xbe\xe7\x89\x87\xe5\xb1\x95\xe7\xa4\xba\xe7\xa4\xba\xe4\xbe\x8b'));"
GALLERY_METADATA_AFTER = b"  const append=(text,url,fallback)=>{\n   if(!text&&!url)return;let safe=false;\n   try{const target=new URL(url);safe=target.protocol==='https:'&&!target.username&&!target.password&&!/[\\u0000-\\u0020\\\\]/.test(url)}catch{}\n   const item=document.createElement(safe?'a':'span');item.textContent=text||fallback;\n   if(safe){item.href=url;item.target='_blank';item.rel='noopener noreferrer'}\n   if(credit.childNodes.length)credit.append(document.createTextNode(' \xc2\xb7 '));credit.append(item);\n  };\n  append([a.author,a.provider].filter(Boolean).join(' / '),a.source,'\xe6\x9d\xa5\xe6\xba\x90');append(a.license,a.licenseUrl,'\xe8\xae\xb8\xe5\x8f\xaf');\n  if(!credit.childNodes.length)credit.textContent='\xe6\x9c\xaa\xe5\xa1\xab\xe5\x86\x99\xe6\x9d\xa5\xe6\xba\x90\xe4\xb8\x8e\xe8\xae\xb8\xe5\x8f\xaf\xe8\xaf\xb4\xe6\x98\x8e';"

def normalize_gallery(actual):
    # This exact literal is the only permitted viewer metadata substitution.
    # Every surrounding statement, including show() control flow, remains compared.
    assert actual.count(GALLERY_METADATA_AFTER) == 1, 'Unexpected gallery metadata implementation'
    return actual.replace(GALLERY_METADATA_AFTER, GALLERY_METADATA_BEFORE, 1)

def gallery_matches(old, actual):
    try:
        return normalize_gallery(actual) == old
    except AssertionError:
        return False

from pathlib import Path
root=Path('.')
base='039d494fd3a394b2353c18214c7a3ccd22806623'
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'src/Blog.Web/wwwroot/css/home','src/Blog.Web/wwwroot/js/home','src/Blog.Web/wwwroot/assets','src/Blog.Web/Pages/Shared/Home','src/Blog.Web/Pages/Index.cshtml']).decode().splitlines()
for p in paths:
    old=subprocess.check_output(['git','show',base+':'+p]); actual=Path(p).read_bytes()
    if p.endswith('/Home/_Hero.cshtml'):
        # F04 only replaces repeated navigation literals with the shared partial.
        actual=actual.replace(b'<partial name="_NavigationLinks" />',b'<a href="/#about">ABOUT</a><a href="/articles">ARTICLE</a><a href="/#columns">COLUMNS</a>').replace(b'href="@SiteNavigation.Home"',b'href="/"')
    if p.endswith('/Home/_Gallery.cshtml'):
        # F21 binds trusted dimensions and removes a claim about arbitrary new uploads.
        actual=actual.replace(b'width="@a.Width" height="@a.Height"',b'width="1240" height="800"').replace('图片来源与说明可在查看器中查看'.encode(),'艺术图片精选 · 展示示例，非本人项目'.encode()).replace('<span>图像与灵感</span>'.encode(),'<span>艺术图片示例</span>'.encode())
    if p.endswith('/Home/_Columns.cshtml'):
        actual=actual.replace(b'width="@img.Width" height="@img.Height"',b'width="1240" height="800"').replace('<span>专栏配图</span>'.encode(),'<span>艺术图片示意</span>'.encode())
    if p.endswith('/js/home/gallery.js'):
        assert gallery_matches(old, actual), 'Gallery changed beyond the exact metadata block'
        negative_controls = [
            actual.replace(b'function show(index){', b'function show(index){distance=[0,0];paint();', 1),
            actual.replace(b'root.dataset.selected=String(selected)', b'paint();root.dataset.selected=String(selected)', 1),
            actual.replace(b'const SPEED=36;', b'const SPEED=40;', 1),
            actual.replace(b'if(disposed||!art.length)return;', b'if(disposed)return;', 1),
            actual.replace(b'   if(!text&&!url)return;', b'   distance=[0,0];paint();if(!text&&!url)return;', 1),
        ]
        assert all(probe != actual and not gallery_matches(old, probe) for probe in negative_controls), 'Motion/control-flow negative control escaped gallery preservation'
        actual=normalize_gallery(actual)
    assert hashlib.sha256(old).digest()==hashlib.sha256(actual).digest(),f'F02 homepage changed beyond the declared F04/F21 data bindings: {p}'
result={'scope':'Source preservation with explicit F04 navigation and F21 trusted metadata bindings; not rendered browser regression','baseline':base,'homepageFilesVerified':len(paths),'galleryMutationNegativeControls':len(negative_controls),'normalization':'Hero navigation; Gallery/Columns trusted width-height and non-misleading labels; gallery viewer credit rendering only. All motion/lifecycle and CSS bytes unchanged.'}
(root/'artifacts/f03/home-preservation.json').write_text(json.dumps(result,indent=2)+'\n')
print(f'PASS F02 homepage: {len(paths)} files preserved (declared navigation and data bindings normalized)' )
