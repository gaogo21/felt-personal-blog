diff --git a/src/Blog.Web/Pages/Admin/Articles/Manage.cshtml b/src/Blog.Web/Pages/Admin/Articles/Manage.cshtml
index 86e5deb..ad5fa09 100644
--- a/src/Blog.Web/Pages/Admin/Articles/Manage.cshtml
+++ b/src/Blog.Web/Pages/Admin/Articles/Manage.cshtml
@@ -13,7 +13,7 @@
 <section data-confirmation hidden aria-labelledby="lifecycle-confirm-title">
 <h2 id="lifecycle-confirm-title" tabindex="-1">确认文章操作</h2><p data-confirmation-text></p>
 <div data-purge-fields hidden>
-<p>永久清空会删除工作草稿、全部发布历史、预览令牌和文章媒体引用，无法恢复。只保留文章标识、地址墓碑和审计；地址不能重新使用。共享媒体文件不会随文章删除。</p>
+<p>永久清空会删除工作草稿、全部发布历史和文章媒体引用，无法恢复。只保留文章标识、地址墓碑和审计；地址不能重新使用。共享媒体文件不会随文章删除。</p>
 <label class="lifecycle-input" for="purge-confirm-slug">完整输入文章地址（须完全一致，不含前后空格）<input id="purge-confirm-slug" data-confirm-slug type="text" autocomplete="off" autocapitalize="none" spellcheck="false" maxlength="100" /></label>
 <form data-reauth-form>
 <label class="lifecycle-input" for="purge-password">当前管理员密码<input id="purge-password" data-password type="password" autocomplete="current-password" maxlength="1024" /></label>
diff --git a/src/Blog.Web/wwwroot/js/admin/article-lifecycle.js b/src/Blog.Web/wwwroot/js/admin/article-lifecycle.js
index 70ce752..f7a595c 100644
--- a/src/Blog.Web/wwwroot/js/admin/article-lifecycle.js
+++ b/src/Blog.Web/wwwroot/js/admin/article-lifecycle.js
@@ -61,6 +61,11 @@ export function createArticleLifecycleAdmin(root, { fetchImpl = globalThis.fetch
       && typeof value.updatedAt === 'string' && !Number.isNaN(new Date(value.updatedAt).getTime())
       && (value.basePublishedRevisionId === null || uuid(value.basePublishedRevisionId));
   }
+  function validPurgeReceipt(value, response, operation) {
+    return response.status === 200 && validArticle(value, response) && value.state === 'Purged'
+      && value.slug === operation.slug && value.articleVersion > operation.articleVersion
+      && typeof value.purgedAt === 'string' && !Number.isNaN(new Date(value.purgedAt).getTime());
+  }
   function observe(value) {
     if (value.article.articleVersion < observedArticleVersion || purgedObserved && value.article.state !== 'Purged' || value.article.state !== 'Purged'
       && value.draft.draftVersion < observedDraftVersion) throw new Error('A stale snapshot cannot replace a newer observation.');
@@ -78,7 +83,9 @@ export function createArticleLifecycleAdmin(root, { fetchImpl = globalThis.fetch
   }
   function describe(operation) {
     const name = operation.articleTitle ?? title(server);
-    const prefix = `文章「${name}」（${operation.slug || server?.article.slug || id}）：${actions[operation.kind]}。`;
+    const prefix = purgedObserved
+      ? `已永久清空的文章（${operation.slug || server?.article.slug || id}）：${actions[operation.kind]}。`
+      : `文章「${name}」（${operation.slug || server?.article.slug || id}）：${actions[operation.kind]}。`;
     if (operation.kind === 'withdraw') return `${prefix}确认后立即停止公开，并移除首页精选与公开专栏目录；草稿和历史保留。`;
     if (operation.kind === 'trash') return `${prefix}${operation.state === 'Published' ? '文章会在同一操作中撤回，立即停止公开并移除首页精选与公开专栏目录。' : ''}草稿和历史保留。以后恢复只回到草稿，不会自动公开。`;
     if (operation.kind === 'restore') return `${prefix}仅恢复到未发布草稿；不会重新公开，也不会恢复首页精选或公开目录。`;
@@ -346,6 +353,8 @@ export function createArticleLifecycleAdmin(root, { fetchImpl = globalThis.fetch
     }
     const operation = attempt, owner = {}; operation.rejected = null; advance(); const started = epoch;
     const current = () => !disposed && epoch === started && attempt === operation && writeOwner === owner;
+    const ownsPendingPurge = () => !disposed && attempt === operation && writeOwner === owner
+      && operation.kind === 'purge' && operation.sent;
     writeOwner = owner; writeBusy = true; retryAllowed = false; fresh = null; confirmation = null; pause = null;
     say('working', retry ? '正在核对原请求的结果；请求标识、目标和版本保持不变。' : '正在执行已确认的文章操作…'); controls();
     try {
@@ -359,7 +368,7 @@ export function createArticleLifecycleAdmin(root, { fetchImpl = globalThis.fetch
         'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf,
         'If-Match': operation.articleEtag, 'Idempotency-Key': operation.key,
       }, body: operation.body });
-      if (!current()) return;
+      if (!current() && !(ownsPendingPurge() && response.ok && response.status === 200)) return;
       if (!response.ok) {
         if (operation.kind === 'purge' && response.status === 403) {
           let problem; try { problem = await response.json(); } catch { problem = {}; }
@@ -374,18 +383,22 @@ export function createArticleLifecycleAdmin(root, { fetchImpl = globalThis.fetch
         fail(response, true); return;
       }
       const result = await response.json();
+      // A newer auth/read epoch still owns all recovery decisions. A complete
+      // terminal receipt from this exact retained request only hides obsolete
+      // body UI; it never clears that epoch, changes the attempt, or sends work.
+      const verifiedPurge = ownsPendingPurge() && validPurgeReceipt(result, response, operation);
+      if (verifiedPurge) {
+        observedArticleVersion = Math.max(observedArticleVersion, result.articleVersion);
+        markPurged(); controls();
+      }
       if (!current()) return;
       const valid = operation.kind === 'revision'
         ? validDraft(result, response) && result.basePublishedRevisionId === operation.revision.id && result.draftVersion >= operation.draftVersion
-        : response.status === 200 && validArticle(result, response)
-          && result.state === { withdraw: 'Withdrawn', trash: 'Trashed', restore: 'Draft', purge: 'Purged' }[operation.kind]
-          && result.articleVersion > operation.articleVersion
-          && (operation.kind === 'purge' ? result.slug === operation.slug : result.draftVersion >= operation.draftVersion);
+        : operation.kind === 'purge' ? verifiedPurge
+          : response.status === 200 && validArticle(result, response)
+            && result.state === { withdraw: 'Withdrawn', trash: 'Trashed', restore: 'Draft' }[operation.kind]
+            && result.articleVersion > operation.articleVersion && result.draftVersion >= operation.draftVersion;
       if (!valid) throw new Error('Cannot verify mutation result.');
-      if (operation.kind === 'purge') {
-        observedArticleVersion = Math.max(observedArticleVersion, result.articleVersion);
-        markPurged();
-      }
       // A replay returns the original result, which may predate an observed server
       // snapshot. Never install mutation responses as the current page baseline.
       attempt = null; intent = null; pause = 'review';
diff --git a/tests/HomeMotion/admin-article-purge.test.mjs b/tests/HomeMotion/admin-article-purge.test.mjs
index 11476f4..b3ec09f 100644
--- a/tests/HomeMotion/admin-article-purge.test.mjs
+++ b/tests/HomeMotion/admin-article-purge.test.mjs
@@ -106,6 +106,11 @@ await check('Purge uses two deliberate confirmations, exact slug, reauth, CAS, C
   assert.doesNotMatch(e.$('[data-confirmation-text]').textContent, /预览令牌/);
   assert.equal(e.w.document.querySelector('[data-confirmation-text] img'), null);
   e.click('[data-confirm]'); await flush(); assert.equal(e.posts.length, 0); assert.equal(e.$('[data-confirm]').disabled, true);
+  assert.equal(e.$('[data-confirmation]').hidden, false); assert.equal(e.$('[data-purge-fields]').hidden, false);
+  const completeExplanation = e.$('[data-confirmation]').textContent;
+  assert.match(e.$('[data-purge-fields] > p').textContent, /删除工作草稿、全部发布历史和文章媒体引用，无法恢复.*文章标识、地址墓碑和审计.*地址不能重新使用.*共享媒体文件不会随文章删除/);
+  assert.doesNotMatch(completeExplanation, /预览令牌/);
+  assert.match(completeExplanation, /完整输入文章地址.*当前管理员密码.*10 分钟内仍须点击最终确认/s);
   e.input('[data-confirm-slug]', slug); e.auth(); assert.equal(e.$('[data-password]').value, ''); await flush();
   assert.equal(e.auths.length, 1); assert.equal(e.purges.length, 0); assert.equal(e.$('[data-confirm]').disabled, false);
   e.click('[data-confirm]'); e.synthetic('[data-confirm]'); await flush();
@@ -310,6 +315,67 @@ await check('Pagehide clears password, aborts handlers, and retained BFCache pag
   const event = new e.w.Event('pageshow'); Object.defineProperty(event, 'persisted', { value: true }); e.w.dispatchEvent(event); e.w.dispatchEvent(event); assert.equal(e.reloads, 1);
 });
 
+for (const timing of ['response', 'json']) await check(`Verified late Purged ${timing} hides stale body UI while preserving newer auth and original pending request`, async track => {
+  const delayed = deferred(); let deny = false, receipt, intercept = true;
+  const e = track(environment({ override: (path, options, server) => {
+    if (intercept && path.endsWith('/purge')) {
+      receipt = server.mutate(path, options);
+      return timing === 'response' ? delayed.promise : { ...receipt, json: () => delayed.promise };
+    }
+    if (deny && path === `/api/admin/v1/articles/${id}`) return response({}, 401);
+  } })); await flush(); await authenticated(e); e.click('[data-confirm]'); await flush();
+  deny = true; e.click('[data-reload]'); await flush(); const frozenStatus = e.$('[data-status]').textContent, callCount = e.calls.length;
+  assert.equal(e.state, 'auth'); assert.equal(e.$('[data-history-list]').children.length, 1);
+  delayed.resolve(timing === 'response' ? receipt : await receipt.json()); await flush();
+  assert.equal(e.state, 'auth'); assert.equal(e.$('[data-status]').textContent, frozenStatus); assert.equal(e.beforeUnload(), true);
+  assert.equal(e.calls.length, callCount); assert.equal(e.$('[data-retry]').disabled, true); assert.equal(e.$('[data-cancel]').disabled, true);
+  tombstone(e); assert.doesNotMatch(e.$('[data-identity]').textContent, /当前草稿/); assert.doesNotMatch(e.$('[data-confirmation-text]').textContent, /当前草稿/);
+  const original = e.purges[0]; deny = false; intercept = false; await replay(e); assert.equal(e.$('[data-retry]').disabled, true);
+  e.auth(); await flush(); e.click('[data-retry]'); await flush(); assert.equal(e.purges.length, 2); assert.equal(e.server.commits, 1);
+  assert.equal(e.purges[1].options.body, original.options.body); assert.deepEqual(e.purges[1].options.headers, original.options.headers);
+  assert.equal(e.beforeUnload(), false); tombstone(e);
+});
+for (const defect of ['article', 'slug', 'state', 'draft', 'missing-draft', 'missing-publication', 'missing-purgedAt', 'etag', 'version', 'status', 'error', 'json']) await check(`Late unverified purge ${defect} cannot supply terminal UI evidence or release auth`, async track => {
+  const delayed = deferred(); let deny = false, terminal;
+  const e = track(environment({ override: (path, options, server) => {
+    if (path.endsWith('/purge')) { server.mutate(path, options); terminal = server.article; return delayed.promise; }
+    if (deny && path === `/api/admin/v1/articles/${id}`) return response({}, 401);
+  } })); await flush(); await authenticated(e); e.click('[data-confirm]'); await flush(); deny = true; e.click('[data-reload]'); await flush();
+  const frozenStatus = e.$('[data-status]').textContent, callCount = e.calls.length, result = structuredClone(terminal);
+  if (defect === 'article') result.id = columnId;
+  if (defect === 'slug') result.slug = 'different-slug';
+  if (defect === 'state') result.state = 'Trashed';
+  if (defect === 'draft') { result.draftVersion = 1; result.draftEtag = dTag(1); }
+  if (defect === 'missing-draft') delete result.draftEtag;
+  if (defect === 'missing-publication') delete result.published;
+  if (defect === 'missing-purgedAt') delete result.purgedAt;
+  if (defect === 'version') { result.articleVersion = 1; result.articleEtag = aTag(1); }
+  const reply = response(result, defect === 'status' ? 202 : defect === 'error' ? 403 : 200, defect === 'etag' ? '"wrong"' : result.articleEtag);
+  delayed.resolve(defect === 'json' ? { ...reply, json: async () => { throw new Error('fixture invalid late JSON'); } } : reply); await flush();
+  assert.equal(e.state, 'auth'); assert.equal(e.$('[data-status]').textContent, frozenStatus); assert.equal(e.beforeUnload(), true);
+  assert.equal(e.calls.length, callCount); assert.equal(e.$('[data-history-section]').hidden, false); assert.equal(e.$('[data-history-list]').children.length, 1);
+  assert.match(e.$('[data-identity]').textContent, /当前草稿/); assert.equal(e.$('[data-retry]').disabled, true);
+});
+await check('A late Purged resource from a different command cannot impersonate the captured purge request', async track => {
+  const delayed = deferred(); let deny = false, terminal;
+  const e = track(environment({ override: (path, options, server) => {
+    if (path.endsWith('/restore')) { server.mutate(path, options); server.changeState('Purged'); terminal = server.article; return delayed.promise; }
+    if (deny && path === `/api/admin/v1/articles/${id}`) return response({}, 401);
+  } })); await flush(); e.click('[data-action="restore"]'); await flush(); e.click('[data-confirm]'); await flush(); deny = true; e.click('[data-reload]'); await flush();
+  const frozenStatus = e.$('[data-status]').textContent; delayed.resolve(response(terminal)); await flush();
+  assert.equal(e.state, 'auth'); assert.equal(e.$('[data-status]').textContent, frozenStatus); assert.equal(e.beforeUnload(), true);
+  assert.equal(e.purges.length, 0); assert.equal(e.$('[data-history-section]').hidden, false); assert.equal(e.$('[data-history-list]').children.length, 1);
+});
+await check('A disposed purge request cannot update its old page after a complete late terminal receipt', async track => {
+  const delayed = deferred(); let receipt;
+  const e = track(environment({ override: (path, options, server) => {
+    if (path.endsWith('/purge')) { receipt = server.mutate(path, options); return delayed.promise; }
+  } })); await flush(); await authenticated(e); e.click('[data-confirm]'); await flush(); e.pagehide();
+  const oldIdentity = e.$('[data-identity]').textContent, oldStatus = e.$('[data-status]').textContent, callCount = e.calls.length;
+  delayed.resolve(receipt); await flush(); assert.equal(e.$('[data-identity]').textContent, oldIdentity); assert.equal(e.$('[data-status]').textContent, oldStatus);
+  assert.equal(e.calls.length, callCount); assert.equal(e.$('[data-history-list]').children.length, 1);
+});
+
 mkdirSync('artifacts/f20', { recursive: true });
 const failed = results.filter(result => result.status === 'failed').length;
 writeFileSync('artifacts/f20/admin-article-purge-results.json', JSON.stringify({ scope: 'Actual shipped article lifecycle module and Razor markup in JSDOM; deterministic in-memory API and clock. No genuine passwords, deletions, database, listener, native browser, or visual-layout proof.', total: results.length, failed, checks: results }, null, 2));
