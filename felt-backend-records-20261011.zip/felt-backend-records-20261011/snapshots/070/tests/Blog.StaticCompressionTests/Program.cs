using System.IO.Compression;
using System.Net;
using System.Text;
using System.Text.Json;
using Blog.StaticCompressionTests;

var root = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../../../"));
var output = Path.Combine(root, "artifacts/f24/static-compression");
Directory.CreateDirectory(output);
var checks = new List<object>();
var failures = 0;
void Assert(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
async Task Check(string name, Func<Task> action)
{
    try { await action().WaitAsync(TimeSpan.FromSeconds(30)); checks.Add(new { name, status = "passed" }); Console.WriteLine("PASS " + name); }
    catch (Exception error) { failures++; checks.Add(new { name, status = "failed", error = error.Message }); Console.WriteLine("FAIL " + name + ": " + error.Message); }
}
void Headers(HttpResponseMessage response, string mime, string? encoding)
{
    Assert(response.StatusCode == HttpStatusCode.OK, "Expected 200");
    Assert(response.Content.Headers.ContentType?.MediaType == mime, "Wrong content type");
    Assert(response.Content.Headers.ContentEncoding.SequenceEqual(encoding is null ? [] : new[] { encoding }), "Wrong content encoding");
    Assert(response.Headers.Vary.Count(value => value.Equals("Accept-Encoding", StringComparison.OrdinalIgnoreCase)) == 1, "Missing or duplicate Accept-Encoding variance");
    Assert(response.Headers.Vary.Contains("Origin"), "Existing Vary value was lost");
    Assert(response.Headers.CacheControl?.ToString() == "public, max-age=60", "Static cache policy changed");
    Assert(response.Content.Headers.LastModified is not null, "Missing Last-Modified revalidation metadata");
    Assert(encoding is null ? response.Headers.ETag is { IsWeak: false } : response.Headers.ETag is null, "Source-only ETag was used for encoded bytes, or identity lost its validator");
    Assert(!response.Headers.Contains("Set-Cookie"), "Static request modified a cookie");
    Assert(response.Content.Headers.ContentRange is null, "Full response contains range metadata");
}
async Task<byte[]> Decode(HttpResponseMessage response, string encoding)
{
    await using var source = await response.Content.ReadAsStreamAsync();
    await using Stream decoder = encoding == "br" ? new BrotliStream(source, CompressionMode.Decompress) : new GZipStream(source, CompressionMode.Decompress);
    await using var decoded = new MemoryStream();
    await decoder.CopyToAsync(decoded);
    return decoded.ToArray();
}

foreach (var asset in CompressionFixture.Assets)
foreach (var encoding in new[] { "gzip", "br" })
await Check("HTTPS " + encoding + " decodes exact source bytes: " + asset.Path, async () =>
{
    await using var fixture = new CompressionFixture(root, output); await fixture.StartAsync();
    using var response = await fixture.SendAsync(asset.Path, encoding);
    Headers(response, asset.Mime, encoding);
    Assert(!response.Content.Headers.Contains("Content-Length"), "Uncompressed Content-Length retained after encoding");
    Assert((await Decode(response, encoding)).SequenceEqual(fixture.SourceBytes[asset.Path]), "Decoded bytes differ from source");
    Assert(fixture.DownstreamCalls == 0, "Static response reached session/auth boundary");
});

foreach (var asset in CompressionFixture.Assets)
await Check("Absent Accept-Encoding preserves exact identity and length: " + asset.Path, async () =>
{
    await using var fixture = new CompressionFixture(root, output); await fixture.StartAsync();
    using var response = await fixture.SendAsync(asset.Path);
    Headers(response, asset.Mime, null);
    Assert(response.Content.Headers.ContentLength == fixture.SourceBytes[asset.Path].Length, "Identity length changed");
    Assert((await response.Content.ReadAsByteArrayAsync()).SequenceEqual(fixture.SourceBytes[asset.Path]), "Identity body changed");
});

foreach (var (accept, expected) in new (string, string?)[]
{
    ("gzip;q=0, br;q=0", null), ("gzip;q=1, br;q=0", "gzip"), ("gzip;q=0, br;q=1", "br"),
    ("gzip;q=0.4, br;q=0.8", "br"), ("gzip;q=1, br;q=0.2", "gzip"),
    ("gzip, br", "br"), ("identity;q=1, gzip;q=0.2, br;q=0.5", null),
    ("deflate", null), ("br;q=0, gzip;q=0, *;q=1", null)
})
await Check("Negotiation respects accepted quality: " + accept, async () =>
{
    await using var fixture = new CompressionFixture(root, output); await fixture.StartAsync();
    var asset = CompressionFixture.Assets[0];
    using var response = await fixture.SendAsync(asset.Path, accept);
    Headers(response, asset.Mime, expected);
    var bytes = expected is null ? await response.Content.ReadAsByteArrayAsync() : await Decode(response, expected);
    Assert(bytes.SequenceEqual(fixture.SourceBytes[asset.Path]), "Negotiated response changed bytes");
});

foreach (var asset in CompressionFixture.Assets)
foreach (var encoding in new string?[] { null, "gzip", "br" })
await Check("HEAD preserves representation headers without a body: " + asset.Path + " " + (encoding ?? "identity"), async () =>
{
    await using var fixture = new CompressionFixture(root, output); await fixture.StartAsync();
    using var response = await fixture.SendAsync(asset.Path, encoding, HttpMethod.Head);
    Headers(response, asset.Mime, encoding);
    if (encoding is null) Assert(response.Content.Headers.ContentLength == fixture.SourceBytes[asset.Path].Length, "Identity HEAD length changed");
    else Assert(!response.Content.Headers.Contains("Content-Length"), "Encoded HEAD advertised original length");
    Assert((await response.Content.ReadAsByteArrayAsync()).Length == 0, "HEAD sent bytes");
});

foreach (var asset in CompressionFixture.Assets)
await Check("206 Range retains exact identity slice and range headers: " + asset.Path, async () =>
{
    await using var fixture = new CompressionFixture(root, output); await fixture.StartAsync();
    using var response = await fixture.SendAsync(asset.Path, "br, gzip", headers: [("Range", "bytes=1-8")]);
    Assert(response.StatusCode == HttpStatusCode.PartialContent, "Range was not 206");
    Assert(!response.Content.Headers.ContentEncoding.Any(), "Partial response was compressed");
    Assert(response.Content.Headers.ContentLength == 8, "Wrong range length");
    Assert(response.Content.Headers.ContentRange?.ToString() == "bytes 1-8/" + fixture.SourceBytes[asset.Path].Length, "Wrong Content-Range");
    Assert(response.Headers.AcceptRanges.SequenceEqual(["bytes"]), "Byte range support lost");
    Assert((await response.Content.ReadAsByteArrayAsync()).SequenceEqual(fixture.SourceBytes[asset.Path].Skip(1).Take(8)), "Wrong range bytes");
    Assert(response.Headers.Vary.Contains("Accept-Encoding") && response.Headers.CacheControl?.ToString() == "public, max-age=60", "Range cache metadata changed");
});

await Check("Identity ETag revalidation returns empty 304 with stable validator and Vary", async () =>
{
    await using var fixture = new CompressionFixture(root, output); await fixture.StartAsync();
    var path = CompressionFixture.Assets[0].Path;
    using var original = await fixture.SendAsync(path);
    var etag = original.Headers.ETag!.ToString();
    using var response = await fixture.SendAsync(path, headers: [("If-None-Match", etag)]);
    Assert(response.StatusCode == HttpStatusCode.NotModified, "Source validator no longer revalidates");
    Assert(response.Headers.ETag?.ToString() == etag && response.Headers.Vary.Contains("Accept-Encoding"), "304 changed validator or lost variance");
    Assert(!response.Content.Headers.ContentEncoding.Any() && (await response.Content.ReadAsByteArrayAsync()).Length == 0, "304 emitted compressed bytes");
});

await Check("Compressed Last-Modified revalidation returns empty 304 with Vary", async () =>
{
    await using var fixture = new CompressionFixture(root, output); await fixture.StartAsync();
    var path = CompressionFixture.Assets[0].Path;
    using var original = await fixture.SendAsync(path, "br");
    Assert(original.Headers.ETag is null, "Encoded response reused source ETag");
    var modified = original.Content.Headers.LastModified!.Value.ToString("R");
    using var response = await fixture.SendAsync(path, "br", headers: [("If-Modified-Since", modified)]);
    Assert(response.StatusCode == HttpStatusCode.NotModified && response.Headers.Vary.Contains("Accept-Encoding"), "Encoded Last-Modified revalidation changed");
    Assert(response.Headers.ETag is null, "304 introduced a source-only strong ETag for cached encoded bytes");
    Assert(!response.Content.Headers.ContentEncoding.Any() && (await response.Content.ReadAsByteArrayAsync()).Length == 0, "304 emitted compressed bytes");
});

await Check("Cookie-bearing asset requests bypass the later session boundary without Set-Cookie", async () =>
{
    await using var fixture = new CompressionFixture(root, output); await fixture.StartAsync();
    foreach (var asset in CompressionFixture.Assets)
    {
        using var response = await fixture.SendAsync(asset.Path, "br", headers: [("Cookie", "__Host-blog-admin=COMPRESSION_SENTINEL")]);
        Headers(response, asset.Mime, "br");
        Assert((await Decode(response, "br")).SequenceEqual(fixture.SourceBytes[asset.Path]), "Cookie influenced source bytes");
    }
    Assert(fixture.DownstreamCalls == 0, "Static requests touched downstream session boundary");
});

foreach (var excluded in CompressionFixture.Excluded)
await Check("Static excluded MIME remains byte/header identical: " + excluded.Mime, async () =>
{
    await using var fixture = new CompressionFixture(root, output); await fixture.StartAsync();
    using var response = await fixture.SendAsync(excluded.Path, "br, gzip");
    Assert(response.StatusCode == HttpStatusCode.OK && response.Content.Headers.ContentType?.MediaType == excluded.Mime, "Wrong excluded response");
    Assert(!response.Content.Headers.ContentEncoding.Any(), "Excluded MIME was compressed");
    Assert(response.Content.Headers.ContentLength == excluded.Bytes.Length, "Excluded MIME length changed");
    Assert((await response.Content.ReadAsByteArrayAsync()).SequenceEqual(excluded.Bytes), "Excluded MIME bytes changed");
    Assert(response.Headers.Vary.SequenceEqual(["Origin"]) && response.Headers.CacheControl?.ToString() == "public, max-age=60", "Excluded MIME cache headers changed");
    Assert(response.Headers.ETag is { IsWeak: false } && !response.Headers.Contains("Set-Cookie"), "Excluded metadata changed");
});

foreach (var dynamic in CompressionFixture.Dynamic)
foreach (var method in new[] { HttpMethod.Get, HttpMethod.Head })
await Check("Dynamic response remains unchanged: " + method + " " + dynamic.Path, async () =>
{
    await using var fixture = new CompressionFixture(root, output); await fixture.StartAsync();
    using var response = await fixture.SendAsync(dynamic.Path, "br, gzip", method);
    Assert(response.StatusCode == HttpStatusCode.OK && response.Content.Headers.ContentType?.ToString() == dynamic.Mime, "Dynamic response changed");
    Assert(!response.Content.Headers.ContentEncoding.Any(), "Dynamic response was compressed");
    Assert(response.Content.Headers.ContentLength == Encoding.UTF8.GetByteCount(dynamic.Body), "Dynamic length changed");
    Assert(await response.Content.ReadAsStringAsync() == (method == HttpMethod.Head ? "" : dynamic.Body), "Dynamic body changed");
    Assert(response.Headers.CacheControl?.Private == true && response.Headers.CacheControl.NoStore, "Dynamic no-store changed");
    Assert(response.Headers.Vary.SequenceEqual(["Origin"]) && !response.Headers.Contains("Set-Cookie"), "Dynamic cookie or cache side effect");
});

await Check("Missing static opt-in fails closed even for allowed MIME", async () =>
{
    await using var fixture = new CompressionFixture(root, output, optIn: false); await fixture.StartAsync();
    foreach (var asset in CompressionFixture.Assets)
    {
        using var response = await fixture.SendAsync(asset.Path, "br, gzip");
        Assert(!response.Content.Headers.ContentEncoding.Any() && response.Content.Headers.ContentLength == fixture.SourceBytes[asset.Path].Length, "Missing opt-in compressed response");
        Assert((await response.Content.ReadAsByteArrayAsync()).SequenceEqual(fixture.SourceBytes[asset.Path]), "Fail-closed bytes changed");
    }
});

await File.WriteAllTextAsync(Path.Combine(output, "results.json"), JsonSerializer.Serialize(new
{
    suite = "F24 bounded static response compression", passed = checks.Count - failures, failed = failures, checks,
    scope = "In-process TestServer; exact normal CSS/JS/font URLs and generated excluded fixtures only. No listener, database, browser, media permission changes, or additional F12 normalization probe."
}, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"F24 static compression: {checks.Count - failures} passed, {failures} failed");
return failures == 0 ? 0 : 1;
