"""Exact public-export provenance; archived references are not private Git history."""
from pathlib import Path
import base64
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[1]
PROVENANCE = Path('docs/development/publication/source-provenance.json')
REFERENCES = Path('docs/development/publication/baseline-references.json')
PUBLIC_BASE = '81eed0f397dfe7ca1a2fe66d6fa2418b2ed480c1'
DELIVERED = '5f6f048a3e4c77c5ef86638bcff280badc4f19ab'
REVIEWED = 'b3b81c0e1f168e355ec9cbe2d26bf5353535cfd7'
PRIVATE_CONFIG = '.openai/hosting.json'
# These are packaging/documentation adapters only. No src/, frontend/, test,
# dependency lock, feature gate, release decision or acceptance change is allowed.
REWRITES = {
    '.gitignore', 'README.md', 'DEVELOPMENT.md', 'eng/f23/README.md',
    'tests/Blog.MediaFileTests/README.md', 'eng/cleanup_contract.py',
    'eng/check-f22-cleanup.py', 'eng/check-home-preservation.py',
    'eng/home_accessibility_contract.py', 'docs/development/f27/check_documents.py',
}
ADDITIONS = {
    str(PROVENANCE), str(REFERENCES), 'docs/development/publication/README.md',
    'eng/publication_contract.py', 'eng/check-publication.py',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def contract(root=ROOT, read=None):
    read = read or (lambda path: (root / path).read_bytes())
    data = json.loads(read(PROVENANCE))
    assert data['formatVersion'] == 1
    assert data['publicBaseCommit'] == PUBLIC_BASE
    assert data['deliveredSourceCommit'] == DELIVERED
    assert data['reviewedProductCommit'] == REVIEWED
    assert data['excludedFiles'] == [PRIVATE_CONFIG]
    assert len(data['deliveredFiles']) == 1468
    assert set(data['packagingRewrites']) == REWRITES
    assert set(data['packagingAdditions']) == ADDITIONS
    assert data['privateHistoryIncluded'] is False
    assert data['privateRollbackRecovery'] == 'unavailable-in-public-export'
    assert all(p in {'README.md', 'DEVELOPMENT.md', 'TODOS.md'} or p.startswith('docs/')
               for p in data['reviewedToDeliveredDocumentationChanges'])
    return data


def replacement_digest(name, predecessor, root=ROOT, read=None):
    row = contract(root, read)['packagingRewrites'][name]
    assert row['beforeSha256'] == predecessor, 'Unexpected packaging predecessor: ' + name
    return row['afterSha256']


def verify_publication(root=ROOT, *, read=None, exists=None, paths=None):
    read = read or (lambda path: (root / path).read_bytes())
    exists = exists or (lambda path: (root / path).exists())
    data = contract(root, read)
    assert not exists(PRIVATE_CONFIG), 'Private hosting configuration must remain excluded'
    expected_paths = set(data['deliveredFiles']) | ADDITIONS
    if paths is None:
        paths = set(subprocess.check_output(
            ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'],
            cwd=root).decode().split('\0')) - {''}
    assert set(paths) == expected_paths, 'Public file inventory differs from the exact export'
    for path, row in data['deliveredFiles'].items():
        expected = row['sha256']
        if path in REWRITES:
            expected = replacement_digest(path, expected, root, read)
        assert sha(read(Path(path))) == expected, 'Public source changed: ' + path
    # Bind every additional file except this manifest itself (no circular hash).
    for path, expected in data['packagingAdditions'].items():
        if path != str(PROVENANCE):
            assert sha(read(Path(path))) == expected, 'Packaging reference changed: ' + path
    return {
        'deliveredFiles': len(data['deliveredFiles']),
        'unchangedDeliveredFiles': len(data['deliveredFiles']) - len(REWRITES),
        'exactPackagingRewrites': len(REWRITES),
        'packagingAdditions': len(ADDITIONS),
        'productFilesByteIdentical': sum(p.startswith('src/') for p in data['deliveredFiles']),
        'privateRollbackRecovery': data['privateRollbackRecovery'],
    }


def references(root=ROOT):
    data = contract(root)
    raw = (root / REFERENCES).read_bytes()
    assert sha(raw) == data['packagingAdditions'][str(REFERENCES)], 'Baseline reference archive changed'
    return json.loads(raw)


def baseline_paths(commit, root=ROOT):
    return sorted(references(root)['baselines'][commit])


def baseline_bytes(commit, path, root=ROOT):
    row = references(root)['baselines'][commit][path]
    raw = base64.b64decode(row['referenceBase64'], validate=True) if 'referenceBase64' in row else (root / path).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'Baseline reference changed: ' + path
    return raw
