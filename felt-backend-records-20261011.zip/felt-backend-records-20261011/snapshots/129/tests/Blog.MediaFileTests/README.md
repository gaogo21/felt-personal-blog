# Media file processing checks

This console suite uses generated fixtures and the approved native tools. It does not start an HTTP server, database, socket listener, ClamAV daemon, updater, or network fetch. Fixtures and machine-readable results remain in ignored `artifacts/f11/media-file-tests/`.

The fixture tool paths follow this checkout's verified toolchain: `/usr/bin/ffmpeg`, `/usr/bin/ffprobe`, and sibling `blog-toolchain/debian-root/usr/bin/clamscan` with `blog-toolchain/clamav-db`. The scanner's private library directory is supplied only to its process. Runtime deployments supply their own trusted `MediaToolOptions` paths.

After the normal approved restore, run:

```sh
source /tmp/blog-dotnet-env.sh
"$BLOG_DOTNET_BIN" run --project tests/Blog.MediaFileTests --no-restore
```

A focused run accepts `-- --filter "case name substring"`; a selection matching no checks fails. The suite requires official scanner signatures, and an unavailable scanner is never treated as a successful real-tool check. EICAR is tested as the unmodified standard benign scanner fixture, independently of image/container validation, since embedding its text into another file changes the test signature.

The process runner enforces a shared deadline, byte-bounded diagnostics, a binary image-output cap, decoder/pixel/thread restrictions, and an RSS watchdog. The RSS check samples the native process; it does not claim kernel-enforced aggregate memory or CPU isolation. Deployment must retain the approved low-privilege/private-storage controls and verified toolchain. The console tests do not alter OS security settings.
