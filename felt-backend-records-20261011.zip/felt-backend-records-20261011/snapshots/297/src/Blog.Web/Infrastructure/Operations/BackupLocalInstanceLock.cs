using Blog.Web.Infrastructure.Backup;

namespace Blog.Web.Infrastructure.Operations;

public interface IBackupLocalInstanceLock
{
    IDisposable Acquire();
}

public sealed class BackupLocalInstanceLockFailure() : Exception("BACKUP_LOCAL_INSTANCE_LOCK_UNAVAILABLE");

// Advisory exclusion for cooperating processes on one Linux host. All instances
// must use the same destination. This cannot establish that remote database,
// filesystem, migration, or other non-cooperating writers have stopped.
public sealed class BackupLocalInstanceLock(BackupOptions options) : IBackupLocalInstanceLock
{
    public const string FileName = ".blog-instance.lock";
    private const ushort PrivateFileMode = 0x8180; // Regular file, exactly 0600.

    public IDisposable Acquire()
    {
        FileStream? stream = null;
        try
        {
            if (!options.Enabled || !OperatingSystem.IsLinux()) throw new BackupLocalInstanceLockFailure();
            var root = BackupArchivePaths.Full(options.DestinationRoot);
            var directory = BackupArchivePaths.ReadStamp(root, directory: true);
            if ((directory.Mode & 0x3f) != 0) throw new BackupLocalInstanceLockFailure();
            var path = Path.Combine(root, FileName);
            if (!BackupArchivePaths.Exists(path))
            {
                try { stream = BackupArchivePaths.CreatePrivateFile(path); }
                // Another cooperating process may have created the permanent
                // file between the existence check and exclusive creation.
                catch (IOException) when (BackupArchivePaths.Exists(path)) { }
            }
            if (stream is null)
            {
                RequirePrivateFile(BackupArchivePaths.ReadStamp(path));
                stream = new FileStream(path, new FileStreamOptions
                {
                    Mode = FileMode.Open, Access = FileAccess.ReadWrite, Share = FileShare.None,
                    BufferSize = 1, Options = FileOptions.None
                });
            }
            var acquired = BackupArchivePaths.Stamp(stream.SafeFileHandle);
            RequirePrivateFile(acquired);
            var current = BackupArchivePaths.ReadStamp(path);
            RequirePrivateFile(current);
            var currentDirectory = BackupArchivePaths.ReadStamp(root, directory: true);
            if (!SameIdentity(acquired, current) || !SameIdentity(directory, currentDirectory) || (currentDirectory.Mode & 0x3f) != 0)
                throw new BackupLocalInstanceLockFailure();
            return stream;
        }
        catch (Exception error) when (error is not OutOfMemoryException)
        {
            stream?.Dispose();
            // Do not disclose host paths or operating-system exception text.
            throw new BackupLocalInstanceLockFailure();
        }
    }

    private static void RequirePrivateFile(BackupArchiveFileStamp stamp)
    {
        if (stamp.Mode != PrivateFileMode || stamp.Links != 1 || stamp.Size != 0)
            throw new BackupLocalInstanceLockFailure();
    }

    private static bool SameIdentity(BackupArchiveFileStamp first, BackupArchiveFileStamp second)
        => first.DeviceMajor == second.DeviceMajor && first.DeviceMinor == second.DeviceMinor && first.Inode == second.Inode;

    // Release only closes the handle. Never delete or replace this file while
    // any cooperating process can run: doing so would split the lock identity.
}
