#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p artifacts/f26
bash eng/check-f25.sh
for item in OperationsHealth RestartRecovery; do
  "${BLOG_DOTNET_BIN:-dotnet}" run --project "tests/Blog.${item}Tests" --no-build --no-restore | tee "artifacts/f26/${item}-output.txt"
done
python3 tests/OperationsArtifacts/test_release_artifact.py 2>&1 | tee artifacts/f26/release-artifact-output.txt
python3 - <<'PY'
import importlib.util,json,shutil,subprocess,tempfile
from pathlib import Path
spec=importlib.util.spec_from_file_location('release_artifact','eng/operations/release_artifact.py')
release=importlib.util.module_from_spec(spec);spec.loader.exec_module(release)
base=Path(tempfile.mkdtemp(prefix='pack-',dir=Path('artifacts/f26').resolve()))
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
contract=release.decode(Path('contracts/release-compatibility.json').read_bytes())
manifest=release.pack('artifacts/f22/publish',base/'release',contract,commit)
assert release.verify(base/'release')==manifest
plan=release.plan(base/'release',release.decode(Path('deploy/runtime-observation.example.json').read_bytes()))
assert plan['canExecute'] is False and plan['declaredPrerequisitesSatisfied'] is False
out=Path('artifacts/f26')
(out/'packaged-release-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(out/'deployment-plan-unverified.json').write_text(json.dumps(plan,indent=2)+'\n')
for source in Path('artifacts/f25').glob('*.json'):
    shutil.copy2(source,out/source.name)
checks={}
for name in ('OperationsHealth','RestartRecovery'):
    lines=(out/f'{name}-output.txt').read_text().splitlines()
    checks[name]={'passed':sum(x.startswith('PASS ') for x in lines),'failed':sum(x.startswith('FAIL ') for x in lines)}
    assert checks[name]['passed']>0 and checks[name]['failed']==0
checks['ReleaseArtifacts']=json.loads((out/'release-artifact-results.json').read_text())
(out/'operations-aggregate-results.json').write_text(json.dumps({'scope':'in-process health, simulated restart with generated persistent fixtures, local publish integrity and read-only deployment plans only','checks':checks,'releaseFiles':len(manifest['files']),'productionDeployed':False,'realPostgreSql':'blocked','realSystemdRestart':'pending','realRollback':'pending','S10':'pending'},indent=2)+'\n')
print('PASS Local publish release inventory and unready deployment plan; no deployment executed')
PY
