using System.Globalization;
using Blog.Web.Application;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace Blog.Web.Pages.Articles;
public sealed class IndexModel(IPublicContentQueries queries) : PageModel
{
    public const int PageSize = 12;
    public ArticlePage Data { get; private set; } = null!;
    public int PageNumber { get; private set; } = 1;
    public string? ColumnSlug { get; private set; }
    public bool HasPrevious => PageNumber > 1;
    public bool HasNext => (long)PageNumber * PageSize < Data.Total;
    public int PreviousPage => Math.Min(PageNumber - 1, Math.Max(1, (int)Math.Ceiling(Data.Total / (double)PageSize)));
    public string PageUrl(int page)
    {
        var values = new Dictionary<string, string?> { ["page"] = page.ToString(CultureInfo.InvariantCulture) };
        if (ColumnSlug is not null) values["column"] = ColumnSlug;
        return Microsoft.AspNetCore.WebUtilities.QueryHelpers.AddQueryString("/articles", values);
    }
    public async Task<IActionResult> OnGetAsync(CancellationToken cancellationToken)
    {
        var rawPage = Request.Query["page"];
        if (rawPage.Count > 1 || (rawPage.Count == 1 && (!int.TryParse(rawPage[0], NumberStyles.None, CultureInfo.InvariantCulture, out var parsed) || parsed < 1)))
            return BadRequest();
        if (rawPage.Count == 1) PageNumber = int.Parse(rawPage[0]!, CultureInfo.InvariantCulture);
        var column = Request.Query["column"];
        if (column.Count > 1) return BadRequest();
        ColumnSlug = column.Count == 1 ? column[0] : null;
        if (ColumnSlug is not null && ColumnSlug.Length == 0) return NotFound();
        var result = await queries.GetArticlesAsync(ColumnSlug, PageNumber, PageSize, cancellationToken);
        if (result is null) return NotFound();
        Data = result;
        ViewData["CanonicalPath"] = PageNumber == 1
            ? ColumnSlug is null ? "/articles" : Microsoft.AspNetCore.WebUtilities.QueryHelpers.AddQueryString("/articles", "column", ColumnSlug)
            : PageUrl(PageNumber);
        ViewData["Description"] = Data.ColumnName is null ? "阅读已发布的文章。" : "阅读专栏：" + Data.ColumnName;
        return Page();
    }
}
