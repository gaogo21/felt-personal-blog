const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const states = { Draft: '草稿', Active: '公开', Archived: '归档' };
const clone = value => JSON.parse(JSON.stringify(value));
const ids = value => value.items.map(item => item.id.toLowerCase());
const equal = (left, right) => left.length === right.length && left.every((id, index) => id === right[index]);
const sameMembers = (left, right) => {
  const members = new Set(right); return left.length === right.length && left.every(id => members.has(id));
};
const natural = value => Number.isSafeInteger(value) && value >= 0;
const validId = value => typeof value === 'string' && UUID.test(value);

/** Full-set ordering is explicitly saved. Reconciliation never adds or drops local IDs. */
export function createOrderAdmin(root, { fetchImpl = globalThis.fetch, reloadPage = () => location.reload() } = {}) {
  const abort = new AbortController(), events = { signal: abort.signal }, $ = selector => root.querySelector(selector);
  const articles = root.dataset.orderAdmin === 'articles', columnId = root.dataset.columnId?.toLowerCase();
  const path = articles ? `/columns/${columnId}/articles/order` : '/columns/order';
  let disposed = false, loaded = false, readBusy = false, writeBusy = false;
  let server = null, local = [], baseline = [], fresh = null, attempt = null, pause = null, drag = null;
  let revision = 0, epoch = 0, readSerial = 0, reviewRevision = null;
  const request = (endpoint, options = {}) => fetchImpl(`/api/admin/v1${endpoint}`, {
    credentials: 'same-origin', cache: 'no-store', signal: abort.signal, ...options,
  });
  const dirty = () => !equal(local, baseline);
  const pending = () => readBusy || writeBusy || dirty() || Boolean(attempt);
  const active = value => !articles || value?.columnState === 'Active';
  const editable = () => !disposed && loaded && !pause && active(server);
  const label = item => (articles ? item.title : item.name) || item.slug;
  const say = (state, text) => { if (!disposed) { root.dataset.saveState = state; $('[data-status]').textContent = text; } };
  const currentRow = row => row?.parentElement === $('[data-order-list]') && root.contains(row);
  const currentDrag = () => drag && currentRow(drag.row) && drag.row.dataset.orderId === drag.id && local.includes(drag.id);
  function clearDrag() {
    drag = null;
    for (const row of $('[data-order-list]').children) delete row.dataset.dragging;
  }
  function valid(value, response) {
    if (!value || !Number.isSafeInteger(value.siteVersion) || value.siteVersion < 1
      || value.siteEtag !== `"s-1-${value.siteVersion}"` || response.headers?.get('ETag') !== value.siteEtag
      || !Array.isArray(value.items) || (server && value.siteVersion < server.siteVersion)) return false;
    if (articles && (!validId(value.columnId) || value.columnId.toLowerCase() !== columnId
      || typeof value.columnName !== 'string' || typeof value.columnSlug !== 'string'
      || !Object.hasOwn(states, value.columnState) || (!active(value) && value.items.length))) return false;
    if (!value.items.every((item, index) => item && validId(item.id) && typeof item.slug === 'string'
      && (articles ? typeof item.title === 'string' && item.position === index + 1
        : typeof item.name === 'string' && ['Draft', 'Active'].includes(item.state)
          && natural(item.sortOrder) && natural(item.publishedArticleCount)))) return false;
    return new Set(ids(value)).size === value.items.length;
  }
  function controls() {
    if (disposed) return;
    $('[data-save]').disabled = !editable() || readBusy || writeBusy || !dirty() || Boolean(attempt);
    // A read may discover expired authentication while a write is pending.
    // A later write response must not release that newer authentication freeze.
    $('[data-reload]').disabled = false;
    $('[data-review]').hidden = !fresh;
    $('[data-use-server]').disabled = !fresh || readBusy || writeBusy || revision !== reviewRevision;
    $('[data-keep-local]').disabled = !fresh || readBusy || writeBusy || revision !== reviewRevision
      || !loaded || !active(fresh) || !sameMembers(local, ids(fresh));
    for (const [index, row] of [...$('[data-order-list]').children].entries()) {
      row.draggable = editable() && local.length > 1;
      if (!row.draggable) delete row.dataset.dragging;
      row.querySelector('[data-move="up"]').disabled = !editable() || index === 0;
      row.querySelector('[data-move="down"]').disabled = !editable() || index === local.length - 1;
    }
  }
  function render(focusId = null, direction = null) {
    if (disposed) return;
    // Replacing a source row can detach it before its dragend bubbles here.
    // Retire that gesture before rebuilding rows, even if the IDs are unchanged.
    clearDrag();
    const byId = new Map(server?.items.map(item => [item.id.toLowerCase(), item]) || []);
    $('[data-order-list]').replaceChildren(...local.map((id, index) => {
      const item = byId.get(id), row = document.createElement('li');
      row.className = 'order-item'; row.dataset.orderId = id; row.tabIndex = 0;
      row.setAttribute('aria-describedby', 'order-help');
      const description = document.createElement('div'); description.className = 'order-label';
      const title = document.createElement('h2'); title.textContent = `${index + 1}. ${label(item)}`; description.append(title);
      const details = document.createElement('span');
      details.textContent = articles ? item.slug : `${states[item.state]} · 已发布 ${item.publishedArticleCount} 篇 · ${item.slug}`;
      description.append(details); row.append(description);
      const actions = document.createElement('div'); actions.className = 'order-actions';
      for (const [move, text] of [['up', '上移'], ['down', '下移']]) {
        const button = document.createElement('button'); button.type = 'button'; button.dataset.move = move;
        button.textContent = text; button.setAttribute('aria-label', `${text}：${label(item)}，当前位置 ${index + 1}，共 ${local.length} 项`);
        actions.append(button);
      }
      row.append(actions); return row;
    }));
    $('[data-empty]').hidden = !loaded || local.length !== 0;
    if (server) {
      $('[data-identity]').textContent = articles
        ? `${server.columnName || server.columnSlug} · ${states[server.columnState]} · 当前已发布 ${server.items.length} 篇${active(server) ? '' : '；只有公开专栏可以保存排序。'}`
        : `全部未归档专栏：${server.items.length} 个（含草稿与公开专栏）。`;
      $('[data-version]').textContent = `已读取站点版本 ${server.siteVersion}`;
    }
    controls();
    if (focusId) {
      const row = $(`[data-order-id="${focusId}"]`), button = direction && row?.querySelector(`[data-move="${direction}"]`);
      (button && !button.disabled ? button : row)?.focus();
    }
  }
  function freeze(reason, text) {
    if (disposed) return;
    // Authentication remains a hard stop until a fresh authenticated read and choice.
    pause = pause === 'auth' ? 'auth' : reason; fresh = null; clearDrag(); epoch++;
    say(pause, text); controls();
  }
  function move(id, target, direction = null) {
    if (!editable()) return;
    const index = local.indexOf(id);
    if (index < 0 || target < 0 || target >= local.length || target === index) return;
    local.splice(index, 1); local.splice(target, 0, id); revision++; fresh = null;
    if (writeBusy) say('saving', '保存请求仍在进行；本页较新的排序已保留，等待服务器确认后再决定保存。');
    else say(dirty() ? 'dirty' : 'saved', dirty() ? '本页顺序尚未保存。点击“保存并应用完整顺序”后生效。' : '本页顺序与已确认的服务器顺序一致。');
    render(id, direction);
  }
  async function failure(response, writing, current) {
    if (disposed || !current()) return;
    if ([401, 403].includes(response.status)) {
      freeze('auth', '会话或防伪验证已失效。当前完整顺序已保留，写入暂停；请在新标签页登录，再读取服务器顺序并明确选择。'); return;
    }
    let problem = null; try { problem = await response.json(); } catch { /* HTTP status remains authoritative. */ }
    if (disposed || !current()) return;
    const detail = typeof problem?.detail === 'string' ? ` ${problem.detail}` : '';
    if ([409, 412, 428].includes(response.status)) {
      freeze('conflict', `服务器版本、状态或完整成员集合已变化（HTTP ${response.status}）。${detail} 本页顺序已保留，请读取服务器顺序并明确选择。`);
    } else if (writing && response.status >= 500) {
      freeze('unknown', '保存结果尚未确认，本页顺序已保留。请读取服务器顺序核对，再明确选择；不会自动重复提交。');
    } else if (writing) {
      say('error', `保存未成功（HTTP ${response.status}）。${detail} 本页完整顺序已保留。`); controls();
    } else freeze(pause || 'review', `读取失败（HTTP ${response.status}）。${detail} 本页顺序已保留，写入暂停；请重新读取。`);
  }
  async function session(current) {
    const response = await request('/session/bootstrap');
    if (!current()) return null;
    if (!response.ok) { await failure(response, false, current); return null; }
    const result = await response.json();
    if (!current()) return null;
    if (!result?.session?.user?.id || typeof result?.csrfToken !== 'string' || !result.csrfToken) {
      freeze('auth', '尚未确认有效登录。本页顺序已保留，请登录后重新读取。'); return null;
    }
    return result;
  }
  function stage(value) {
    fresh = clone(value); reviewRevision = revision; pause ||= 'review'; clearDrag(); epoch++;
    const incoming = ids(value), same = sameMembers(local, incoming);
    const confirmed = attempt?.uncertain && equal(incoming, attempt.ids);
    $('[data-server-details]').textContent = `服务器站点版本 ${value.siteVersion} · 完整集合 ${incoming.length} 项。${articles ? ` 专栏状态：${states[value.columnState]}。` : ''}${confirmed ? ' 服务器当前顺序与上次提交相同；仍需明确选择如何继续。' : ''}`;
    $('[data-membership]').textContent = !loaded ? '载入此完整集合后可开始排序。'
      : same ? '成员集合一致。可以保留本页顺序，以刚读取的版本继续；之后仍需手动保存。'
        : `成员集合已变化：新增 ${incoming.filter(id => !local.includes(id)).length} 项，移除 ${local.filter(id => !incoming.includes(id)).length} 项。不能保留旧集合或自动合并；请核对两个完整列表后，明确载入服务器完整顺序。`;
    $('[data-server-list]').replaceChildren(...value.items.map(item => {
      const row = document.createElement('li'); row.textContent = `${label(item)} · ${item.slug}`; return row;
    }));
    say(pause, '已读取服务器完整顺序，本页排序仍保留。请核对后明确选择如何继续。'); controls();
  }
  async function readServer(initial = false) {
    if (disposed) return;
    const serial = ++readSerial, startedEpoch = epoch, startedRevision = revision;
    const current = () => !disposed && serial === readSerial && startedEpoch === epoch;
    readBusy = true; fresh = null; controls();
    if (!pause) say('loading', '正在读取会话与完整顺序…');
    try {
      if (!await session(current) || !current()) return;
      const response = await request(path);
      if (!current()) return;
      if (!response.ok) { await failure(response, false, current); return; }
      const value = await response.json();
      if (!current()) return;
      if (!valid(value, response)) throw new Error('无法确认完整排序响应。');
      if (writeBusy) {
        freeze('review', '读取时保存请求仍在进行，本页顺序已保留。请等待保存请求结束，再重新读取完整顺序。'); return;
      }
      if (initial && !loaded && !pause && revision === startedRevision && !attempt) {
        server = clone(value); local = ids(value); baseline = [...local]; loaded = true; revision++;
        say('saved', active(value) ? '已读取完整顺序。调整后请手动保存并应用。' : '此专栏尚未公开或已归档，不能保存文章排序。'); render();
      } else stage(value);
    } catch {
      if (current()) freeze(pause || 'review', '无法确认服务器完整顺序。本页排序已保留，写入仍暂停，请重新读取。');
    } finally { if (serial === readSerial) { readBusy = false; controls(); } }
  }
  async function save() {
    if (!editable() || readBusy || writeBusy || !dirty() || attempt) return;
    const currentAttempt = { ids: [...local], revision, etag: server.siteEtag, uncertain: false, sent: false };
    const startedEpoch = ++epoch, current = () => !disposed && startedEpoch === epoch;
    attempt = currentAttempt; writeBusy = true; fresh = null; controls(); say('saving', '正在保存并应用完整顺序…');
    try {
      const context = await session(current); if (!context || !current()) return;
      currentAttempt.sent = true;
      const response = await request(path, { method: 'PUT', headers: {
        'Content-Type': 'application/json', 'X-CSRF-TOKEN': context.csrfToken, 'If-Match': currentAttempt.etag,
      }, body: JSON.stringify({ [articles ? 'articleIds' : 'columnIds']: currentAttempt.ids }) });
      if (disposed) return;
      if (!response.ok) {
        if (response.status >= 500) currentAttempt.uncertain = true; else if (attempt === currentAttempt) attempt = null;
        await failure(response, true, current); return;
      }
      const result = await response.json();
      if (disposed) return;
      if (!valid(result, response) || !active(result) || !equal(ids(result), currentAttempt.ids)) throw new Error('无法确认保存结果。');
      if (!current()) {
        // A read/auth signal superseded this write. Even a known successful write
        // invalidates a review captured while it was pending; reconcile again.
        // Keep the pending attempt until that choice: the untouched old baseline
        // may equal local order although the confirmed write changed the server.
        fresh = null; controls(); return;
      }
      if (attempt === currentAttempt) attempt = null;
      server = clone(result); baseline = ids(result); epoch++;
      say(dirty() ? 'dirty' : 'saved', dirty() ? '服务器已确认提交的完整顺序；较新的本页排序仍保留，尚未保存。' : '完整顺序已保存并应用。'); render();
    } catch {
      if (!disposed && attempt === currentAttempt && currentAttempt.sent) {
        currentAttempt.uncertain = true; fresh = null;
        if (current()) freeze('unknown', '保存结果尚未确认，本页完整顺序已保留。请读取服务器顺序核对，再明确选择；不会自动重复提交。');
      } else if (current()) freeze(pause || 'review', '无法确认登录会话，尚未发送保存请求。本页顺序已保留，请重新读取。');
    } finally {
      if (!currentAttempt.sent && attempt === currentAttempt) attempt = null;
      writeBusy = false; controls();
    }
  }
  function accept(keepLocal) {
    if (disposed || !fresh || readBusy || writeBusy || revision !== reviewRevision) return;
    if (keepLocal && (!loaded || !active(fresh) || !sameMembers(local, ids(fresh)))) return;
    server = clone(fresh); baseline = ids(server);
    if (!keepLocal) local = [...baseline];
    loaded = true; fresh = null; pause = null; attempt = null; revision++; epoch++;
    say(dirty() ? 'dirty' : 'saved', dirty() ? '已保留本页完整顺序。请再次点击保存，以刚读取的版本应用。'
      : active(server) ? '已确认当前完整顺序。' : '此专栏尚未公开或已归档，不能保存文章排序。'); render();
  }
  root.addEventListener('click', event => {
    const button = event.target.closest('button'); if (!button || button.disabled) return;
    if (button.hasAttribute('data-save')) void save();
    else if (button.hasAttribute('data-reload')) void readServer();
    else if (button.hasAttribute('data-use-server')) accept(false);
    else if (button.hasAttribute('data-keep-local')) accept(true);
    else if (button.dataset.move) {
      const id = button.closest('[data-order-id]')?.dataset.orderId;
      move(id, local.indexOf(id) + (button.dataset.move === 'up' ? -1 : 1), button.dataset.move);
    }
  }, events);
  root.addEventListener('keydown', event => {
    const row = event.target.closest('[data-order-id]');
    if (!row || !event.altKey || !['ArrowUp', 'ArrowDown'].includes(event.key) || !editable()) return;
    event.preventDefault(); move(row.dataset.orderId, local.indexOf(row.dataset.orderId) + (event.key === 'ArrowUp' ? -1 : 1));
  }, events);
  root.addEventListener('dragstart', event => {
    const row = event.target.closest('[data-order-id]');
    clearDrag();
    if (!currentRow(row) || !local.includes(row.dataset.orderId) || !editable() || local.length < 2) { event.preventDefault(); return; }
    drag = { id: row.dataset.orderId, row }; row.dataset.dragging = 'true';
    if (event.dataTransfer) { event.dataTransfer.effectAllowed = 'move'; event.dataTransfer.setData('text/plain', drag.id); }
  }, events);
  root.addEventListener('dragover', event => {
    if (currentDrag() && editable() && currentRow(event.target.closest('[data-order-id]'))) { event.preventDefault(); if (event.dataTransfer) event.dataTransfer.dropEffect = 'move'; }
  }, events);
  root.addEventListener('drop', event => {
    const row = event.target.closest('[data-order-id]');
    if (!currentRow(row) || !currentDrag() || !editable()) return;
    event.preventDefault(); const source = drag.id; clearDrag(); move(source, local.indexOf(row.dataset.orderId));
  }, events);
  root.addEventListener('dragend', event => { if (event.target.closest('[data-order-id]') === drag?.row) clearDrag(); }, events);
  window.addEventListener('beforeunload', event => { if (pending()) { event.preventDefault(); event.returnValue = ''; } }, events);
  const restorePage = event => {
    if (!event.persisted) return;
    window.removeEventListener('pageshow', restorePage); reloadPage();
  };
  const api = { hasPending: pending, destroy({ preserveRestoreListener = false } = {}) {
    if (!preserveRestoreListener) window.removeEventListener('pageshow', restorePage);
    if (disposed) return;
    disposed = true; epoch++; readSerial++; clearDrag(); abort.abort();
  } };
  window.addEventListener('pagehide', event => api.destroy({ preserveRestoreListener: event.persisted }), { once: true, signal: abort.signal });
  // Keep this outside the aborted controller: BFCache restores a disposed document.
  window.addEventListener('pageshow', restorePage);
  controls();
  if (articles && !validId(columnId)) freeze('error', '专栏地址无效，无法读取排序。'); else void readServer(true);
  return api;
}

const root = document.querySelector('[data-order-admin]');
if (root) createOrderAdmin(root);
