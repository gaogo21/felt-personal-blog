# F14 column management and public query boundary

This gate implements column administration and the public-column read adapter. It does not enable publication, global/within-column reordering, homepage configuration or the production public facade. Those remain F15, F16, F18 and F21 respectively. The production public facade remains fail-fast until F21 connects the complete set of approved queries.

## State, identities and snapshots

Columns have Draft, Active and Archived states. Creation produces Draft with a unique canonical slug, an optional empty name, introduction, homepage visibility and an append-only initial sort position. First activation requires a nonblank name and exactly three distinct Ready Image assets. An Active column may contain zero published articles. ShowOnHome controls homepage discovery only; an Active directory remains publicly eligible when it is false.

The first activation sets ActivatedAt and permanently freezes the slug. Archive requires zero currently published articles and preserves all foreign-key references. Restore moves Archived to Draft, preserving ActivatedAt and its frozen address. An Archived column cannot be edited until restored. No physical deletion is implemented.

A complete SaveAndApply form supplies name, slug, introduction, showOnHome and 0–3 unique mediaIds. Active requires exactly three. The server captures the current media library defaults into each independent DisplayMeta slot snapshot: alt, empty caption, credit, sourceUrl, licenseName and licenseUrl. It does not accept caller-supplied display HTML or metadata. A later library-default edit does not rewrite a saved column until that column is saved again. Activation validates the captured snapshots without refreshing them. Mandatory alt, Unicode scalar limits, NFC text normalization and HTTPS-only source/license URLs are validated server-side.

All mutations use the F07 executor, authenticated administrator session, CSRF, private/no-store responses and sanitized errors. Saves require the exact column ETag. Creation and state actions additionally require UUID idempotency keys. Same-key replay retains the original result; a changed canonical body conflicts. Each real mutation increments both column and SiteState versions and commits the references, audit and idempotency outcome in one transaction. A no-op save retains the versions.

The lock order is SiteState, target Column, then the sorted union of old and new Media IDs. Existing references are discovered under the column lock. Replacing slots deletes the previous rows inside that transaction before inserting replacements, avoiding a transient unique(column_id, media_id) collision when images swap slots. Archive eligibility counts Article.State=Published with an owned current ArticleRevision pointer, not work drafts, old revisions or an order-row shortcut. Maintenance prevents new business mutations; full process-wide maintenance draining remains F25.

## Administrative interface

/admin/columns lists, filters and creates columns. /admin/columns/{id} edits the complete in-memory form and offers explicit SaveAndApply, Activate, Archive and Restore actions. It shows current state, real published counts, column/site versions and the permanent-slug rule. This gate does not implement a global sort or article-membership sort interface.

Three image slots use the existing authenticated media library. Column mode is Image-only, hides per-article captions and requires library default changes to be saved first. A fresh Ready read verifies the selected image and current saved metadata. Slot intent and edit generation protect against asynchronous selection replacing newer form input. Unsubmitted form changes remain only in browser memory and trigger leave/refresh warnings. There is no column autosave or persistent form-recovery promise.

Creation/state unknown outcomes retain the exact request and idempotency key. Unknown PUT, expired login and stale-version conflicts pause writes until a successful server read and explicit recovery choice. Failed recovery reads do not unlock writes. Creation inputs are read-only while the request is in progress. Editing during an existing-column save is retained by captured input generations, and later UI responses must not replace newer local state. Media-processing completion refreshes the library without changing the selected slot or pending form.

## Public read adapter, reserved for F21 integration

IPublicColumnQueries exposes the Active directory and homepage-column projections. Homepage results additionally require ShowOnHome; a direct directory does not. Counts are based on owned current published revisions. Directory membership uses ColumnArticleOrder and verifies that each article is Published and its owned current revision still belongs to that column. Order is position then article ID. Neither drafts nor historical revisions establish a public member.

Column image projections use exactly the saved three-slot metadata snapshots and Ready Image records with trusted dimensions. They return only controlled /media/{UUID} URLs. Missing/corrupt required slots fail closed with a sanitized diagnostic rather than falling back to mutable defaults. Metadata, counts, image snapshots and membership are read in one RepeatableRead snapshot. A caller-owned RepeatableRead or Serializable transaction may be reused; weaker isolation fails closed and the adapter never commits its caller’s transaction. F21 must reuse this adapter and its complete field contract when composing the homepage and directory queries; it must not switch routes to this partial adapter before the complete public facade is ready.

## Evidence boundary

HTTP tests use TestServer with actual routing, authentication and CSRF but explicit fake persistence. Public graph tests exercise composable LINQ predicates and closed-connection Npgsql SQL translation, not PostgreSQL execution. UI tests use JSDOM, actual modules and controlled HTTP/clock fixtures. No EF InMemory or SQLite result is used as relational proof.

Real PostgreSQL transaction/FK/lock/concurrency behavior, complete publication integration and native-browser rendering/focus/touch remain pending. F12's extra denied static-normalization probe remains blocked and is not retried. The approved homepage and static baseline assets remain unchanged. No remote push, Site publication or production setup is part of F14.
