using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32.SafeHandles;

namespace Blog.Web.Infrastructure.Backup;

internal sealed record BackupArchiveFileStamp(
    uint DeviceMajor, uint DeviceMinor, ulong Inode, ulong Size,
    long ModifiedSeconds, uint ModifiedNanoseconds, long ChangedSeconds, uint ChangedNanoseconds,
    ushort Mode, uint Links);

internal static class BackupArchivePaths
{
    private const int ReadOnly = 0, DirectoryFlag = 0x10000, NoFollow = 0x20000,
        CloseOnExec = 0x80000, NonBlocking = 0x800, EmptyPath = 0x1000;

    public static string Full(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || !Path.IsPathFullyQualified(path) || path.Contains('\0') ||
            path.Split(Path.DirectorySeparatorChar).Any(x => x is "." or ".."))
            throw new BackupArchiveFailure("BACKUP_PATH_INVALID");
        return Path.TrimEndingDirectorySeparator(Path.GetFullPath(path));
    }

    public static bool Within(string path, string root) => path == root || path.StartsWith(root == "/" ? "/" : root + "/", StringComparison.Ordinal);

    public static void RequireSeparate(string first, string second)
    {
        if (Within(first, second) || Within(second, first)) throw new BackupArchiveFailure("BACKUP_PATH_OVERLAP");
    }

    public static bool Exists(string path) => Path.Exists(path) || new FileInfo(path).LinkTarget is not null;

    public static string EntryName(string name, BackupArchiveLimits limits, bool manifest = false)
    {
        if (string.IsNullOrEmpty(name) || Encoding.UTF8.GetByteCount(name) > limits.MaxPathBytes ||
            name.StartsWith('/') || name.Contains('\\') || name.Any(c => char.IsControl(c) || c is ':' or '<' or '>' or '"' or '|' or '?' or '*') ||
            !name.IsNormalized(NormalizationForm.FormC)) throw new BackupArchiveFailure("BACKUP_ENTRY_INVALID");
        var parts = name.Split('/');
        if (parts.Any(x => x.Length == 0 || x is "." or ".." || x.EndsWith('.') || x.EndsWith(' ') || Encoding.UTF8.GetByteCount(x) > 255))
            throw new BackupArchiveFailure("BACKUP_ENTRY_INVALID");
        if (manifest && name == "manifest.json") return name;
        if (name == "database.dump" || parts.Length > 1 && (parts[0] == "media" || parts[0] == "data-protection")) return name;
        throw new BackupArchiveFailure("BACKUP_ENTRY_INVALID");
    }

    public static void RequireNoNameConflicts(IEnumerable<string> names)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var directories = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var name in names)
        {
            if (!seen.Add(name) || directories.Contains(name)) throw new BackupArchiveFailure("BACKUP_ENTRY_DUPLICATE");
            var index = name.IndexOf('/');
            while (index >= 0)
            {
                var directory = name[..index];
                if (seen.Contains(directory)) throw new BackupArchiveFailure("BACKUP_ENTRY_DUPLICATE");
                directories.Add(directory);
                index = name.IndexOf('/', index + 1);
            }
        }
    }

    public static FileStream OpenRead(string path)
    {
        var handle = OpenNoFollow(path, false);
        try
        {
            var stamp = Stamp(handle);
            if ((stamp.Mode & 0xF000) != 0x8000) throw new BackupArchiveFailure("BACKUP_SOURCE_INVALID");
            return new FileStream(handle, FileAccess.Read, 64 * 1024, isAsync: false);
        }
        catch { handle.Dispose(); throw; }
    }

    public static BackupArchiveFileStamp ReadStamp(string path, bool directory = false)
    {
        using var handle = OpenNoFollow(path, directory);
        var stamp = Stamp(handle);
        if ((stamp.Mode & 0xF000) != (directory ? 0x4000 : 0x8000)) throw new BackupArchiveFailure("BACKUP_SOURCE_INVALID");
        return stamp;
    }

    public static BackupArchiveFileStamp Stamp(SafeFileHandle handle)
    {
        RequireLinux();
        // statx has a fixed, architecture-independent ABI. AT_EMPTY_PATH inspects
        // this open descriptor, not a path which could have been replaced.
        if (Statx(handle.DangerousGetHandle().ToInt32(), "", EmptyPath, 0x7ff, out var value) != 0 || (value.Mask & 0x7e3) != 0x7e3)
            throw new BackupArchiveFailure("BACKUP_SOURCE_UNAVAILABLE");
        return new(value.DeviceMajor, value.DeviceMinor, value.Inode, value.Size,
            value.ModifiedSeconds, value.ModifiedNanoseconds, value.ChangedSeconds, value.ChangedNanoseconds, value.Mode, value.Links);
    }

    public static void CheckDirectory(string path) => ReadStamp(path, directory: true);

    public static void CreatePrivateDirectory(string path)
    {
        RequireLinux();
        CheckDirectory(Path.GetDirectoryName(path)!);
        // mkdir, unlike Directory.CreateDirectory, never adopts an existing path.
        if (Mkdir(path, 0x1c0) != 0) throw new BackupArchiveFailure("BACKUP_DESTINATION_EXISTS_OR_UNAVAILABLE");
        CheckDirectory(path);
    }

    public static FileStream CreatePrivateFile(string path)
    {
        if (!OperatingSystem.IsLinux()) throw new BackupArchiveFailure("BACKUP_REQUIRES_LINUX");
        CheckDirectory(Path.GetDirectoryName(path)!);
        return new FileStream(path, new FileStreamOptions
        {
            Mode = FileMode.CreateNew, Access = FileAccess.ReadWrite, Share = FileShare.None,
            BufferSize = 64 * 1024, Options = FileOptions.Asynchronous | FileOptions.SequentialScan,
            UnixCreateMode = UnixFileMode.UserRead | UnixFileMode.UserWrite
        });
    }

    private static SafeFileHandle OpenNoFollow(string path, bool directory)
    {
        RequireLinux();
        path = Full(path);
        var descriptor = Open("/", ReadOnly | DirectoryFlag | NoFollow | CloseOnExec);
        if (descriptor < 0) throw new BackupArchiveFailure("BACKUP_SOURCE_UNAVAILABLE");
        var handle = new SafeFileHandle((IntPtr)descriptor, ownsHandle: true);
        try
        {
            var segments = path.Split('/', StringSplitOptions.RemoveEmptyEntries);
            for (var i = 0; i < segments.Length; i++)
            {
                var flags = ReadOnly | NoFollow | CloseOnExec | NonBlocking;
                if (directory || i < segments.Length - 1) flags |= DirectoryFlag;
                descriptor = OpenAt(handle.DangerousGetHandle().ToInt32(), segments[i], flags);
                if (descriptor < 0) throw new BackupArchiveFailure("BACKUP_SOURCE_INVALID");
                var next = new SafeFileHandle((IntPtr)descriptor, ownsHandle: true);
                handle.Dispose(); handle = next;
            }
            return handle;
        }
        catch { handle.Dispose(); throw; }
    }

    private static void RequireLinux()
    {
        if (!OperatingSystem.IsLinux()) throw new BackupArchiveFailure("BACKUP_REQUIRES_LINUX");
    }

    [StructLayout(LayoutKind.Explicit, Size = 256)]
    private struct StatxBuffer
    {
        [FieldOffset(0)] public uint Mask;
        [FieldOffset(16)] public uint Links;
        [FieldOffset(28)] public ushort Mode;
        [FieldOffset(32)] public ulong Inode;
        [FieldOffset(40)] public ulong Size;
        [FieldOffset(96)] public long ChangedSeconds;
        [FieldOffset(104)] public uint ChangedNanoseconds;
        [FieldOffset(112)] public long ModifiedSeconds;
        [FieldOffset(120)] public uint ModifiedNanoseconds;
        [FieldOffset(136)] public uint DeviceMajor;
        [FieldOffset(140)] public uint DeviceMinor;
    }

    [DllImport("libc", EntryPoint = "open", SetLastError = true)]
    private static extern int Open([MarshalAs(UnmanagedType.LPUTF8Str)] string path, int flags);
    [DllImport("libc", EntryPoint = "openat", SetLastError = true)]
    private static extern int OpenAt(int directory, [MarshalAs(UnmanagedType.LPUTF8Str)] string path, int flags);
    [DllImport("libc", EntryPoint = "statx", SetLastError = true)]
    private static extern int Statx(int directory, [MarshalAs(UnmanagedType.LPUTF8Str)] string path, int flags, uint mask, out StatxBuffer value);
    [DllImport("libc", EntryPoint = "mkdir", SetLastError = true)]
    private static extern int Mkdir([MarshalAs(UnmanagedType.LPUTF8Str)] string path, uint mode);
}
