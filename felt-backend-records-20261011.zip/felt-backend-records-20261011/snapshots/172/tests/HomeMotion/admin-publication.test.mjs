import { JSDOM, VirtualConsole } from 'jsdom';
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

// These are deterministic DOM/controller checks with a fake clock and HTTP/editor
// stubs. They do not claim native navigation, clipboard, download, or IME coverage.
const source = readFileSync('src/Blog.Web/wwwroot/js/admin/articles.js', 'utf8');
const id = '11111111-1111-4111-8111-111111111111';
const aTag = `"a-${id}-1"`, dTag = `"d-${id}-1"`;
const baseArticle = { id, slug: 'original', state: 'Draft', firstPublishedAt: null, published: null, articleVersion: 1, articleEtag: aTag };
const columnId = '22222222-2222-4222-8222-222222222222';
const activeColumn = { id: columnId, name: '公开专栏', state: 'Active' };
const body = text => ({ type: 'doc', content: [{ type: 'paragraph', content: [{ type: 'text', text }] }] });
const baseDraft = { articleId: id, title: '原标题', summary: '原摘要', columnId: '22222222-2222-4222-8222-222222222222',
  coverMediaId: '33333333-3333-4333-8333-333333333333', coverDisplayMeta: { alt: '封面', caption: '', credit: '作者', sourceUrl: '', licenseName: '', licenseUrl: '' },
  contentJson: body('原正文'), schemaVersion: 1, draftVersion: 1, contentHash: 'fixture-hash-1', draftEtag: dTag, updatedAt: '2026-10-10T09:00:00Z' };
const response = (value, status = 200) => ({ ok: status >= 200 && status < 300, status, json: async () => structuredClone(value) });
const deferred = () => { let resolve, reject; const promise = new Promise((yes, no) => { resolve = yes; reject = no; }); return { promise, resolve, reject }; };
const flush = async () => { for (let i = 0; i < 60; i++) await Promise.resolve(); };
function environment({ override, seed = true, renderedTag = dTag, draft = baseDraft, article = baseArticle, editable = true, editorLoader, columns = [activeColumn], actualEditor = false } = {}) {
  const console = new VirtualConsole();
  console.on('jsdomError', error => { throw error; });
  const dom = new JSDOM(`<section class="admin-articles"><form id="article-identity"><input name="slug" value="original"><button type="submit">保存地址</button></form>
    <form id="article-draft"><input name="title" value="原标题"><textarea name="summary">原摘要</textarea><select id="article-column" name="columnId"></select><div id="body-editor"></div><button type="submit">保存</button></form>
    <button id="article-publish" type="button">发布</button><button id="article-publish-retry" type="button" hidden>核对上次发布结果</button><p id="article-publication-details"></p><button id="article-columns-refresh" type="button">刷新专栏</button><p id="article-column-status"></p><section id="article-media-library"></section><button id="article-preview" type="button">预览</button><p id="article-status" role="status"></p><p id="draft-save-details"></p>
    <button id="draft-recovery-copy" type="button">复制恢复 JSON</button><button id="draft-recovery-download" type="button">下载恢复 JSON</button>
    <button id="draft-reconcile" type="button">重新读取服务器版本</button><a id="draft-login" href="/admin/login" target="_blank" rel="noopener">重新登录</a>
    <div id="draft-recovery-choice" hidden><p id="draft-server-details"></p><button id="draft-use-server" type="button">载入服务器版本并替换本页输入</button>
    <button id="draft-keep-local" type="button">保留本页输入并继续</button></div></section>`, { url: 'https://localmock.invalid/admin/articles/' + id, runScripts: 'outside-only', pretendToBeVisual: true, virtualConsole: console });
  const w = dom.window, root = w.document.querySelector('section'), calls = [], navigations = [], copies = [], downloads = [], blobs = [];
  Object.assign(root.dataset, { articleId: id, articleEtag: aTag, draftEtag: renderedTag, editable: String(editable) });
  if (!editable) for (const input of w.document.querySelectorAll('#article-draft input, #article-draft textarea, #article-draft button, #article-identity input, #article-identity button, #article-preview')) input.disabled = true;
  if (seed) { const seedElement = w.document.createElement('textarea'); seedElement.id = 'draft-initial-state'; seedElement.hidden = true; seedElement.value = JSON.stringify({ article, draft }); root.append(seedElement); }
  let now = 0, nextTimer = 0, active = 0, maxActive = 0, destroyed = 0, editorEditable = false, editorContent, editorOptions, editorReplacements = 0, mediaOptions, mediaPending = false;
  const timers = new Map();
  w.Date.now = () => now;
  w.setTimeout = (fn, delay) => { const key = ++nextTimer; timers.set(key, { at: now + Number(delay), fn }); return key; };
  w.clearTimeout = key => timers.delete(key);
  let serverDraft = structuredClone(draft), serverArticle = structuredClone(article);
  const save = requestBody => {
    serverDraft = { ...serverDraft, ...structuredClone(requestBody), draftVersion: serverDraft.draftVersion + 1,
      draftEtag: `"d-${id}-${serverDraft.draftVersion + 1}"`, contentHash: 'fixture-hash-' + (serverDraft.draftVersion + 1), updatedAt: '2026-10-10T10:00:00Z' };
    return structuredClone(serverDraft);
  };
  const publications = new Map();
  const commitPublication = request => {
    const key = request.headers['Idempotency-Key'];
    if (publications.has(key)) return structuredClone(publications.get(key));
    const source = JSON.parse(request.body).expectedDraftVersion;
    serverArticle = { ...serverArticle, state: 'Published', articleVersion: serverArticle.articleVersion + 1,
      articleEtag: `"a-${id}-${serverArticle.articleVersion + 1}"`, firstPublishedAt: '2026-10-10T11:00:00Z', lastPublishedAt: '2026-10-10T11:00:00Z',
      published: { revisionId: '44444444-4444-4444-8444-444444444444', title: serverDraft.title, summary: serverDraft.summary, columnId: serverDraft.columnId, contentHash: serverDraft.contentHash, revisionNo: publications.size + 1 } };
    serverDraft = { ...serverDraft, draftVersion: serverDraft.draftVersion + 1, draftEtag: `"d-${id}-${serverDraft.draftVersion + 1}"`, basePublishedRevisionId: serverArticle.published.revisionId };
    const result = { state: 'Published', publishedRevisionId: serverArticle.published.revisionId, firstPublishedAt: serverArticle.firstPublishedAt, lastPublishedAt: serverArticle.lastPublishedAt,
      url: '/articles/original', articleVersion: serverArticle.articleVersion, articleEtag: serverArticle.articleEtag,
      draftVersion: source + 1, draftEtag: serverDraft.draftEtag, contentHash: serverDraft.contentHash };
    publications.set(key, structuredClone(result)); return result;
  };
  w.fetch = async (path, options = {}) => {
    calls.push({ path, options, at: now });
    const writing = ['PUT', 'PATCH', 'POST'].includes(options.method);
    if (writing) { active++; maxActive = Math.max(active, maxActive); }
    try {
      const special = override?.(path, options, { calls, save, commitPublication, get draft() { return serverDraft; }, get article() { return serverArticle; } });
      if (special !== undefined && special !== null) return await special;
      if (path.includes('/columns?')) return response({ items: columns, page: Number(new URL(path, 'https://fixture.invalid').searchParams.get('page')), pageSize: 100, total: columns.length });
      if (path.endsWith('/publish') && options.method === 'POST') return response(commitPublication(options));
      if (path.endsWith('/bootstrap')) return response({ csrfToken: 'fixture-csrf-secret' });
      if (options.method === 'PUT') return response(save(JSON.parse(options.body)));
      if (options.method === 'PATCH') { serverArticle = { ...serverArticle, slug: JSON.parse(options.body).slug, articleVersion: serverArticle.articleVersion + 1, articleEtag: `"a-${id}-${serverArticle.articleVersion + 1}"` }; return response(serverArticle); }
      return response(path.endsWith('/draft') ? serverDraft : serverArticle);
    } finally { if (writing) active--; }
  };
  const defaultEditor = async () => ({ createBodyEditor(_element, options) {
    editorOptions = options; editorContent = structuredClone(options.content);
    return { getJSON: () => structuredClone(editorContent), setContent(value) { editorReplacements++; editorContent = structuredClone(value); return true; }, setEditable(value) { editorEditable = value; }, destroy() { destroyed++; } };
  } });
  w.__loadMedia = async () => ({ createMediaLibrary(_element, options) { mediaOptions = options; return { setEnabled() {}, hasPending: () => mediaPending, destroy() {} }; } });
  w.__loadEditor = editorLoader ? () => editorLoader(defaultEditor) : defaultEditor;
  if (actualEditor) {
    for (const name of ['window', 'document', 'navigator', 'HTMLElement', 'Element', 'Node', 'MutationObserver', 'DOMParser', 'Event', 'KeyboardEvent', 'MouseEvent', 'AbortController', 'getComputedStyle', 'location', 'DOMRect']) {
      Object.defineProperty(globalThis, name, { value: name === 'getComputedStyle' ? w[name].bind(w) : w[name], configurable: true });
    }
    globalThis.requestAnimationFrame = w.requestAnimationFrame.bind(w); globalThis.cancelAnimationFrame = w.cancelAnimationFrame.bind(w);
    w.Range.prototype.getClientRects = () => []; w.Range.prototype.getBoundingClientRect = () => ({ left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 }); w.scrollBy = () => {};
    w.__loadEditor = async () => {
      const bundled = await import('data:text/javascript;base64,' + Buffer.from(readFileSync('src/Blog.Web/wwwroot/js/admin/editor.bundle.js', 'utf8')).toString('base64'));
      return { createBodyEditor(element, options) {
        const actual = bundled.createBodyEditor(element, options);
        return { ...actual, setContent(value) { editorReplacements++; return actual.setContent(value); }, destroy() { destroyed++; actual.destroy(); } };
      } };
    };
  }
  w.__navigate = url => navigations.push(url);
  Object.defineProperty(w.navigator, 'clipboard', { value: { writeText: async text => { copies.push(text); } } });
  w.URL.createObjectURL = blob => { blobs.push(blob); return `blob:fixture-${blobs.length}`; };
  const revoked = []; w.URL.revokeObjectURL = value => revoked.push(value);
  w.HTMLAnchorElement.prototype.click = function () { downloads.push({ href: this.href, filename: this.download }); };
  w.eval(source.replace("import('./editor.bundle.js')", 'globalThis.__loadEditor()').replace("import('./media-library.js')", 'globalThis.__loadMedia()').replaceAll('location.assign(', 'globalThis.__navigate('));
  return { w, calls, navigations, copies, downloads, blobs, revoked, timers, save, commitPublication,
    auth() { mediaOptions.onAuthRequired(); },
    setMediaPending(value) { mediaPending = value; },
    get editorReplacements() { return editorReplacements; },
    get publishCalls() { return calls.filter(call => call.path.endsWith('/publish') && call.options.method === 'POST'); },
    get publicationText() { return w.document.querySelector('#article-publication-details').textContent; },
    choose(value) { const field = w.document.querySelector('#article-column'); field.value = value; field.dispatchEvent(new w.Event('change', { bubbles: true })); },
    get maxActive() { return maxActive; }, get destroyed() { return destroyed; }, get editorEditable() { return editorEditable; },
    get state() { return root.dataset.saveState; }, get message() { return w.document.querySelector('#article-status').textContent; },
    get serverDraft() { return serverDraft; }, set serverDraft(value) { serverDraft = structuredClone(value); },
    get serverArticle() { return serverArticle; }, set serverArticle(value) { serverArticle = structuredClone(value); },
    get content() { return editorContent; }, get putCalls() { return calls.filter(call => call.options.method === 'PUT'); },
    input(selector, value) { const field = w.document.querySelector(selector); field.value = value; field.dispatchEvent(new w.Event('input', { bubbles: true })); },
    changeBody(value) { editorContent = structuredClone(value); editorOptions.onUpdate(); },
    submit(selector = '#article-draft') { w.document.querySelector(selector).dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true })); },
    click(selector) { w.document.querySelector(selector).click(); },
    value(selector) { return w.document.querySelector(selector).value; },
    disabled(selector) { return w.document.querySelector(selector).disabled; },
    beforeUnload() { const event = new w.Event('beforeunload', { cancelable: true }); w.dispatchEvent(event); return event.defaultPrevented; },
    async tick(milliseconds) {
      const target = now + milliseconds;
      while (true) {
        const next = [...timers].filter(([, value]) => value.at <= target).sort((a, b) => a[1].at - b[1].at || a[0] - b[0])[0];
        if (!next) break;
        now = next[1].at; timers.delete(next[0]); next[1].fn(); await flush();
      }
      now = target; await flush();
    },
    close() { w.dispatchEvent(new w.Event('pagehide')); dom.window.close(); }
  };
}
const results = [];
async function check(name, run) { let e; try { await run(value => { e = value; return e; }); results.push({ name, status: 'passed' }); console.log('PASS ' + name); } catch (error) { results.push({ name, status: 'failed', error: error.stack }); console.error('FAIL ' + name + ': ' + error.stack); } finally { e?.close(); } }
const publishClick = async e => { e.click('#article-publish'); await flush(); };
await check('All Active-column pages are loaded before publication; selection is saved in the full draft', async track => {
  const second = '22222222-2222-4222-8222-222222222223', third = '22222222-2222-4222-8222-222222222224';
  const items = [activeColumn, { id: second, name: '第二栏', state: 'Active' }, { id: third, name: '第三栏', state: 'Active' }];
  const e = track(environment({ override: path => { if (path.includes('/columns?')) { const p = Number(new URL(path, 'https://fixture.invalid').searchParams.get('page')); return response({ items: items.slice(p - 1, p), total: 3, page: p, pageSize: 1 }); } } })); await flush();
  assert.equal(e.calls.filter(x => x.path.includes('/columns?')).length, 3); assert.equal(e.w.document.querySelector('#article-column').options.length, 4);
  e.choose(third); await publishClick(e); assert.equal(e.putCalls.length, 1); assert.equal(JSON.parse(e.putCalls[0].options.body).columnId, third); assert.equal(e.publishCalls.length, 1); assert.equal(JSON.parse(e.publishCalls[0].options.body).expectedDraftVersion, 2);
});
await check('No Active columns leaves null-column drafts saveable and prevents publishing', async track => {
  const e = track(environment({ columns: [], draft: { ...baseDraft, columnId: null } })); await flush(); e.input('[name=title]', '可保存空专栏稿'); e.submit(); await flush(); assert.equal(JSON.parse(e.putCalls[0].options.body).columnId, null); await publishClick(e);
  assert.equal(e.publishCalls.length, 0); assert.match(e.message, /Active/); assert.match(e.w.document.querySelector('#article-column-status').textContent, /专栏管理/);
});
await check('An inactive previously selected column remains visible and is never silently cleared', async track => {
  const e = track(environment({ columns: [] })); await flush(); assert.equal(e.value('#article-column'), columnId); assert.match(e.w.document.querySelector('#article-column').selectedOptions[0].textContent, /不能发布/); e.input('[name=summary]', '仍保留原专栏'); e.submit(); await flush(); assert.equal(JSON.parse(e.putCalls[0].options.body).columnId, columnId); await publishClick(e); assert.equal(e.publishCalls.length, 0);
});
await check('A later column page failure cannot publish using an incomplete Active list', async track => {
  const e = track(environment({ override: path => path.includes('/columns?') ? new URL(path, 'https://fixture.invalid').searchParams.get('page') === '1' ? response({ items: [activeColumn], total: 2, page: 1, pageSize: 1 }) : response({}, 503) : undefined })); await flush(); await publishClick(e); assert.equal(e.publishCalls.length, 0); assert.match(e.message, /刷新专栏/); e.input('[name=title]', '失败仍可保存'); e.submit(); await flush(); assert.equal(e.putCalls.length, 1);
});
await check('A delayed column refresh never replaces the newer selection or local draft fields', async track => {
  const pending = deferred(); let reads = 0;
  const e = track(environment({ override: path => path.includes('/columns?') && ++reads === 2 ? pending.promise : undefined })); await flush(); e.click('#article-columns-refresh'); await flush(); e.choose(''); e.input('[name=summary]', '刷新中输入'); pending.resolve(response({ items: [activeColumn], total: 1, page: 1, pageSize: 100 })); await flush();
  assert.equal(e.value('#article-column'), ''); assert.equal(e.value('[name=summary]'), '刷新中输入'); e.submit(); await flush(); assert.equal(JSON.parse(e.putCalls[0].options.body).columnId, null);
});
await check('A clean publication sends the exact version, article If-Match, UUID and CSRF; locks slug after success', async track => {
  const e = track(environment()); await flush(); await publishClick(e); assert.equal(e.putCalls.length, 0); assert.equal(e.publishCalls.length, 1);
  const sent = e.publishCalls[0]; assert.deepEqual(JSON.parse(sent.options.body), { expectedDraftVersion: 1 }); assert.equal(sent.options.headers['If-Match'], aTag); assert.match(sent.options.headers['Idempotency-Key'], /^[0-9a-f-]{36}$/); assert.equal(sent.options.headers['X-CSRF-TOKEN'], 'fixture-csrf-secret'); assert.equal(sent.options.credentials, 'same-origin');
  assert.equal(e.state, 'published'); assert.equal(e.disabled('[name=slug]'), true); assert.equal(e.editorReplacements, 0); assert.match(e.publicationText, /线上版本一致.*fixture-hash-1.*草稿版本：2/); assert.equal(e.beforeUnload(), false);
});
await check('Publishing flushes every queued edit and delayed save JSON before pinning its version', async track => {
  const first = deferred(), second = deferred(); let bodyOne, bodyTwo, count = 0;
  const e = track(environment({ override: (_path, options) => { if (options.method === 'PUT') { count++; if (count === 1) { bodyOne = JSON.parse(options.body); return first.promise; } if (count === 2) { bodyTwo = JSON.parse(options.body); return { ok: true, status: 200, json: () => second.promise }; } } } })); await flush();
  e.input('[name=title]', '第一稿'); e.submit(); await flush(); e.input('[name=title]', '第二稿'); await publishClick(e); assert.equal(e.publishCalls.length, 0); first.resolve(response(e.save(bodyOne))); await flush(); e.changeBody(body('第三稿正文')); second.resolve(e.save(bodyTwo)); await flush();
  assert.equal(e.putCalls.length, 3); assert.equal(e.publishCalls.length, 1); assert.deepEqual(JSON.parse(e.publishCalls[0].options.body), { expectedDraftVersion: 4 }); assert.equal(e.maxActive, 1); assert.deepEqual(e.content, body('第三稿正文')); assert.equal(e.state, 'published');
});
await check('New input during publication bootstrap cancels preparation and publishes only the newly saved version', async track => {
  const token = deferred(); let bootstraps = 0;
  const e = track(environment({ override: path => path.endsWith('/bootstrap') && ++bootstraps === 1 ? { ok: true, status: 200, json: () => token.promise } : undefined })); await flush(); await publishClick(e); e.input('[name=title]', '准备时新标题'); e.changeBody(body('准备时正文')); token.resolve({ csrfToken: 'token' }); await flush();
  assert.equal(e.putCalls.length, 1); assert.equal(e.publishCalls.length, 1); assert.equal(JSON.parse(e.publishCalls[0].options.body).expectedDraftVersion, 2); assert.equal(e.serverArticle.published.title, '准备时新标题'); assert.deepEqual(e.content, body('准备时正文'));
});
await check('IME beginning during publication preparation blocks both stale publish and partial draft until compositionend', async track => {
  const token = deferred(); let first = true;
  const e = track(environment({ override: path => path.endsWith('/bootstrap') && first ? (first = false, token.promise) : undefined })); await flush(); await publishClick(e); const title = e.w.document.querySelector('[name=title]'); title.dispatchEvent(new e.w.Event('compositionstart', { bubbles: true })); e.input('[name=title]', '拼'); token.resolve(response({ csrfToken: 'token' })); await flush(); await e.tick(20000); assert.equal(e.putCalls.length, 0); assert.equal(e.publishCalls.length, 0);
  e.input('[name=title]', '拼音完成'); title.dispatchEvent(new e.w.Event('compositionend', { bubbles: true })); await flush(); assert.equal(e.putCalls.length, 1); assert.equal(e.publishCalls.length, 1); assert.equal(e.serverArticle.published.title, '拼音完成');
});
for (const late of [false, true]) for (const kind of ['slug', 'media']) await check(`${late ? 'Late preparation' : 'Initial'} unsaved ${kind} blocks publication without silently saving identity or media`, async track => {
  const token = deferred(); let first = true;
  const e = track(environment({ override: path => late && path.endsWith('/bootstrap') && first ? (first = false, token.promise) : undefined })); await flush(); if (late) await publishClick(e); if (kind === 'slug') e.input('[name=slug]', 'new-slug'); else e.setMediaPending(true);
  if (late) token.resolve(response({ csrfToken: 'token' })); else await publishClick(e); await flush(); assert.equal(e.publishCalls.length, 0); assert.equal(e.calls.filter(x => x.options.method === 'PATCH').length, 0); assert.match(e.message, kind === 'slug' ? /地址尚未保存/ : /媒体/); assert.equal(e.beforeUnload(), true);
});
await check('Late publication JSON advances the draft ETag only and preserves newer title, summary, body and column', async track => {
  const json = deferred(); let sent;
  const e = track(environment({ override: (path, options, server) => { if (path.endsWith('/publish')) { sent = server.commitPublication(options); return { ok: true, status: 200, json: () => json.promise }; } } })); await flush(); await publishClick(e); e.input('[name=title]', '发布中较新标题'); e.input('[name=summary]', '较新摘要'); e.changeBody(body('较新正文')); e.choose(''); await e.tick(20000); assert.equal(e.putCalls.length, 0); json.resolve(sent); await flush();
  assert.equal(e.putCalls.length, 1); assert.equal(e.putCalls[0].options.headers['If-Match'], `"d-${id}-2"`); const saved = JSON.parse(e.putCalls[0].options.body); assert.equal(saved.title, '发布中较新标题'); assert.equal(saved.summary, '较新摘要'); assert.equal(saved.columnId, null); assert.deepEqual(saved.contentJson, body('较新正文')); assert.equal(e.editorReplacements, 0); assert.match(e.publicationText, /尚未发布的修改.*fixture-hash-1/); assert.equal(e.serverArticle.published.title, baseDraft.title);
});
await check('Repeated and synthetic publish clicks cannot overlap or duplicate the publication', async track => {
  const pending = deferred(); let result;
  const e = track(environment({ override: (path, options, server) => { if (path.endsWith('/publish')) { result = server.commitPublication(options); return pending.promise; } } })); await flush(); await publishClick(e); for (let i = 0; i < 5; i++) e.w.document.querySelector('#article-publish').dispatchEvent(new e.w.Event('click', { bubbles: true })); await flush(); assert.equal(e.publishCalls.length, 1); pending.resolve(response(result)); await flush(); assert.equal(e.state, 'published');
});
await check('Unknown publication preserves the same UUID, body and old article ETag for explicit retry, including newer input', async track => {
  let first = true;
  const e = track(environment({ override: (path, options, server) => { if (path.endsWith('/publish') && first) { first = false; server.commitPublication(options); return Promise.reject(new Error('lost after commit')); } } })); await flush(); await publishClick(e); assert.equal(e.state, 'unknown'); assert.equal(e.beforeUnload(), true); await e.tick(60000); assert.equal(e.publishCalls.length, 1); e.input('[name=title]', '未知期间新标题'); e.click('#article-publish'); e.submit(); await flush(); assert.equal(e.publishCalls.length, 1); e.click('#article-publish-retry'); await flush();
  assert.equal(e.publishCalls.length, 2); assert.equal(e.publishCalls[1].options.body, e.publishCalls[0].options.body); assert.equal(e.publishCalls[1].options.headers['Idempotency-Key'], e.publishCalls[0].options.headers['Idempotency-Key']); assert.equal(e.publishCalls[1].options.headers['If-Match'], aTag); assert.equal(e.value('[name=title]'), '未知期间新标题'); await e.tick(1500); assert.equal(e.putCalls[0].options.headers['If-Match'], `"d-${id}-2"`); assert.match(e.publicationText, /尚未发布的修改/);
});
await check('Clean unknown publication still warns before unload and no automatic retry occurs', async track => {
  const e = track(environment({ override: path => path.endsWith('/publish') ? response({}, 503) : undefined })); await flush(); await publishClick(e); assert.equal(e.beforeUnload(), true); assert.equal(e.state, 'unknown'); await e.tick(60000); assert.equal(e.publishCalls.length, 1); assert.equal(e.disabled('#article-publish-retry'), false);
});
for (const code of [400, 409, 412, 422, 428, 429, 503]) await check(`Publish HTTP ${code} preserves current input, reports API detail and does not automatically republish`, async track => {
  const e = track(environment({ override: path => path.endsWith('/publish') ? { ...response({ code: 'TEST_FAILURE', requestId: 'fixture-request', fieldErrors: { columnId: ['Select Active column'] } }, code), headers: { get: name => name === 'Retry-After' ? '30' : null } } : undefined })); await flush(); e.input('[name=title]', '保留错误稿'); await publishClick(e); assert.equal(e.value('[name=title]'), '保留错误稿'); assert.match(e.message, /TEST_FAILURE.*columnId.*fixture-request.*30/); await e.tick(60000); assert.equal(e.publishCalls.length, 1);
  if ([412, 428].includes(code)) { e.submit(); await publishClick(e); assert.equal(e.publishCalls.length, 1); assert.equal(e.disabled('#article-publish-retry'), true); }
});
for (const stage of ['bootstrap-response', 'bootstrap-json', 'post-response', 'post-json', 'post-reject', 'post-error-json']) await check(`Media auth invalidation defeats stale publication ${stage} completion and requires explicit recovery`, async track => {
  const gate = deferred(); let result, boot = 0;
  const e = track(environment({ override: (path, options, server) => {
    if (path.endsWith('/bootstrap') && ++boot === 1) { if (stage === 'bootstrap-response') return gate.promise; if (stage === 'bootstrap-json') return { ok: true, status: 200, json: () => gate.promise }; }
    if (path.endsWith('/publish')) { result = server.commitPublication(options); if (stage === 'post-response' || stage === 'post-reject') return gate.promise; if (stage === 'post-json') return { ok: true, status: 200, json: () => gate.promise }; if (stage === 'post-error-json') return { ok: false, status: 503, json: () => gate.promise }; }
  } })); await flush(); await publishClick(e); e.auth(); e.input('[name=title]', '登录失效仍保留');
  if (stage === 'bootstrap-response') gate.resolve(response({ csrfToken: 'late' })); else if (stage === 'bootstrap-json') gate.resolve({ csrfToken: 'late' }); else if (stage === 'post-response') gate.resolve(response(result)); else if (stage === 'post-json') gate.resolve(result); else if (stage === 'post-reject') gate.reject(new Error('late failed network')); else gate.resolve({ code: 'OLD_UNKNOWN_ERROR' });
  await flush(); assert.equal(e.state, 'auth'); assert.equal(e.value('[name=title]'), '登录失效仍保留'); assert.equal(e.disabled('#article-publish-retry'), true); assert.doesNotMatch(e.message, /OLD_UNKNOWN_ERROR/); await e.tick(60000); assert.equal(e.putCalls.length, 0); assert.equal(e.publishCalls.length, stage.startsWith('bootstrap') ? 0 : 1);
});
for (const stage of ['save-response', 'save-json', 'save-reject', 'identity-json', 'column-json', 'recovery-json']) await check(`Auth epoch also invalidates older ${stage} without losing input or unfreezing writes`, async track => {
  const gate = deferred(); let saved, reads = 0;
  const e = track(environment({ override: (path, options, server) => {
    if (options.method === 'PUT') { saved = server.save(JSON.parse(options.body)); if (stage === 'save-response' || stage === 'save-reject') return gate.promise; if (stage === 'save-json') return { ok: true, status: 200, json: () => gate.promise }; }
    if (options.method === 'PATCH' && stage === 'identity-json') return { ok: true, status: 200, json: () => gate.promise };
    if (path.includes('/columns?') && stage === 'column-json' && ++reads === 2) return { ok: true, status: 200, json: () => gate.promise };
    if (!options.method && path.endsWith('/draft') && stage === 'recovery-json' && ++reads === 2) return { ok: true, status: 200, json: () => gate.promise };
  } })); await flush();
  if (stage.startsWith('save')) { e.input('[name=title]', '已提交'); e.submit(); } else if (stage === 'identity-json') { e.input('[name=slug]', 'changed'); e.submit('#article-identity'); } else if (stage === 'column-json') e.click('#article-columns-refresh'); else e.click('#draft-reconcile');
  await flush(); e.auth(); e.input('[name=title]', '新的未保存标题');
  if (stage === 'save-response') gate.resolve(response(saved)); else if (stage === 'save-json') gate.resolve(saved); else if (stage === 'save-reject') gate.reject(new Error('late')); else if (stage === 'identity-json') gate.resolve({ ...baseArticle, slug: 'changed' }); else if (stage === 'column-json') gate.resolve({ items: [], total: 0, page: 1, pageSize: 100 }); else gate.resolve(baseDraft);
  await flush(); assert.equal(e.state, 'auth'); assert.equal(e.value('[name=title]'), '新的未保存标题'); assert.equal(e.w.document.querySelector('#draft-recovery-choice').hidden, true); e.submit(); await e.tick(60000); assert.equal(e.putCalls.length, stage.startsWith('save') ? 1 : 0);
});
await check('Publication 401 recovery requires successful reread and explicit choice, never automatically republishes', async track => {
  let unauth = true;
  const e = track(environment({ override: path => path.endsWith('/publish') && unauth ? response({}, 401) : undefined })); await flush(); await publishClick(e); assert.equal(e.state, 'auth'); unauth = false; e.input('[name=title]', '重登保留稿'); e.click('#draft-reconcile'); await flush(); assert.equal(e.state, 'auth'); assert.equal(e.disabled('#draft-keep-local'), false); await e.tick(60000); assert.equal(e.publishCalls.length, 1); e.click('#draft-keep-local'); await flush(); assert.equal(e.putCalls.length, 1); assert.equal(e.publishCalls.length, 1); await publishClick(e); assert.equal(e.publishCalls.length, 2); assert.equal(e.serverArticle.published.title, '重登保留稿');
});
await check('Unknown publication followed by auth recovery retains its pinned key until explicit replay', async track => {
  const gate = deferred(); let first = true, result;
  const e = track(environment({ override: (path, options, server) => { if (path.endsWith('/publish') && first) { first = false; result = server.commitPublication(options); return gate.promise; } } })); await flush(); await publishClick(e); e.auth(); gate.resolve(response(result)); await flush(); e.input('[name=title]', '登录恢复后输入'); e.click('#draft-reconcile'); await flush(); assert.equal(e.disabled('#draft-keep-local'), false); assert.equal(e.disabled('#draft-use-server'), true); assert.equal(e.disabled('#article-publish-retry'), true); e.click('#draft-keep-local'); await flush(); assert.equal(e.disabled('#article-publish-retry'), false); assert.equal(e.putCalls.length, 0); e.click('#article-publish-retry'); await flush();
  assert.equal(e.publishCalls[1].options.headers['Idempotency-Key'], e.publishCalls[0].options.headers['Idempotency-Key']); assert.equal(e.value('[name=title]'), '登录恢复后输入'); assert.notEqual(e.state, 'conflict'); await e.tick(1500); assert.equal(e.putCalls.length, 1);
});
for (const needsAuthRecovery of [false, true]) await check(`Unknown uncommitted publication with ${needsAuthRecovery ? 'auth recovery' : 'direct reconciliation'} accepts its original baseline and first replay commit resumes newer-input autosave`, async track => {
  let first = true;
  const e = track(environment({ override: path => {
    if (path.endsWith('/publish') && first) { first = false; return Promise.reject(new Error('network failed before commit')); }
  } })); await flush(); await publishClick(e); const original = e.publishCalls[0];
  assert.equal(e.state, 'unknown'); assert.equal(e.serverArticle.articleEtag, aTag); assert.equal(e.serverDraft.draftEtag, dTag);
  if (needsAuthRecovery) e.auth();
  e.input('[name=title]', '未提交重试期间的新标题'); e.input('[name=summary]', '较新摘要'); e.changeBody(body('较新正文'));
  e.click('#draft-reconcile'); await flush(); assert.equal(e.disabled('#draft-keep-local'), false); assert.equal(e.disabled('#article-publish-retry'), true);
  e.click('#draft-keep-local'); await flush(); assert.equal(e.putCalls.length, 0); assert.equal(e.disabled('#article-publish-retry'), false);
  e.click('#article-publish-retry'); await flush(); assert.equal(e.publishCalls.length, 2);
  const replay = e.publishCalls[1]; assert.equal(replay.options.headers['Idempotency-Key'], original.options.headers['Idempotency-Key']); assert.equal(replay.options.headers['If-Match'], aTag); assert.equal(replay.options.body, original.options.body);
  assert.equal(e.state, 'dirty'); assert.equal(e.serverArticle.published.title, baseDraft.title); assert.equal(e.value('[name=title]'), '未提交重试期间的新标题'); assert.deepEqual(e.content, body('较新正文'));
  await e.tick(1500); assert.equal(e.putCalls.length, 1); assert.equal(e.putCalls[0].options.headers['If-Match'], `"d-${id}-2"`);
  const saved = JSON.parse(e.putCalls[0].options.body); assert.equal(saved.title, '未提交重试期间的新标题'); assert.equal(saved.summary, '较新摘要'); assert.deepEqual(saved.contentJson, body('较新正文'));
  assert.equal(e.state, 'saved'); assert.match(e.publicationText, /尚未发布的修改/); assert.equal(e.beforeUnload(), false);
});
await check('Known newer server versions after unknown publication are never overwritten by its older replay result', async track => {
  let first = true;
  const e = track(environment({ override: (path, options, server) => { if (path.endsWith('/publish') && first) { first = false; server.commitPublication(options); return Promise.reject(new Error('lost')); } } })); await flush(); await publishClick(e); e.auth(); e.serverDraft = { ...e.serverDraft, title: '其他地方新稿', draftVersion: 3, draftEtag: `"d-${id}-3"`, contentHash: 'external-new' }; e.click('#draft-reconcile'); await flush(); e.click('#draft-keep-local'); await flush(); e.click('#article-publish-retry'); await flush(); assert.equal(e.state, 'conflict'); assert.equal(e.putCalls.length, 0); assert.equal(e.value('[name=title]'), baseDraft.title); await e.tick(60000); assert.equal(e.putCalls.length, 0);
});
for (const field of ['draftVersion', 'draftEtag', 'articleEtag', 'contentHash', 'url', 'header']) await check(`Unconfirmed publication ${field} is kept unknown with retry identity intact`, async track => {
  const e = track(environment({ override: (path, options, server) => { if (path.endsWith('/publish')) { const result = server.commitPublication(options); if (field !== 'header') result[field] = 'invalid'; return { ...response(result), headers: { get: () => field === 'header' ? '"wrong"' : null } }; } } })); await flush(); await publishClick(e); assert.equal(e.state, 'unknown'); assert.equal(e.beforeUnload(), true); assert.equal(e.editorReplacements, 0); assert.equal(e.disabled('#article-publish-retry'), false);
});
await check('Pagehide during publish JSON does not change fields, continue saving, or accept the late metadata', async track => {
  const gate = deferred(); let result;
  const e = track(environment({ override: (path, options, server) => path.endsWith('/publish') ? (result = server.commitPublication(options), { ok: true, status: 200, json: () => gate.promise }) : undefined })); await flush(); await publishClick(e); e.input('[name=title]', '离开前新稿'); e.w.dispatchEvent(new e.w.Event('pagehide')); gate.resolve(result); await flush(); assert.equal(e.value('[name=title]'), '离开前新稿'); assert.equal(e.putCalls.length, 0); assert.equal(e.editorReplacements, 0); assert.equal(e.destroyed, 1);
});
await check('Published-summary hash distinguishes already published content from saved newer changes on reload', async track => {
  const e = track(environment({ article: { ...baseArticle, state: 'Published', published: { revisionId: '44444444-4444-4444-8444-444444444444', revisionNo: 1, title: '线上旧稿', contentHash: 'old-hash' } } })); await flush(); assert.match(e.publicationText, /尚未发布的修改.*old-hash/); assert.equal(e.w.document.querySelector('#article-publish').textContent, '发布更新');
});
await check('Read-only article ignores synthetic publication and column change events', async track => {
  const e = track(environment({ editable: false })); await flush(); e.w.document.querySelector('#article-publish').dispatchEvent(new e.w.Event('click', { bubbles: true })); e.choose(''); await e.tick(60000); assert.equal(e.putCalls.length, 0); assert.equal(e.publishCalls.length, 0);
});
for (const rejection of [401, 403, 429]) await check(`Unknown publication replay HTTP ${rejection} retains its original operation through recovery`, async track => {
  let count = 0;
  const e = track(environment({ override: (path, options, server) => {
    if (path.endsWith('/publish')) { count++; if (count === 1) { server.commitPublication(options); return Promise.reject(new Error('commit result lost')); } if (count === 2) return response({}, rejection); }
  } })); await flush(); await publishClick(e); const original = e.publishCalls[0]; e.click('#article-publish-retry'); await flush();
  assert.equal(e.beforeUnload(), true); assert.equal(e.disabled('#article-publish'), true); e.input('[name=title]', '重试拒绝后输入'); e.submit(); await e.tick(10000); assert.equal(e.putCalls.length, 0);
  if (rejection !== 429) { assert.equal(e.state, 'auth'); assert.equal(e.disabled('#article-publish-retry'), true); e.click('#draft-reconcile'); await flush(); e.click('#draft-keep-local'); await flush(); }
  else assert.equal(e.state, 'unknown');
  e.click('#article-publish-retry'); await flush(); assert.equal(e.publishCalls.length, 3); const latest = e.publishCalls[2]; assert.equal(latest.options.body, original.options.body); assert.equal(latest.options.headers['Idempotency-Key'], original.options.headers['Idempotency-Key']); assert.equal(latest.options.headers['If-Match'], original.options.headers['If-Match']); assert.equal(e.value('[name=title]'), '重试拒绝后输入'); await e.tick(1500); assert.equal(e.putCalls.length, 1);
});
await check('Slug input is read-only while publication is pending and frozen permanently on first success', async track => {
  const pending = deferred(); let result;
  const e = track(environment({ override: (path, options, server) => path.endsWith('/publish') ? (result = server.commitPublication(options), pending.promise) : undefined })); await flush(); assert.equal(e.w.document.querySelector('[name=slug]').readOnly, false); await publishClick(e); assert.equal(e.w.document.querySelector('[name=slug]').readOnly, true); assert.equal(e.w.document.querySelector('[name=title]').readOnly, false); pending.resolve(response(result)); await flush(); assert.equal(e.disabled('[name=slug]'), true);
});
await check('Missing CSRF context never marks an unsent publication as an unknown committed operation', async track => {
  let invalid = true;
  const e = track(environment({ override: path => path.endsWith('/bootstrap') && invalid ? response({}) : undefined })); await flush(); await publishClick(e); assert.equal(e.state, 'auth'); assert.equal(e.publishCalls.length, 0); assert.equal(e.w.document.querySelector('#article-publish-retry').hidden, true);
  invalid = false; e.input('[name=title]', '重登后新稿'); e.click('#draft-reconcile'); await flush(); e.click('#draft-keep-local'); await flush(); assert.equal(e.putCalls.length, 1); assert.equal(e.publishCalls.length, 0); await publishClick(e); assert.equal(JSON.parse(e.publishCalls[0].options.body).expectedDraftVersion, 2);
});
await check('An unexpected AbortError before page disposal is an uncertain publication and retains replay identity', async track => {
  const e = track(environment({ override: path => path.endsWith('/publish') ? Promise.reject(Object.assign(new Error('transport aborted'), { name: 'AbortError' })) : undefined })); await flush(); await publishClick(e); assert.equal(e.state, 'unknown'); assert.equal(e.beforeUnload(), true); assert.equal(e.disabled('#article-publish-retry'), false); await e.tick(60000); assert.equal(e.publishCalls.length, 1);
});
for (const rejection of [401, 403, 429, 400]) await check(`Unknown publication survives retry bootstrap HTTP ${rejection} without clearing its identity or resuming autosave`, async track => {
  let boot = 0, writes = 0;
  const e = track(environment({ override: (path, options, server) => {
    if (path.endsWith('/bootstrap') && ++boot === 2) return response({}, rejection);
    if (path.endsWith('/publish') && ++writes === 1) { server.commitPublication(options); return Promise.reject(new Error('lost result')); }
  } })); await flush(); await publishClick(e); const original = e.publishCalls[0]; e.click('#article-publish-retry'); await flush(); e.input('[name=title]', '防伪重试失败保留'); e.submit(); await e.tick(10000); assert.equal(e.putCalls.length, 0); assert.equal(e.beforeUnload(), true);
  if ([401, 403].includes(rejection)) { assert.equal(e.state, 'auth'); e.click('#draft-reconcile'); await flush(); e.click('#draft-keep-local'); await flush(); } else assert.equal(e.state, 'unknown');
  e.click('#article-publish-retry'); await flush(); assert.equal(e.publishCalls.length, 2); assert.equal(e.publishCalls[1].options.headers['Idempotency-Key'], original.options.headers['Idempotency-Key']); assert.equal(e.publishCalls[1].options.body, original.options.body);
});
await check('Actual shipped Tiptap publication keeps caret, nonempty selection and newer body; subsequent autosave uses post-publish ETag', async track => {
  let pending = null, result;
  const e = track(environment({ actualEditor: true, override: (path, options, server) => {
    if (path.endsWith('/publish')) { result = server.commitPublication(options); if (pending) return { ok: true, status: 200, json: () => pending.promise }; }
  } }));
  for (let i = 0; i < 20 && !e.w.document.querySelector('.tiptap'); i++) { await new Promise(resolve => setTimeout(resolve, 5)); await flush(); }
  const editor = e.w.document.querySelector('.tiptap').editor; assert.ok(editor); await flush();
  for (const selection of [{ from: 2, to: 2 }, { from: 1, to: 3 }]) {
    pending = deferred(); await publishClick(e); editor.commands.setTextSelection(selection); pending.resolve(result); await flush();
    assert.equal(editor.state.selection.from, selection.from); assert.equal(editor.state.selection.to, selection.to); assert.equal(e.editorReplacements, 0); assert.equal(e.state, 'published');
  }
  pending = deferred(); await publishClick(e); const prePublicationSaves = e.putCalls.length;
  editor.commands.selectAll(); editor.commands.insertContent('发布等待时新增真实正文'); editor.commands.setTextSelection(4); await e.tick(1500);
  assert.equal(e.putCalls.length, prePublicationSaves); const afterPublishTag = result.draftEtag; pending.resolve(result); await flush();
  assert.equal(e.putCalls.length, prePublicationSaves + 1); assert.equal(e.putCalls.at(-1).options.headers['If-Match'], afterPublishTag); assert.equal(editor.getText(), '发布等待时新增真实正文'); assert.equal(editor.state.selection.from, 4); assert.equal(editor.state.selection.to, 4); assert.equal(e.editorReplacements, 0); assert.match(e.publicationText, /尚未发布的修改/);
});
mkdirSync('artifacts/f15', { recursive: true });
const failed = results.filter(result => result.status === 'failed').length;
writeFileSync('artifacts/f15/admin-publication-results.json', JSON.stringify({ scope: 'Actual shipped articles controller in JSDOM with deterministic HTTP, clock, media, clipboard, download, and navigation stubs; Controller checks use an editor stub; the final integration check uses the unchanged shipped Tiptap bundle. No native browser, network server, PostgreSQL, or genuine IME proof.', total: results.length, failed, checks: results }, null, 2));
console.log(`F15 editor publication simulation checks: ${results.length - failed}/${results.length} passed.`);
if (failed) process.exitCode = 1;
