"""Exact F24 accessibility deltas; unknown modifications fail preservation."""
import hashlib
import json
import subprocess
from pathlib import Path

BASE = '8c7ef09de1efcc790298774ad4ba11436e944157'
PATCHES = json.loads(Path('docs/development/f24/home-accessibility-patches.json').read_text())
assert PATCHES['baselineCommit'] == BASE
BY_PATH = {item['path']: item for item in PATCHES['files']}
assert len(BY_PATH) == 3


def normalize_about(path, actual):
    item = BY_PATH.get(path)
    if item is None:
        return actual
    baseline = subprocess.check_output(['git', 'show', BASE + ':' + path])
    assert hashlib.sha256(baseline).hexdigest() == item['beforeSha256']
    result = actual
    for hunk in reversed(item['hunks']):
        before, after = hunk['before'].encode(), hunk['after'].encode()
        assert after and result.count(after) == 1, 'Unexpected ABOUT accessibility block: ' + path
        result = result.replace(after, before, 1)
    assert result == baseline, 'ABOUT changed outside exact accessibility blocks: ' + path
    return result


def verify_negative_controls():
    probes = [
        ('src/Blog.Web/wwwroot/js/home/about-stage.js', b'/2100', b'/100'),
        ('src/Blog.Web/wwwroot/js/home/about-stage.js', b'>=.25', b'>=.05'),
        ('src/Blog.Web/wwwroot/js/home/about-stage.js', b'disposed||!visible', b'!visible'),
        ('src/Blog.Web/Pages/Shared/Home/_About.cshtml', b'ABOUT ME', b'UNAPPROVED TITLE'),
        ('src/Blog.Web/wwwroot/css/home/about-stage.css', b'@keyframes about-drift', b'@keyframes unapprovedFloat'),
    ]
    for path, needle, change in probes:
        actual = Path(path).read_bytes()
        assert needle in actual, 'Negative control no longer exercises the real source'
        modified = actual.replace(needle, change, 1)
        try:
            normalize_about(path, modified)
        except AssertionError:
            continue
        raise AssertionError('ABOUT mutation escaped preservation: ' + path)
    return len(probes)
