# F13 media library and editor contract

This gate adds component-level media selection and upload UI. It does not implement publication, media deletion, production deployment, or PostgreSQL integration evidence.

## Administrative API

- `GET /api/admin/v1/media` accepts only `kind`, `state`, `q`, `page`, `pageSize`, once each. Kind is Image or Video; state is a defined exact enum name. Page defaults to 1; size defaults to 20 and is capped at 100. Query searches alt, credit and license text, not original filenames. Sorting is server-owned creation time descending then id ascending. Default excludes Purged.
- List items and `GET /api/admin/v1/media/{id}` use `{id,state,errorCode,version,metadata}`. Metadata includes kind, MIME, byte size, trusted dimensions/duration and default alt/credit/source/license fields. No storage path, uploader identity, filename or hashes are returned.
- `PATCH /api/admin/v1/media/{id}` requires the exact five default fields: altText, credit, sourceUrl, licenseName, licenseUrl. Missing If-Match is 428, valid stale version 412. Auth, CSRF, maintenance, Ready state, scalar/NFC limits and HTTPS checks apply. The transaction locks the media row and commits the new version and audit together. A no-op retains its version. Existing article, gallery and column snapshots remain unchanged.

## Upload controller

The UI permits one active transfer per page, within the server-wide maximum of two receivers. Client limits are generated from ContentLimits.cs. Files are JPEG, PNG, WebP or MP4 only. The browser computes SHA-256 over original bytes. An empty browser MIME may be derived from an allowed extension; nonempty mismatches are rejected. The server still scans, decodes and validates the actual bytes.

Every attempt obtains an authenticated session bootstrap and fresh CSRF token. Multipart order is sha256, byteSize, then one file, with one UUID idempotency key. XHR exposes progress and cancellation. A 202 means Processing; only a validated Ready status invokes the library callback, which performs another authenticated read before insertion. No upload automatically mutates the article.

Unknown network, timeout, cancellation or ambiguous server outcomes keep the same file fingerprint and key. Retrying requires the same name/type/size/content. Only a confirmed terminal rejection permits an explicit fresh-key retry. Known jobs can resume from their ID; an arbitrary library row cannot prove an unknown POST succeeded. Cancelling stops client transport or polling, not already accepted server work.

A bounded per-tab sessionStorage recovery record contains the upload manifest/key or known job ID, never credentials or file bytes. Recovery is bound to the authenticated administrator UUID; retrying an unknown upload as another account is refused before transmission. Reload requires reselecting the exact file for an unknown request; known job IDs can be polled. Storage failure is visible and leaves current-memory state intact. The 24-hour window starts at first transmission. Expired/corrupt records fail closed; an explicit confirmation may discard only local recovery after checking the library, warning that another upload could duplicate server data. No server files are deleted.

Polling pauses offscreen/offline. Visibility/online recovery resumes only those environmental pauses. Authentication errors, missing/failed status reads, explicit cancellation and restored records require explicit recovery. Destroy aborts requests and clears timers. Already accepted server processing may continue.

## Media snapshots and editor input

`/admin/media` offers authenticated upload and default metadata editing. Article editing embeds the same library with image/video insertion and optional cover selection. The panel rechecks Ready and expected kind for the body/cover asset and every manually selected poster. Remote image/video URLs, iframe, audio and attachments are not insertion inputs.

Images store alt, caption and the approved displayMeta snapshot. Videos store mediaId, optional Image posterMediaId and caption. Cover metadata is a snapshot. Default metadata changes do not rewrite these snapshots. Standalone defaults have no caption field; caption belongs to each article use. Changed caption/poster remains pending until applied. NFC payload normalization does not falsely leave unchanged decomposed input dirty or overwrite newer input.

The editor inserts into the live selection, not a captured upload-start range, and rejects code/table selections. One insertion emits one normal update to the existing autosave queue. A safe trailing caret prevents consecutive media insertions from replacing one another. Selected-media editing requires a current image/video NodeSelection with matching kind and media ID; moved selections are refused without touching text. All candidate documents pass the existing schema before mutation. Previews use only protected `/media/{UUID}` URLs; videos have controls, metadata preload and no autoplay.

Media UI errors and 412 conflicts retain input. Late requests after destruction cannot insert, PATCH or trigger an authentication flow. Article auth expiry uses F10's existing hard pause and explicit recovery; media completion cannot silently unlock it. Pending media work warns before leaving and blocks automatic preview navigation, while unrelated text can continue autosaving.

## Evidence boundaries

TestServer uses actual HTTP routing, cookie/CSRF boundaries and explicit fake persistence. SQL translation is inspected with a closed connection. JSDOM runs actual editor bundles and UI modules, with controlled HTTP/XHR/clock/storage fixtures. None proves native browser file dialogs, video playback, IME, touch or visual layout. Real PostgreSQL row locks, concurrent transactions, persistence and recovery remain pending. F12's additional static-normalization dynamic probe remains blocked; no retry is included here. F15/F21 must enrich published media dimensions from trusted metadata and verify production reference behavior.
