namespace Blog.Web.Application;
public sealed record DesignImage(string Src, string Alt, string Title, string Author, string Provider, string Source, string License, string LicenseUrl,
    int Width = 1240, int Height = 800);
