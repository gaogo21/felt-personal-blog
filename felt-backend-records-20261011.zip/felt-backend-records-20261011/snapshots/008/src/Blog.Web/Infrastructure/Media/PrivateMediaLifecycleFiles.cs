using System.Security.Cryptography;
using System.Text.RegularExpressions;
using Blog.Web.Application.Media;
using Blog.Web.Infrastructure.Persistence;

namespace Blog.Web.Infrastructure.Media;

// The lifecycle store holds the media row lock and validates its current lease before calling
// this adapter. Storage keys are immutable, unique and never reused or overwritten by the app.
// This adapter verifies that exact private object; it never derives a path from a filename.
public sealed class PrivateMediaLifecycleFiles(PrivateMediaStorage storage, IPrivateFileDurability durability) : IMediaLifecycleFiles
{
    private static readonly IReadOnlyDictionary<Guid, DesignSeedAsset> Seeds = DesignSeedCatalog.Load().ToDictionary(x => x.Id);

    public async Task<bool> VerifyAsync(MediaFileIdentity identity, CancellationToken ct)
    {
        var path = Resolve(identity);
        try
        {
            await using var file = Open(path);
            return await Matches(file, identity, ct);
        }
        catch (FileNotFoundException) { return false; }
        catch (DirectoryNotFoundException) { return false; }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException)
        { throw new MediaLifecycleFileFailure("MEDIA_STORAGE_UNAVAILABLE", true); }
        catch (InvalidOperationException) { throw new MediaLifecycleFileFailure("MEDIA_FILE_INVALID", false); }
    }

    public async Task DeleteExactAsync(MediaFileIdentity identity, CancellationToken ct)
    {
        var path = Resolve(identity);
        try
        {
            bool exists;
            try
            {
                await using var file = Open(path);
                if (!await Matches(file, identity, ct)) throw new MediaLifecycleFileFailure("MEDIA_FILE_CHANGED", false);
                exists = true;
            }
            catch (FileNotFoundException) { exists = false; }
            catch (DirectoryNotFoundException) { exists = false; }
            ct.ThrowIfCancellationRequested();
            if (exists)
            {
                PrivateMediaStorage.NoLinks(path);
                durability.DeleteFile(path);
            }
            // Even a retry that finds the file absent must synchronize the directory entry.
            // Do not interrupt between unlink and fsync, or mark the database job complete first.
            var parent = Path.GetDirectoryName(path)!;
            while (true)
            {
                PrivateMediaStorage.NoLinks(parent);
                try
                {
                    if ((File.GetAttributes(parent) & FileAttributes.Directory) == 0) throw new IOException("MEDIA_PARENT_UNAVAILABLE");
                    break;
                }
                catch (Exception error) when (error is FileNotFoundException or DirectoryNotFoundException)
                { parent = Path.GetDirectoryName(parent) ?? throw new IOException("MEDIA_PARENT_UNAVAILABLE"); }
            }
            PrivateMediaStorage.NoLinks(parent);
            durability.SyncDirectory(parent);
        }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException)
        { throw new MediaLifecycleFileFailure("MEDIA_STORAGE_UNAVAILABLE", true); }
        catch (InvalidOperationException) { throw new MediaLifecycleFileFailure("MEDIA_FILE_INVALID", false); }
    }

    private string Resolve(MediaFileIdentity identity)
    {
        if (identity.MediaId == Guid.Empty || identity.ByteSize <= 0 || identity.Sha256 is null
            || !Regex.IsMatch(identity.Sha256, "\\A[a-f0-9]{64}\\z") || identity.StorageKey is null)
            throw new MediaLifecycleFileFailure("MEDIA_FILE_INVALID", false);
        try
        {
            if (identity.StorageKey.StartsWith("design-v1/", StringComparison.Ordinal))
            {
                if (!Seeds.TryGetValue(identity.MediaId, out var seed) || identity.StorageKey != seed.StorageKey
                    || identity.ByteSize != seed.ByteSize || identity.Sha256 != seed.Sha256)
                    throw new MediaLifecycleFileFailure("MEDIA_FILE_INVALID", false);
                var path = Path.Combine(storage.Root, seed.StorageKey);
                PrivateMediaStorage.NoLinks(path);
                return path;
            }
            if (!Regex.IsMatch(identity.StorageKey, "\\Aobjects/" + identity.MediaId.ToString("N") + "-[a-f0-9]{32}\\.(jpg|png|webp|mp4)\\z"))
                throw new MediaLifecycleFileFailure("MEDIA_FILE_INVALID", false);
            return storage.Resolve(identity.StorageKey);
        }
        catch (InvalidOperationException)
        { throw new MediaLifecycleFileFailure("MEDIA_FILE_INVALID", false); }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException)
        { throw new MediaLifecycleFileFailure("MEDIA_STORAGE_UNAVAILABLE", true); }
    }

    private static FileStream Open(string path)
    {
        PrivateMediaStorage.NoLinks(path);
        return new(path, FileMode.Open, FileAccess.Read, FileShare.Read, 65536, FileOptions.Asynchronous | FileOptions.SequentialScan);
    }

    private static async Task<bool> Matches(FileStream file, MediaFileIdentity identity, CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        if (file.Length != identity.ByteSize) return false;
        var digest = Convert.ToHexStringLower(await SHA256.HashDataAsync(file, ct));
        return file.Length == identity.ByteSize && digest == identity.Sha256;
    }
}
