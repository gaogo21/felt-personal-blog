using System.Text;
using Blog.Web.Infrastructure.Media;
using Blog.Web.Infrastructure.Operations;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Blog.StaticCompressionTests;

internal sealed class CompressionFixture : IAsyncDisposable
{
    public static readonly (string Path, string Mime)[] Assets =
    [
        ("/css/navigation.css", "text/css"),
        ("/js/navigation/legacy-resolver.js", "text/javascript"),
        ("/assets/fonts/anton.ttf", "application/x-font-ttf")
    ];
    public static readonly (string Path, string Mime, byte[] Bytes)[] Excluded =
    [
        ("/fixture.html", "text/html", Encoding.UTF8.GetBytes("<!doctype html><p>Private fixture token</p>")),
        ("/fixture.json", "application/json", Encoding.UTF8.GetBytes("{\"fixture\":\"private\"}")),
        ("/fixture.png", "image/png", [137, 80, 78, 71, 13, 10, 26, 10, 0, 0, 0, 0]),
        ("/fixture.mp4", "video/mp4", [0, 0, 0, 20, 102, 116, 121, 112, 105, 115, 111, 109, 0, 0, 0, 0])
    ];
    public static readonly (string Path, string Mime, string Body)[] Dynamic =
    [
        ("/", "text/html; charset=utf-8", "<!doctype html><p>Dynamic private page</p>"),
        ("/api/admin/fixture", "application/json; charset=utf-8", "{\"private\":\"fixture\"}"),
        ("/dynamic.css", "text/css", "body { --private-fixture: 42; }"),
        ("/dynamic.js", "text/javascript", "const privateFixture = 42;")
    ];

    private readonly string root;
    private readonly bool compression;
    private readonly bool optIn;
    private IHost? host;
    private PhysicalFileProvider? files;
    public Dictionary<string, byte[]> SourceBytes { get; } = new(StringComparer.Ordinal);
    public HttpClient Client { get; private set; } = null!;
    public int DownstreamCalls { get; private set; }

    public CompressionFixture(string repositoryRoot, string artifactRoot, bool compression = true, bool optIn = true)
    {
        this.compression = compression;
        this.optIn = optIn;
        root = Path.Combine(artifactRoot, "http-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        foreach (var asset in Assets)
        {
            var bytes = File.ReadAllBytes(Path.Combine(repositoryRoot, "src/Blog.Web/wwwroot", asset.Path[1..]));
            Write(asset.Path, bytes);
        }
        foreach (var fixture in Excluded) Write(fixture.Path, fixture.Bytes);
    }

    private void Write(string path, byte[] bytes)
    {
        var target = Path.Combine(root, path[1..]);
        Directory.CreateDirectory(Path.GetDirectoryName(target)!);
        File.WriteAllBytes(target, bytes);
        SourceBytes.Add(path, bytes);
    }

    public async Task StartAsync()
    {
        files = new PhysicalFileProvider(root);
        host = new HostBuilder().ConfigureLogging(logging => logging.ClearProviders())
            .ConfigureWebHost(web => web.UseEnvironment("ComponentTests").UseTestServer()
                .ConfigureServices(services => services.AddStaticAssetCompression())
                .Configure(app =>
                {
                    if (compression) app.UseStaticAssetCompression();
                    app.UseStaticFiles(new StaticFileOptions
                    {
                        FileProvider = new ProtectedStaticFiles(files),
                        OnPrepareResponse = file =>
                        {
                            file.Context.Response.Headers.CacheControl = "public, max-age=60";
                            file.Context.Response.Headers.Vary = "Origin";
                            if (optIn && compression) StaticAssetCompression.PrepareResponse(file);
                        }
                    });
                    app.Use(async (context, next) =>
                    {
                        // Stands in for the existing later no-store/session/auth
                        // boundary. Static assets must never reach it.
                        DownstreamCalls++;
                        context.Response.Headers.CacheControl = "private, no-store";
                        context.Response.Headers.Vary = "Origin";
                        await next(context);
                    });
                    app.Run(async context =>
                    {
                        var fixture = Dynamic.FirstOrDefault(item => item.Path == context.Request.Path);
                        if (fixture.Path is null) { context.Response.StatusCode = 404; return; }
                        var bytes = Encoding.UTF8.GetBytes(fixture.Body);
                        context.Response.ContentType = fixture.Mime;
                        context.Response.ContentLength = bytes.Length;
                        if (!HttpMethods.IsHead(context.Request.Method)) await context.Response.Body.WriteAsync(bytes);
                    });
                })).Build();
        await host.StartAsync();
        if (host.GetTestServer() is not TestServer) throw new InvalidOperationException("In-process TestServer required");
        Client = host.GetTestClient();
        Client.BaseAddress = new Uri("https://static-compression-fixture.invalid");
    }

    public Task<HttpResponseMessage> SendAsync(string path, string? acceptEncoding = null, HttpMethod? method = null,
        params (string Name, string Value)[] headers)
    {
        var request = new HttpRequestMessage(method ?? HttpMethod.Get, path);
        if (acceptEncoding is not null) request.Headers.TryAddWithoutValidation("Accept-Encoding", acceptEncoding);
        foreach (var (name, value) in headers) request.Headers.TryAddWithoutValidation(name, value);
        return Client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead);
    }

    public async ValueTask DisposeAsync()
    {
        Client?.Dispose();
        if (host is not null) { await host.StopAsync(); host.Dispose(); }
        files?.Dispose();
        Directory.Delete(root, recursive: true);
    }
}
