using Blog.Web.Infrastructure.Backup;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Blog.Web.Infrastructure.Operations;

public static class OperationsHealthHosting
{
    public static IServiceCollection AddOperationsHealth(this IServiceCollection services)
    {
        services.TryAddSingleton(TimeProvider.System);
        services.TryAddSingleton(_ => ReleaseCompatibility.ReadEmbedded());
        services.TryAddSingleton<IBackupKeyValidator, BackupKeyValidator>();
        services.TryAddSingleton<IReadinessDatabase, PostgresReadinessDatabase>();
        services.TryAddSingleton<IReadinessPrivateStorage, ReadinessPrivateStorage>();
        services.TryAddScoped<IOperationsReadinessDependencies, OperationsReadinessDependencies>();
        services.TryAddSingleton<IOperationsReadiness, OperationsReadiness>();
        return services;
    }
}
