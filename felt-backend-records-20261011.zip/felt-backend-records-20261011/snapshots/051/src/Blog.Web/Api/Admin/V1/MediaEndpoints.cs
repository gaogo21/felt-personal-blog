using System.Text;
using Blog.Web.Application.Administration;
using Blog.Web.Application.Media;
using Blog.Web.Application.Security;
using Blog.Web.Domain;
using Blog.Web.Infrastructure.Administration;
using Blog.Web.Infrastructure.Media;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Net.Http.Headers;

namespace Blog.Web.Api.Admin.V1;
public sealed class StreamingUploadMarker;
public sealed class UploadSlots { public SemaphoreSlim Slots { get; } = new(ContentLimits.ConcurrentUploads); }
public static class MediaEndpoints
{
    public static void MapAdminMediaEndpoints(this WebApplication app)
    {
        var group = app.MapGroup("/api/admin/v1/media").RequireAuthorization(AdminSecurityService.Policy);
        group.MapGet("/{id:guid}", async (Guid id, HttpContext context, MediaUploadService service) =>
        {
            if (context.Request.Query.Count != 0) throw new ApiFailure(ProblemCode.MALFORMED_REQUEST);
            var result = await service.ReadAsync(id, context.RequestAborted); context.Response.Headers.ETag = new EntityVersion(ResourceKind.Media, id, result.Version).ETag;
            return Results.Json(result);
        });
        group.MapPost("/uploads", Upload).WithMetadata(new StreamingUploadMarker());
    }
    private static async Task Upload(HttpContext context, MediaUploadService service, PrivateMediaStorage files, UploadSlots slots)
    {
        if (!await slots.Slots.WaitAsync(0, context.RequestAborted)) { context.Response.Headers.RetryAfter = "5"; throw new ApiFailure(ProblemCode.RATE_LIMITED); }
        UploadAdmission? admission = null; var actor = AdminActor.From(context.User, context.TraceIdentifier);
        using var budget = CancellationTokenSource.CreateLinkedTokenSource(context.RequestAborted); budget.CancelAfter(TimeSpan.FromSeconds(MediaStorageOptions.UploadTimeoutSeconds));
        try
        {
            if (context.Request.Query.Count != 0) throw new ApiFailure(ProblemCode.MALFORMED_REQUEST);
            var key = IdempotencyKey.Require(context.Request.Headers["Idempotency-Key"]);
            if (context.Request.ContentLength > ContentLimits.ProxyRequestBytes) throw new ApiFailure(ProblemCode.REQUEST_TOO_LARGE);
            if (context.Features.Get<IHttpMaxRequestBodySizeFeature>() is { IsReadOnly: false } limit) limit.MaxRequestBodySize = ContentLimits.ProxyRequestBytes;
            if (!MediaTypeHeaderValue.TryParse(context.Request.ContentType, out var type) || type.MediaType != "multipart/form-data") throw new ApiFailure(ProblemCode.MEDIA_TYPE_UNSUPPORTED);
            var boundary = HeaderUtilities.RemoveQuotes(type.Boundary).Value;
            if (string.IsNullOrWhiteSpace(boundary) || boundary.Length > 70) throw new ApiFailure(ProblemCode.MALFORMED_REQUEST);
            var bounded = new LimitedRequestStream(context.Request.Body, ContentLimits.ProxyRequestBytes);
            var reader = new MultipartReader(boundary, bounded) { HeadersCountLimit = 8, HeadersLengthLimit = 8192, BodyLengthLimit = ContentLimits.VideoBytes };
            var fields = new Dictionary<string, string>(StringComparer.Ordinal);
            MultipartSection? file = null; ContentDispositionHeaderValue? disposition = null;
            while ((file = await reader.ReadNextSectionAsync(budget.Token)) is not null)
            {
                if (!ContentDispositionHeaderValue.TryParse(file.ContentDisposition, out disposition) || disposition.DispositionType != "form-data") throw new ApiFailure(ProblemCode.MALFORMED_REQUEST);
                var name = HeaderUtilities.RemoveQuotes(disposition.Name).Value;
                if (disposition.FileName.HasValue || disposition.FileNameStar.HasValue)
                {
                    if (name != "file" || fields.Count != 2) throw new ApiFailure(ProblemCode.MALFORMED_REQUEST);
                    break;
                }
                if (name is not ("sha256" or "byteSize") || !fields.TryAdd(name, await SmallField(file.Body, budget.Token))) throw new ApiFailure(ProblemCode.MALFORMED_REQUEST);
            }
            if (file is null || disposition is null || !fields.ContainsKey("sha256") || !fields.ContainsKey("byteSize")) throw new ApiFailure(ProblemCode.MALFORMED_REQUEST);
            var fileName = HeaderUtilities.RemoveQuotes(disposition.FileNameStar.HasValue ? disposition.FileNameStar : disposition.FileName).Value ?? "";
            var manifest = UploadManifest.Parse(fileName, file.ContentType ?? "", fields["byteSize"], fields["sha256"]);
            admission = await service.BeginAsync(actor, key, manifest, budget.Token);
            await files.ReceiveAsync(file.Body, manifest, admission.Replay ? null : files.UploadPath(admission.MediaId, admission.Token), budget.Token).WaitAsync(budget.Token);
            if (await reader.ReadNextSectionAsync(budget.Token) is not null) throw new ApiFailure(ProblemCode.MALFORMED_REQUEST);
            await bounded.CopyToAsync(Stream.Null, budget.Token); // Count even a chunked MIME epilogue toward the request cap.
            var response = admission.Replay ? admission.Response! : await service.CompleteAsync(actor, admission, budget.Token);
            await AdminApiHosting.WriteMutation(context, response);
        }
        catch (Exception error) when (error is ApiFailure or InvalidDataException or DecoderFallbackException or OperationCanceledException or IOException or UnauthorizedAccessException)
        {
            var responseCode = error switch
            {
                ApiFailure known => known.Code,
                OperationCanceledException => ProblemCode.VALIDATION_FAILED,
                InvalidDataException or DecoderFallbackException => ProblemCode.MALFORMED_REQUEST,
                _ => ProblemCode.MEDIA_STORAGE_UNAVAILABLE
            };
            if (admission is { Replay: false })
            {
                using var cleanup = new CancellationTokenSource(TimeSpan.FromSeconds(10));
                var mediaCode = responseCode == ProblemCode.MEDIA_STORAGE_UNAVAILABLE ? "MEDIA_STORAGE_UNAVAILABLE"
                    : error is OperationCanceledException ? "MEDIA_UPLOAD_TIMEOUT" : "MEDIA_UPLOAD_INVALID";
                await service.FailAsync(actor, admission, mediaCode, cleanup.Token, responseCode);
                await service.CleanupRejectedAsync(actor, admission, cleanup.Token);
            }
            if (error is ApiFailure api && api.Code == ProblemCode.RATE_LIMITED) context.Response.Headers.RetryAfter = "5";
            if (error is ApiFailure) throw;
            if (error is OperationCanceledException && context.RequestAborted.IsCancellationRequested) throw;
            throw new ApiFailure(responseCode);
        }
        finally { slots.Slots.Release(); }
    }
    private static async Task<string> SmallField(Stream input, CancellationToken ct)
    {
        var bytes = new byte[129]; var size = 0;
        while (size < bytes.Length) { var read = await input.ReadAsync(bytes.AsMemory(size), ct); if (read == 0) break; size += read; }
        if (size > 128) throw new ApiFailure(ProblemCode.MALFORMED_REQUEST);
        return new UTF8Encoding(false, true).GetString(bytes, 0, size);
    }
    private sealed class LimitedRequestStream(Stream input, long limit) : Stream
    {
        private long count;
        private int Add(int size) { count = checked(count + size); if (count > limit) throw new ApiFailure(ProblemCode.REQUEST_TOO_LARGE); return size; }
        public override int Read(byte[] buffer, int offset, int count) => Add(input.Read(buffer, offset, count));
        public override async ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken ct = default) => Add(await input.ReadAsync(buffer, ct));
        public override Task<int> ReadAsync(byte[] buffer, int offset, int count, CancellationToken ct) => ReadAsync(buffer.AsMemory(offset, count), ct).AsTask();
        public override bool CanRead => true; public override bool CanSeek => false; public override bool CanWrite => false; public override long Length => throw new NotSupportedException();
        public override long Position { get => count; set => throw new NotSupportedException(); } public override void Flush() => throw new NotSupportedException();
        public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException(); public override void SetLength(long value) => throw new NotSupportedException();
        public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
    }
}
