[
  {
    "original_path": "licenses/legacy-fonts/README.md",
    "original_line": 5,
    "exact_retained_line": "The cleanup manifest records original paths and SHA-256 values. These records do not add a blanket license to the site source or generated portraits."
  },
  {
    "original_path": "DEVELOPMENT.md",
    "original_line": 107,
    "exact_retained_line": "19 张获批图片、两个现用字体、来源与许可继续保留，详见 [资源说明](src/Blog.Web/wwwroot/assets/README.md)。当前源码不保留旧静态运行包或 `build-static.mjs`，历史审计材料和 Git 历史中的旧路径用于追溯，不构成第二个运行入口。`.openai/hosting.json` 仅保留既有静态 Site 的历史身份；其中 `dist` 路径不是 .NET 构建或部署配置，本轮不使用它发布。"
  },
  {
    "original_path": "eng/cleanup_contract.py",
    "original_line": 44,
    "exact_retained_line": "            assert name == '.openai/hosting.json', f'Unexpected retained baseline entry: {name}'"
  },
  {
    "original_path": "eng/check-f22-cleanup.py",
    "original_line": 67,
    "exact_retained_line": "check('Negative control: retained hosting identity changes are rejected', lambda: rejects_probe(changed={'.openai/hosting.json':b'changed'}))"
  },
  {
    "original_path": "eng/check-f22-cleanup.py",
    "original_line": 69,
    "exact_retained_line": "check('Negative control: approved portrait corruption remains rejected', lambda: rejects_probe(changed={'src/Blog.Web/wwwroot/assets/trio/felt-green-peace.png':b'changed'}))"
  },
  {
    "original_path": "eng/check-f22-cleanup.py",
    "original_line": 89,
    "exact_retained_line": "    check('Publish contains the actual production web assembly and configuration', lambda: require((publish/'Blog.Web.runtimeconfig.json').is_file() and (publish/'appsettings.json').is_file(), 'Incomplete publish artifact'))"
  },
  {
    "original_path": "docs/development/ADR-001-baseline-and-gates.md",
    "original_line": 9,
    "exact_retained_line": "现站原始提交 78207ed7d20514901da34cb59a94ebef947f580a；已公开 GitHub 提交 81eed0f397dfe7ca1a2fe66d6fa2418b2ed480c1。已实际 fetch 精确提交并比较 Git 对象，不只比较以前导出目录。dist、build-static.mjs、validate.mjs 全部字节相同。差异仅 README、GitHub新增 .gitignore/THIRD_PARTY_ASSETS.md、GitHub移除平台私有 .openai/hosting.json。"
  },
  {
    "original_path": "docs/development/f23/DELIVERY-READINESS.md",
    "original_line": 82,
    "exact_retained_line": "The tracked-tree scan inventory contains 1,376 files at the baseline. It scanned 1,339 UTF-8 text files totaling 21,777,308 bytes with a per-file 8 MiB ceiling and ten patterns for private-key/provider-token/JWT/credential-URI/literal-secret forms. The 37 excluded files were image/font binaries. Thirty-three broad-rule matches were confined to isolated fixture/invalid-URL inputs or code expressions; no actual-looking credential or private key was detected. No candidate value was printed or written to the report. See [tracked-secret-scan.json](tracked-secret-scan.json) for path/type-only results."
  },
  {
    "original_path": "docs/development/gate0/static-validation.txt",
    "original_line": 9,
    "exact_retained_line": "  \"hero\": \"approved green/pink/blue portraits, English title, 3000ms interval, no former model dependencies\","
  },
  {
    "original_path": "docs/development/gate0/source-diff.txt",
    "original_line": 2,
    "exact_retained_line": "D\t.openai/hosting.json"
  },
  {
    "original_path": "docs/development/f05/REPORT.md",
    "original_line": 17,
    "exact_retained_line": "`design-seed-v1.json` is an embedded whitelist of exactly 19 approved images: 3 portraits, 4 glass objects, 2 star fields and 10 gallery images. It records fixed UUIDs, filenames, byte sizes, dimensions, SHA256 and attribution. Total file size is 14,290,002 bytes. No old avatar, orange outfit, video, model, original user photograph, sample article or sample project is included."
  },
  {
    "original_path": "docs/development/f23/ACCEPTANCE-EVIDENCE.md",
    "original_line": 278,
    "exact_retained_line": "- PostgreSQL: Publish representative long Chinese, unbroken URL, table/code and portrait media through actual database-backed workflows."
  },
  {
    "original_path": "docs/development/f22/REPORT.md",
    "original_line": 11,
    "exact_retained_line": "Sixteen old-only binary assets have no reference in current production source: sample covers/portrait, sample video/poster and nine unused Chinese/numeral font files. Their combined size is 12,063,665 bytes. The two small article fonts became unreferenced when their retired stylesheet was removed. The three historical font license texts remain byte-for-byte under licenses/legacy-fonts."
  },
  {
    "original_path": "docs/development/f22/REPORT.md",
    "original_line": 15,
    "exact_retained_line": "The .openai/hosting.json identity file is retained unchanged for historical Site continuity. Its old dist directory is explicitly documented as non-operative for the .NET build. No Site publication is attempted. Legacy fragment migration, the explicit mapping boundary and /about and /knowledge server aliases remain. Fixture content stays inside tests and is excluded from the production project and publish artifact."
  },
  {
    "original_path": "docs/development/f24/LICENSE-AUDIT.md",
    "original_line": 64,
    "exact_retained_line": "The approved set consists of three felt portraits, four glass illustrations, ten gallery visuals and two night-sky backgrounds. Every file has a per-file hash result in the JSON. Provenance remains in `wwwroot/assets/gallery/sources.json`, `gallery/CREDITS.txt`, `article-sky/credits.json`, and the design seed. Individual image source-page claims are historical repository evidence; this audit did not revisit all 12 source pages or independently establish releases for depicted subjects."
  },
  {
    "original_path": "docs/development/f24/ACCESSIBILITY-AUDIT.md",
    "original_line": 105,
    "exact_retained_line": "- **V10:** render representative long Chinese, uninterrupted URLs, tables, code and portrait media at 1440×900, 1280×720, 390×844, 360×640 and 844×390. Check page versus intended region scrolling, 200%/400% zoom, text-spacing overrides, controls/labels and the new ABOUT button for overlap/occlusion."
  },
  {
    "original_path": "tests/Blog.ComponentTests/Program.cs",
    "original_line": 97,
    "exact_retained_line": "    Assert(html.Contains(\"felt-pink-hoodie.png\")&&!html.Contains(\"felt-orange\"),\"Wrong approved portrait\");"
  },
  {
    "original_path": "docs/development/f26/REPORT.md",
    "original_line": 7,
    "exact_retained_line": "The shared embedded release compatibility contract names the complete reviewed migration history, supported rich-text schema versions, configuration version and runtime/database majors. Operational health uses the same contract. /health/live and /health/ready are read-only GET/HEAD paths before session-touch middleware; payloads expose only status. Readiness fails closed for incomplete configuration, LocalMock, active maintenance, inaccessible private storage/key material and mismatched or unavailable PostgreSQL observations. Actual PostgreSQL connections are never made in tests."
  },
  {
    "original_path": "docs/development/f26/REPORT.md",
    "original_line": 9,
    "exact_retained_line": "The local pack/verify utility produces an exact hashed release inventory from trusted reviewed publish output, requires absent destinations, rejects links, extra or missing files and embedded deployment secrets/configuration. It does not configure filesystem immutability or establish authenticity by hash alone. The read-only deployment planner requires declared compatibility, exclusivity, backup/recovery and authorization prerequisites but always returns canExecute=false. It has no switch, migration, database downgrade, restore or service execution command."
  },
  {
    "original_path": "docs/development/f26/REPORT.md",
    "original_line": 13,
    "exact_retained_line": "OPERATIONS.md gives the controlled code-only rollback procedure, compatibility failure/forward-fix behavior and required cross-process maintenance boundary. F25's runtime gate automatically reopens and is not represented as that lasting boundary. The systemd file is an uninstalled review-only template with placeholders. No proxy/TLS/systemd security setting or real credential is configured."
  },
  {
    "original_path": "docs/development/f26/REPORT.md",
    "original_line": 21,
    "exact_retained_line": "Real PG apply/query/backup/restore and concurrency remain blocked. Real systemd stop/start, process death, platform-specific permissions, TLS/proxy configuration, actual compatible build switch, isolated restore and retained new-content checks remain pending. No previous independently exercised production rollback target currently exists. The current local Debug publish artifact is not a deployment. S10 and all 36 overall cases remain unpassed; F12's denied extra probe is not retried."
  },
  {
    "original_path": "src/Blog.Web/Pages/Shared/Home/_Hero.cshtml",
    "original_line": 1,
    "exact_retained_line": "<section id=\"hero\" data-section=\"hero\" class=\"collectible-hero\" aria-labelledby=\"collectible-title\" data-current=\"green\" data-playback=\"loading\"><nav class=\"collectible-nav\" aria-label=\"Main navigation\"><a href=\"@SiteNavigation.Home\" aria-label=\"Always Curious 首页\">AC.</a><div><partial name=\"_NavigationLinks\" /></div></nav><h1 id=\"collectible-title\"><span>ALWAYS</span><span>CURIOUS.</span></h1><div class=\"collectible-crop\"><div class=\"collectible-stage\" tabindex=\"0\" role=\"group\" aria-label=\"Three felt portraits. Use left and right arrow keys to switch.\"><div class=\"collectible-parallax\"><figure class=\"collectible-figure\" data-look=\"green\" data-slot=\"center\"><img src=\"/assets/trio/felt-green-peace.png\" alt=\"Green felt outfit, arms raised in two peace signs\" width=\"1024\" height=\"1536\" fetchpriority=\"high\" draggable=\"false\"></figure><figure class=\"collectible-figure\" data-look=\"pink\" data-slot=\"right\"><img src=\"/assets/trio/felt-pink-hoodie.png\" alt=\"Pink felt hoodie, both arms raised\" width=\"1024\" height=\"1536\" fetchpriority=\"high\" draggable=\"false\"></figure><figure class=\"collectible-figure\" data-look=\"blue\" data-slot=\"left\"><img src=\"/assets/trio/felt-blue-pointing.png\" alt=\"Blue felt streetwear, one hand pointing forward\" width=\"1024\" height=\"1536\" fetchpriority=\"high\" draggable=\"false\"></figure></div></div></div><div class=\"collectible-bottom\"><a class=\"collectible-intro\" href=\"/articles\">A LITTLE CODE.<br>A LOT OF CURIOSITY.<span>READ MY NOTES →</span></a><div class=\"collectible-controls\" aria-label=\"Portrait carousel controls\"><div class=\"look-progress\" aria-label=\"Choose a portrait\"><button data-select=\"0\" aria-label=\"Show green outfit\" aria-pressed=\"true\"><span></span></button><button data-select=\"1\" aria-label=\"Show pink outfit\" aria-pressed=\"false\"><span></span></button><button data-select=\"2\" aria-label=\"Show blue outfit\" aria-pressed=\"false\"><span></span></button></div><div class=\"look-actions\"><span class=\"look-count\" aria-hidden=\"true\">01 / 03</span><button data-step=\"-1\" aria-label=\"Previous portrait\">←</button><button data-step=\"1\" aria-label=\"Next portrait\">→</button><button class=\"look-toggle\" aria-pressed=\"false\" aria-label=\"Pause automatic rotation\"><span aria-hidden=\"true\">||</span><span class=\"toggle-label\">PAUSE</span></button></div><span class=\"look-status\" aria-live=\"off\">THREE SIDES. ONE ME.</span></div></div><p class=\"collectible-error\" role=\"status\" hidden>Portraits are unavailable. You can still explore the notes below.</p></section>",
    "whole_file_eof_observed": false
  }
]
